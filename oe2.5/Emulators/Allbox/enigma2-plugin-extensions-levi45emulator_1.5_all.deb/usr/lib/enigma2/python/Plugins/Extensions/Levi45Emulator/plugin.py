# -*- coding: utf-8 -*-
from __future__ import print_function
import os
import sys
import re
from xml.dom import minidom
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.Console import Console
from Screens.ChoiceBox import ChoiceBox
from Components.config import config, ConfigSubsection, ConfigYesNo, configfile
from Plugins.Plugin import PluginDescriptor
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from Components.Label import Label
from enigma import getDesktop, gFont, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_VALIGN_CENTER
from twisted.web.client import getPage
from Components.Pixmap import Pixmap

BASE = 'https://raw.githubusercontent.com/levi-45/Levi45Emulator/main/'
VERSION = '1.5'

if not hasattr(config.plugins, 'levi45emulator'):
    config.plugins.levi45emulator = ConfigSubsection()
config.plugins.levi45emulator.show_in_mainmenu = ConfigYesNo(default=True)


# QR images are stored in the plugin's images/ directory.
IMAGES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'images')


def dreamos():
    # DreamOS uses dpkg/apt; avoid treating all Dreambox hardware as DreamOS.
    return os.path.exists('/usr/bin/dpkg') and (os.path.exists('/etc/apt/sources.list') or os.path.isdir('/etc/apt/sources.list.d'))


def feed():
    return BASE + ('Debmulator.xml' if dreamos() else 'emulator.xml')


def skin():
    try:
        w, h = getDesktop(0).size().width(), getDesktop(0).size().height()
    except Exception:
        w, h = 1280, 720
    # Enigma2 renders XML in actual desktop pixels. Scale for HD/FHD/WQHD.
    factor = min(float(w) / 1280.0, float(h) / 720.0)
    def box(x, y, width, height):
        return 'position="%d,%d" size="%d,%d"' % tuple(max(1, int(v * factor)) for v in (x, y, width, height))
    def font(size):
        return 'Regular;%d' % max(12, int(size * factor))
    return ('''<screen name="Levi45Emulator" position="center,center" size="%d,%d" title="Levi45 Emulator" backgroundColor="#101419" flags="wfNoBorder">
      <eLabel %s backgroundColor="#101419" zPosition="-1" />
      <eLabel %s backgroundColor="#30485C" />
      <widget name="heading" %s font="%s" foregroundColor="#C3CBD3" transparent="1" />
      <widget name="subtitle" %s font="%s" foregroundColor="#929FAA" transparent="1" />
      <eLabel %s backgroundColor="#29323B" />
      <widget name="list" %s itemHeight="%d" scrollbarMode="showOnDemand" transparent="0" foregroundColor="#C3CBD3" backgroundColor="#101419" foregroundColorSelected="#CCD2D8" backgroundColorSelected="#2B4358" />
      <widget name="kofi" %s alphatest="blend" />
      <widget name="paypal" %s alphatest="blend" />
      <widget name="status" %s font="%s" foregroundColor="#929FAA" transparent="1" />
      <eLabel %s backgroundColor="#141A20" />
      <eLabel %s backgroundColor="#70303A" />
      <widget name="redkey" %s font="%s" foregroundColor="#CCD2D8" transparent="1" zPosition="5" />
      <eLabel %s backgroundColor="#28543F" />
      <widget name="greenkey" %s font="%s" foregroundColor="#CCD2D8" transparent="1" zPosition="5" />
      <eLabel %s backgroundColor="#66572D" />
      <widget name="yellowkey" %s font="%s" foregroundColor="#D2CBB5" transparent="1" zPosition="5" />
      <eLabel %s backgroundColor="#2B4358" />
      <widget name="bluekey" %s font="%s" foregroundColor="#CCD2D8" transparent="1" zPosition="5" />
    </screen>''' % (int(1100*factor), int(630*factor),
        box(0,0,1100,630),box(0,0,1100,7),box(35,27,1020,53),font(37),
        box(36,88,1020,30),font(21),box(32,132,1036,2),
        box(38,151,1020,344),max(24,int(45*factor)),
        box(870,490,70,70),box(965,490,70,70),box(37,508,760,42),font(20),box(0,563,1100,67),
        box(27,579,218,40),box(48,580,200,35),font(22),
        box(295,579,218,40),box(316,580,200,35),font(22),
        box(558,579,218,40),box(579,580,200,35),font(22),
        box(820,579,250,40),box(841,580,230,35),font(22)))


def to_text(value):
    if isinstance(value, bytes):
        return value.decode('utf-8', 'replace')
    return value


def ui_text(value):
    # DreamOS Python 2 SWIG eLabel/eMessageBox bindings require UTF-8 bytes.
    # Python 3 bindings accept Unicode text.
    if sys.version_info[0] < 3:
        if isinstance(value, unicode):
            return value.encode('utf-8')
        return str(value)
    if isinstance(value, bytes):
        return value.decode('utf-8', 'replace')
    return str(value)


def menu_text(value):
    # DreamOS Python 2 eListboxPythonStringContent expects byte strings.
    # XML attributes from minidom are Unicode, which otherwise display
    # as <not-a-string> on some DreamOS images.
    if sys.version_info[0] < 3 and isinstance(value, unicode):
        return value.encode('utf-8')
    return value


def menu_items(values):
    return [menu_text(value) for value in values]


def parse_feed(data):
    doc = minidom.parseString(data)
    groups = []
    for node in doc.getElementsByTagName('plugins'):
        title = node.getAttribute('cont').strip()
        entries = []
        for item in node.getElementsByTagName('plugin'):
            name = item.getAttribute('name').strip()
            urls = item.getElementsByTagName('url')
            if not name or not urls or not urls[0].firstChild:
                continue
            url = to_text(urls[0].firstChild.data).strip()
            if url.startswith('https://') or url.startswith('http://'):
                entries.append((name, url))
        if title and entries:
            groups.append((title, entries))
    return groups


def install_command(url):
    # Shell quote for untrusted XML values; allow only package URLs.
    if not re.match(r'^https?://[^\s\x00-\x1f]+$', url, re.I):
        raise ValueError('Invalid package URL')
    if not url.lower().split('?')[0].endswith(('.ipk', '.deb')):
        raise ValueError('Only .ipk and .deb package URLs are supported')
    try:
        from shlex import quote
    except ImportError:
        from pipes import quote
    if dreamos():
        if not url.lower().split('?')[0].endswith('.deb'):
            raise ValueError('DreamOS requires a .deb package')
        return 'wget -O /tmp/levi45-emulator.deb %s && dpkg -i --install --force-depends --force-overwrite /tmp/levi45-emulator.deb; rc=$?; rm -f /tmp/levi45-emulator.deb; exit $rc' % quote(url)
    if not url.lower().split('?')[0].endswith('.ipk'):
        raise ValueError('This Enigma2 image requires an .ipk package')
    return 'wget -O /tmp/levi45-emulator.ipk %s && opkg install --force-reinstall --force-overwrite --force-downgrade /tmp/levi45-emulator.ipk; rc=$?; rm -f /tmp/levi45-emulator.ipk; exit $rc' % quote(url)


class ReadableMenuList(MenuList):
    """Use multi-content rows, whose content object supports explicit fonts."""
    def __init__(self):
        try:
            desktop = getDesktop(0).size()
            scale = min(float(desktop.width()) / 1280.0,
                        float(desktop.height()) / 720.0)
        except Exception:
            scale = 1.0
        self.row_height = max(24, int(45 * scale))
        self.row_width = max(1, int(990 * scale))
        self.row_padding = max(1, int(12 * scale))
        MenuList.__init__(self, [], content=eListboxPythonMultiContent)
        self.l.setFont(0, gFont('Regular', max(16, int(24 * scale))))
        self.l.setItemHeight(self.row_height)

    def setList(self, values):
        rows = [[value, MultiContentEntryText(
            pos=(self.row_padding, 0),
            size=(self.row_width, self.row_height), font=0,
            flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER, text=menu_text(value),
            color=0x00C3CBD3, color_sel=0x00E1E6EB)]
            for value in values]
        MenuList.setList(self, rows)


class Levi45Emulator(Screen):
    def __init__(self, session):
        self.skin = skin()
        Screen.__init__(self, session)
        self.groups = []
        self.entries = None
        self['heading'] = Label('LEVI45  |  EMULATOR')
        self['subtitle'] = Label(('DreamOS / DEB' if dreamos() else 'Enigma2 / IPK') + '  |  Python %d  |  v%s' % (sys.version_info[0], VERSION))
        self['list'] = ReadableMenuList()
        self['status'] = Label('Connecting to GitHub...')
        self['kofi'] = Pixmap()
        self['paypal'] = Pixmap()
        self.onLayoutFinish.append(self.load_donation_icons)
        self['redkey'] = Label('Exit')
        self['greenkey'] = Label('Refresh')
        self['yellowkey'] = Label('Categories')
        self['bluekey'] = Label('Options')
        self['actions'] = ActionMap(['OkCancelActions', 'ColorActions'], {
            'ok': self.select, 'cancel': self.back, 'red': self.close, 'green': self.refresh,
            'yellow': self.back, 'blue': self.options
        }, -1)
        self.onLayoutFinish.append(self.refresh)


    def load_donation_icons(self):
        # Display the user-provided Ko-fi and PayPal QR PNGs from images/.
        for key in ('kofi', 'paypal'):
            path = os.path.join(IMAGES_DIR, key + '.png')
            try:
                if os.path.isfile(path):
                    widget = self[key].instance
                    if hasattr(widget, 'setScale'):
                        widget.setScale(1)
                    widget.setPixmapFromFile(path)
                else:
                    self[key].hide()
                    print('[Levi45Emulator] Missing image: %s' % path)
            except Exception as exc:
                print('[Levi45Emulator] Icon error: %s' % exc)

    def refresh(self):
        self.entries = None
        self['list'].setList([])
        self['status'].setText('Downloading %s ...' % feed().rsplit('/', 1)[-1])
        url = feed()
        try:
            # Twisted releases differ in whether URL is accepted as str or bytes.
            try:
                deferred = getPage(url.encode('utf-8'))
            except TypeError:
                deferred = getPage(url)
            deferred.addCallback(self.loaded)
            deferred.addErrback(self.failed)
        except Exception as exc:
            self['status'].setText(ui_text('Connection error: %s' % exc))

    def loaded(self, data):
        try:
            self.groups = parse_feed(data)
            self['list'].setList(menu_items([g[0] for g in self.groups]))
            self['status'].setText('%d categories loaded from GitHub' % len(self.groups))
        except Exception as exc:
            self['status'].setText(ui_text('Invalid XML: %s' % exc))

    def failed(self, failure):
        self['status'].setText(ui_text('Download failed: %s' % to_text(str(failure))[:120]))

    def select(self):
        idx = self['list'].getSelectionIndex()
        if idx < 0:
            return
        if self.entries is None:
            if idx >= len(self.groups):
                return
            self.entries = self.groups[idx][1]
            self['list'].setList(menu_items([e[0] for e in self.entries]))
            self['status'].setText(ui_text(self.groups[idx][0] + '  |  Select package to install'))
        elif idx < len(self.entries):
            name, url = self.entries[idx]
            try:
                cmd = install_command(url)
            except Exception as exc:
                self.session.open(MessageBox, ui_text(str(exc)), MessageBox.TYPE_ERROR)
                return
            self.session.openWithCallback(lambda yes: self.install(yes, name, cmd), MessageBox,
                ui_text('Install %s?\nOnly install packages you trust.' % name), MessageBox.TYPE_YESNO)

    def install(self, yes, name, cmd):
        if yes:
            self.session.open(Console, ui_text('Installing %s' % name), [ui_text(cmd)])

    def options(self):
        enabled = config.plugins.levi45emulator.show_in_mainmenu.value
        label = 'Disable Main Menu shortcut' if enabled else 'Enable Main Menu shortcut'
        choices = [(ui_text(label), 'toggle'), (ui_text('About'), 'about')]
        self.session.openWithCallback(self.option_selected, ChoiceBox,
                                      title=ui_text('Levi45 Emulator options'), list=choices)

    def option_selected(self, choice):
        if not choice:
            return
        if choice[1] == 'about':
            self.about()
        elif choice[1] == 'toggle':
            setting = config.plugins.levi45emulator.show_in_mainmenu
            setting.value = not setting.value
            setting.save()
            configfile.save()
            state = 'enabled' if setting.value else 'disabled'
            self.session.open(MessageBox,
                ui_text('Main Menu shortcut %s.\nClose and reopen the Main Menu to see the change.\nIf it does not update, restart Enigma2.' % state),
                MessageBox.TYPE_INFO)

    def about(self):
        self.session.open(MessageBox, ui_text("Levi45 Emulator v%s\nAutomatic HD / Full HD / WQHD\nPython 2 / Python 3 / DreamOS Support" % VERSION), MessageBox.TYPE_INFO)

    def back(self):
        if self.entries is not None:
            self.entries = None
            self['list'].setList(menu_items([g[0] for g in self.groups]))
            self['status'].setText('Select a category')
        else:
            self.close()


def main(session, **kwargs):
    session.open(Levi45Emulator)


def main_menu(menuid, **kwargs):
    if menuid != 'mainmenu' or not config.plugins.levi45emulator.show_in_mainmenu.value:
        return []
    return [(ui_text('Levi45 Emulator'), main, 'levi45emulator', 60)]


def Plugins(**kwargs):
    return [
        PluginDescriptor(name='Levi45 Emulator', description='Enigma2 / DreamOS emulator package installer v%s' % VERSION,
                         where=PluginDescriptor.WHERE_PLUGINMENU, icon='images/plugin.png', fnc=main),
        PluginDescriptor(name='Levi45 Emulator Main Menu',
                         where=PluginDescriptor.WHERE_MENU, fnc=main_menu)
    ]
