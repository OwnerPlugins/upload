#!/bin/sh
#### "***********************************************"
#### "*              Created by Levi45              *"
#### "***********************************************"
OSD="OSCam_11975-803"
OSCAM_BINARY="/usr/bin/oscam"
OSCAM_NAME="oscam"
LOG_FILE="/tmp/oscam_boot.log"
ACTION="${1:-cam_up}"
PID=""
chmod 755 /usr/bin/oscam

log() {
    printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >> "$LOG_FILE"
}
get_pid() {
    PID=$(pidof "$OSCAM_NAME" 2>/dev/null) || PID=""
    [ -n "$PID" ]
}
cam_down() {
    log "Stopping OSCam"
    if get_pid; then
        log "Sending TERM to PID(s): $PID"
        kill $PID 2>/dev/null
        i=0
        while [ "$i" -lt 3 ]; do
            sleep 1
            get_pid || break
            i=$((i + 1))
        done
        if get_pid; then
            log "Force stopping PID(s): $PID"
            kill -9 $PID 2>/dev/null
            i=0
            while [ "$i" -lt 3 ]; do
                sleep 1
                get_pid || break
                i=$((i + 1))
            done
            if get_pid; then
                log "ERROR: OSCam still running: $PID"
                return 1
            fi
        fi
    else
        log "OSCam already stopped"
    fi
    return 0
}
cam_up() {
    if get_pid; then
        log "Already running: $PID"
        return 0
    fi
    if [ ! -x "$OSCAM_BINARY" ]; then
        log "ERROR: OSCam binary missing or not executable: $OSCAM_BINARY"
        return 1
    fi
    log "Launching OSCam"
    "$OSCAM_BINARY" -b >> "$LOG_FILE" 2>&1 &
    launcher=$!
    i=0
    while [ "$i" -lt 4 ]; do
        sleep 1
        if get_pid; then
            log "SUCCESS: OSCam running: $PID"
            return 0
        fi
        i=$((i + 1))
    done
    if kill -0 "$launcher" 2>/dev/null; then
        log "WARNING: OSCam launcher still initializing; no duplicate launch"
    else
        log "ERROR: OSCam not detected"
    fi
    return 1
}
log "===== Levi45 OSCam action: $ACTION ====="
case "$ACTION" in
    cam_startup|cam_up|cam_start) cam_up; result=$? ;;
    cam_res|cam_restart)
        cam_down && cam_up
        result=$?
        ;;
    cam_down|cam_stop) cam_down; result=$? ;;
    *) log "Unknown action: $ACTION"; result=2 ;;
esac
log "Finished with status: $result"
exit "$result"
