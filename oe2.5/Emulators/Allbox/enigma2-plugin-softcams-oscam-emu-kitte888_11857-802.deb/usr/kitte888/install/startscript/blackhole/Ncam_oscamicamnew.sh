#!/bin/sh

CAMNAME="oscamicamnew"
BINARY="oscamicamnew"

remove_tmp () {
  rm -rf /tmp/*.info* /tmp/*.tmp* /tmp/*share* /tmp/*.pid* /tmp/*sbox*
}

case "$1" in
  start)
  echo "[SCRIPT] $1: $CAMNAME"
  remove_tmp
  touch /tmp/.emu.info
  echo OSCam_11771-801 > /tmp/.emu.info
  /usr/bin/oscamicamnew &
  ;;
  stop)
  echo "[SCRIPT] $1: $CAMNAME"
  killall -9 OSCam_11771-801  2>/dev/null
  remove_tmp
  ;;
  restart)
  $0 stop
  sleep 2
  $0 start
  exit
  ;;
  *)
  $0 stop
  exit 0
  ;;
esac

exit 0
