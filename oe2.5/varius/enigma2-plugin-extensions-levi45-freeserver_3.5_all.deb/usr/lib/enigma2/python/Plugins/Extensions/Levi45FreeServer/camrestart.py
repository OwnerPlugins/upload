# -*- coding: utf-8 -*-
"""Restart an explicitly selected receiver service after a successful save."""
import glob
import os
import re
import subprocess
import tempfile
import time

CAM_NAME = re.compile(r'(?:oscam|ncam|cccam|mgcam|gbox|wicard|doscam|oscam|softcam|camd|sbox)', re.I)
SCRIPT_DIRS = ('/etc/init.d',)
MULTICAM_DIRS = ('/usr/camscript',)
UNIT_DIRS = ('/etc/systemd/system', '/lib/systemd/system', '/usr/lib/systemd/system')


def _placeholder_script(path):
    # OpenATV/OpenPLi may point the generic softcam link at softcam.None.
    for name in (os.path.basename(path), os.path.basename(os.path.realpath(path))):
        if name.lower() in ('softcam.none', 'softcam.null', 'softcam.disabled'):
            return True
    return False


def _choice_label(name, method):
    limit = 28 - len(method) - 3
    if len(name) > limit:
        name = name[:max(1, limit - 3)] + '...'
    return name + ' [' + method + ']'


def restart_choices():
    choices = [('disabled', 'Disabled')]
    for directory in SCRIPT_DIRS:
        for path in sorted(glob.glob(os.path.join(directory, '*'))):
            if os.path.isfile(path) and CAM_NAME.search(os.path.basename(path)) and not _placeholder_script(path):
                choices.append(('script:' + path, _choice_label(os.path.basename(path), 'init')))
    for directory in MULTICAM_DIRS:
        for path in sorted(glob.glob(os.path.join(directory, '*.sh'))):
            if not os.path.isfile(path):
                continue
            try:
                with open(path, 'r') as handle:
                    content = handle.read(131072)
            except (IOError, UnicodeError):
                continue
            if all(token in content for token in ('cam_res', 'cam_up', 'cam_down')):
                choices.append(('multicam:' + path,
                                _choice_label(os.path.basename(path)[:-3], 'Levi45')))
    units = set()
    for directory in UNIT_DIRS:
        for path in glob.glob(os.path.join(directory, '*.service')):
            name = os.path.basename(path)
            if os.path.isfile(path) and CAM_NAME.search(name) and '@' not in name:
                units.add(name)
    for name in sorted(units):
        choices.append(('service:' + name, _choice_label(name, 'systemd')))
    if len(choices) == 1:
        choices.append(('custom', 'Custom restart script'))
    return choices


def validate_custom_script(path, action):
    if action not in ('restart', 'cam_res'):
        raise ValueError('Choose restart or cam_res for the custom script.')
    if not os.path.isabs(path) or not os.path.isfile(path):
        raise ValueError('Select a full cam control script filename, not a directory.')
    with open(path, 'rb') as handle:
        header = handle.readline(256)
    if not re.match(br'^#![^\r\n]*\b(?:ba|da|a|k|z)?sh(?:\s|$)', header):
        raise ValueError('Select a shell cam control script, not the emu binary in /usr/bin.')
    return ['/bin/sh', path, action]


def restart_command(target, custom_path='', custom_action='restart'):
    if target == 'custom':
        return validate_custom_script(custom_path, custom_action)
    allowed = dict(restart_choices())
    if target not in allowed or target == 'disabled':
        raise ValueError('Selected cam service is unavailable. Check restart settings.')
    kind, value = target.split(':', 1)
    if kind == 'multicam':
        return ['/bin/sh', value, 'cam_res']
    if kind == 'script':
        return ['/bin/sh', value, 'restart']
    for binary in ('/bin/systemctl', '/usr/bin/systemctl'):
        if os.path.isfile(binary) and os.access(binary, os.X_OK):
            return [binary, 'restart', value]
    raise ValueError('systemctl is unavailable on this receiver.')


def restart_cam(target, timeout=45, custom_path="", custom_action="restart"):
    if target == 'disabled':
        return 'Cam restart disabled.'
    command = restart_command(target, custom_path, custom_action)
    # File-backed output avoids pipe deadlocks on noisy receiver scripts.
    with tempfile.TemporaryFile() as output:
        process = subprocess.Popen(command, stdout=output, stderr=subprocess.STDOUT)
        deadline = time.time() + timeout
        while process.poll() is None:
            if time.time() >= deadline:
                process.terminate()
                for unused in range(10):
                    if process.poll() is not None:
                        break
                    time.sleep(0.1)
                if process.poll() is None:
                    process.kill()
                process.wait()
                raise RuntimeError('Cam restart timed out; check your softcam manager.')
            time.sleep(0.1)
        if process.returncode:
            raise RuntimeError('Cam restart failed (exit {}). Check your softcam manager.'.format(process.returncode))
    return 'Restart command completed: ' + (custom_path if target == 'custom' else target.split(':', 1)[1])


def configured_options(path='/etc/enigma2/settings'):
    values = {'restartcam': 'disabled', 'restartscript': '', 'restartaction': 'restart'}
    try:
        with open(path, 'r') as handle:
            for line in handle:
                key, separator, value = line.rstrip('\r\n').partition('=')
                prefix = 'config.plugins.Levi45FreeServer.'
                if separator and key.startswith(prefix) and key[len(prefix):] in values:
                    values[key[len(prefix):]] = value
    except IOError:
        pass
    return values


def configured_target(path='/etc/enigma2/settings'):
    return configured_options(path)['restartcam']


if __name__ == '__main__':
    import sys
    try:
        options = configured_options()
        print(restart_cam(options['restartcam'], custom_path=options['restartscript'],
                          custom_action=options['restartaction']))
    except Exception as exc:
        print('Servers saved; cam restart failed: ' + str(exc))
        sys.exit(1)
