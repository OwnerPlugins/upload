# -*- coding: utf-8 -*-
# stub - real code lives in plugin.so
