# -*- coding: utf-8 -*-
from __future__ import print_function

import os
import sys
import gettext
import io
import tempfile
import stat
import time
import traceback
import threading

from Components.config import config, ConfigSubsection, ConfigYesNo
from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_PLUGINS, SCOPE_LANGUAGE

PluginLanguageDomain = "ServiceScanUpdates"

PY2 = sys.version_info[0] == 2
PY3 = not PY2
LOG_FILE_PATH = "/tmp/ServiceScanUpdates.log"
LOG_MAX_BYTES = 1024 * 1024
_log_lock = threading.RLock()
_log_initialized = False


# ===== Resolve the plugin base path dynamically =====
def getPluginBasePath():
    # Resources belong to the imported package, including renamed installations.
    return os.path.dirname(os.path.abspath(__file__))


PLUGIN_BASE_PATH = getPluginBasePath()
PluginLanguagePath = os.path.join(PLUGIN_BASE_PATH, "locale")


# ===== Build an absolute path inside the plugin folder =====
def pluginResourcePath(*parts):
    return os.path.join(PLUGIN_BASE_PATH, *parts)


# ===== Open text files in a Python 2 / Python 3 compatible way =====
def openTextFile(path, mode, encoding="utf-8"):
    return io.open(path, mode, encoding=encoding)


def readTextFile(path, default_value="", encodings=None, strict=False):
    if encodings is None:
        encodings = ("utf-8", "latin-1")
    for encoding in encodings:
        try:
            with openTextFile(path, "r", encoding) as handle:
                return handle.read()
        except (IOError, OSError, UnicodeError) as error:
            last_error = error
    if strict:
        raise last_error
    return default_value


def toText(value):
    try:
        text_type = unicode
    except NameError:
        text_type = str
    if isinstance(value, bytes):
        return value.decode("utf-8")
    return text_type(value)


def toNativeText(value):
    # DreamOS Python 2 SWIG widgets require UTF-8 str, not unicode.
    # Keep file contents as unicode internally and convert at the UI boundary.
    text = toText(value)
    return text.encode("utf-8") if PY2 else text


def atomicWriteText(path, text, encoding="utf-8"):
    logMessage("[ServiceScanUpdates] FILE atomic write begin: %s" % path)
    # A failed write must not truncate the user's existing bouquets.
    fd, temporary = tempfile.mkstemp(prefix=".ssu-", dir=os.path.dirname(path) or ".")
    try:
        mode = stat.S_IMODE(os.stat(path).st_mode) if os.path.exists(path) else 0o644
        os.fchmod(fd, mode)
        with os.fdopen(fd, "wb") as handle:
            fd = None
            handle.write(toText(text).encode(encoding))
            handle.flush()
            os.fsync(handle.fileno())
        os.rename(temporary, path)
        logMessage("[ServiceScanUpdates] FILE atomic write complete: %s" % path)
    finally:
        if fd is not None:
            os.close(fd)
        if os.path.exists(temporary):
            os.unlink(temporary)


# ===== Initialize plugin settings if they don't exist =====
def initConfig():
    if not hasattr(config.plugins, "servicescanupdates"):
        config.plugins.servicescanupdates = ConfigSubsection()
    settings = config.plugins.servicescanupdates
    for name, default in (
        ("add_new_tv_services", True), ("add_new_radio_services", True),
        ("always_create_bouquet", False), ("create_removed_services_file", False),
        ("clear_bouquet", False), ("enable_log", False),
    ):
        if not hasattr(settings, name):
            setattr(settings, name, ConfigYesNo(default=default))
    return settings


def logMessage(message):
    # File logging is optional; a logging failure must never break the plugin.
    try:
        if not initConfig().enable_log.value:
            return
        text = toText(message)
        print(toNativeText(text))
        stamp = time.strftime("%Y-%m-%d %H:%M:%S")
        payload = (u"[%s] %s\n" % (stamp, text)).encode("utf-8")
        with _log_lock:
            if os.path.exists(LOG_FILE_PATH) and os.path.getsize(LOG_FILE_PATH) + len(payload) > LOG_MAX_BYTES:
                backup = LOG_FILE_PATH + ".1"
                if os.path.exists(backup):
                    os.unlink(backup)
                os.rename(LOG_FILE_PATH, backup)
            with open(LOG_FILE_PATH, "ab") as handle:
                handle.write(payload)
    except Exception:
        # Console only here: do not recursively call the logger.
        print("[ServiceScanUpdates] Unable to write diagnostic log")


def logException():
    logMessage("[ServiceScanUpdates] EXCEPTION:\n%s" % traceback.format_exc())


def initializeLog():
    global _log_initialized
    if _log_initialized:
        return
    _log_initialized = True
    with _log_lock:
        for path in (LOG_FILE_PATH, LOG_FILE_PATH + ".1"):
            try:
                if os.path.exists(path):
                    os.unlink(path)
            except OSError:
                print("[ServiceScanUpdates] Unable to clear previous log")
    logMessage("[ServiceScanUpdates] STARTUP new log session; profile=%s" % getRuntimeProfile())


# ===== Try to identify the box model =====
def getBoxModel():
    model_candidates = (
        "/proc/stb/info/model",
        "/proc/stb/info/boxtype",
        "/proc/stb/info/vumodel",
    )
    for candidate in model_candidates:
        value = readTextFile(candidate, "").strip()
        if value:
            return value.lower()
    return ""


# ===== Try to identify the running image / distro =====
def getImageName():
    distro_sources = (
        "/etc/image-version",
        "/etc/issue",
        "/etc/os-release",
        "/etc/vtiversion.info",
    )
    chunks = []
    for candidate in distro_sources:
        value = readTextFile(candidate, "").strip()
        if value:
            chunks.append(value.lower())
    return " ".join(chunks)


# ===== Function to check if running on DreamOS =====
def isDreamOS():
    image_name = getImageName()
    box_model = getBoxModel()

    if "dreamos" in image_name or "dreambox" in image_name:
        return True
    if box_model.startswith("dm") and ("oe2.5" in image_name or "oe2.6" in image_name):
        return True

    try:
        from enigma import eMediaDatabase
        return eMediaDatabase is not None
    except Exception:
        return False


# ===== Build a runtime profile used by condition checks =====
def getRuntimeProfile():
    image_name = getImageName()
    box_model = getBoxModel()
    return {
        "python_version": sys.version.split()[0],
        "python_major": sys.version_info[0],
        "dreamos": isDreamOS(),
        "dreambox": box_model.startswith("dm") or "dreambox" in image_name,
        "vuplus": box_model.startswith("vu") or "vu+" in image_name or "vuplus" in image_name,
        "vti": "vti" in image_name,
        "openatv": "openatv" in image_name,
        "openpli": "openpli" in image_name,
        "openspa": "openspa" in image_name,
        "openvix": "openvix" in image_name,
        "openhdf": "openhdf" in image_name or "hdf" in image_name,
        "image_name": image_name,
        "box_model": box_model,
    }


# ===== Initialize locale =====
def localeInit():
    lang = language.getLanguage()[:2]
    os.environ["LANGUAGE"] = lang
    gettext.bindtextdomain("enigma2", resolveFilename(SCOPE_LANGUAGE))
    gettext.textdomain("enigma2")
    gettext.bindtextdomain(PluginLanguageDomain, PluginLanguagePath)


# ===== Translation function =====
def _(txt):
    translated = gettext.dgettext(PluginLanguageDomain, txt)
    if translated == txt:
        translated = gettext.gettext(txt)
    return toNativeText(translated)


# ===== Initialize translation immediately at plugin start =====
localeInit()

# ===== Ensure plugin settings exist immediately =====
initConfig()

# ===== Register callback only if the image supports it safely =====
if not isDreamOS() and hasattr(language, "addCallback"):
    # fixed: pass function, don't call it
    language.addCallback(localeInit)
