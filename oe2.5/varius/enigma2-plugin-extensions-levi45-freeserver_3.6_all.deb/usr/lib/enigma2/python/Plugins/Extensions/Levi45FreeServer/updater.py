# -*- coding: utf-8 -*-
"""Pinned-commit GitHub updates with integrity checks and rollback."""
import hashlib
import json
import os
import re
import shutil
import tempfile
import time
try:
    from urllib.request import Request, urlopen
except ImportError:
    from urllib2 import Request, urlopen

REPO = 'levi-45/Levi45FreeServer'
PREFIX = 'usr/lib/enigma2/python/Plugins/Extensions/Levi45FreeServer/'
REQUIRED = ('plugin.py', '__init__.py', 'trial.py', 'camrestart.py', 'updater.py', 'images/plugin.png')


def fetch(url, limit=4 * 1024 * 1024):
    request = Request(url, headers={'User-Agent': 'Levi45FreeServer-Updater', 'Accept': 'application/vnd.github+json'})
    response = urlopen(request, timeout=30)
    try:
        data = response.read(limit + 1)
    finally:
        response.close()
    if len(data) > limit:
        raise ValueError('Update response exceeds size limit.')
    return data


def version_key(version):
    if not re.match(r'^\d+(?:\.\d+){0,3}$', version):
        raise ValueError('Unsupported version number: ' + version)
    parts = [int(part) for part in version.split('.')]
    return tuple(parts + [0] * (4 - len(parts)))


def source_version(data):
    match = re.search(br'^PLUGIN_VERSION\s*=\s*[\"\']([0-9.]+)[\"\']', data, re.M)
    if not match:
        raise ValueError('Update has no valid PLUGIN_VERSION.')
    value = match.group(1).decode('ascii')
    version_key(value)
    return value


def checked_blob(commit, relative, expected_sha):
    data = fetch('https://raw.githubusercontent.com/' + REPO + '/' + commit + '/' + PREFIX + relative)
    digest = hashlib.sha1(b'blob ' + str(len(data)).encode('ascii') + b'\0' + data).hexdigest()
    if digest != expected_sha:
        raise ValueError('Update integrity check failed: ' + relative)
    return data


def check_update(current_version):
    tree = json.loads(fetch('https://api.github.com/repos/' + REPO + '/git/trees/main?recursive=1').decode('utf-8'))
    commit = tree.get('sha', '')
    if tree.get('truncated') or not re.match(r'^[0-9a-f]{40}$', commit):
        raise ValueError('GitHub returned an incomplete update manifest.')
    files = {}
    for item in tree.get('tree', []):
        path = item.get('path', '')
        if not path.startswith(PREFIX) or item.get('type') != 'blob':
            continue
        relative = path[len(PREFIX):]
        if relative.startswith('/') or any(part in ('', '.', '..') for part in relative.split('/')):
            raise ValueError('Unsafe update filename.')
        if not (relative.endswith('.py') or (relative.startswith('images/') and relative.endswith('.png'))):
            continue
        if item.get('mode') not in ('100644', '100755'):
            raise ValueError('Update contains a non-regular file.')
        sha = item.get('sha', '')
        if not re.match(r'^[0-9a-f]{40}$', sha):
            raise ValueError('Invalid GitHub file hash.')
        files[relative] = sha
    if 'plugin.py' not in files:
        raise ValueError('Repository plugin.py not found.')
    version = source_version(checked_blob(commit, 'plugin.py', files['plugin.py']))
    return {'version': version, 'commit': commit, 'files': files,
            'newer': version_key(version) > version_key(current_version)}


def cleanup_legacy_backups(plugin_dir):
    """Remove only the old updater's timestamped plugin backup directories."""
    parent = os.path.dirname(os.path.abspath(plugin_dir))
    for name in os.listdir(parent):
        if not re.match(r'^\.Levi45FreeServer-backup-[0-9]{8}-[0-9]{6}$', name):
            continue
        path = os.path.join(parent, name)
        if os.path.islink(path) or not os.path.isdir(path):
            continue
        source = os.path.join(path, 'plugin.py')
        if os.path.isfile(source):
            with open(source, 'rb') as handle:
                content = handle.read(1024 * 1024)
            if b'Levi45 Free Server' in content and b'PLUGIN_VERSION' in content:
                shutil.rmtree(path)


def install_update(plugin_dir, plan, current_version):
    if version_key(plan['version']) <= version_key(current_version):
        raise ValueError('Update is not newer; downgrade refused.')
    for required in REQUIRED:
        if required not in plan['files']:
            raise ValueError('Repository update is incomplete: missing ' + required)
    plugin_dir = os.path.abspath(plugin_dir)
    if os.path.islink(plugin_dir) or not os.path.isdir(plugin_dir):
        raise ValueError('Plugin directory is missing or is a symlink.')
    parent = os.path.dirname(plugin_dir)
    # Use the Python directory, outside Plugins: Enigma2 must never scan staging.
    work_parent = os.path.dirname(os.path.dirname(parent))
    lock = os.path.join(work_parent, '.Levi45FreeServer-update.lock')
    os.mkdir(lock)
    workspace = None
    stage = None
    moved = False
    committed = False
    try:
        workspace = tempfile.mkdtemp(prefix='.levi45-update-', dir=work_parent)
        if os.stat(workspace).st_dev != os.stat(plugin_dir).st_dev:
            raise ValueError('Update staging and plugin must be on the same filesystem.')
        stage = os.path.join(workspace, 'stage')
        os.mkdir(stage)
        backup = os.path.join(workspace, 'previous')
        # Preserve local generated scheduler files; settings/readers live outside this folder.
        for name in os.listdir(plugin_dir):
            source = os.path.join(plugin_dir, name)
            destination = os.path.join(stage, name)
            if name == '__pycache__' or name.endswith(('.pyc', '.pyo')):
                continue
            if os.path.islink(source):
                continue
            if os.path.isdir(source):
                shutil.copytree(source, destination, symlinks=True)
            else:
                shutil.copy2(source, destination)
        for relative, sha in plan['files'].items():
            destination = os.path.join(stage, relative)
            if os.path.islink(destination):
                raise ValueError('Local update destination is a symlink.')
            directory = os.path.dirname(destination)
            # Prevent inherited directory links from escaping staging.
            if not os.path.realpath(directory).startswith(os.path.realpath(stage) + os.sep) and directory != stage:
                raise ValueError('Unsafe local update directory.')
            if not os.path.isdir(directory):
                os.makedirs(directory)
            data = checked_blob(plan['commit'], relative, sha)
            if relative.endswith('.py'):
                compile(data, relative, 'exec')  # Validate on the receiver's Python version.
            if relative == 'plugin.py' and source_version(data) != plan['version']:
                raise ValueError('Update version changed unexpectedly.')
            with open(destination, 'wb') as handle:
                handle.write(data)
                handle.flush()
                os.fsync(handle.fileno())
            os.chmod(destination, 0o644)
        os.chmod(stage, os.stat(plugin_dir).st_mode & 0o777)
        os.rename(plugin_dir, backup)
        moved = True
        try:
            os.rename(stage, plugin_dir)
            stage = None
        except Exception:
            os.rename(backup, plugin_dir)
            moved = False
            raise
        committed = True
        cleanup_legacy_backups(plugin_dir)
        return True
    finally:
        # Retain temporary recovery data only if rollback itself failed.
        if workspace and (committed or not moved):
            shutil.rmtree(workspace)
        os.rmdir(lock)
