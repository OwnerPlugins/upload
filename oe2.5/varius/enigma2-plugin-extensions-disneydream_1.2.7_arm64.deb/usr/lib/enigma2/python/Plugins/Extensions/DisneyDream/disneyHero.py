from enigma import ePicLoad, eTimer, gPixmapPtr
from Components.Pixmap import Pixmap
import os

from .disneyHelper import *


class DisneyHero:
    def __init__(self, disney):
        # Hero Timer
        self.hero_list = []
        self.disney = disney
        self.hero_index = 0
        self['DisneyHeroGui'] = Pixmap()
        self.timerHero_active = False
        self.timerHero_return = False
        self.timerHero = eTimer()
        self.timerHero_conn = self.timerHero.timeout.connect(self.loadTimerHero)

        self.onShow.append(self.setReloadTimer)
        self.onHide.append(self.setStopTimer)

    def setStopTimer(self):
        self.timerHero_return = self.timerHero_active
        if self.timerHero is not None:
            self.timerHero.stop()

    def setReloadTimer(self):
        if self.timerHero_return:
            self.timerHero_return = False
            self.loadTimerHero()

    def setHeroList(self, data):
        self.hero_list = data

    def stopHero(self):
        self.timerHero_active = False
        if self.timerHero is not None:
            self.timerHero.stop()

    def startHero(self):
        self.timerHero_active = True
        self.loadTimerHero()

    def loadTimerHero(self):
        if self.hero_list:
            (cover, png_destination) = self.hero_list[self.hero_index]
            if not os.path.isfile(png_destination) and cover:
                item = {"png_destination": png_destination,
                        "x": 1670,
                        "y": 427,
                        "type": "PNG"}
                self.disney.contentDownloader(cover, item, callback=self.showHeroPic)
            else:
                png = png_destination if os.path.isfile(png_destination) else None
                self.showHeroPic(None, png)
        else:
            self.showHeroPic(None, DISNEY_DEFAULT_HERO_PNG)

    def showHeroPic(self, item, png):
        png = DISNEY_DEFAULT_HERO_PNG if not png else png
        if os.path.isfile(png):
            self["DisneyHeroGui"].instance.setPixmapFromFile(png)
        if self.hero_list:
            if self.hero_index + 1 <= len(self.hero_list) - 1:
                self.hero_index += 1
            else:
                self.hero_index = 0
        if self.timerHero_active:
            self.timerHero.start(6000, True)
