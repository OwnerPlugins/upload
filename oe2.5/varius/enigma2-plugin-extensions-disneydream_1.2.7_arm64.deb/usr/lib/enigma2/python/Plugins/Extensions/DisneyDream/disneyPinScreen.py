from Components.ActionMap import NumberActionMap
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label

from .disneyHelper import *
from .disneyHelper import _


class DisneyPinScreen(Screen):
    def __init__(self, session):
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen backgroundColor="#002d3343" flags="wfNoBorder" name="DisneyDream" position="center,center" size="2560,1440" title="DisneyDream">
                           <widget name="Pin" position="80,533" size="2400,80" backgroundColor="#002d3343" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="DD; 60" valign="top" halign="center" />
                           <ePixmap position="993,667" size="573,133" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/disney_pin_573x133.png" zPosition="1" />
                           <widget name="Label0" position="1007,693" size="107,80" backgroundColor="#002d3343" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="DD; 60" valign="center" halign="center" />
                           <widget name="Label1" position="1153,693" size="107,80" backgroundColor="#002d3343" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="DD; 60" valign="center" halign="center" />
                           <widget name="Label2" position="1300,693" size="107,80" backgroundColor="#002d3343" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="DD; 60" valign="center" halign="center" />
                           <widget name="Label3" position="1447,693" size="107,80" backgroundColor="#002d3343" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="DD; 60" valign="center" halign="center" />
                           <ePixmap position="2240,1267" size="267,147" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/logo_200x110.png" zPosition="99" />
                           </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """<screen backgroundColor="#002d3343" flags="wfNoBorder" name="DisneyDream" position="center,center" size="1920,1080" title="DisneyDream">
                           <widget name="Pin" position="60,400" size="1800,60" backgroundColor="#002d3343" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="DD; 45" valign="top" halign="center" />
                           <ePixmap position="745,500" size="430,100" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/disney_pin_430x100.png" zPosition="1" />
                           <widget name="Label0" position="755,520" size="80,60" backgroundColor="#002d3343" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="DD; 45" valign="center" halign="center" />
                           <widget name="Label1" position="865,520" size="80,60" backgroundColor="#002d3343" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="DD; 45" valign="center" halign="center" />
                           <widget name="Label2" position="975,520" size="80,60" backgroundColor="#002d3343" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="DD; 45" valign="center" halign="center" />
                           <widget name="Label3" position="1085,520" size="80,60" backgroundColor="#002d3343" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="DD; 45" valign="center" halign="center" />
                           <ePixmap position="1680,950" size="200,110" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/logo_200x110.png" zPosition="99" />
                           </screen>
                        """
        else:
            self.skin = """<screen backgroundColor="#002d3343" flags="wfNoBorder" name="DisneyDream" position="center,center" size="1280,720" title="DisneyDream">
                           <widget name="Pin" position="40,266" size="1200,40" backgroundColor="#002d3343" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="DD; 30" valign="top" halign="center" />
                           <ePixmap position="496,333" size="286,67" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/disney_pin_286x67.png" zPosition="1" />
                           <widget name="Label0" position="503,346" size="53,40" backgroundColor="#002d3343" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="DD; 30" valign="center" halign="center" />
                           <widget name="Label1" position="576,346" size="53,40" backgroundColor="#002d3343" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="DD; 30" valign="center" halign="center" />
                           <widget name="Label2" position="650,346" size="53,40" backgroundColor="#002d3343" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="DD; 30" valign="center" halign="center" />
                           <widget name="Label3" position="723,346" size="53,40" backgroundColor="#002d3343" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="DD; 30" valign="center" halign="center" />
                           <ePixmap position="1120,633" size="133,73" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/logo_133x73.png" zPosition="99" />
                           </screen>
                           """
        Screen.__init__(self, session)
        self['actions'] = ActionMap(['DisneyDream_Actions'],
                                    {'ok': self.keyOk,
                                     'cancel': self.keyCancel,
                                     "left": self.delete,
                                     "power": self.keyPower}, -1)

        self["myNumberActions"] = NumberActionMap(["InputActions"], {
            "1": self.keyNumberGlobal,
            "2": self.keyNumberGlobal,
            "3": self.keyNumberGlobal,
            "4": self.keyNumberGlobal,
            "5": self.keyNumberGlobal,
            "6": self.keyNumberGlobal,
            "7": self.keyNumberGlobal,
            "8": self.keyNumberGlobal,
            "9": self.keyNumberGlobal,
            "0": self.keyNumberGlobal
        }, -1)

        self['Pin'] = Label(_("Enter your profile PIN"))
        self['Label0'] = Label("")
        self['Label1'] = Label("")
        self['Label2'] = Label("")
        self['Label3'] = Label("")

        self.pin_text = ""

    def keyNumberGlobal(self, number):
        if not len(self.pin_text) >= 4:
            self.pin_text += str(number)
            self.updatePin()

    def delete(self):
        if self.pin_text:
            if len(self.pin_text) > 1:
                self.pin_text = self.pin_text[:-1]
            else:
                self.pin_text = ""
            self.updatePin()

    def updatePin(self):
        for i in range(4):
            label = "Label" + str(i)
            self[label].setText("")
        if self.pin_text:
            for i in range(len(self.pin_text)):
                d = self.pin_text[i]
                label = "Label" + str(i)
                self[label].setText("*")

    def keyOk(self):
        if len(self.pin_text) > 3:
            self.close(self.pin_text, False)

    def keyCancel(self):
        self.close(None, False)

    def keyPower(self):
        self.close(None, True)

    def MyDisneySummary(self):
        return MyDisneySummary