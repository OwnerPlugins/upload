from Components.AVSwitch import AVSwitch
from Components.MenuList import MenuList
from enigma import gFont, getDesktop, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP, RT_WRAP, ePicLoad, eTimer, gPixmapPtr, eSize, ePoint
from Tools.LoadPixmap import LoadPixmap
from Components.Label import Label
from Components.Pixmap import Pixmap

from .disneyHelper import *
from .disneyHelper import _
from .disneySpinner import DisneySpinner
from .disneyHero import DisneyHero

import os


class DisneyGui(DisneySpinner, DisneyHero):
    def __init__(self, disney=None):

        self.disney = disney
        DisneyHero.__init__(self, self.disney)
        DisneySpinner.__init__(self)

        self.coverList1 = [("Cover0", skinValueCalculate(100), skinValueCalculate(766)),
                           ("Cover1", skinValueCalculate(490), skinValueCalculate(766)),
                           ("Cover2", skinValueCalculate(880), skinValueCalculate(766)),
                           ("Cover3", skinValueCalculate(1270), skinValueCalculate(766)),
                           ("Cover4", skinValueCalculate(1660), skinValueCalculate(766))]
        for skin_value, x, y in self.coverList1:
            self[skin_value] = Pixmap()

        self.coverList2 = [("Cover5", skinValueCalculate(100), skinValueCalculate(1059)),
                           ("Cover6", skinValueCalculate(490), skinValueCalculate(1059)),
                           ("Cover7", skinValueCalculate(880), skinValueCalculate(1059)),
                           ("Cover8", skinValueCalculate(1270), skinValueCalculate(1059)),
                           ("Cover9", skinValueCalculate(1660), skinValueCalculate(1059))]
        for skin_value, x, y in self.coverList2:
            self[skin_value] = Pixmap()

        self["CoverSelect"] = Pixmap()
        self["CoverSelect"].hide()

        self.chooseDisneyBrandGuiList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseDisneyBrandGuiList.l.setItemHeight(skinValueCalculate(133))
        self['DisneyBrandGui'] = self.chooseDisneyBrandGuiList

        self['DisneyGuiText1'] = Label("")
        self['DisneyGuiText2'] = Label("")

        self.disney_gui_index = 0
        self.disney_item_index = 0
        self.disney_brand_index = 0
        self.callback_list1 = []
        self.callback_list2 = []
        self.last = None

        self.video_list = []
        self.brand_gui_data = [(DISNEY_BRAND_DISNEY_PNG, "brand", "disney"),
                               (DISNEY_BRAND_PIXAR_PNG, "brand", "pixar"),
                               (DISNEY_BRAND_MARVEL_PNG, "brand", "marvel"),
                               (DISNEY_BRAND_STAR_WARS_PNG, "brand", "star-wars"),
                               (DISNEY_BRAND_NATIONAL_PNG, "brand", "national-geographic"),
                               (DISNEY_BRAND_STAR_PNG, "brand", "star")]

        self.disney_gui_focus = 0

    def buildGuiData(self, update=None):
        print("Disney Dream build gui")
        if update:
            self.disney_gui_index = 0
            self.disney_item_index = 0
            self.disney_brand_index = 0
            self.disney_gui_focus = 0
            self["DisneyHeroGui"].instance.move(ePoint(skinValueCalculate(125), skinValueCalculate(30)))
            self["DisneyBrandGui"].instance.move(ePoint(skinValueCalculate(130), skinValueCalculate(520)))
            self["DisneyGuiText1"].instance.move(ePoint(skinValueCalculate(100), skinValueCalculate(706)))
            self["DisneyGuiText2"].instance.move(ePoint(skinValueCalculate(100), skinValueCalculate(999)))
            self.moveCover(0)
            self.hideSelectCover()
        self.last = None
        if self.video_list:
            title = getTxt(self.video_list[self.disney_gui_index]["title"]).replace("{title}", "")
            self['DisneyGuiText1'].setText(title)
            self.loadSelectCoverList(self.disney_item_index)
            data = []
            if self.disney_gui_index + 1 <= len(self.video_list) - 1:
                title = getTxt(self.video_list[self.disney_gui_index + 1]["title"]).replace("{title}", "")
                video_data = self.video_list[self.disney_gui_index + 1]["videos"]
                self['DisneyGuiText2'].setText(title)
                max_range = 5 if len(video_data) > 4 else len(video_data)
                data = []
                for i in range(max_range):
                    video = video_data[i]
                    data.append(video)
            else:
                self.last = True
                self['DisneyGuiText2'].setText("")
            self.setCategoryList2(data)
        else:
            self['DisneyGuiText1'].setText("")
            self['DisneyGuiText2'].setText("")
            self.setCategoryList2([])
        if update:
            if self.video_list:
                self.setHeroList(self.disney.getHeroItems(self.video_list[0]["videos"]))
                self.startHero()
                self.update_disney_brand_gui()

    def update_disney_brand_gui(self):
        data = [self.disney_brand_index, self.disney_gui_focus, self.brand_gui_data]
        self.chooseDisneyBrandGuiList.setList(list(map(disney_gui_brand_entry, [data])))
        self.chooseDisneyBrandGuiList.selectionEnabled(0)

    def loadSelectCoverList(self, index):
        if self.video_list:
            select_category_videos = self.video_list[self.disney_gui_index]["videos"]
            self.callback_list1 = []
            start = index - 3 if index >= 4 else 0
            max_range = 5 if len(select_category_videos) - index >= 5 else len(select_category_videos) - start
            for skin_value, x, y in self.coverList1:
                if max_range is not 0:
                    png_data = select_category_videos[start]["cover"] if not select_category_videos[start].get("cover_series") else select_category_videos[start]["cover_series"]
                    png_data.update({"skin_value": skin_value})
                    self.callback_list1.append((png_data["skin_value"], png_data["png_destination"]))
                    if os.path.isfile(png_data["png_destination"]):
                        self[png_data["skin_value"]].instance.setPixmapFromFile(png_data["png_destination"])
                        self[png_data["skin_value"]].show()
                    else:
                        self[png_data["skin_value"]].instance.setPixmapFromFile(DISNEY_DEFAULT_COVER_PNG)
                        self[png_data["skin_value"]].show()
                        self.disney.contentDownloader(png_data["url"], png_data, callback=self.loadCoverList1)
                    max_range -= 1
                else:
                    self[skin_value].hide()
                start += 1

    def loadCoverList1(self, item, png):
        if (item["skin_value"], item["png_destination"]) in self.callback_list1 and png:
            ptr = decodePic(item)
            if ptr != None:
                self[item["skin_value"]].instance.setPixmap(ptr)
                self[item["skin_value"]].show()
            else:
                self[item["skin_value"]].instance.setPixmapFromFile(DISNEY_DEFAULT_COVER_PNG)
                self[item["skin_value"]].show()

    def setCategoryList2(self, data):
        self.callback_list2 = []
        max = len(data)
        item = 0
        for skin_value, x, y in self.coverList2:
            if max is not 0:
                png_data = data[item]["cover"] if not data[item].get("cover_series") else data[item]["cover_series"]
                png_data.update({"skin_value": skin_value})
                if os.path.isfile(getTxt(png_data["png_destination"])):
                    ptr = decodePic(png_data)
                    if ptr != None:
                        self[png_data["skin_value"]].instance.setPixmap(ptr)
                        self[png_data["skin_value"]].show()
                    else:
                        self[png_data["skin_value"]].instance.setPixmapFromFile(DISNEY_DEFAULT_COVER_PNG)
                        self[png_data["skin_value"]].show()
                else:
                    self.callback_list2.append((png_data["skin_value"], png_data["png_destination"]))
                    self[png_data["skin_value"]].instance.setPixmapFromFile(DISNEY_DEFAULT_COVER_PNG)
                    self[png_data["skin_value"]].show()
                    self.disney.contentDownloader(png_data["url"], png_data, callback=self.loadCoverList2)
                max -= 1
            else:
                self[skin_value].hide()
            item += 1

    def loadCoverList2(self, item, png):
        if self.last:
            for skin_value, x, y in self.coverList2:
                self[skin_value].hide()
        else:
            if (item["skin_value"], item["png_destination"]) in self.callback_list2 and png:
                ptr = decodePic(item)
                if ptr != None:
                    self[item["skin_value"]].instance.setPixmap(ptr)
                    self[item["skin_value"]].show()
                else:
                    self[item["skin_value"]].instance.setPixmapFromFile(DISNEY_DEFAULT_COVER_PNG)
                    self[item["skin_value"]].show()

    def moveSelectCover(self, index, mode):
        if mode is None:
            for skin_value, x, y in self.coverList1:
                self[skin_value].instance.move(ePoint(x, y - skinValueCalculate(200)))
                self[skin_value].instance.resize(eSize(skinValueCalculate(350), skinValueCalculate(196)))
        if index <= 3:
            skin_value = "Cover" + str(index)
            x = skinValueCalculate(75)
            for i in range(index):
                x = x + skinValueCalculate(390)
            self[skin_value].instance.move(ePoint(x, skinValueCalculate(550)))
            self[skin_value].instance.resize(eSize(skinValueCalculate(400), skinValueCalculate(225)))
            self["CoverSelect"].instance.move(ePoint(x, skinValueCalculate(550)))
            self["CoverSelect"].show()
            if mode == "+" and index is not 0:
                (skin_value, x, y) = self.coverList1[index - 1]
                self[skin_value].instance.move(ePoint(x, y - skinValueCalculate(200)))
                self[skin_value].instance.resize(eSize(skinValueCalculate(350), skinValueCalculate(196)))
            elif mode == "-":
                (skin_value, x, y) = self.coverList1[index + 1]
                self[skin_value].instance.move(ePoint(x, y - skinValueCalculate(200)))
                self[skin_value].instance.resize(eSize(skinValueCalculate(350), skinValueCalculate(196)))

    def hideSelectCover(self):
        for skin_value, x, y in self.coverList1:
            self[skin_value].instance.move(ePoint(x, y))
            self[skin_value].instance.resize(eSize(skinValueCalculate(350), skinValueCalculate(196)))
        self["CoverSelect"].hide()

    def moveCover(self, index):
        if index == 0:
            for skin_value, x, y in self.coverList1:
                self[skin_value].instance.move(ePoint(x, y))
            for skin_value, x, y in self.coverList2:
                self[skin_value].instance.move(ePoint(x, y))
        elif index == 1:
            for skin_value, x, y in self.coverList1:
                self[skin_value].instance.move(ePoint(x, y - skinValueCalculate(200)))
            for skin_value, x, y in self.coverList2:
                self[skin_value].instance.move(ePoint(x, y - skinValueCalculate(200)))

    def key_disney_gui_ok(self):
        if not self.timerSpinnerStatusSpinner:
            if self.video_list and self.disney_gui_focus == 1:
                refType = self.video_list[self.disney_gui_index]["refType"]
                video_data = self.video_list[self.disney_gui_index]["videos"]
                if video_data:
                    return refType, video_data[self.disney_item_index]
                else:
                    return refType, {}

    def key_disney_gui_left(self):
        if not self.timerSpinnerStatusSpinner:
            if self.video_list and self.disney_gui_focus == 1:
                if self.disney_item_index is not 0:
                    self.disney_item_index -= 1
                    self.loadSelectCoverList(self.disney_item_index)
                    self.moveSelectCover(self.disney_item_index, "-")
            elif self.disney_gui_focus == 0 and self.disney_brand_index is not 0:
                self.disney_brand_index -= 1
                self.update_disney_brand_gui()

    def key_disney_gui_right(self):
        if not self.timerSpinnerStatusSpinner:
            if self.disney_gui_focus == 1 and self.video_list:
                if self.disney_item_index < len(self.video_list[self.disney_gui_index]["videos"]) - 1:
                    if self.video_list[self.disney_gui_index].get("page") and self.video_list[self.disney_gui_index].get("totalPages"):
                        if len(self.video_list[self.disney_gui_index]["videos"]) - self.disney_item_index == 4 and self.video_list[self.disney_gui_index]["page"] < self.video_list[self.disney_gui_index]["totalPages"]:
                            self.startTimerSpinner()
                            self.video_list[self.disney_gui_index]["page"] += 1
                            self.disney.getSetBySetIdVideos(self.video_list[self.disney_gui_index], callback=self.cbUpdateCategoryVideosList)
                            return
                    self.disney_item_index += 1
                    self.loadSelectCoverList(self.disney_item_index)
                    self.moveSelectCover(self.disney_item_index, "+")
            elif self.disney_gui_focus == 0 and self.disney_brand_index is not 5:
                self.disney_brand_index += 1
                self.update_disney_brand_gui()

    def cbUpdateCategoryVideosList(self, category):
        self.stopTimerSpinner()
        self.disney_item_index += 1
        self.loadSelectCoverList(self.disney_item_index)
        self.moveSelectCover(self.disney_item_index, "+")

    def key_disney_gui_up(self):
        if not self.timerSpinnerStatusSpinner:
            if self.disney_gui_focus == 1:
                if self.disney_gui_index is 0:
                    self.disney_gui_focus -= 1
                    self.disney_item_index = 0
                    self.update_disney_brand_gui()
                    self.startHero()
                    self["DisneyHeroGui"].instance.move(ePoint(skinValueCalculate(125), skinValueCalculate(30)))
                    self["DisneyBrandGui"].instance.move(ePoint(skinValueCalculate(130), skinValueCalculate(520)))
                    self["DisneyGuiText1"].instance.move(ePoint(skinValueCalculate(100), skinValueCalculate(706)))
                    self["DisneyGuiText2"].instance.move(ePoint(skinValueCalculate(100), skinValueCalculate(999)))
                    self.hideSelectCover()
                    self.moveCover(0)
                    self.buildGuiData()
                else:
                    self.disney_gui_index -= 1
                    self.disney_item_index = 0
                    self.buildGuiData()
                    self.moveSelectCover(self.disney_item_index, None)

    def key_disney_gui_down(self):
        if not self.timerSpinnerStatusSpinner:
            if self.disney_gui_focus == 0:
                self.disney_gui_focus += 1
                self.update_disney_brand_gui()
                self.stopHero()
                self["DisneyHeroGui"].instance.move(ePoint(skinValueCalculate(125), skinValueCalculate(-190)))
                self["DisneyBrandGui"].instance.move(ePoint(skinValueCalculate(130), skinValueCalculate(320)))
                self["DisneyGuiText1"].instance.move(ePoint(skinValueCalculate(100), skinValueCalculate(506)))
                self["DisneyGuiText2"].instance.move(ePoint(skinValueCalculate(100), skinValueCalculate(799)))
                self.moveCover(1)
                self.moveSelectCover(self.disney_item_index, None)
            elif self.disney_gui_focus == 1 and self.disney_gui_index + 1 <= len(self.video_list) - 1:
                self.disney_gui_index += 1
                self.disney_item_index = 0
                self.moveSelectCover(self.disney_item_index, None)
                self.buildGuiData()


def disney_gui_brand_entry(entry):
    res = [entry]
    index = entry[0]
    focus = entry[1]
    data = entry[2]

    w_pos = skinValueCalculate(4)
    if data:
        for i in range(len(data)):
            w_pos_png = w_pos + skinValueCalculate(25)
            png_w = skinValueCalculate(200)
            png_h = skinValueCalculate(100)
            h_pos = skinValueCalculate(20)
            if i == index and focus == 0:
                png = LoadPixmap(DISNEY_BRAND_SELECT)
                res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, w_pos - skinValueCalculate(4), 0, skinValueCalculate(258), skinValueCalculate(133), png))
                w_pos_png = w_pos
                png_w = skinValueCalculate(250)
                png_h = skinValueCalculate(125)
                h_pos = skinValueCalculate(4)
            png = LoadPixmap(data[i][0])
            res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, w_pos_png, h_pos, png_w, png_h, png))
            w_pos = w_pos + skinValueCalculate(280)
    return res


def disney_gui_hero_entry(entry):
    res = [entry]
    index = entry[0]
    data = entry[1]
    if data:
        (cover, png_destination) = data[index]
        png = LoadPixmap(png_destination) if os.path.isfile(png_destination) else LoadPixmap(DISNEY_DEFAULT_HERO_PNG)
        res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, 0, 0, skinValueCalculate(1670), skinValueCalculate(427), png))
    return res


def decodePic(item, color="#ff111111"):
    ptr = None
    try:
        scale = AVSwitch().getFramebufferScale()
        picload = ePicLoad()
        picload.setPara((item["x"], item["y"], scale[0], scale[1], False, 1, color))
        picload.startDecode(getTxt(item["png_destination"]), False)
        ptr = picload.getData()
        if ptr != None:
            del picload
    except Exception as error:
        print("[DisneyDream]: decodePic %s error: %s" % (item, str(error)))
    return ptr
