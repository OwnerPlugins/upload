from enigma import ePoint, eSize
from Components.Pixmap import Pixmap
import os

from .disneyHelper import *


class DisneyHomeCoverHelper:
    def __init__(self, disney):
        self.coverList1 = [("Cover0", skinValueCalculate(100), skinValueCalculate(766)),
                           ("Cover1", skinValueCalculate(490), skinValueCalculate(766)),
                           ("Cover2", skinValueCalculate(880), skinValueCalculate(766)),
                           ("Cover3", skinValueCalculate(1270), skinValueCalculate(766)),
                           ("Cover4", skinValueCalculate(1660), skinValueCalculate(766))]
        for skin_value, x, y in self.coverList1:
            self[skin_value] = Pixmap()

        self.coverList2 = [("Cover5", skinValueCalculate(100), skinValueCalculate(1059)),
                           ("Cover6", skinValueCalculate(490), skinValueCalculate(1059)),
                           ("Cover7", skinValueCalculate(880), skinValueCalculate(1059)),
                           ("Cover8", skinValueCalculate(1270), skinValueCalculate(1059)),
                           ("Cover9", skinValueCalculate(1660), skinValueCalculate(1059))]
        for skin_value, x, y in self.coverList2:
            self[skin_value] = Pixmap()

        self["CoverSelect"] = Pixmap()
        self["CoverSelect"].hide()

        self.disney = disney
        self.callback_list1 = []
        self.callback_list2 = []
        self.dataCover1 = []
        self.dataCover2 = []
        self.last = None

    def setCoverList(self, data, index):
        value_list = self.coverList1 if index == 0 else self.coverList2
        if index is 0:
            self.callback_list1 = []
            self.dataCover1 = data
            callback = self.loadCoverList1
        else:
            self.callback_list2 = []
            self.dataCover2 = data
            callback = self.loadCoverList2
        max = len(data)
        item = 0
        for skin_value, x, y in value_list:
            if max is not 0:
                png_data = data[item]
                png_data.update({"skin_value": skin_value})
                if index == 0:
                    self.callback_list1.append((png_data["skin_value"], png_data["png_destination"]))
                else:
                    self.callback_list2.append((png_data["skin_value"], png_data["png_destination"]))
                if os.path.isfile(png_data["png_destination"]):
                    self[png_data["skin_value"]].instance.setPixmapFromFile(png_data["png_destination"])
                    self[png_data["skin_value"]].show()
                else:
                    self[png_data["skin_value"]].instance.setPixmapFromFile(DISNEY_DEFAULT_COVER_PNG)
                    self[png_data["skin_value"]].show()
                    self.disney.contentDownloader(png_data["url"], png_data, callback=callback)
                max -= 1
            else:
                self[skin_value].hide()
            item += 1

    def loadSelectCoverList(self, index):
        if self.dataCover1:
            self.callback_list1 = []
            start = index - 3 if index >= 4 else 0
            max_range = 5 if len(self.dataCover1) - index >= 5 else len(self.dataCover1) - start
            for skin_value, x, y in self.coverList1:
                if max_range is not 0:
                    png_data = self.dataCover1[start]
                    png_data.update({"skin_value": skin_value})
                    self.callback_list1.append((png_data["skin_value"], png_data["png_destination"]))
                    if os.path.isfile(png_data["png_destination"]):
                        self[png_data["skin_value"]].instance.setPixmapFromFile(png_data["png_destination"])
                        self[png_data["skin_value"]].show()
                    else:
                        self[png_data["skin_value"]].instance.setPixmapFromFile(DISNEY_DEFAULT_COVER_PNG)
                        self[png_data["skin_value"]].show()
                        self.disney.contentDownloader(png_data["url"], png_data, callback=self.loadCoverList1)
                    max_range -= 1
                else:
                    self[skin_value].hide()
                start += 1

    def loadCoverList1(self, item, png):
        if (item["skin_value"], item["png_destination"]) in self.callback_list1 and png:
            self[item["skin_value"]].instance.setPixmapFromFile(png)
            self[item["skin_value"]].show()

    def loadCoverList2(self, item, png):
        if self.last:
            for skin_value, x, y in self.coverList2:
                self[skin_value].hide()
        else:
            if (item["skin_value"], item["png_destination"]) in self.callback_list2 and png:
                self[item["skin_value"]].instance.setPixmapFromFile(png)
                self[item["skin_value"]].show()

    def moveSelectCover(self, index, mode):
        if mode is None:
            for skin_value, x, y in self.coverList1:
                self[skin_value].instance.move(ePoint(x, y - skinValueCalculate(200)))
                self[skin_value].instance.resize(eSize(skinValueCalculate(350), skinValueCalculate(196)))
        if index <= 3:
            skin_value = "Cover" + str(index)
            x = skinValueCalculate(75)
            for i in range(index):
                x = x + skinValueCalculate(390)
            self[skin_value].instance.move(ePoint(x, skinValueCalculate(550)))
            self[skin_value].instance.resize(eSize(skinValueCalculate(400), skinValueCalculate(225)))
            self["CoverSelect"].instance.move(ePoint(x, skinValueCalculate(550)))
            self["CoverSelect"].show()
            if mode == "+" and index is not 0:
                (skin_value, x, y) = self.coverList1[index - 1]
                self[skin_value].instance.move(ePoint(x, y - skinValueCalculate(200)))
                self[skin_value].instance.resize(eSize(skinValueCalculate(350), skinValueCalculate(196)))
            elif mode == "-":
                (skin_value, x, y) = self.coverList1[index + 1]
                self[skin_value].instance.move(ePoint(x, y - skinValueCalculate(200)))
                self[skin_value].instance.resize(eSize(skinValueCalculate(350), skinValueCalculate(196)))

    def hideSelectCover(self):
        for skin_value, x, y in self.coverList1:
            self[skin_value].instance.move(ePoint(x, y))
            self[skin_value].instance.resize(eSize(skinValueCalculate(350), skinValueCalculate(196)))
        self["CoverSelect"].hide()

    def moveCover(self, index):
        if index == 0:
            for skin_value, x, y in self.coverList1:
                self[skin_value].instance.move(ePoint(x, y))
            for skin_value, x, y in self.coverList2:
                self[skin_value].instance.move(ePoint(x, y))
        elif index == 1:
            for skin_value, x, y in self.coverList1:
                self[skin_value].instance.move(ePoint(x, y - skinValueCalculate(200)))
            for skin_value, x, y in self.coverList2:
                self[skin_value].instance.move(ePoint(x, y - skinValueCalculate(200)))

