from enigma import gFont, getDesktop, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP, RT_WRAP, ePicLoad, eTimer, ePoint, eSize
from Components.Pixmap import Pixmap
from Components.Label import Label
from Components.ActionMap import ActionMap
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox

from .disneyHelper import *
from .disneyHelper import _
from .disneyAddProfileScreen import DisneyAddProfileScreen
from .disneyYesNoScreen import DisneyYesNoScreen
from .disneyPinScreen import DisneyPinScreen

import os


class DisneyProfileSpinner:
    def __init__(self):
        # Spinner Timer
        self['TimerSpinner'] = Pixmap()
        self['TimerSpinner'].hide()
        self.timerSpinner = eTimer()
        self.timerSpinnerStatusSpinner = False
        self.timerSpinnerCounter = 1
        self.timerSpinner_conn = self.timerSpinner.timeout.connect(self.loadTimerSpinner)

    def stopTimerSpinner(self):
        self.timerSpinnerStatusSpinner = False

    def startTimerSpinner(self):
        self.timerSpinnerStatusSpinner = True
        self.loadTimerSpinner()

    def loadTimerSpinner(self):
        if self.timerSpinnerStatusSpinner:
            png = "%s/%s.png" % (DISNEY_SPINNER_DIRECTORY, str(self.timerSpinnerCounter))
            self.showTimerSpinner(png)
        else:
            self['TimerSpinner'].hide()

    def showTimerSpinner(self, png):
        self["TimerSpinner"].instance.setPixmapFromFile(png)
        self["TimerSpinner"].show()
        if self.timerSpinnerCounter is not 34:
            self.timerSpinnerCounter += 1
        else:
            self.timerSpinnerCounter = 1
        self.timerSpinner.start(10, True)


class DisneyProfileScreen(Screen, DisneyProfileSpinner):
    def __init__(self, session, disney, data):
        # load skin
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen name="DisneyDream" backgroundColor="#002d3343" position="center,center" size="2560,1440" title="DisneyDream" flags="wfNoBorder">
                           <widget name="DisneyProfileLabel1" position="0,267" size="2560,87" font="DD;64" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="1" valign="center" halign="center"/>
                           <widget name="Cover0" position="133,511" size="467,467" zPosition="1" />
                           <widget name="Cover1" position="640,511" size="467,467" zPosition="1" />
                           <widget name="Cover2" position="1147,511" size="467,467" zPosition="1" />
                           <widget name="Cover3" position="1653,511" size="467,467" zPosition="1" />
                           <widget name="Cover4" position="2160,511" size="467,467" zPosition="1" />
                           <widget name="CoverSelect" position="123,500" size="488,488" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/avatar_select_366x366.png" zPosition="2" />
                           <widget name="ProfileLabel0" position="133,1007" size="467,67" font="DD;51" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="1" valign="center" halign="center"/>
                           <widget name="ProfileLabel1" position="640,1007" size="467,67" font="DD;51" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="1" valign="center" halign="center"/>
                           <widget name="ProfileLabel2" position="1147,1007" size="467,67" font="DD;51" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="1" valign="center" halign="center"/>
                           <widget name="ProfileLabel3" position="1653,1007" size="467,67" font="DD;51" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="1" valign="center" halign="center"/>
                           <widget name="ProfileLabel4" position="2160,1007" size="467,67" font="DD;51" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="1" valign="center" halign="center"/>
                           <widget name="ProfileEditSelect" position="915,1155" size="811,111" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/edit_profile_select_608x83.png" zPosition="2" />
                           <widget name="ProfileEdit" position="920,1160" size="800,100" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/edit_profile_600x75.png" zPosition="3" />
                           <widget name="ProfileDeleteLabel" position="1053,1160" size="667,100" font="DD;53" foregroundColor="#00ffffff" backgroundColor="#002d3343" transparent="1" zPosition="4" valign="center" halign="left"/>
                           <ePixmap position="2240,1267" size="267,147" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/logo_200x110.png" zPosition="99" />
                           <widget name="TimerSpinner" position="1233,673" size="93,93" zPosition="99" />
                           </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """<screen name="DisneyDream" backgroundColor="#002d3343" position="center,center" size="1920,1080" title="DisneyDream" flags="wfNoBorder">
                           <widget name="DisneyProfileLabel1" position="0,200" size="1920,65" font="DD;48" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="1" valign="center" halign="center"/>
                           <widget name="Cover0" position="100,383" size="350,350" zPosition="1" />
                           <widget name="Cover1" position="480,383" size="350,350" zPosition="1" />
                           <widget name="Cover2" position="860,383" size="350,350" zPosition="1" />
                           <widget name="Cover3" position="1240,383" size="350,350" zPosition="1" />
                           <widget name="Cover4" position="1620,383" size="350,350" zPosition="1" />
                           <widget name="CoverSelect" position="92,375" size="366,366" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/avatar_select_366x366.png" zPosition="2" />
                           <widget name="ProfileLabel0" position="100,755" size="350,50" font="DD;38" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="1" valign="center" halign="center"/>
                           <widget name="ProfileLabel1" position="480,755" size="350,50" font="DD;38" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="1" valign="center" halign="center"/>
                           <widget name="ProfileLabel2" position="860,755" size="350,50" font="DD;38" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="1" valign="center" halign="center"/>
                           <widget name="ProfileLabel3" position="1240,755" size="350,50" font="DD;38" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="1" valign="center" halign="center"/>
                           <widget name="ProfileLabel4" position="1620,755" size="350,50" font="DD;38" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="1" valign="center" halign="center"/>
                           <widget name="ProfileEditSelect" position="686,866" size="608,83" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/edit_profile_select_608x83.png" zPosition="2" />
                           <widget name="ProfileEdit" position="690,870" size="600,75" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/edit_profile_600x75.png" zPosition="3" />
                           <widget name="ProfileDeleteLabel" position="780,870" size="500,75" font="DD;40" foregroundColor="#00ffffff" backgroundColor="#002d3343" transparent="1" zPosition="4" valign="center" halign="left"/>
                           <ePixmap position="1680,950" size="200,110" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/logo_200x110.png" zPosition="99" />
                           <widget name="TimerSpinner" position="925,505" size="70,70" zPosition="99" />
                           </screen>
                        """
        else:
            self.skin = """<screen name="DisneyDream" backgroundColor="#002d3343" position="center,center" size="1280,720" title="DisneyDream" flags="wfNoBorder">
                           <widget name="DisneyProfileLabel1" position="0,133" size="1280,43" font="DD;32" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="1" valign="center" halign="center"/>
                           <widget name="Cover0" position="66,255" size="233,233" zPosition="1" />
                           <widget name="Cover1" position="320,255" size="233,233" zPosition="1" />
                           <widget name="Cover2" position="573,255" size="233,233" zPosition="1" />
                           <widget name="Cover3" position="826,255" size="233,233" zPosition="1" />
                           <widget name="Cover4" position="1080,255" size="233,233" zPosition="1" />
                           <widget name="CoverSelect" position="61,250" size="244,244" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/avatar_select_244x244.png" zPosition="2" />
                           <widget name="ProfileLabel0" position="66,503" size="233,33" font="DD;25" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="1" valign="center" halign="center"/>
                           <widget name="ProfileLabel1" position="320,503" size="233,33" font="DD;25" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="1" valign="center" halign="center"/>
                           <widget name="ProfileLabel2" position="573,503" size="233,33" font="DD;25" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="1" valign="center" halign="center"/>
                           <widget name="ProfileLabel3" position="826,503" size="233,33" font="DD;25" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="1" valign="center" halign="center"/>
                           <widget name="ProfileLabel4" position="1080,503" size="233,33" font="DD;25" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="1" valign="center" halign="center"/>
                           <widget name="ProfileEditSelect" position="457,577" size="405,55" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/edit_profile_select_405x55.png" zPosition="2" />
                           <widget name="ProfileEdit" position="460,580" size="400,50" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/edit_profile_400x50.png" zPosition="3" />
                           <widget name="ProfileDeleteLabel" position="520,580" size="333,50" font="DD;26" foregroundColor="#00ffffff" backgroundColor="#002d3343" transparent="1" zPosition="4" valign="center" halign="left"/>
                           <ePixmap position="1120,633" size="133,73" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/logo_133x73.png" zPosition="99" />
                           <widget name="TimerSpinner" position="616,336" size="46,46" zPosition="99" />
                           </screen>
                        """

        Screen.__init__(self, session)

        self['actions'] = ActionMap(['DisneyDream_Actions'],
                                    {'ok': self.keyOk,
                                     'cancel': self.keyCancel,
                                     'left': self.keyLeft,
                                     'right': self.keyRight,
                                     'up': self.keyUp,
                                     'down': self.keyDown,
                                     'info': self.keyInfo,
                                     'power': self.keyPower}, -1)

        DisneyProfileSpinner.__init__(self)

        # Disney Profile
        self.coverList = [("Cover0", skinValueCalculate(100), skinValueCalculate(383)),
                          ("Cover1", skinValueCalculate(480), skinValueCalculate(383)),
                          ("Cover2", skinValueCalculate(860), skinValueCalculate(383)),
                          ("Cover3", skinValueCalculate(1240), skinValueCalculate(383)),
                          ("Cover4", skinValueCalculate(1620), skinValueCalculate(383))]
        for skin_value, x, y in self.coverList:
            self[skin_value] = Pixmap()
        self["CoverSelect"] = Pixmap()
        self["ProfileEdit"] = Pixmap()
        self["ProfileEditSelect"] = Pixmap()
        self["ProfileEditSelect"].hide()

        self.profileLabelList = ["ProfileLabel0", "ProfileLabel1", "ProfileLabel2", "ProfileLabel3", "ProfileLabel4"]
        for skin_value in self.profileLabelList:
            self[skin_value] = Label("")

        self['DisneyProfileLabel1'] = Label(WHO_PROFILE_STR)
        self["ProfileDeleteLabel"] = Label(DELETE_PROFILE_STR)

        self.profile_index = 0
        self.disney = disney
        self.data = data
        self.callback_list = []
        self.focus = 0
        self.avatarCountdown = 0
        self.avatars = []
        self.profile_title_list = []

        self.data.append({"profileName": _(DISNEY_ADD_PROFILE_STR),
                          "profileId": "add",
                          "avatarId": "",
                          "url": None,
                          "png_destination": DISNEY_ADD_AVATAR_PNG,
                          })

        if len(self.data) == 1:
            self["ProfileDeleteLabel"].hide()
            self["ProfileEdit"].hide()
        self.onLayoutFinish.append(self.loadSelectCoverList)

    def loadSelectCoverList(self, index=0):
        if self.data:
            self.callback_list = []
            start = index - 3 if index >= 4 else 0
            max_range = 5 if len(self.data) - index >= 5 else len(self.data) - start
            for skin_value, x, y in self.coverList:
                if max_range is not 0:
                    png_data = self.data[start]
                    if not png_data.get("profileId") == "add" and not png_data.get("profileName") in self.profile_title_list:
                        self.profile_title_list.append(png_data.get("profileName"))
                    png_data.update({"skin_value": skin_value})
                    self.callback_list.append((png_data["skin_value"], png_data["png_destination"]))
                    if png_data["png_destination"]:
                        if os.path.isfile(png_data["png_destination"]):
                            self[png_data["skin_value"]].instance.setPixmapFromFile(png_data["png_destination"])
                            self[png_data["skin_value"]].show()
                        else:
                            self[png_data["skin_value"]].instance.setPixmapFromFile(DISNEY_DEFAULT_AVATAR_PNG)
                            self[png_data["skin_value"]].show()
                            self.disney.contentDownloader(png_data["url"], png_data, callback=self.loadCoverList)
                    else:
                        self[png_data["skin_value"]].instance.setPixmapFromFile(DISNEY_DEFAULT_AVATAR_PNG)
                        self[png_data["skin_value"]].show()
                        self.disney.contentDownloader(png_data["url"], png_data, callback=self.loadCoverList)
                    max_range -= 1
                else:
                    self[skin_value].hide()
                start += 1
            self.setProfileLabel(self.profile_index)

    def loadCoverList(self, item, png):
        if (item["skin_value"], item["png_destination"]) in self.callback_list and png:
            self[item["skin_value"]].instance.setPixmapFromFile(png)
            self[item["skin_value"]].show()

    def moveSelectCover(self, index, mode):
        if mode is None:
            for skin_value, x, y in self.coverList:
                self[skin_value].instance.move(ePoint(x, y))
                self[skin_value].instance.resize(eSize(skinValueCalculate(350), skinValueCalculate(350)))
            return
        if index <= 3:
            skin_value = "Cover" + str(index)
            x = skinValueCalculate(92)
            for i in range(index):
                x = x + skinValueCalculate(380)
            self[skin_value].instance.move(ePoint(x, skinValueCalculate(375)))
            self[skin_value].instance.resize(eSize(skinValueCalculate(366), skinValueCalculate(366)))
            self["CoverSelect"].instance.move(ePoint(x, skinValueCalculate(375)))
            if mode == "+" and index is not 0:
                (skin_value, x, y) = self.coverList[index - 1]
                self[skin_value].instance.move(ePoint(x, y))
                self[skin_value].instance.resize(eSize(skinValueCalculate(350), skinValueCalculate(350)))
            elif mode == "-":
                (skin_value, x, y) = self.coverList[index + 1]
                self[skin_value].instance.move(ePoint(x, y))
                self[skin_value].instance.resize(eSize(skinValueCalculate(350), skinValueCalculate(350)))

    def setProfileLabel(self, index=0):
        if self.data:
            start = index - 3 if index >= 4 else 0
            max_range = 5 if len(self.data) - index >= 5 else len(self.data) - start
            for skin_value in self.profileLabelList:
                if max_range is not 0:
                    profile = self.data[start]
                    self[skin_value].setText(getTxt(profile.get("profileName", "")))
                    max_range -= 1
                else:
                    self[skin_value].setText("")
                start += 1

    def keyOk(self):
        if self.data:
            profileId = self.data[self.profile_index].get("profileId")
            if self.focus is 0:
                if profileId == "add":
                    self.startTimerSpinner()
                    self.disney.getAllAvatar(self.backAllAvatar)
                else:
                    if self.data[self.profile_index].get("isPinProtected"):
                        self.session.openWithCallback(self.backPin, DisneyPinScreen)
                    else:
                        self.disney.setProfile(self.data[self.profile_index], self.backSetProfile)
            elif self.focus is 1 and not profileId == "add":
                profileTitle = getTxt(self.data[self.profile_index].get("profileName"))
                message = profileTitle + " " + DISNEY_DELETE_PROFILE_STR
                self.session.openWithCallback(self.backDeleteMessageBox, DisneyYesNoScreen, message, value=False)

    def keyInfo(self):
        profileId = self.data[self.profile_index].get("profileId")
        if self.focus is 0:
            if not profileId == "add":
                info = self.disney.getAccInfo(self.data[self.profile_index])
                self.session.open(MessageBox, windowTitle="Disney+ Dream", text=getTxt(info), type=MessageBox.TYPE_INFO)

    def backPin(self, pin, faster_exit):
        if faster_exit:
            self.close(None, "", True)
            return
        if pin:
            profile = self.data[self.profile_index]
            self.disney.setProfile(profile, self.backSetProfile, isPinProtected=True, pin=pin)

    def backDeleteMessageBox(self, answer):
        if answer:
            profileId = self.data[self.profile_index].get("profileId")
            self.disney.getDeleteProfile(profileId, self.backDeleteProfile)

    def keyPower(self):
        self.close(False, "reload", True)

    def backDeleteProfile(self, callback):
        self.close(False, "reload", False)

    def backAllAvatar(self, avatars):
        self.avatarCountdown = len(avatars)
        self.avatars = avatars
        x = 0
        for avatar in self.avatars:
            if not avatar.get("avatars"):
                self.disney.getSetBySetId(avatar, self.updateAvatarList)
            else:
                self.avatarCountdown -= 1
            x += 1
        if self.avatarCountdown is 0:
            self.stopTimerSpinner()
            self.session.openWithCallback(self.backAddProfile, DisneyAddProfileScreen, self.disney, self.avatars, self.profile_title_list)

    def updateAvatarList(self, data, item):
        if data:
            self.disney.getAvatarItems(data, item)
        self.avatarCountdown -= 1
        if self.avatarCountdown is 0:
            self.stopTimerSpinner()
            self.session.openWithCallback(self.backAddProfile, DisneyAddProfileScreen, self.disney, self.avatars, self.profile_title_list)

    def backAddProfile(self, callback, faster_exit):
        if faster_exit:
            self.close(None, "", True)
        if callback:
            self.data.insert(0, callback)
            self.focus = 0
            self.profile_index = 0
            self["ProfileEditSelect"].hide()
            self.profile_title_list = []
            self.moveSelectCover(self.profile_index, None)
            self.loadSelectCoverList()
            self.moveSelectCover(self.profile_index, "-")

    def backSetProfile(self, callback):
        if callback:
            self.close(True, "profile", False)
        else:
            self.session.open(MessageBox, windowTitle="Disney+ Dream", text=DISNEY_ERROR_PIN_STR, type=MessageBox.TYPE_ERROR)

    def keyLeft(self):
        if self.data:
            if self.profile_index is not 0 and self.focus is 0:
                self.profile_index -= 1
                self.loadSelectCoverList(self.profile_index)
                self.moveSelectCover(self.profile_index, "-")

    def keyRight(self):
        if self.data:
            if self.focus is 0:
                if self.profile_index < len(self.data) - 1:
                    self.profile_index += 1
                self.loadSelectCoverList(self.profile_index)
                self.moveSelectCover(self.profile_index, "+")

    def keyUp(self):
        if self.focus is 1:
            self.focus -= 1
            self["ProfileEditSelect"].hide()

    def keyDown(self):
        if len(self.data) > 1 and self.focus is 0:
            self.focus += 1
            self["ProfileEditSelect"].show()

    def keyCancel(self):
        self.close(False, "exit", False)

    def createSummary(self):
        return MyDisneySummary
