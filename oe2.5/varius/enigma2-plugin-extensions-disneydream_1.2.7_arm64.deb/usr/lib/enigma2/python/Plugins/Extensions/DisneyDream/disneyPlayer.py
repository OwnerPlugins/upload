# -*- coding:utf-8 -*-
from Screens.InfoBarGenerics import InfoBarSeek, InfoBarNotifications, InfoBarAudioSelection, InfoBarMenu, \
    InfoBarSubtitleSupport, InfoBarShowHide, InfoBarSimpleEventView, InfoBarServiceNotifications
from Components.ServiceEventTracker import ServiceEventTracker, InfoBarBase
from Components.Pixmap import Pixmap, MovingPixmap
from Screens.InfoBarGenerics import InfoBarSeek
from Components.ProgressBar import ProgressBar
from Components.ActionMap import NumberActionMap, ActionMap
from Components.MenuList import MenuList
from Screens.Screen import Screen
from Components.ConfigList import ConfigListScreen
from enigma import gFont, eLabel, addFont, eTimer, eConsoleAppContainer, gPixmapPtr, ePicLoad, loadPNG, getDesktop, \
    eServiceReference, iServiceInformation, iPlayableService, eListboxPythonMultiContent, RT_HALIGN_LEFT, \
    RT_HALIGN_RIGHT, RT_HALIGN_CENTER, RT_VALIGN_CENTER, RT_VALIGN_TOP, RT_WRAP, eListbox, eBackgroundFileEraser, \
    getPrevAsciiCode
from Components.Label import Label
from Components.config import config, configfile, getConfigListEntry
import urllib
import os

from .disneyHelper import *
from .disneyYesNoScreen import DisneyYesNoScreen


class MyInfoBarSeek:
    def __init__(self):
        self.seekMode = None
        self.isShowSeek = None
        self.onHide.append(self.seekHide)
        self.onShow.append(self.isBarShow)

    def seekHide(self):
        self.seekMode = None
        self.isShowSeek = None

    def showInfoBar(self):
        if not self.isShowSeek:
            InfoBarShowHide.toggleShow(self)
            self.isShowSeek = True

    def isBarShow(self):
        self.isShowSeek = True

    def key1(self):
        self.seekMode = "Backward"
        self.keyNumberSeek(1)

    def key3(self):
        self.seekMode = "Forward"
        self.keyNumberSeek(3)

    def key4(self):
        self.seekMode = "Backward"
        self.keyNumberSeek(4)

    def key6(self):
        self.seekMode = "Forward"
        self.keyNumberSeek(6)

    def key7(self):
        self.seekMode = "Backward"
        self.keyNumberSeek(7)

    def key9(self):
        self.seekMode = "Forward"
        self.keyNumberSeek(9)

    def keyNumberSeek(self, number):
        service = self.session.nav.getCurrentService()
        seek = service and service.seek()
        position = seek.getPlayPosition()
        activePos = position[1]
        length = seek.getLength()

        seekOption = None
        newPos = None
        if length and activePos:
            if number == 1:
                newPos = (int(activePos) / 90000 - 30)
                seekOption = 'minus'
            elif number == 3:
                newPos = (int(activePos) / 90000 + 30)
                seekOption = 'plus'
            elif number == 4:
                seekconfig = 4 * 60
                newPos = (int(activePos) / 90000 - seekconfig)
                seekOption = 'minus'
            elif number == 6:
                seekconfig = 4 * 60
                newPos = (int(activePos) / 90000 + seekconfig)
                seekOption = 'plus'
            elif number == 7:
                seekconfig = 8 * 60
                newPos = (int(activePos) / 90000 - seekconfig)
                seekOption = 'minus'
            elif number == 9:
                seekconfig = 8 * 60
                newPos = (int(activePos) / 90000 + seekconfig)
                seekOption = 'plus'

            newPos = int(newPos) * 90000

            if seekOption and newPos:
                if seekOption == 'plus':
                    if int(newPos) < int(length[1]):
                        percent = float(newPos) * 100.0 / float(length[1])
                        seek.seekTo(int(float(length[1]) / 100.0 * percent))
                        self.showInfoBar()
                else:
                    if int(newPos) > 0:
                        percent = float(newPos) * 100.0 / float(length[1])
                        seek.seekTo(int(float(length[1]) / 100.0 * percent))
                        self.showInfoBar()

    def keySeekPlus(self):
        print('Seek +')
        self.seekMode = "Forward"
        service = self.session.nav.getCurrentService()
        seek = service and service.seek()
        position = seek.getPlayPosition()
        activePos = position[1]
        length = seek.getLength()

        if length and activePos:
            seekconfig = 15 * 60
            newPos = int(activePos) / 90000 + seekconfig
            newPos = int(newPos) * 90000
            if int(newPos) < int(length[1]):
                percent = float(newPos) * 100.0 / float(length[1])
                seek.seekTo(int(float(length[1]) / 100.0 * percent))
                self.showInfoBar()

    def keySeekMinus(self):
        print('Seek -')
        self.seekMode = "Backward"
        service = self.session.nav.getCurrentService()
        seek = service and service.seek()
        position = seek.getPlayPosition()
        activePos = position[1]
        length = seek.getLength()

        if activePos:
            seekconfig = 15 * 60
            newPos = int(activePos) / 90000 - seekconfig
            newPos = int(newPos) * 90000
            if int(newPos) > 0:
                percent = float(newPos) * 100.0 / float(length[1])
                seek.seekTo(int(float(length[1]) / 100.0 * percent))


class MyScreenSaver(Screen):
    if DESKTOPSIZE.width() > 1920:
        skin = """<screen position="0,0" size="2560,1440" flags="wfNoBorder" zPosition="9" transparent="0">
            		</screen>"""
    elif DESKTOPSIZE.width() == 1920:
        skin = """
            		<screen position="0,0" size="1920,1080" flags="wfNoBorder" zPosition="9" transparent="0">
            		</screen>"""
    else:
        skin = """
            		<screen position="0,0" size="1280,720" flags="wfNoBorder" zPosition="9" transparent="0">
            		</screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self.skin = MyScreenSaver.skin
        self["setupActions"] = ActionMap(["SetupActions"],
                                         {
                                             "cancel": self.cancel,
                                             "ok": self.cancel
                                         })

    def cancel(self):
        self.close()


class disneyDreamPlayer(Screen, MyInfoBarSeek, InfoBarSimpleEventView, InfoBarNotifications,
                        InfoBarServiceNotifications,
                        InfoBarBase, InfoBarSeek, InfoBarShowHide, InfoBarMenu, InfoBarAudioSelection,
                        InfoBarSubtitleSupport):
    def __init__(self, session, data, disney, season=0, episode=0, continue_play=None, extra_index=0, is_extra=False, content_type="MOVIE"):
        # Skin
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen position="0,0" backgroundColor="#ff111111" name="DisneyDreamPlayer" size="2560,1440" >
                           <ePixmap gradient="#20000000,#60000000,horizontal" position="0,0" size="2560,1440" zPosition="-2"/>
                           <widget name="DisneyLogo" position="53,800" size="444,249" alphatest="blend" zPosition="1" />
                           <widget name="DisneyPoster" position="2133,800" size="400,533" zPosition="2" transparent="1" alphatest="blend" />
                           <widget name="playIcon" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/player/play_100x100.png" position="53,1244" size="133,133" alphatest="blend" zPosition="2" />
                           <widget name="pauseIcon" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/player/pause_100x100.png" position="53,1244" size="133,133" alphatest="blend" zPosition="2" />
                           <widget source="session.CurrentService" position="227,1200" size="1743,80" render="Label" font="DD; 60" halign="center" valign="center" foregroundColor="#00ffffff" zPosition="2" transparent="1" backgroundColor="#07000000">
                             <convert type="ServiceName">Name</convert>
                           </widget>
                           <eLabel name="progress_balken" position="393,1317" size="1427,1" backgroundColor="#00ffffff" zPosition="2" />
                           <widget source="session.CurrentService" render="Progress" foregroundColor="#00e40000" position="393,1315" size="1427,4" transparent="1" zPosition="3">
                            <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="193,1291" size="160,40" render="Label" font="DD; 36" halign="right" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="1860,1291" size="160,40" render="Label" font="DD; 36" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Remaining,Negate</convert>
                           </widget>
                           <widget source="session.CurrentService" position="1036,1349" size="160,40" render="Label" font="DD; 36" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Length</convert>
                           </widget>
                           <widget source="session.CurrentService" render="Label" font="DD; 36" position="2107,1380" size="400,47" halign="right" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServiceInfo">VideoParams</convert>"
                           </widget>
                           <ePixmap position="2240,27" size="267,147" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/logo_200x110.png" zPosition="99" />
                           </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """<screen position="0,0" backgroundColor="#ff111111" name="DisneyDreamPlayer" size="1920,1080" >
                           <ePixmap gradient="#20000000,#60000000,horizontal" position="0,0" size="1920,1080" zPosition="-2"/>
                           <widget name="DisneyLogo" position="40,600" size="333,187" alphatest="blend" zPosition="1" />                  
                           <widget name="DisneyPoster" position="1600,600" size="300,400" zPosition="2" transparent="1" alphatest="blend" />
                           <widget name="playIcon" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/player/play_100x100.png" position="40,933" size="100,100" alphatest="blend" zPosition="2" />
                           <widget name="pauseIcon" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/player/pause_100x100.png" position="40,933" size="100,100" alphatest="blend" zPosition="2" />
                           <widget source="session.CurrentService" position="170,900" size="1307,60" render="Label" font="DD; 45" halign="center" valign="center" foregroundColor="#00ffffff" zPosition="2" transparent="1" backgroundColor="#07000000">
                             <convert type="ServiceName">Name</convert>
                           </widget>
                           <eLabel name="progress_balken" position="295,988" size="1070,1" backgroundColor="#00ffffff" zPosition="2" />
                           <widget source="session.CurrentService" render="Progress" foregroundColor="#00e40000" position="295,986" size="1070,3" transparent="1" zPosition="3">
                            <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="145,968" size="120,30" render="Label" font="DD; 27" halign="right" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="1395,968" size="120,30" render="Label" font="DD; 27" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Remaining,Negate</convert>
                           </widget>
                           <widget source="session.CurrentService" position="770,1012" size="120,30" render="Label" font="DD; 27" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Length</convert>
                           </widget>
                           <widget source="session.CurrentService" render="Label" font="DD; 27" position="1580,1035" size="300,35" halign="right" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServiceInfo">VideoParams</convert>"
                           </widget>
                           <ePixmap position="1680,20" size="200,110" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/logo_200x110.png" zPosition="99" />
                           </screen>"""
        else:
            self.skin = """<screen position="0,0" backgroundColor="#ff111111" name="DisneyDreamPlayer" size="1280,720" >
                           <ePixmap gradient="#20000000,#60000000,horizontal" position="0,0" size="1280,720" zPosition="-2"/>
                           <widget name="DisneyLogo" position="26,400" size="222,124" alphatest="blend" zPosition="1" />
                           <widget name="DisneyPoster" position="1066,400" size="200,266" zPosition="2" transparent="1" alphatest="blend" /><widget name="playIcon" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/player/play_66x66.png" position="26,622" size="66,66" alphatest="blend" zPosition="2" />
                           <widget name="pauseIcon" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/player/pause_66x66.png" position="26,622" size="66,66" alphatest="blend" zPosition="2" />
                           <widget source="session.CurrentService" position="113,600" size="871,40" render="Label" font="DD; 30" halign="center" valign="center" foregroundColor="#00ffffff" zPosition="2" transparent="1" backgroundColor="#07000000">
                             <convert type="ServiceName">Name</convert>
                           </widget>
                           <eLabel name="progress_balken" position="196,658" size="713,1" backgroundColor="#00ffffff" zPosition="2" />
                           <widget source="session.CurrentService" render="Progress" foregroundColor="#00e40000" position="196,657" size="713,2" transparent="1" zPosition="3">
                             <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="96,645" size="80,20" render="Label" font="DD; 18" halign="right" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="930,645" size="80,20" render="Label" font="DD; 18" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Remaining,Negate</convert>
                           </widget>
                           <widget source="session.CurrentService" position="513,674" size="80,20" render="Label" font="DD; 18" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Length</convert>
                           </widget>
                           <widget source="session.CurrentService" render="Label" font="DD; 18" position="1053,690" size="200,23" halign="right" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServiceInfo">VideoParams</convert>"
                           </widget>
                           <ePixmap position="1120,13" size="133,73" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/logo_133x73.png" zPosition="99" />
                           </screen>"""

        Screen.__init__(self, session)
        self["actions"] = ActionMap(
            ['DisneyDream_Player_Actions', 'MediaPlayerSeekActions', 'MoviePlayerActions',
             'DisneyDream_Seek_Actions'], {
                "leavePlayer": self.keyCancel,
                "back": self.keyCancel,
                "menu": self.keyMenu,
                "play": self.keyPause,
                "playPause": self.keyPause,
                "playNext": self.playNext,
                "seek_up": self.keySeekPlus,
                "seek_down": self.keySeekMinus,
                "seek_left": self.keySeekMinus,
                "seek_right": self.keySeekPlus,
                "yellow": self.keyYellow,
                "seek_1": self.key1,
                "seek_3": self.key3,
                "seek_4": self.key4,
                "seek_6": self.key6,
                "seek_7": self.key7,
                "seek_9": self.key9
            }, -1)

        self.content_type = content_type
        self.disney = disney
        self.episode_index = episode
        self.season_index = season
        self.extra_index = extra_index
        self.season_data = None
        self.upNextMillis = 0
        self.introStartMillis = 0
        self.introEndMillis = 0
        self.data = data
        if content_type == "EPISODE":
            self.upNextMillis = self.data["season"][self.season_index]["episodes"][self.episode_index]["upNextMillis"]
            self.introEndMillis = self.data["season"][self.season_index]["episodes"][self.episode_index]["introEndMillis"]
            self.introStartMillis = self.data["season"][self.season_index]["episodes"][self.episode_index]["introStartMillis"]
            self.playhead = self.data["season"][self.season_index]["episodes"][self.episode_index].get("userMeta", {}).get("playhead", 0)
            self.stream_url = self.data["season"][self.season_index]["episodes"][self.episode_index]["contentUrl"]
            self.licenseUrl = self.data["season"][self.season_index]["episodes"][self.episode_index]["licenseUrl"]
            self.stream_title = getTxt(self.data["season"][self.season_index]["episodes"][self.episode_index]["title"])
            self.disney.getPlaybackMediaData(self.data["season"][self.season_index]["episodes"][self.episode_index])
        elif content_type == "EXTRA":
            self.stream_title = getTxt(self.data["familyData"]["extras"][self.extra_index]["title"])
            self.stream_url = self.data["familyData"]["extras"][self.extra_index]["contentUrl"]
            self.licenseUrl = self.data["familyData"]["extras"][self.extra_index]["licenseUrl"]
            self.playhead = 0
        else:
            self.stream_title = getTxt(self.data["title"])
            self.stream_url = self.data["contentUrl"]
            self.licenseUrl = self.data["licenseUrl"]
            self.playhead = self.data.get("userMeta", {}).get("playhead", 0)
            self.disney.getPlaybackMediaData(self.data)
        self.cover_destination = ""
        self.logo_destination = ""
        self.continue_play = continue_play

        self.isPlaying = True
        self.is_load = None
        self.is_extra = is_extra

        self['DisneyPoster'] = Pixmap()
        self['pauseIcon'] = Pixmap()
        self['playIcon'] = Pixmap()
        self['DisneyLogo'] = Pixmap()

        self['pauseIcon'].hide()

        MyInfoBarSeek.__init__(self)
        InfoBarNotifications.__init__(self)
        InfoBarServiceNotifications.__init__(self)
        InfoBarBase.__init__(self)
        InfoBarShowHide.__init__(self)
        InfoBarMenu.__init__(self)
        InfoBarAudioSelection.__init__(self)
        InfoBarSubtitleSupport.__init__(self)
        InfoBarSimpleEventView.__init__(self)
        InfoBarSeek.__init__(self, actionmap="DisneyDream_Seek_Actions")

        self.__event_tracker = ServiceEventTracker(screen=self, eventmap={iPlayableService.evUpdatedInfo: self.__evUpdatedInfo,
                                                   iPlayableService.evUpdatedEventInfo: self.__evUpdatedInfo,
                                                   iPlayableService.evVideoSizeChanged: self.__evUpdatedInfo,
                                                   iPlayableService.evVideoProgressiveChanged: self.__evUpdatedInfo,
                                                   iPlayableService.evVideoFramerateChanged: self.__evUpdatedInfo})

        self.lastService = self.session.nav.getCurrentlyPlayingServiceReference()
        self.session.nav.stopService()

        # Screen Server
        self.SaverTimer = eTimer()
        self.SaverTimer_conn = self.SaverTimer.timeout.connect(self.openScreenSaver)

        # Timer Last Pos
        self.StatusTimerCheckIsPlay = eTimer()
        self.StatusTimerCheckIsPlay_conn = self.StatusTimerCheckIsPlay.timeout.connect(self.startLastPos)

        # Timer check is end
        self.StatusTimerCheckPlayer = eTimer()
        self.StatusTimerCheckPlayer_conn = self.StatusTimerCheckPlayer.timeout.connect(self.checkPlayer)

        # Timer check is Intro
        self.StatusTimerCheckIntro = eTimer()
        self.StatusTimerCheckIntro_conn = self.StatusTimerCheckIntro.timeout.connect(self.checkIntro)

        # Timer check is cast
        self.StatusTimerCheckCast = eTimer()
        self.StatusTimerCheckCast_conn = self.StatusTimerCheckCast.timeout.connect(self.checkCast)

        self.onFirstExecBegin.append(self.startMovie)
        self.onLayoutFinish.append(self.loadPic)

    infobar = property(lambda self: self.__event_tracker.getActiveInfoBar())

    def setAudioStreams(self):
        print("[DisneyDream] setAudioStreams")
        try:
            service = self.session.nav.getCurrentService()
            audioTracks = service and isinstance(self.infobar, InfoBarAudioSelection) and service.audioTracks() or None
            n = audioTracks and audioTracks.getNumberOfTracks() or 0
            if n == 0:
                return
            for idx in range(n):
                info = audioTracks.getTrackInfo(idx)
                languages = info.getLanguage().split('/')[0]
                if languages == config.plugins.disneyDream.languages_code.value:
                    audioTracks.selectTrack(idx)
                    break
        except Exception as error:
            print("[DisneyDream] set audio track error: %s" % str(error))

    def startMovie(self):
        refString = "8739:0:1:0:0:0:0:0:0:0:%s:%s" % (urllib.quote_plus(self.stream_url), self.stream_title)
        ref = eServiceReference(refString)
        ref.setSuburi(self.licenseUrl)
        self.session.nav.playService(ref)

    def __evUpdatedInfo(self):
        print("[DisneyDream] Player evUpdatedInfo")
        ref = self.session.nav.getCurrentlyPlayingServiceReference()
        self.is_load = True
        if ref and self.playhead > 0 and self.continue_play:
            self.StatusTimerCheckIsPlay.start(400, True)
        if self.content_type == "EPISODE":
            if not self.continue_play and self.introEndMillis > 1:
                self.StatusTimerCheckIntro.start(6000, True)
            self.StatusTimerCheckCast.start(1000, True)
        self.StatusTimerCheckPlayer.start(10000, True)
        if config.plugins.disneyDream.player_languages.value and not config.plugins.disneyDream.languages_code.value == "default":
            self.setAudioStreams()
        return

    def checkCast(self):
        service = self.session.nav.getCurrentService()
        seek = service and service.seek()
        position = seek.getPlayPosition()
        activePos = position[1] / 90000
        if activePos > self.upNextMillis:
            if self.episode_index + 1 < len(self.data["season"][self.season_index]["episodes"]) - 1:
                if self.StatusTimerCheckPlayer is not None:
                    self.StatusTimerCheckPlayer.stop()
                self.session.openWithCallback(self.backNextEpisode, DisneySkipScreen, "next", self.cover_destination, self.logo_destination)
        else:
            self.StatusTimerCheckCast.start(1000, True)

    def playNext(self):
        if self.content_type == "EPISODE":
            if self.episode_index + 1 < len(self.data["season"][self.season_index]["episodes"]) - 1:
                if self.StatusTimerCheckPlayer is not None:
                    self.StatusTimerCheckPlayer.stop()
                self.backNextEpisode(True)

    def backNextEpisode(self, callback):
        if callback:
            self.setTimeLine()
            self.episode_index += 1
            if self.episode_index <= len(self.data["season"][self.season_index]["episodes"]) - 1:
                playbackUrl = self.data["season"][self.season_index]["episodes"][self.episode_index].get("playbackUrls")
                if playbackUrl:
                    self.disney.getPlaybackUrl(playbackUrl[0], self.gotPlaybackUrl)
                return
            self.stopDisneyPlayer()
        else:
            self.StatusTimerCheckPlayer.start(1000, True)

    def setTimeLine(self, callback=None):
        service = self.session.nav.getCurrentService()
        seek = service and service.seek()
        position = seek.getPlayPosition()
        if position[1] and self.is_load and not self.is_extra:
            stopPos = position[1] / 90000
            if self.content_type == "EPISODE":
                self.disney.getUpdatePlaybackPosition(self.data["season"][self.season_index]["episodes"][self.episode_index], stopPos, callback)
            elif self.content_type == "MOVIE":
                self.disney.getUpdatePlaybackPosition(self.data, stopPos, callback)

    def gotPlaybackUrl(self, licenseUrl, contentUrl):
        self.data["season"][self.season_index]["episodes"][self.episode_index]["licenseUrl"] = licenseUrl
        self.data["season"][self.season_index]["episodes"][self.episode_index]["contentUrl"] = contentUrl
        self.upNextMillis = self.data["season"][self.season_index]["episodes"][self.episode_index]["upNextMillis"]
        self.introEndMillis = self.data["season"][self.season_index]["episodes"][self.episode_index]["introEndMillis"]
        self.introStartMillis = self.data["season"][self.season_index]["episodes"][self.episode_index]["introStartMillis"]
        self.playhead = self.data["season"][self.season_index]["episodes"][self.episode_index].get("userMeta", {}).get("playhead", 0)
        self.stream_url = contentUrl
        self.licenseUrl = licenseUrl
        self.stream_title = getTxt(self.data["season"][self.season_index]["episodes"][self.episode_index]["title"])
        self.disney.getPlaybackMediaData(self.data["season"][self.season_index]["episodes"][self.episode_index])

        self.session.nav.stopService()
        self.is_load = None
        self.continue_play = False

        self.startMovie()

    def checkIntro(self):
        service = self.session.nav.getCurrentService()
        if service:
            seek = service and service.seek()
            if seek:
                position = seek.getPlayPosition()
                activePos = position[1] / 90000
                if activePos > self.introStartMillis:
                    if self.introEndMillis > activePos:
                        self.session.openWithCallback(self.backIntro, DisneySkipScreen, "intro", self.cover_destination, self.logo_destination)
                    elif not activePos > self.introEndMillis:
                        self.StatusTimerCheckIntro.start(400, True)
                elif not activePos > self.introEndMillis:
                    self.StatusTimerCheckIntro.start(400, True)
            else:
                self.StatusTimerCheckIntro.start(400, True)
        else:
            self.StatusTimerCheckIntro.start(400, True)

    def backIntro(self, callback):
        if callback:
            service = self.session.nav.getCurrentService()
            if service:
                seek = service.seek()
                if seek:
                    pos = self.introEndMillis * 90000
                    seek.seekTo(pos)

    def openScreenSaver(self):
        self.session.open(MyScreenSaver)

    def stopDisneyPlayer(self, callback=None):
        if self.SaverTimer is not None:
            self.SaverTimer.stop()
        self.session.nav.stopService()
        self.session.nav.playService(self.lastService)
        self.close(self.data)

    def startLastPos(self):
        service = self.session.nav.getCurrentService()
        if service:
            seek = service.seek()
            if seek:
                pos = self.playhead * 90000
                seek.seekTo(pos)
                self.playhead = 0

    def setIsPlay(self):
        service = self.session.nav.getCurrentService()
        seek = service and service.seek()
        position = seek.getPlayPosition()
        if position[1] and self.is_load and not self.is_extra:
            self.setTimeLine(callback=self.stopDisneyPlayer)
        else:
            self.stopDisneyPlayer()

    def checkPlayer(self):
        service = self.session.nav.getCurrentService()
        seek = service and service.seek()
        position = seek.getPlayPosition()
        playTime = position[1]
        length = seek.getLength()

        if length and playTime:
            endTime = (int(length[1]) / 90000)
            isTime = (int(playTime) / 90000)

            if isTime >= endTime:
                self.stopPlayer(True)
            else:
                self.StatusTimerCheckPlayer.start(2000, True)
        else:
            self.StatusTimerCheckPlayer.start(2000, True)

    def stopPlayer(self, answer):
        if answer is True:
            if self.StatusTimerCheckPlayer is not None:
                self.StatusTimerCheckPlayer.stop()
            if self.StatusTimerCheckIntro is not None:
                self.StatusTimerCheckIntro.stop()
            if self.StatusTimerCheckCast is not None:
                self.StatusTimerCheckCast.stop()
            self.setIsPlay()

    def keyPause(self):
        if self.isPlaying:
            if self.StatusTimerCheckPlayer is not None:
                self.StatusTimerCheckPlayer.stop()
            self.keyStartPause()
        else:
            self.keyUnPause()

    def keyStartPause(self):
        self.isPlaying = False
        self.pauseService()

    def keyUnPause(self):
        self.isPlaying = True
        self.setSeekState(self.SEEK_STATE_PLAY)
        self.StatusTimerCheckPlayer.start(2000, True)

    def unlockShow(self):
        self['pauseIcon'].hide()
        self['playIcon'].show()
        self.doTimerHide()

    def lockShow(self):
        self['pauseIcon'].show()
        self['playIcon'].hide()
        self.doShow()

    def keyMenu(self):
        self.goMenu(1)
        #self.session.openWithCallback(self.goMenu, enterMenu)

    def keyYellow(self):
        self.goMenu(1)

    def goMenu(self, index):
        if index == 0:
            self.mainMenu()
        elif index == 1:
            self.session.openWithCallback(self.backPlayerConfigScreen, PlayerConfigScreen)

    def backPlayerConfigScreen(self, callback):
        if callback:
            self.setAudioStreams()

    def keyCancel(self):
        self.session.openWithCallback(self.stopPlayer, DisneyYesNoScreen, STOP_PLAYBACK_STR)

    def loadPic(self):
        url = self.data.get("cover_h_image")
        try:
            png_destination = DISNEY_TMP_DIRECTORY + "/Poster-%s.png" % str(url.split("/")[-2]) if url else ""
        except Exception as error:
            png_destination = ""
        self.cover_destination = png_destination
        if not os.path.isfile(png_destination) and url:
            item = {"png_destination": png_destination,
                    "x": 300,
                    "y": 400,
                    "type": "PNG"}
            self.disney.contentDownloader(url, item, callback=self.showDisneyPoster)
        else:
            self.showDisneyPoster(None, png_destination)

        url = self.data.get("title_logo")
        try:
            png_destination = DISNEY_TMP_DIRECTORY + "/hero-logo-%s.png" % str(url.split("/")[-2]) if url else ""
        except Exception as error:
            png_destination = ""
        self.logo_destination = png_destination
        if not os.path.isfile(png_destination) and url:
            item = {"png_destination": png_destination,
                    "x": 400,
                    "y": 225,
                    "type": "PNG"}
            self.disney.contentDownloader(url, item, callback=self.showDisneyLogo)
        else:
            self.showDisneyLogo(None, png_destination)

    def showDisneyLogo(self, item, png):
        if os.path.isfile(png):
            self['DisneyLogo'].instance.setPixmapFromFile(png)
            self['DisneyLogo'].show()

    def showDisneyPoster(self, item, png):
        if os.path.isfile(png):
            self['DisneyPoster'].instance.setPixmapFromFile(png)
            self['DisneyPoster'].show()

    def createSummary(self):
        return MySummary


class MySummary(Screen):
    def __init__(self, session, parent):
        Screen.__init__(self, session)
        self.skinName = "InfoBarMoviePlayerSummary"


def enterPlayerEntry(entry):
    return [entry,
            (eListboxPythonMultiContent.TYPE_TEXT, 20, 0, 790, 30, 0, RT_HALIGN_LEFT | RT_VALIGN_CENTER, entry[0])
            ]


class DisneySkipScreen(Screen):
    def __init__(self, session, mode, cover_destination, logo_destination):
        # Skin
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen position="0,0" backgroundColor="#ff111111" name="DisneyDreamPlayer" size="2560,1440" >
                           <ePixmap gradient="#20000000,#60000000,horizontal" position="0,0" size="2560,1440" zPosition="-2"/>
                           <widget name="DisneyLogo" position="53,800" size="444,249" alphatest="blend" zPosition="1" />
                           <widget name="DisneyPoster" position="2133,800" size="400,533" zPosition="2" transparent="1" alphatest="blend" />
                           <ePixmap position="53,1067" size="667,67" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/select_500x50.png" zPosition="4" />
                           <widget name="DisneyIntro" position="60,1071" size="653,59" foregroundColor="#00ffffff" backgroundColor="#20000000" transparent="0" zPosition="0" font="DD; 43" valign="center" halign="left"/>
                           <widget name="DisneyProgress" position="53,1129" size="667,5" backgroundColor="#00ffffff" zPosition="5" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/progress_667x5.png"/>
                           <widget name="playIcon" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/player/play_100x100.png" position="53,1244" size="133,133" alphatest="blend" zPosition="2" />
                           <widget source="session.CurrentService" position="227,1200" size="1743,80" render="Label" font="DD; 60" halign="center" valign="center" foregroundColor="#00ffffff" zPosition="2" transparent="1" backgroundColor="#07000000">
                             <convert type="ServiceName">Name</convert>
                           </widget>
                           <eLabel name="progress_balken" position="393,1317" size="1427,1" backgroundColor="#00ffffff" zPosition="2" />
                           <widget source="session.CurrentService" render="Progress" foregroundColor="#00e40000" position="393,1315" size="1427,4" transparent="1" zPosition="3">
                            <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="193,1291" size="160,40" render="Label" font="DD; 36" halign="right" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="1860,1291" size="160,40" render="Label" font="DD; 36" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Remaining,Negate</convert>
                           </widget>
                           <widget source="session.CurrentService" position="1036,1349" size="160,40" render="Label" font="DD; 36" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Length</convert>
                           </widget>
                           <widget source="session.CurrentService" render="Label" font="DD; 36" position="2107,1380" size="400,47" halign="right" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServiceInfo">VideoParams</convert>"
                           </widget>
                           <ePixmap position="2240,27" size="267,147" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/logo_200x110.png" zPosition="99" />
                           </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """<screen position="0,0" backgroundColor="#ff111111" name="DisneyDreamPlayer" size="1920,1080" >
                           <ePixmap gradient="#20000000,#60000000,horizontal" position="0,0" size="1920,1080" zPosition="-2"/>
                           <widget name="DisneyLogo" position="40,600" size="333,187" alphatest="blend" zPosition="1" />                  
                           <widget name="DisneyPoster" position="1600,600" size="300,400" zPosition="2" transparent="1" alphatest="blend" />
                           <ePixmap position="40,800" size="500,50" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/select_500x50.png" zPosition="4" />
                           <widget name="DisneyIntro" position="45,803" size="490,44" foregroundColor="#00ffffff" backgroundColor="#20000000" transparent="0" zPosition="0" font="DD; 32" valign="center" halign="left"/>
                           <widget name="DisneyProgress" position="40,847" size="500,4" backgroundColor="#00ffffff" zPosition="5" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/progress_500x4.png"/>
                           <widget name="playIcon" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/player/play_100x100.png" position="40,933" size="100,100" alphatest="blend" zPosition="2" />
                           <widget source="session.CurrentService" position="170,900" size="1307,60" render="Label" font="DD; 45" halign="center" valign="center" foregroundColor="#00ffffff" zPosition="2" transparent="1" backgroundColor="#07000000">
                             <convert type="ServiceName">Name</convert>
                           </widget>
                           <eLabel name="progress_balken" position="295,988" size="1070,1" backgroundColor="#00ffffff" zPosition="2" />
                           <widget source="session.CurrentService" render="Progress" foregroundColor="#00e40000" position="295,986" size="1070,3" transparent="1" zPosition="3">
                            <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="145,968" size="120,30" render="Label" font="DD; 27" halign="right" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="1395,968" size="120,30" render="Label" font="DD; 27" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Remaining,Negate</convert>
                           </widget>
                           <widget source="session.CurrentService" position="770,1012" size="120,30" render="Label" font="DD; 27" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Length</convert>
                           </widget>
                           <widget source="session.CurrentService" render="Label" font="DD; 27" position="1580,1035" size="300,35" halign="right" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServiceInfo">VideoParams</convert>"
                           </widget>
                           <ePixmap position="1680,20" size="200,110" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/logo_200x110.png" zPosition="99" />
                           </screen>"""
        else:
            self.skin = """<screen position="0,0" backgroundColor="#ff111111" name="DisneyDreamPlayer" size="1280,720" >
                           <ePixmap gradient="#20000000,#60000000,horizontal" position="0,0" size="1280,720" zPosition="-2"/>
                           <ePixmap position="26,533" size="333,33" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/select_333x33.png" zPosition="4" />
                           <widget name="DisneyIntro" position="30,535" size="216,29" foregroundColor="#00ffffff" backgroundColor="#20000000" transparent="0" zPosition="0" font="DD; 21" valign="center" halign="left"/>
                           <widget name="DisneyProgress" position="26,564" size="333,2" backgroundColor="#00ffffff" zPosition="5" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/progress_333x2.png"/>   
                           <widget name="DisneyLogo" position="26,400" size="222,124" alphatest="blend" zPosition="1" />
                           <widget name="DisneyPoster" position="1066,400" size="200,266" zPosition="2" transparent="1" alphatest="blend" /><widget name="playIcon" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/player/play_66x66.png" position="26,622" size="66,66" alphatest="blend" zPosition="2" />
                           <widget source="session.CurrentService" position="113,600" size="871,40" render="Label" font="DD; 30" halign="center" valign="center" foregroundColor="#00ffffff" zPosition="2" transparent="1" backgroundColor="#07000000">
                             <convert type="ServiceName">Name</convert>
                           </widget>
                           <eLabel name="progress_balken" position="196,658" size="713,1" backgroundColor="#00ffffff" zPosition="2" />
                           <widget source="session.CurrentService" render="Progress" foregroundColor="#00e40000" position="196,657" size="713,2" transparent="1" zPosition="3">
                             <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="96,645" size="80,20" render="Label" font="DD; 18" halign="right" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="930,645" size="80,20" render="Label" font="DD; 18" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Remaining,Negate</convert>
                           </widget>
                           <widget source="session.CurrentService" position="513,674" size="80,20" render="Label" font="DD; 18" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Length</convert>
                           </widget>
                           <widget source="session.CurrentService" render="Label" font="DD; 18" position="1053,690" size="200,23" halign="right" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServiceInfo">VideoParams</convert>"
                           </widget>
                           <ePixmap position="1120,13" size="133,73" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/logo_133x73.png" zPosition="99" />
                          </screen>"""

        Screen.__init__(self, session)
        self['actions'] = ActionMap(['DisneyDream_Actions'],
                                    {'ok': self.keyOk,
                                     'cancel': self.keyCancel}, -1)

        self['DisneyPoster'] = Pixmap()
        self['playIcon'] = Pixmap()
        self['DisneyLogo'] = Pixmap()
        text = SKIP_INTRO_STR if mode == "intro" else NEXT_EPISODE_STR
        self['DisneyIntro'] = Label(text)
        self['DisneyProgress'] = ProgressBar()

        self.logo_destination = logo_destination
        self.cover_destination = cover_destination
        self.process = 0
        self.mode = mode

        # Timer
        self.StatusTimerProcess = eTimer()
        self.StatusTimerProcess_conn = self.StatusTimerProcess.timeout.connect(self.calculateProgress)

        self.onLayoutFinish.append(self.showCover)
        self.onLayoutFinish.append(self.showLogo)
        self.onLayoutFinish.append(self.calculateProgress)

    def calculateProgress(self):
        if self.process < 100:
            self.process += 1
            self['DisneyProgress'].setValue(self.process)
            self.StatusTimerProcess.start(100, True)
        else:
            if self.mode == "intro":
                self.close(False)
            else:
                self.close(True)

    def keyOk(self):
        self.close(True)

    def keyCancel(self):
        self.close(False)

    def showLogo(self):
        if os.path.isfile(self.logo_destination):
            self['DisneyLogo'].instance.setPixmapFromFile(self.logo_destination)
            self['DisneyLogo'].show()

    def showCover(self):
        if os.path.isfile(self.cover_destination):
            self['DisneyPoster'].instance.setPixmapFromFile(self.cover_destination)
            self['DisneyPoster'].show()

    def createSummary(self):
        return MySummary


class enterMenu(Screen):
    skin = """
		<screen name="DisneyDreamMenu" title="DisneyDreamMenu" position="center,center" size="800,230">
		<eLabel position="0,0" size="800,230" zPosition="-15" backgroundColor="#00000000" transparent="0" />
		<widget name="menu" position="5,20" size="790,200" zPosition="1" transparent="1" scrollbarMode="showOnDemand" />
	    </screen>"""

    def __init__(self, session):
        self.skin = enterMenu.skin
        Screen.__init__(self, session)

        self["actions"] = ActionMap(["DisneyDream_Actions"], {
            "ok": self.keyOK,
            "cancel": self.keyCancel
        }, -1)

        self.genreListe = []
        self.chooseMenuList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseMenuList.l.setFont(0, gFont('DD', 23))
        self.chooseMenuList.l.setItemHeight(30)
        self['menu'] = self.chooseMenuList

        self.onLayoutFinish.append(self.load)

    def load(self):
        self.keyLocked = False
        self.genreListe.append((DISNEY_MENU, 0))
        self.genreListe.append((DISNEY_PLAYER_MENU, 1))
        self.chooseMenuList.setList(list(map(enterPlayerEntry, self.genreListe)))

    def keyOK(self):
        index = self['menu'].getCurrent()[0][1]
        if index == 0:
            # Main Menu
            self.close(0)
        elif index == 1:
            # Player Menu
            self.close(1)

    def keyCancel(self):
        self.close(2)

    def createSummary(self):
        return MySummary


class PlayerConfigScreen(Screen, ConfigListScreen):
    skin = """
		<screen name="DisneyDreamPlayerConfig" title="DisneyDreamPlayerConfig" position="center,center" size="1024,576">
		<eLabel position="0,0" size="1024,576" zPosition="-15" backgroundColor="#00000000" transparent="0" />
		<widget name="config" position="20,40" size="984,526" transparent="1" scrollbarMode="showOnDemand" />
	    </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session

        self["actions"] = ActionMap(["DisneyDream_Actions"], {
            "ok": self.keyOK,
            "cancel": self.keyCancel,
            "left": self.keyLeft,
            "right": self.keyRight
        }, -1)

        self.list = []
        self.createConfigList()
        ConfigListScreen.__init__(self, self.list)
        self.onLayoutFinish.append(self.createConfigList)

    def createConfigList(self):
        self.list = []
        self.list.append(getConfigListEntry(DISNEY_PLAYER_LANGUAGE, config.plugins.disneyDream.languages_code))

    def changedEntry(self):
        self.createConfigList()
        self["config"].setList(self.list)

    def keyLeft(self):
        ConfigListScreen.keyLeft(self)
        self.changedEntry()

    def keyRight(self):
        ConfigListScreen.keyRight(self)
        self.changedEntry()

    def keyOK(self):
        config.plugins.disneyDream.languages_code.save()
        if not config.plugins.disneyDream.languages_code.value == "default":
            config.plugins.disneyDream.player_languages.value = True
            config.plugins.disneyDream.player_languages.save()
        configfile.save()
        self.close(True)

    def keyCancel(self):
        self.close(False)

    def createSummary(self):
        return MySummary
