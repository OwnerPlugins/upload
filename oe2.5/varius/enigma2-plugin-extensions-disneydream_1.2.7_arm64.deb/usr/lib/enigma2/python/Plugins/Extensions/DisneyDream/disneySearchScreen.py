#	-*-	coding:	utf-8	-*-
from enigma import gFont, getDesktop, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP, RT_WRAP, ePicLoad, getPrevAsciiCode, eTimer, eLabel, ePoint, eSize
from Tools.NumericalTextInput import NumericalTextInput
from Components.ActionMap import NumberActionMap
from Components.MenuList import MenuList
from Screens.Screen import Screen
from Components.MultiContent import MultiContentEntryText, MultiContentEntryText, MultiContentEntryPixmapAlphaTest, \
    MultiContentEntryPixmapAlphaBlend
from Tools.LoadPixmap import LoadPixmap
from Components.HTMLComponent import HTMLComponent
from Components.GUIComponent import GUIComponent
from Components.VariableText import VariableText
from Components.Label import Label
from Components.Pixmap import Pixmap

from .disneyHeroLogoAnimation import DisneyHeroLogoGuiAnimation
from .disneyHeroAnimation import DisneyHeroGuiAnimation
from .disneyDetailsMovieScreen import DisneyDetailsMovieScreen
from .disneyDetailsSeasonScreen import DisneyDetailsSeasonScreen


import os

from disneyHelper import *


class DisneySearchSpinner:
    def __init__(self):
        # Spinner Timer
        self['TimerSpinner'] = Pixmap()
        self['TimerSpinner'].hide()
        self.timerSpinner = eTimer()
        self.timerSpinnerStatusSpinner = False
        self.timerSpinnerCounter = 1
        self.timerSpinner_conn = self.timerSpinner.timeout.connect(self.loadTimerSpinner)

    def stopTimerSpinner(self):
        self.timerSpinnerStatusSpinner = False

    def startTimerSpinner(self):
        self.timerSpinnerStatusSpinner = True
        self.loadTimerSpinner()

    def loadTimerSpinner(self):
        if self.timerSpinnerStatusSpinner:
            png = "%s/%s.png" % (DISNEY_SPINNER_DIRECTORY, str(self.timerSpinnerCounter))
            self.showTimerSpinner(png)
        else:
            self['TimerSpinner'].hide()

    def showTimerSpinner(self, png):
        self["TimerSpinner"].instance.setPixmapFromFile(png)
        self["TimerSpinner"].show()
        if self.timerSpinnerCounter is not 34:
            self.timerSpinnerCounter += 1
        else:
            self.timerSpinnerCounter = 1
        self.timerSpinner.start(10, True)


class VirtualKeyBoardList(MenuList):
    def __init__(self, list, enableWrapAround=False):
        MenuList.__init__(self, list, enableWrapAround, eListboxPythonMultiContent)
        if DESKTOPSIZE.width() >= 1920:
            self.l.setFont(0, gFont('DD', 34))
            self.l.setItemHeight(68)
        else:
            self.l.setFont(0, gFont('DD', 22))
            self.l.setItemHeight(45)


class VirtualKeyBoardEntryComponent:
    def __init__(self):
        pass


class DisneySearchScreen(Screen, DisneySearchSpinner, DisneyHeroLogoGuiAnimation, DisneyHeroGuiAnimation):
    def __init__(self, session, disney, **kwargs):
        # load skin
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen backgroundColor="#00000000" flags="wfNoBorder" name="DisneyDream" position="center,center" size="2560,1440" title="DisneyDream">
                           <widget name="DisneyHeroGuiAnimation" position="0,0" size="2560,853" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/hero_default_movie_1920x640.png" zPosition="4" />
                           <widget name="DisneyHeroLogoAnimation" position="133,333" size="533,300" zPosition="5" />
                           <widget name="text" position="736,80" size="1088,80" backgroundColor="#003a3a3a" foregroundColor="#00ffffff" zPosition="2" font="DD; 60" noWrap="1" valign="center" halign="left" />
                           <widget name="list" position="736,200" size="1088,373" backgroundColor="#00161b20" foregroundColor="#00ffffff" selectionDisabled="1" transparent="1" zPosition="3" />
                           <widget name="SearchText" position="53,888" size="2453,67" backgroundColor="#00000000" foregroundColor="#00ffffff" zPosition="2" font="DD; 48" noWrap="1" valign="center" halign="left" />
                           <widget name="Cover0" cornerDia="40" position="53,981" size="467,261" zPosition="1" />
                           <widget name="Cover1" cornerDia="40" position="573,981" size="467,261" zPosition="1" />
                           <widget name="Cover2" cornerDia="40" position="1093,981" size="467,261" zPosition="1" />
                           <widget name="Cover3" cornerDia="40" position="1613,981" size="467,261" zPosition="1" />
                           <widget name="Cover4" cornerDia="40" position="2133,981" size="467,261" zPosition="1" />
                           <widget name="CoverSelect" position="20,963" size="533,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/select_black_400x225.png"  zPosition="3" />
                           <widget name="TimerSpinner" position="1233,673" size="93,93" zPosition="99" />
                           </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """<screen backgroundColor="#00000000" flags="wfNoBorder" name="DisneyDream" position="center,center" size="1920,1080" title="DisneyDream">
                           <widget name="DisneyHeroGuiAnimation" position="0,0" size="1920,640" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/hero_default_movie_1920x640.png" zPosition="4" />                  
                           <widget name="DisneyHeroLogoAnimation" position="100,250" size="400,225" zPosition="5" />
                           <widget name="text" position="552,60" size="816,60" backgroundColor="#003a3a3a" foregroundColor="#00ffffff" zPosition="2" font="DD; 45" noWrap="1" valign="center" halign="left" />
                           <widget name="list" position="552,150" size="816,280" backgroundColor="#00161b20" foregroundColor="#00ffffff" selectionDisabled="1" transparent="1" zPosition="3" />
                           <widget name="SearchText" position="40,666" size="1840,50" backgroundColor="#00000000" foregroundColor="#00ffffff" zPosition="2" font="DD; 36" noWrap="1" valign="center" halign="left" />
                           <widget name="Cover0" position="40,736" size="350,196" zPosition="1" />
                           <widget name="Cover1" position="430,736" size="350,196" zPosition="1" />
                           <widget name="Cover2" position="820,736" size="350,196" zPosition="1" />
                           <widget name="Cover3" position="1210,736" size="350,196" zPosition="1" />
                           <widget name="Cover4" position="1600,736" size="350,196" zPosition="1" />
                           <widget name="CoverSelect" position="15,722" size="400,225" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/select_black_400x225.png"  zPosition="3" />                          
                           <widget name="TimerSpinner" position="925,505" size="70,70" zPosition="99" />
                           </screen>
                        """
        else:
            self.skin = """<screen backgroundColor="#00000000" flags="wfNoBorder" name="DisneyDream" position="center,center" size="1280,720" title="DisneyDream">
                           <widget name="DisneyHeroGuiAnimation" position="0,0" size="1280,426" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/hero_default_movie_1920x640.png" zPosition="4" />
                           <widget name="DisneyHeroLogoAnimation" position="66,166" size="266,150" zPosition="5" />
                           <widget name="text" position="368,40" size="544,40" backgroundColor="#003a3a3a" foregroundColor="#00ffffff" zPosition="2" font="DD; 30" noWrap="1" valign="center" halign="left" />
                           <widget name="list" position="368,100" size="544,186" backgroundColor="#00161b20" foregroundColor="#00ffffff" selectionDisabled="1" transparent="1" zPosition="3" />
                           <widget name="SearchText" position="26,444" size="1226,33" backgroundColor="#00000000" foregroundColor="#00ffffff" zPosition="2" font="DD; 24" noWrap="1" valign="center" halign="left" />
                           <widget name="Cover0" position="26,490" size="233,130" zPosition="1" />
                           <widget name="Cover1" position="286,490" size="233,130" zPosition="1" />
                           <widget name="Cover2" position="546,490" size="233,130" zPosition="1" />
                           <widget name="Cover3" position="806,490" size="233,130" zPosition="1" />
                           <widget name="Cover4" position="1066,490" size="233,130" zPosition="1" />
                           <widget name="CoverSelect" position="10,481" size="266,150" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/select_black_400x225.png"  zPosition="3" />
                           <widget name="TimerSpinner" position="616,336" size="46,46" zPosition="99" /></screen>
                        """

        Screen.__init__(self, session)
        DisneySearchSpinner.__init__(self)
        DisneyHeroLogoGuiAnimation.__init__(self)
        DisneyHeroGuiAnimation.__init__(self)

        self.coverList = [("Cover0", skinValueCalculate(40), skinValueCalculate(736)),
                          ("Cover1", skinValueCalculate(430), skinValueCalculate(736)),
                          ("Cover2", skinValueCalculate(820), skinValueCalculate(736)),
                          ("Cover3", skinValueCalculate(1210), skinValueCalculate(736)),
                          ("Cover4", skinValueCalculate(1600), skinValueCalculate(736))]
        for skin_value, x, y in self.coverList:
            self[skin_value] = Pixmap()

        self["CoverSelect"] = Pixmap()
        self["CoverSelect"].hide()

        self.keys_list = []
        self.selectedKey = 0
        self.smsChar = None
        self.sms = NumericalTextInput(self.smsOK)

        self.search_str = ""

        self.DisneyReloadSearchTimer = eTimer()
        self.DisneyReloadSearchTimer_conn = self.DisneyReloadSearchTimer.timeout.connect(self.checkSearchText)

        self.disney = disney
        self.data = []
        self.callback_list = []
        self.dataCover = []
        self.item_index = 0
        self.callback_hero_index = 0
        self.callback_hero_logo_index = 0
        self.search_active = True
        self.video_active = False
        self.season_data = []
        self.seasonCountdown = 0

        self.key_bg = LoadPixmap(
            '/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/search/%s/vkey_bg.png' % desksize)
        self.key_sel = LoadPixmap(
            '/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/search/%s/vkey_sel.png' % desksize)
        self.key_backspace = LoadPixmap(
            '/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/search/%s/vkey_backspace.png' % desksize)
        self.key_shift_sel = LoadPixmap(
            '/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/search/%s/vkey_shift_sel.png' % desksize)
        self.key_space = LoadPixmap(
            '/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/search/%s/vkey_space.png' % desksize)
        self.key_left = LoadPixmap(
            '/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/search/%s/vkey_left.png' % desksize)
        self.key_right = LoadPixmap(
            '/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/search/%s/vkey_right.png' % desksize)

        self.keyImages = {'BACKSPACE': self.key_backspace,
                          'SPACE': self.key_space,
                          'LEFT': self.key_left,
                          'RIGHT': self.key_right}
        self.keyImagesShift = {'BACKSPACE': self.key_backspace,
                               'SPACE': self.key_space,
                               'LEFT': self.key_left,
                               'RIGHT': self.key_right}

        self['text'] = Input(currPos=len(kwargs.get('text', '').decode('utf-8', 'ignore')), allMarked=False, **kwargs)
        self['list'] = VirtualKeyBoardList([])
        self['SearchText'] = Label("")
        self['SearchText'].hide()
        self['actions'] = NumberActionMap(['OkCancelActions',
                                           'WizardActions',
                                           'ColorActions',
                                           'KeyboardInputActions',
                                           'InputBoxActions',
                                           "MenuActions",
                                           "DisneyDream_Actions",
                                           'InputAsciiActions'], {'gotAsciiCode': self.keyGotAscii,
                                                                  'ok': self.okClicked,
                                                                  'OKLong': self.okLongClicked,
                                                                  'cancel': self.exit,
                                                                  'left': self.left,
                                                                  'right': self.right,
                                                                  'up': self.up,
                                                                  'down': self.down,
                                                                  'deleteBackward': self.backClicked,
                                                                  'deleteForward': self.forwardClicked,
                                                                  'power': self.keyPower,
                                                                  'back': self.exit,
                                                                  'pageUp': self.cursorRight,
                                                                  'pageDown': self.cursorLeft,
                                                                  '1': self.keyNumberGlobal,
                                                                  '2': self.keyNumberGlobal,
                                                                  '3': self.keyNumberGlobal,
                                                                  '4': self.keyNumberGlobal,
                                                                  '5': self.keyNumberGlobal,
                                                                  '6': self.keyNumberGlobal,
                                                                  '7': self.keyNumberGlobal,
                                                                  '8': self.keyNumberGlobal,
                                                                  '9': self.keyNumberGlobal,
                                                                  '0': self.keyNumberGlobal}, -2)
        self.setLang()
        self.onExecBegin.append(self.setKeyboardModeAscii)
        self.onLayoutFinish.append(self.buildVirtualKeyBoard)
        self.onLayoutFinish.append(self.startSearchTimer)
        self.onClose.append(self.__onClose)

    def __onClose(self):
        self.sms.timer.stop()

    def setLang(self):
        self.keys_list = [[u'a',
                           u'b',
                           u'c',
                           u'd',
                           u'e',
                           u'f',
                           u'g',
                           u'h',
                           u'i',
                           u'j',
                           u'k',
                           u'l'
                           ],
                          [u'm',
                           u'n',
                           u'o',
                           u'p',
                           u'q',
                           u'r',
                           u's',
                           u't',
                           u'u',
                           u'v',
                           u'w',
                           u'x'],
                          [u'y',
                           u'z',
                           u'1',
                           u'2',
                           u'3',
                           u'4',
                           u'5',
                           u'6',
                           u'7',
                           u'8',
                           u'9',
                           u'0'],
                          [u'SPACE',
                           u'BACKSPACE',
                           u'LEFT',
                           u'RIGHT'
                           ]
                          ]

    def virtualKeyBoardEntryComponent(self, keys):
        # w, h = skin.parameters.get('VirtualKeyboard', (45, 45))
        if DESKTOPSIZE.width() >= 1920:
            w = 68
            h = 68
        else:
            w = 45
            h = 45
        key_bg_width = self.key_bg and self.key_bg.size().width() or w
        key_images = self.keyImagesShift or self.keyImages
        res = [keys]
        text = []
        x = 0
        for key in keys:
            png = key_images.get(key, None)
            if png:
                width = png.size().width()
                res.append(MultiContentEntryPixmapAlphaTest(pos=(x, 0), size=(width, h), png=png))
            else:
                width = key_bg_width
                res.append(MultiContentEntryPixmapAlphaTest(pos=(x, 0), size=(width, h), png=self.key_bg))
                text.append(MultiContentEntryText(pos=(x, 0), size=(width, h), font=0, text=key.encode('utf-8'),
                                                  flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER))
            x += width

        return res + text

    def buildVirtualKeyBoard(self):
        self.previousSelectedKey = None
        self.list = []
        self.max_key = 0
        for keys in self.keys_list:
            self.list.append(self.virtualKeyBoardEntryComponent(keys))
            self.max_key += len(keys)

        self.max_key -= 1
        self.markSelectedKey()
        return

    def markSelectedKey(self):
        # w, h = skin.parameters.get('VirtualKeyboard', (45, 45))
        if DESKTOPSIZE.width() >= 1920:
            w = 68
            h = 68
        else:
            w = 45
            h = 45
        if self.previousSelectedKey is not None:
            self.list[self.previousSelectedKey / 12] = self.list[self.previousSelectedKey / 12][:-1]
        width = self.key_sel.size().width()
        try:
            x = self.list[self.selectedKey / 12][self.selectedKey % 12 + 1][1]
        except IndexError:
            self.selectedKey = self.max_key
            x = self.list[self.selectedKey / 12][self.selectedKey % 12 + 1][1]

        self.list[self.selectedKey / 12].append(
            MultiContentEntryPixmapAlphaTest(pos=(x, 0), size=(width, h), png=self.key_sel))
        self.previousSelectedKey = self.selectedKey
        self['list'].setList(self.list)
        return

    def backClicked(self):
        self['text'].deleteBackward()
        self.setSearchText()

    def forwardClicked(self):
        self['text'].deleteForward()
        self.setSearchText()

    def okClicked(self):
        if self.search_active:
            self.smsChar = None
            text = self.keys_list[self.selectedKey / 12][
                self.selectedKey % 12].encode('UTF-8')
            if text == 'BACKSPACE':
                self['text'].deleteBackward()
            elif text == 'SPACE':
                self['text'].char(' '.encode('UTF-8'))
            elif text == 'LEFT':
                self['text'].left()
            elif text == 'RIGHT':
                self['text'].right()
            else:
                self['text'].char(text)
            self.setSearchText()
            return
        else:
            if self.data:
                self.stopHeroMoviePlayer()
                video = self.data[self.item_index]
                if video.get("mediaType") == "MOVIE" and not video.get("seriesId"):
                    if video.get("encodedFamilyId"):
                        self.startTimerSpinner()
                        self.disney.getVideoBundle(video.get("encodedFamilyId"), self.backReadFamilyId, video)
                elif video.get("mediaType") == "SERIES" or video.get("encodedSeriesId"):
                    self.startTimerSpinner()
                    self.series = video
                    self.disney.getSeriesBundle(video.get("encodedSeriesId"), self.backSeriesBundle)

    def backSeriesBundle(self, seasons, family, series):
        if seasons:
            self.season_data = []
            self.family_data = family
            self.seasonCountdown = len(seasons)
            if series:
                self.series = series
            for season in seasons:
                season.update({"episodes": []})
                self.disney.getSeriesEpisodes(season.get("seasonId"), self.backReadEpisode, season)
        else:
            self.stopTimerSpinner()

    def backReadEpisode(self, callback):
        self.seasonCountdown -= 1
        self.season_data.append(callback)
        if self.seasonCountdown is 0:
            self.season_data = sorted(self.season_data, key=lambda item: (item["seasonSequenceNumber"]))
            self.series.update({"season": self.season_data})
            self.series.update({"familyData": self.family_data})
            self.disney.getContinueWatchingSeries(self.series.get("encodedSeriesId"), self.callbackContinueWatchingSeries, self.series)

    def backReadFamilyId(self, video):
        self.disney.getContinueWatching(video.get("encodedFamilyId"), self.callbackContinueWatching, video)

    def fasterExit(self, callback=None):
        if callback:
            self.close(True)

    def callbackContinueWatching(self, video):
        self.stopTimerSpinner()
        self.session.openWithCallback(self.fasterExit, DisneyDetailsMovieScreen, video, self.disney)

    def callbackContinueWatchingSeries(self, video):
        self.seasonCountdown = len(video["season"])
        for season in video["season"]:
            self.disney.getContinueWatchingSeason(self.callbackContinueWatchingSeason, season)

    def callbackContinueWatchingSeason(self, season):
        self.seasonCountdown -= 1
        if self.seasonCountdown is 0:
            self.stopTimerSpinner()
            self.session.openWithCallback(self.fasterExit, DisneyDetailsSeasonScreen, self.series, self.disney)

    def okLongClicked(self):
        if not self.video_active:
            self.smsChar = None
            text = self.keys_list[self.selectedKey / 12][
                self.selectedKey % 12].encode('UTF-8')
            if text == 'BACKSPACE':
                self['text'].deleteAllChars()
                self['text'].update()
            self.setSearchText()
            return

    def ok(self):
        search_str = self['text'].getText().encode('UTF-8')
        self.setSearchText()
        self.startTimerSpinner()
        self.disney.getSearchVideos(search_str, self.cbReceivedSearchResult)

    def startSearchTimer(self):
        self.DisneyReloadSearchTimer.start(4000, True)

    def checkSearchText(self):
        search_str = self['text'].getText().encode('UTF-8')
        if not search_str == self.search_str and not search_str == "":
            self.search_str = search_str
            self.startTimerSpinner()
            self.disney.getSearchVideos(search_str, self.cbReceivedSearchResult)
        else:
            self.stopTimerSpinner()
        self.DisneyReloadSearchTimer.start(4000, True)

    def cbReceivedSearchResult(self, videos):
        self.stopTimerSpinner()
        self.data = videos
        if self.data:
            self.__build_video_gui()

    def __build_video_gui(self):
        cover_data = []
        if self.data:
            for video in self.data:
                try:
                    file_destination = "%s/poster-%s.png" % (DISNEY_TMP_DIRECTORY, str(video.get("tile_image").split("/")[-2])) if video.get("tile_image") else ""
                except:
                    file_destination = DISNEY_DEFAULT_COVER_PNG
                item = {"png_destination": file_destination,
                        "url": video.get("tile_image"),
                        "x": 350,
                        "y": 196,
                        "type": "PNG",
                        "title": video.get("title")}
                cover_data.append(item)
        self.item_index = 0
        self.moveSelectCover(self.item_index, None)
        self.setCoverList(cover_data)
        if self.video_active:
            self.setCoverList(cover_data)
            self.moveSelectCover(self.item_index, "+")
            self.update_disney_hero_gui()
            self.update_disney_hero_logo()

    def setCoverList(self, data):
        self.callback_list = []
        self.dataCover = data
        max = len(data)
        item = 0
        for skin_value, x, y in self.coverList:
            if max is not 0:
                png_data = data[item]
                png_data.update({"skin_value": skin_value})
                self.callback_list.append((png_data["skin_value"], png_data["png_destination"]))
                if os.path.isfile(png_data["png_destination"]):
                    self[png_data["skin_value"]].instance.setPixmapFromFile(png_data["png_destination"])
                    self[png_data["skin_value"]].show()
                else:
                    self[png_data["skin_value"]].instance.setPixmapFromFile(DISNEY_DEFAULT_COVER_PNG)
                    self[png_data["skin_value"]].show()
                    self.disney.contentDownloader(png_data["url"], png_data, callback=self.loadCoverList)
                max -= 1
            else:
                self[skin_value].hide()
            item += 1

    def loadSelectCoverList(self, index):
        if self.dataCover:
            self.callback_list = []
            start = index - 3 if index >= 4 else 0
            max_range = 5 if len(self.dataCover) - index >= 5 else len(self.dataCover) - start
            for skin_value, x, y in self.coverList:
                if max_range is not 0:
                    png_data = self.dataCover[start]
                    png_data.update({"skin_value": skin_value})
                    self.callback_list.append((png_data["skin_value"], png_data["png_destination"]))
                    if os.path.isfile(png_data["png_destination"]):
                        self[png_data["skin_value"]].instance.setPixmapFromFile(png_data["png_destination"])
                        self[png_data["skin_value"]].show()
                    else:
                        self[png_data["skin_value"]].instance.setPixmapFromFile(DISNEY_DEFAULT_COVER_PNG)
                        self[png_data["skin_value"]].show()
                        self.disney.contentDownloader(png_data["url"], png_data, callback=self.loadCoverList)
                    max_range -= 1
                else:
                    self[skin_value].hide()
                start += 1

    def moveSelectCover(self, index, mode):
        if mode is None:
            for skin_value, x, y in self.coverList:
                self[skin_value].instance.move(ePoint(x, y))
                self[skin_value].instance.resize(eSize(skinValueCalculate(350), skinValueCalculate(196)))
            self["CoverSelect"].instance.move(ePoint(skinValueCalculate(15), skinValueCalculate(722)))
            return
        if index <= 3:
            skin_value = "Cover" + str(index)
            x = skinValueCalculate(15)
            for i in range(index):
                x = x + skinValueCalculate(390)
            self[skin_value].instance.move(ePoint(x, skinValueCalculate(722)))
            self[skin_value].instance.resize(eSize(skinValueCalculate(400), skinValueCalculate(225)))
            self["CoverSelect"].instance.move(ePoint(x, skinValueCalculate(722)))
            self["CoverSelect"].show()
            if mode == "+" and index is not 0:
                (skin_value, x, y) = self.coverList[index - 1]
                self[skin_value].instance.move(ePoint(x, y))
                self[skin_value].instance.resize(eSize(skinValueCalculate(350), skinValueCalculate(196)))
            elif mode == "-":
                (skin_value, x, y) = self.coverList[index + 1]
                self[skin_value].instance.move(ePoint(x, y))
                self[skin_value].instance.resize(eSize(skinValueCalculate(350), skinValueCalculate(196)))

    def loadCoverList(self, item, png):
        if (item["skin_value"], item["png_destination"]) in self.callback_list and png and self.item_index is not 2:
            self[item["skin_value"]].instance.setPixmapFromFile(png)
            self[item["skin_value"]].show()

    def doHideCoverList(self):
        for skin_value, x, y in self.coverList:
            self[skin_value].hide()

    def setSearchText(self):
        txt = DISNEY_SEARCH_RESULT_STR + " " + self['text'].getText().encode('UTF-8')
        self['SearchText'].setText(txt)

    def exit(self):
        self.stopHeroMoviePlayer()
        self.close(False)

    def keyPower(self):
        self.close(True)

    def cursorRight(self):
        if not self.video_active:
            self['text'].right()

    def cursorLeft(self):
        if not self.video_active:
            self['text'].left()

    def left(self):
        if self.search_active:
            self.smsChar = None
            self.selectedKey = self.selectedKey / 12 * 12 + (self.selectedKey + 11) % 12
            self.markSelectedKey()
            return
        else:
            if self.item_index is not 0:
                self.item_index -= 1
                self.loadSelectCoverList(self.item_index)
                self.moveSelectCover(self.item_index, "-")
                self.update_disney_hero_gui()
                self.update_disney_hero_logo()

    def right(self):
        if self.search_active:
            self.smsChar = None
            selectedKey = self.selectedKey / 12 * 12 + (self.selectedKey + 1) % 12
            self.selectedKey = selectedKey
            self.markSelectedKey()
            return
        else:
            if self.item_index + 1 < len(self.data):
                self.item_index += 1
                self.loadSelectCoverList(self.item_index)
                self.moveSelectCover(self.item_index, "+")
                self.update_disney_hero_gui()
                self.update_disney_hero_logo()

    def up(self):
        if self.search_active:
            self.smsChar = None
            self.selectedKey -= 12
            if self.selectedKey < 0:
                self.selectedKey = self.max_key / 12 * 12 + self.selectedKey % 12
                if self.selectedKey > self.max_key:
                    self.selectedKey -= 12
            self.markSelectedKey()
        elif self.video_active:
            if self.data:
                self.search_active = True
                self.video_active = False
                self['list'].show()
                self['text'].show()
                self["CoverSelect"].hide()
                self['SearchText'].hide()
                self.item_index = 0
                self.stopTimerHeroLogoGuiAnimation()
                self.stopTimerHeroGuiAnimation()
                self.stopHeroMoviePlayer()
                self.moveSelectCover(self.item_index, None)

    def down(self):
        if self.search_active:
            self.smsChar = None
            self.selectedKey += 12
            if self.selectedKey > self.max_key:
                if self.data:
                    self.search_active = False
                    self.video_active = True
                    self['list'].hide()
                    self['text'].hide()
                    self['SearchText'].show()
                    self.loadSelectCoverList(self.item_index)
                    self.moveSelectCover(self.item_index, "+")
                    self.update_disney_hero_gui()
                    self.update_disney_hero_logo()
            else:
                self.markSelectedKey()
            return

    def keyNumberGlobal(self, number):
        if not self.video_active:
            self.smsChar = self.sms.getKey(number)
            self.selectAsciiKey(self.smsChar)
            self.setSearchText()

    def smsOK(self):
        if self.smsChar and self.selectAsciiKey(self.smsChar):
            print 'pressing ok now'
            self.okClicked()

    def keyGotAscii(self):
        self.smsChar = None
        if self.selectAsciiKey(str(unichr(getPrevAsciiCode()).encode('utf-8'))):
            self.okClicked()
        return

    def selectAsciiKey(self, char):
        if char == ' ':
            self['text'].char(' '.encode('UTF-8'))
            return False
        selkey = 0
        for keys in self.keys_list:
            for key in keys:
                if key == char:
                    self.selectedKey = selkey
                    self.markSelectedKey()
                    return True
                selkey += 1
        self.setSearchText()

        return False

    def update_disney_hero_gui(self):
        if self.data:
            self.stopTimerHeroGuiAnimation()
            video = self.data[self.item_index]
            #url = video.get("background_hero_image")
            url = video.get("background_details_image")
            try:
                png_destination = DISNEY_TMP_DIRECTORY + "/hero-brand-%s.png" % str(url.split("/")[-2])
            except Exception as error:
                png_destination = ""
            if not os.path.isfile(png_destination) and url:
                self.callback_hero_index += 1
                item = {"png_destination": png_destination,
                        "callback": self.callback_hero_index,
                        "x": 1920,
                        "y": 640,
                        "type": "PNG"}
                self.disney.contentDownloader(url, item, callback=self.showHeroGui)
            else:
                if os.path.isfile(png_destination) and self.video_active:
                    self.startTimerHeroGuiAnimation(png_destination, video.get("videoArt"))

    def showHeroGui(self, item, png):
        if os.path.isfile(png) and item.get("callback") == self.callback_hero_index and self.video_active:
            video = self.data[self.item_index]
            self.startTimerHeroGuiAnimation(png, video.get("videoArt"))

    def update_disney_hero_logo(self):
        self.hideHeroLogoGuiAnimation()
        if self.data:
            self.stopTimerHeroLogoGuiAnimation()
            video = self.data[self.item_index]
            url = video.get("title_logo")
            try:
                png_destination = DISNEY_TMP_DIRECTORY + "/hero-logo-%s.png" % str(url.split("/")[-2]) if url else ""
            except:
                png_destination = ""
            if not os.path.isfile(png_destination) and url:
                self.callback_hero_logo_index += 1
                item = {"png_destination": png_destination,
                        "callback": self.callback_hero_logo_index,
                        "x": 400,
                        "y": 225,
                        "type": "PNG"}
                self.disney.contentDownloader(url, item, callback=self.showHeroLogo)
            else:
                if os.path.isfile(png_destination) and self.video_active:
                    self.startTimerHeroLogoGuiAnimation(png_destination)

    def showHeroLogo(self, item, png):
        if os.path.isfile(png) and item.get("callback") == self.callback_hero_logo_index and self.video_active:
            self.startTimerHeroLogoGuiAnimation(png)
        else:
            self.stopTimerHeroLogoGuiAnimation()

    def createSummary(self):
        return MyDisneySummary


class Input(VariableText, HTMLComponent, GUIComponent, NumericalTextInput):
    TEXT = 0
    PIN = 1
    NUMBER = 2

    def __init__(self, text='', maxSize=False, visible_width=False, type=TEXT, currPos=0, allMarked=True):
        NumericalTextInput.__init__(self, self.right)
        GUIComponent.__init__(self)
        VariableText.__init__(self)
        self.type = type
        self.allmarked = allMarked and text != '' and type != self.PIN
        self.maxSize = maxSize
        self.currPos = currPos
        self.visible_width = visible_width
        self.offset = 0
        self.overwrite = maxSize
        self.setText(text)

    def __len__(self):
        return len(self.text)

    def update(self):
        if self.visible_width:
            if self.currPos < self.offset:
                self.offset = self.currPos
            if self.currPos >= self.offset + self.visible_width:
                if self.currPos == len(self.Text):
                    self.offset = self.currPos - self.visible_width
                else:
                    self.offset = self.currPos - self.visible_width + 1
            if self.offset > 0 and self.offset + self.visible_width > len(self.Text):
                self.offset = max(0, len(self.Text) - self.visible_width)
        if self.allmarked:
            self.setMarkedPos(-2)
        else:
            self.setMarkedPos(self.currPos - self.offset)
        if self.visible_width:
            if self.type == self.PIN:
                self.text = ''
                for x in self.Text[self.offset:self.offset + self.visible_width]:
                    self.text += x == ' ' and ' ' or '*'

            else:
                self.text = self.Text[self.offset:self.offset + self.visible_width].encode('utf-8') + ' '
        elif self.type == self.PIN:
            self.text = ''
            for x in self.Text:
                self.text += x == ' ' and ' ' or '*'

        else:
            self.text = self.Text.encode('utf-8') + ' '

    def setText(self, text):
        if not len(text):
            self.currPos = 0
            self.Text = u''
        elif isinstance(text, str):
            self.Text = text.decode('utf-8', 'ignore')
        else:
            self.Text = text
        self.update()

    def getText(self):
        return self.Text.encode('utf-8')

    def createWidget(self, parent):
        if self.allmarked:
            return eLabel(parent, -2)
        else:
            return eLabel(parent, self.currPos - self.offset)

    def getSize(self):
        s = self.instance.calculateSize()
        return (s.width(), s.height())

    def markAll(self):
        self.allmarked = True
        self.update()

    def innerright(self):
        if self.allmarked:
            self.currPos = 0
            self.allmarked = False
        elif self.maxSize:
            if self.currPos < len(self.Text) - 1:
                self.currPos += 1
        elif self.currPos < len(self.Text):
            self.currPos += 1

    def right(self):
        if self.type == self.TEXT:
            self.timeout()
        self.innerright()
        self.update()

    def left(self):
        if self.type == self.TEXT:
            self.timeout()
        if self.allmarked:
            if self.maxSize:
                self.currPos = len(self.Text) - 1
            else:
                self.currPos = len(self.Text)
            self.allmarked = False
        elif self.currPos > 0:
            self.currPos -= 1
        self.update()

    def up(self):
        self.allmarked = False
        if self.type == self.TEXT:
            self.timeout()
        if self.currPos == len(self.Text) or self.Text[self.currPos] == '9' or self.Text[self.currPos] == ' ':
            newNumber = '0'
        else:
            newNumber = str(int(self.Text[self.currPos]) + 1)
        self.Text = self.Text[0:self.currPos] + newNumber + self.Text[self.currPos + 1:]
        self.update()

    def down(self):
        self.allmarked = False
        if self.type == self.TEXT:
            self.timeout()
        if self.currPos == len(self.Text) or self.Text[self.currPos] == '0' or self.Text[self.currPos] == ' ':
            newNumber = '9'
        else:
            newNumber = str(int(self.Text[self.currPos]) - 1)
        self.Text = self.Text[0:self.currPos] + newNumber + self.Text[self.currPos + 1:]
        self.update()

    def home(self):
        self.allmarked = False
        if self.type == self.TEXT:
            self.timeout()
        self.currPos = 0
        self.update()

    def end(self):
        self.allmarked = False
        if self.type == self.TEXT:
            self.timeout()
        if self.maxSize:
            self.currPos = len(self.Text) - 1
        else:
            self.currPos = len(self.Text)
        self.update()

    def insertChar(self, ch, pos=False, owr=False, ins=False):
        if isinstance(ch, str):
            ch = ch.decode('utf-8', 'ignore')
        if not pos:
            pos = self.currPos
        if ins and not self.maxSize:
            self.Text = self.Text[0:pos] + ch + self.Text[pos:]
        elif owr or self.overwrite:
            self.Text = self.Text[0:pos] + ch + self.Text[pos + 1:]
        elif self.maxSize:
            self.Text = self.Text[0:pos] + ch + self.Text[pos:-1]
        else:
            self.Text = self.Text[0:pos] + ch + self.Text[pos:]

    def deleteChar(self, pos):
        if not self.maxSize:
            self.Text = self.Text[0:pos] + self.Text[pos + 1:]
        elif self.overwrite:
            self.Text = self.Text[0:pos] + u' ' + self.Text[pos + 1:]
        else:
            self.Text = self.Text[0:pos] + self.Text[pos + 1:] + u' '

    def deleteAllChars(self):
        if self.maxSize:
            self.Text = u' ' * len(self.Text)
        else:
            self.Text = u''
        self.currPos = 0
        self.update()

    def tab(self):
        if self.type == self.TEXT:
            self.timeout()
        if self.allmarked:
            self.deleteAllChars()
            self.allmarked = False
        else:
            self.insertChar(u' ', self.currPos, False, True)
            self.innerright()
        self.update()

    def delete(self):
        if self.type == self.TEXT:
            self.timeout()
        if self.allmarked:
            self.deleteAllChars()
            self.allmarked = False
        else:
            self.deleteChar(self.currPos)
            if self.maxSize and self.overwrite:
                self.innerright()
        self.update()

    def deleteBackward(self):
        if self.type == self.TEXT:
            self.timeout()
        if self.allmarked:
            self.deleteAllChars()
            self.allmarked = False
        elif self.currPos > 0:
            self.deleteChar(self.currPos - 1)
            if not self.maxSize and self.offset > 0:
                self.offset -= 1
            self.currPos -= 1
        self.update()

    def deleteForward(self):
        if self.type == self.TEXT:
            self.timeout()
        if self.allmarked:
            self.deleteAllChars()
            self.allmarked = False
        else:
            self.deleteChar(self.currPos)
        self.update()

    def toggleOverwrite(self):
        if self.type == self.TEXT:
            self.timeout()
        self.overwrite = not self.overwrite
        self.update()

    def handleAscii(self, code):
        if self.type == self.TEXT:
            self.timeout()
        if self.allmarked:
            self.deleteAllChars()
            self.allmarked = False
        self.insertChar(unichr(code), self.currPos, False, False)
        self.innerright()
        self.update()

    def number(self, number):
        if self.type == self.TEXT:
            owr = self.lastKey == number
            newChar = self.getKey(number)
        elif self.type == self.PIN or self.type == self.NUMBER:
            owr = False
            newChar = str(number)
        if self.allmarked:
            self.deleteAllChars()
            self.allmarked = False
        self.insertChar(newChar, self.currPos, owr, False)
        if self.type == self.PIN or self.type == self.NUMBER:
            self.innerright()
        self.update()

    def char(self, char):
        if self.allmarked:
            self.deleteAllChars()
            self.allmarked = False
        self.insertChar(char)
        self.innerright()
        self.update()
