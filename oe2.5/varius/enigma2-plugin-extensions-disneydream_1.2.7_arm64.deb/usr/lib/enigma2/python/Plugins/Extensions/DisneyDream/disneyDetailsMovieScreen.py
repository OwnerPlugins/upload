#	-*-	coding:	utf-8	-*-#
from enigma import gFont, getDesktop, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP, RT_WRAP, ePicLoad, eTimer, gPixmapPtr, ePoint, eSize, eServiceReference
from Components.MultiContent import MultiContentEntryText
from Components.ActionMap import ActionMap
from Screens.Screen import Screen
from Components.Pixmap import Pixmap
from Components.Label import Label
from Components.MenuList import MenuList
from Tools.LoadPixmap import LoadPixmap

from .disneyHelper import *
from .disneyPlayer import disneyDreamPlayer
from .Disney import get_json_value
import os


class DisneyMovieDetailsSpinner:
    def __init__(self):
        # Spinner Timer
        self['TimerSpinner'] = Pixmap()
        self['TimerSpinner'].hide()
        self.timerSpinner = eTimer()
        self.timerSpinnerStatusSpinner = False
        self.timerSpinnerCounter = 1
        self.timerSpinner_conn = self.timerSpinner.timeout.connect(self.loadTimerSpinner)

    def stopTimerSpinner(self):
        self.timerSpinnerStatusSpinner = False

    def startTimerSpinner(self):
        self.timerSpinnerStatusSpinner = True
        self.loadTimerSpinner()

    def loadTimerSpinner(self):
        if self.timerSpinnerStatusSpinner:
            png = "%s/%s.png" % (DISNEY_SPINNER_DIRECTORY, str(self.timerSpinnerCounter))
            self.showTimerSpinner(png)
        else:
            self['TimerSpinner'].hide()

    def showTimerSpinner(self, png):
        self["TimerSpinner"].instance.setPixmapFromFile(png)
        self["TimerSpinner"].show()
        if self.timerSpinnerCounter is not 34:
            self.timerSpinnerCounter += 1
        else:
            self.timerSpinnerCounter = 1
        self.timerSpinner.start(10, True)


class DisneyDetailsMovieScreen(Screen, DisneyMovieDetailsSpinner):
    def __init__(self, session, data, disney, continue_watching=None):
        # load skin
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen name="DisneyDream" backgroundColor="#00000000" position="center,center" size="2560,1440" title="DisneyDream" flags="wfNoBorder">
                           <ePixmap gradient="#50000000,#80000000,horizontal" position="0,0" size="2560,1440" zPosition="-2"/>
                           <widget name="DisneyBackgroundPoster" position="0,0" size="2560,1440" zPosition="-3" />"
                           <widget name="DisneyLogo" position="133,67" size="667,375" zPosition="1" />
                           <widget name="DisneyPlayList" position="133,493" size="2293,80" zPosition="1" transparent="1" enableWrapAround="1" />
                           <widget name="DisneyInfoList" position="147,627" size="1533,51" zPosition="1" transparent="1" enableWrapAround="1" />
                           <widget name="DisneyDescriptionShort" position="147,747" size="1533,333" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="2" font="DD; 40" valign="top" halign="left" />
                           <widget name="DisneyDetailsList" position="133,1187" size="2293,87" zPosition="1" transparent="1" enableWrapAround="1" />
                           <widget name="Cover0" cornerDia="40" position="133,1287" size="467,261" zPosition="1" />
                           <widget name="Cover1" cornerDia="40" position="653,1287" size="467,261" zPosition="1" />
                           <widget name="Cover2" cornerDia="40" position="1173,1287" size="467,261" zPosition="1" />
                           <widget name="Cover3" cornerDia="40" position="1693,1287" size="467,261" zPosition="1" />
                           <widget name="Cover4" cornerDia="40" position="2213,1287" size="467,261" zPosition="1" />
                           <widget name="CoverSelect" position="100,597" size="533,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/select_black_400x225.png"  zPosition="3" />
                           <widget name="CoverLabel0" position="133,897" size="467,53" font="DD;37" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" valign="center" halign="center"/>
                           <widget name="CoverLabel1" position="653,897" size="467,53" font="DD;37" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" valign="center" halign="center"/>
                           <widget name="CoverLabel2" position="1173,897" size="467,53" font="DD;37" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" valign="center" halign="center"/>
                           <widget name="CoverLabel3" position="1693,897" size="467,53" font="DD;37" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" valign="center" halign="center"/>
                           <widget name="CoverLabel4" position="2213,897" size="467,53" font="DD;37" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" valign="center" halign="center"/>
                           <widget name="DisneyDetailsLabel" position="133,560" size="2293,880" zPosition="2" transparent="1" enableWrapAround="1" />
                           <widget name="TimerSpinner" position="1233,673" size="93,93" zPosition="99" />
                           </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """<screen name="DisneyDream" backgroundColor="#00000000" position="center,center" size="1920,1080" title="DisneyDream" flags="wfNoBorder">
                           <ePixmap gradient="#50000000,#80000000,horizontal" position="0,0" size="1920,1080" zPosition="-2"/>
                           <widget name="DisneyBackgroundPoster" position="0,0" size="1920,1080" zPosition="-3" />"
                           <widget name="DisneyLogo" position="100,50" size="500,281" zPosition="1" /> 
                           <widget name="DisneyPlayList" position="100,370" size="1720,60" zPosition="1" transparent="1" enableWrapAround="1" /> 
                           <widget name="DisneyInfoList" position="110,470" size="1150,38" zPosition="1" transparent="1" enableWrapAround="1" />                  
                           <widget name="DisneyDescriptionShort" position="110,560" size="1150,250" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="2" font="DD; 30" valign="top" halign="left" />                  
                           <widget name="DisneyDetailsList" position="100,890" size="1720,65" zPosition="1" transparent="1" enableWrapAround="1" /> 
                           <widget name="Cover0" position="100,965" size="350,196" zPosition="1" />
                           <widget name="Cover1" position="490,965" size="350,196" zPosition="1" />
                           <widget name="Cover2" position="880,965" size="350,196" zPosition="1" />
                           <widget name="Cover3" position="1270,965" size="350,196" zPosition="1" />
                           <widget name="Cover4" position="1660,965" size="350,196" zPosition="1" />
                           <widget name="CoverSelect" position="75,448" size="400,225" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/select_black_400x225.png"  zPosition="3" />                          
                           <widget name="CoverLabel0" position="100,673" size="350,40" font="DD;28" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" valign="center" halign="center"/>
                           <widget name="CoverLabel1" position="490,673" size="350,40" font="DD;28" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" valign="center" halign="center"/>
                           <widget name="CoverLabel2" position="880,673" size="350,40" font="DD;28" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" valign="center" halign="center"/>
                           <widget name="CoverLabel3" position="1270,673" size="350,40" font="DD;28" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" valign="center" halign="center"/>
                           <widget name="CoverLabel4" position="1660,673" size="350,40" font="DD;28" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" valign="center" halign="center"/>
                           <widget name="DisneyDetailsLabel" position="100,420" size="1720,660" zPosition="2" transparent="1" enableWrapAround="1" /> 
                           <widget name="TimerSpinner" position="925,505" size="70,70" zPosition="99" />
                           </screen>
                        """
        else:
            self.skin = """<screen name="DisneyDream" backgroundColor="#00000000" position="center,center" size="1280,720" title="DisneyDream" flags="wfNoBorder">
                           <ePixmap gradient="#50000000,#80000000,horizontal" position="0,0" size="1280,720" zPosition="-2"/>
                           <widget name="DisneyBackgroundPoster" position="0,0" size="1280,720" zPosition="-3" />"
                           <widget name="DisneyLogo" position="66,33" size="333,187" zPosition="1" />
                           <widget name="DisneyPlayList" position="66,246" size="1146,40" zPosition="1" transparent="1" enableWrapAround="1" />
                           <widget name="DisneyInfoList" position="73,313" size="766,25" zPosition="1" transparent="1" enableWrapAround="1" />
                           <widget name="DisneyDescriptionShort" position="73,373" size="766,166" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="2" font="DD; 20" valign="top" halign="left" />
                           <widget name="DisneyDetailsList" position="66,593" size="1146,43" zPosition="1" transparent="1" enableWrapAround="1" />
                           <widget name="Cover0" position="66,643" size="233,130" zPosition="1" />
                           <widget name="Cover1" position="326,643" size="233,130" zPosition="1" />
                           <widget name="Cover2" position="586,643" size="233,130" zPosition="1" />
                           <widget name="Cover3" position="846,643" size="233,130" zPosition="1" />
                           <widget name="Cover4" position="1106,643" size="233,130" zPosition="1" />
                           <widget name="CoverSelect" position="57,298" size="266,150" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/select_black_266x150.png"  zPosition="3" />
                           <widget name="CoverLabel0" position="66,448" size="233,26" font="DD;18" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" valign="center" halign="center"/>
                           <widget name="CoverLabel1" position="326,448" size="233,26" font="DD;18" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" valign="center" halign="center"/>
                           <widget name="CoverLabel2" position="586,448" size="233,26" font="DD;18" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" valign="center" halign="center"/>
                           <widget name="CoverLabel3" position="846,448" size="233,26" font="DD;18" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" valign="center" halign="center"/>
                           <widget name="CoverLabel4" position="1106,448" size="233,26" font="DD;18" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" valign="center" halign="center"/>
                           <widget name="DisneyDetailsLabel" position="66,280" size="1146,440" zPosition="2" transparent="1" enableWrapAround="1" />
                           <widget name="TimerSpinner" position="616,336" size="46,46" zPosition="99" />
                           </screen>
                        """

        Screen.__init__(self, session)

        self['actions'] = ActionMap(['DisneyDream_Actions'],
                                    {'ok': self.keyOk,
                                     'cancel': self.keyCancel,
                                     'up': self.keyUp,
                                     'down': self.keyDown,
                                     'left': self.keyLeft,
                                     'right': self.keyRight,
                                     'power': self.keyPower
                                     }, -1)

        DisneyMovieDetailsSpinner.__init__(self)

        self.chooseDisneyPlayList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseDisneyPlayList.l.setItemHeight(skinValueCalculate(60))
        self.chooseDisneyPlayList.l.setFont(0, gFont('DD', skinValueCalculate(32)))
        self.chooseDisneyPlayList.l.setFont(1, gFont('DD', skinValueCalculate(28)))
        self['DisneyPlayList'] = self.chooseDisneyPlayList

        self.chooseDisneyDetailsList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseDisneyDetailsList.l.setItemHeight(skinValueCalculate(65))
        self.chooseDisneyDetailsList.l.setFont(0, gFont('DD', skinValueCalculate(32)))
        self.chooseDisneyDetailsList.l.setFont(1, gFont('DD', skinValueCalculate(28)))
        self['DisneyDetailsList'] = self.chooseDisneyDetailsList

        self.chooseDisneyDetailsLabel = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseDisneyDetailsLabel.l.setItemHeight(skinValueCalculate(660))
        self.chooseDisneyDetailsLabel.l.setFont(0, gFont('DD', skinValueCalculate(42)))
        self.chooseDisneyDetailsLabel.l.setFont(1, gFont('DD', skinValueCalculate(30)))
        self['DisneyDetailsLabel'] = self.chooseDisneyDetailsLabel
        self['DisneyDetailsLabel'].hide()

        self.chooseDisneyInfoList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseDisneyInfoList.l.setItemHeight(skinValueCalculate(38))
        self.chooseDisneyInfoList.l.setFont(0, gFont('DD', skinValueCalculate(28)))
        self['DisneyInfoList'] = self.chooseDisneyInfoList

        self['DisneyBackgroundPoster'] = Pixmap()
        self['DisneyLogo'] = Pixmap()
        self['DisneyDescriptionShort'] = Label("")

        self.coverList = [("Cover0", skinValueCalculate(100), skinValueCalculate(965)),
                          ("Cover1", skinValueCalculate(490), skinValueCalculate(965)),
                          ("Cover2", skinValueCalculate(880), skinValueCalculate(965)),
                          ("Cover3", skinValueCalculate(1270), skinValueCalculate(965)),
                          ("Cover4", skinValueCalculate(1660), skinValueCalculate(965))]
        for skin_value, x, y in self.coverList:
            self[skin_value] = Pixmap()

        self.coverLabelList = ["CoverLabel0", "CoverLabel1", "CoverLabel2", "CoverLabel3", "CoverLabel4"]
        for skin_value in self.coverLabelList:
            self[skin_value] = Label("")
            self[skin_value].hide()

        self["CoverSelect"] = Pixmap()
        self["CoverSelect"].hide()

        self.disney = disney

        self.family_data = data.get("familyData")
        self.data = data
        self.gui_focus = 0
        self.play_list_index = 0
        self.details_index = 0
        self.details_video_index = 0
        self.play_list = []
        self.details_list = []
        self.callback_list = []
        self.dataCover = self.data
        self.continue_play = False
        self.content_type = ""

        self.extras = []
        self.related = []
        self.reload_data = []

        self.season_data = []
        self.family_related_data = []
        self.seasonCountdown = 0
        self.continue_watching = continue_watching

        self.onLayoutFinish.append(self.loadScreen)

    def loadScreen(self):
        if self.data:
            self.updatePlayList()
            self.updateDetailList()
            self.updateDetailLabel()
            self.updateInfoList()

            self['DisneyDescriptionShort'].setText(getTxt(self.data.get("medium_description")))

            # Background
            if self.data.get("background_details_image"):
                url = self.data.get("background_details_image")
            elif self.data.get("background_up_next_image"):
                url = self.data.get("background_up_next_image")
            else:
                url = self.data.get("background_image")
            try:
                png_destination = DISNEY_TMP_DIRECTORY + "/background-%s.png" % str(url.split("/")[-2]) if url else ""
            except Exception as error:
                png_destination = ""
            if not os.path.isfile(png_destination) and url:
                item = {"png_destination": png_destination,
                        "x": 1920,
                        "y": 720,
                        "type": "PNG"}
                self.disney.contentDownloader(url, item, callback=self.showDisneyBackgroundPoster)
            else:
                if os.path.isfile(png_destination):
                    self["DisneyBackgroundPoster"].instance.setPixmapFromFile(png_destination)
                    self["DisneyBackgroundPoster"].show()
            # End

            # Logo
            url = self.data.get("title_logo")
            try:
                png_destination = DISNEY_TMP_DIRECTORY + "/hero-logo-%s.png" % str(url.split("/")[-2]) if url else ""
            except Exception as error:
                png_destination = ""
            if not os.path.isfile(png_destination) and url:
                item = {"png_destination": png_destination,
                        "x": 400,
                        "y": 225,
                        "type": "PNG"}
                self.disney.contentDownloader(url, item, callback=self.showDisneyLogo)
            else:
                if os.path.isfile(png_destination):
                    self["DisneyLogo"].instance.setPixmapFromFile(png_destination)
                    self["DisneyLogo"].show()
            # End
            if self.continue_watching:
                self.continue_watching = None

    def updateInfoList(self):
        info = ""
        if self.data.get("releaseYear"):
            info += str(self.data.get("releaseYear")) + "  "
        if self.data.get("runtimeMillis"):
            info += str(self.data.get("runtimeMillis") / 1000 / 60) + ".Min   "
        if self.data.get("genres"):
            info += ", ".join(self.data.get("genres"))

        data = [(self.data.get("ratingsFsk"), info)]
        self.chooseDisneyInfoList.setList(list(map(disney_info_entry, [data])))
        self.chooseDisneyInfoList.selectionEnabled(0)

    def updateDetailLabel(self):
        data = [self.data]
        self.chooseDisneyDetailsLabel.setList(list(map(disney_details_label_entry, [data])))
        self.chooseDisneyDetailsLabel.selectionEnabled(0)

    def updateDetailList(self):
        if self.details_index is 0:
            if not self.related:
                if self.family_data.get("related"):
                    for video in self.family_data.get("related"):
                        self.related.append(video)
            self.details_video_index = 0
            self.setCoverList(self.related)
            self.doHideCoverLabel()
        elif self.details_index is 1:
            if not self.extras:
                if self.family_data.get("extras"):
                    for video in self.family_data.get("extras"):
                        try:
                            file_destination = "%s/poster-%s.png" % (DISNEY_TMP_DIRECTORY, str(video.get("thumbnail").split("/")[-2])) if video.get("thumbnail") else ""
                        except Exception as error:
                            file_destination = DISNEY_DEFAULT_COVER_PNG
                        item = {"png_destination": file_destination,
                                "url": video.get("thumbnail"),
                                "x": 350,
                                "y": 196,
                                "type": "PNG",
                                "title": video.get("title"),
                                "playbackUrls": video.get("playbackUrls")}
                        video["cover"] = item
                        self.extras.append(video)
            self.details_video_index = 0
            self.setCoverList(self.extras)
            self.setCoverLabel(self.details_video_index)
        elif self.details_index is 2:
            self.doHideCoverList()
            self.doHideCoverLabel()

        self.details_list = []
        self.details_list.append((DISNEY_RECOMMENDATIONS_STR, True)) if self.details_index == 0 else self.details_list.append((DISNEY_RECOMMENDATIONS_STR, False))
        self.details_list.append((DISNEY_EXTRAS_STR, True)) if self.details_index == 1 else self.details_list.append((DISNEY_EXTRAS_STR, False))
        self.details_list.append((DISNEY_DETAILS_STR, True)) if self.details_index == 2 else self.details_list.append((DISNEY_DETAILS_STR, False))
        data = [self.details_list]
        self.chooseDisneyDetailsList.setList(list(map(disney_details_entry, [data])))
        self.chooseDisneyDetailsList.selectionEnabled(0)

    def updatePlayList(self):
        self.play_list = []
        png = DISNEY_PLAY_SELECT_PNG if self.play_list_index is 0 else DISNEY_PLAY_NO_SELECT_PNG
        txt = DISNEY_PLAY_CONTINUE_STR if get_json_value(self.data.get("userMeta"), ["playhead"], default=0) > 1 else DISNEY_PLAY_STR
        select = True if self.play_list_index is 0 else False
        mode = "playAgain" if get_json_value(self.data.get("userMeta"), ["playhead"], default=0) > 0 else "play"
        self.play_list.append((txt, png, select, mode))

        if get_json_value(self.data.get("userMeta"), ["playhead"], default=0) > 1:
            png = DISNEY_PLAY_AGAIN_SELECT_PNG if self.play_list_index is 1 else DISNEY_PLAY_AGAIN_NO_SELECT_PNG
            txt = DISNEY_PLAY_STR
            select = True if self.play_list_index is 1 else False
            self.play_list.append((txt, png, select, "play"))

            if self.data.get("onWatchlist"):
                png = DISNEY_IS_WATCHLIST_SELECT_PNG if self.play_list_index is 2 else DISNEY_IS_WATCHLIST_NO_SELECT_PNG
                mode = "remove"
            else:
                png = DISNEY_NOT_WATCHLIST_SELECT_PNG if self.play_list_index is 2 else DISNEY_NOT_WATCHLIST_NO_SELECT_PNG
                mode = "add"
            select = True if self.play_list_index is 2 else False
            self.play_list.append((None, png, select, mode))
        else:
            if self.data.get("onWatchlist"):
                png = DISNEY_IS_WATCHLIST_SELECT_PNG if self.play_list_index is 1 else DISNEY_IS_WATCHLIST_NO_SELECT_PNG
                mode = "remove"
            else:
                png = DISNEY_NOT_WATCHLIST_SELECT_PNG if self.play_list_index is 1 else DISNEY_NOT_WATCHLIST_NO_SELECT_PNG
                mode = "add"
            select = True if self.play_list_index is 1 else False
            self.play_list.append((None, png, select, mode))
        data = [self.play_list, self.data]
        self.chooseDisneyPlayList.setList(list(map(disney_play_entry, [data])))
        self.chooseDisneyPlayList.selectionEnabled(0)

    def updateScreen(self):
        if self.gui_focus is 0:
            self['DisneyInfoList'].show()
            self['DisneyDescriptionShort'].show()
            self['DisneyBackgroundPoster'].show()
            self['DisneyPlayList'].show()
            self['DisneyDetailsList'].instance.move(ePoint(skinValueCalculate(100), skinValueCalculate(890)))
            for skin_value, x, y in self.coverList:
                self[skin_value].instance.move(ePoint(x, y))
        elif self.gui_focus is 1:
            self['DisneyInfoList'].hide()
            self['DisneyDescriptionShort'].hide()
            self['DisneyBackgroundPoster'].hide()
            self['DisneyPlayList'].hide()
            self['DisneyDetailsList'].instance.move(ePoint(skinValueCalculate(100), skinValueCalculate(340)))
            for skin_value, x, y in self.coverList:
                self[skin_value].instance.move(ePoint(x, y - skinValueCalculate(500)))

    def setCoverLabel(self, index=0):
        if self.dataCover and self.details_index == 1:
            start = index - 3 if index >= 4 else 0
            max_range = 5 if len(self.dataCover) - index >= 5 else len(self.dataCover) - start
            for skin_value in self.coverLabelList:
                if max_range is not 0:
                    video = self.dataCover[start]
                    self[skin_value].setText(getTxt(video.get("title")))
                    self[skin_value].show()
                    max_range -= 1
                else:
                    self[skin_value].setText("")
                    self[skin_value].hide()
                start += 1

    def setCoverList(self, data):
        self.callback_list = []
        self.dataCover = data
        max = len(data)
        item = 0
        for skin_value, x, y in self.coverList:
            if max is not 0:
                png_data = data[item]["cover"]
                png_data.update({"skin_value": skin_value})
                self.callback_list.append((png_data["skin_value"], png_data["png_destination"]))
                if os.path.isfile(png_data["png_destination"]):
                    self[png_data["skin_value"]].instance.setPixmapFromFile(png_data["png_destination"])
                    self[png_data["skin_value"]].show()
                else:
                    self[png_data["skin_value"]].instance.setPixmapFromFile(DISNEY_DEFAULT_COVER_PNG)
                    self[png_data["skin_value"]].show()
                    self.disney.contentDownloader(png_data["url"], png_data, callback=self.loadCoverList)
                max -= 1
            else:
                self[skin_value].hide()
            item += 1

    def loadSelectCoverList(self, index):
        if self.dataCover:
            self.callback_list = []
            start = index - 3 if index >= 4 else 0
            max_range = 5 if len(self.dataCover) - index >= 5 else len(self.dataCover) - start
            for skin_value, x, y in self.coverList:
                if max_range is not 0:
                    png_data = self.dataCover[start]["cover"]
                    png_data.update({"skin_value": skin_value})
                    self.callback_list.append((png_data["skin_value"], png_data["png_destination"]))
                    if os.path.isfile(png_data["png_destination"]):
                        self[png_data["skin_value"]].instance.setPixmapFromFile(png_data["png_destination"])
                        self[png_data["skin_value"]].show()
                    else:
                        self[png_data["skin_value"]].instance.setPixmapFromFile(DISNEY_DEFAULT_COVER_PNG)
                        self[png_data["skin_value"]].show()
                        self.disney.contentDownloader(png_data["url"], png_data, callback=self.loadCoverList)
                    max_range -= 1
                else:
                    self[skin_value].hide()
                start += 1

    def moveSelectCover(self, index, mode):
        if index <= 3:
            skin_value = "Cover" + str(index)
            x = skinValueCalculate(75)
            for i in range(index):
                x = x + skinValueCalculate(390)
            self[skin_value].instance.move(ePoint(x, skinValueCalculate(448)))
            self[skin_value].instance.resize(eSize(skinValueCalculate(400), skinValueCalculate(225)))
            self["CoverSelect"].instance.move(ePoint(x, skinValueCalculate(448)))
            self["CoverSelect"].show()
            if mode == "+" and index is not 0:
                (skin_value, x, y) = self.coverList[index - 1]
                self[skin_value].instance.move(ePoint(x, y - skinValueCalculate(500)))
                self[skin_value].instance.resize(eSize(skinValueCalculate(350), skinValueCalculate(196)))
            elif mode == "-":
                (skin_value, x, y) = self.coverList[index + 1]
                self[skin_value].instance.move(ePoint(x, y - skinValueCalculate(500)))
                self[skin_value].instance.resize(eSize(skinValueCalculate(350), skinValueCalculate(196)))
        if mode is None:
            for skin_value, x, y in self.coverList:
                self[skin_value].instance.move(ePoint(x, y - skinValueCalculate(500)))
                self[skin_value].instance.resize(eSize(skinValueCalculate(350), skinValueCalculate(196)))
        self.setCoverLabel(self.details_video_index)

    def loadCoverList(self, item, png):
        if (item["skin_value"], item["png_destination"]) in self.callback_list and png and self.details_index is not 2:
            self[item["skin_value"]].instance.setPixmapFromFile(png)
            self[item["skin_value"]].show()

    def doHideCoverList(self):
        for skin_value, x, y in self.coverList:
            self[skin_value].hide()

    def doHideCoverLabel(self):
        for skin_value in self.coverLabelList:
            self[skin_value].hide()

    def keyCancel(self, callback=None):
        if self.reload_data:
            self['TimerSpinner'].hide()
            ### read old data ###
            video = self.reload_data[len(self.reload_data) - 1]
            ### load old data ###
            self.continue_watching = None
            self.data = video.get("video")
            self.family_data = video.get("familyData")
            self.related = []
            self.extras = []
            self.gui_focus = 0
            self.play_list_index = 0
            self.details_index = 0
            self.details_video_index = 0
            self.play_list = []
            self.details_list = []
            self.callback_list = []
            self.dataCover = []
            self.season_data = []
            self.family_related_data = []
            self.seasonCountdown = 0
            self.moveSelectCover(0, None)
            self.updateScreen()
            self['DisneyDetailsLabel'].hide()
            self["DisneyBackgroundPoster"].hide()
            self["DisneyLogo"].hide()
            self["CoverSelect"].hide()
            self.loadScreen()

            self.reload_data.remove(self.reload_data[len(self.reload_data) - 1])
        else:
            self.close(False)

    def keyPower(self):
        self.close(True)

    def keyRight(self):
        if self.gui_focus is 0:
            if self.play_list_index < len(self.play_list) - 1:
                self.play_list_index += 1
                self.updatePlayList()
        elif self.gui_focus is 1:
            if self.details_index < len(self.details_list) - 1:
                self.details_index += 1
                self.updateDetailList()
                if self.details_index is 2:
                    self['DisneyDetailsLabel'].show()
        elif self.gui_focus is 2:
            data = None
            if self.details_index is 0:
                data = self.related
            elif self.details_index is 1:
                data = self.extras
            if data:
                if self.details_video_index < len(data) - 1:
                    self.details_video_index += 1
                    self.loadSelectCoverList(self.details_video_index)
                    self.moveSelectCover(self.details_video_index, "+")

    def keyLeft(self):
        if self.gui_focus is 0:
            if self.play_list_index is not 0:
                self.play_list_index -= 1
                self.updatePlayList()
        elif self.gui_focus is 1:
            if self.details_index is not 0:
                if self.details_index is 2:
                    self['DisneyDetailsLabel'].hide()
                self.details_index -= 1
                self.updateDetailList()
        elif self.gui_focus is 2:
            data = None
            if self.details_index is 0:
                data = self.related
            elif self.details_index is 1:
                data = self.extras
            if data:
                if self.details_video_index is not 0:
                    self.details_video_index -= 1
                    self.loadSelectCoverList(self.details_video_index)
                    self.moveSelectCover(self.details_video_index, "-")

    def keyOk(self):
        if self.data:
            if self.gui_focus is 0:
                mode = self.play_list[self.play_list_index][3]
                if mode == "playAgain":
                    self.continue_play = True
                    playbackUrl = self.data.get("playbackUrls")
                    if playbackUrl:
                        self.startTimerSpinner()
                        self.disney.getPlaybackUrl(playbackUrl[0], self.gotPlaybackUrl)
                elif mode == "play":
                    self.continue_play = False
                    playbackUrl = self.data.get("playbackUrls")
                    if playbackUrl:
                        self.startTimerSpinner()
                        self.disney.getPlaybackUrl(playbackUrl[0], self.gotPlaybackUrl)
                elif mode == "remove":
                    self.disney.getDeleteWatchlist(self.data.get("contentId"), self.callbackWatchlist, self.data)
                elif mode == "add":
                    self.disney.getAddWatchlist(self.data.get("contentId"), self.callbackWatchlist, self.data)
            elif self.gui_focus is 2 and self.details_index is 0:
                if self.family_data.get("related"):
                    video = self.family_data["related"][self.details_video_index]
                    if video.get("mediaType") == "MOVIE" and not video.get("seriesId"):
                        if video.get("encodedFamilyId"):
                            self.startTimerSpinner()
                            self.disney.getVideoBundle(video.get("encodedFamilyId"), self.backReadFamilyId, video)
                    elif video.get("mediaType") == "SERIES" or video.get("encodedSeriesId"):
                        self.startTimerSpinner()
                        self.series = video
                        self.disney.getSeriesBundle(video.get("encodedSeriesId"), self.backSeriesBundle)
            elif self.gui_focus is 2 and self.details_index is 1:
                if self.extras:
                    playbackUrl = self.extras[self.details_video_index].get("playbackUrls")
                    if playbackUrl:
                        self.startTimerSpinner()
                        self.disney.getPlaybackUrl(playbackUrl[0], self.gotPlaybackUrl)

    def backReadFamilyId(self, video):
        self.disney.getContinueWatching(video.get("encodedFamilyId"), self.callbackContinueWatching, video)

    def callbackContinueWatching(self, video):
        self.stopTimerSpinner()
        self['TimerSpinner'].hide()
        ### save old data ###
        item = {"video": self.data,
                "familyData": self.family_data}
        self.reload_data.append(item)
        ### set new data ###
        self.continue_watching = None
        self.family_data = video.get("familyData")
        self.data = video
        self.gui_focus = 0
        self.play_list_index = 0
        self.details_index = 0
        self.details_video_index = 0
        self.play_list = []
        self.details_list = []
        self.callback_list = []
        self.dataCover = []

        self.extras = []
        self.related = []

        self.season_data = []
        self.family_related_data = []
        self.seasonCountdown = 0
        self.moveSelectCover(0, None)
        self.updateScreen()
        self["CoverSelect"].hide()
        self['DisneyDetailsLabel'].hide()
        self["DisneyBackgroundPoster"].hide()
        self["DisneyLogo"].hide()
        self.loadScreen()

    def backSeriesBundle(self, seasons, family, series):
        if seasons:
            self.season_data = []
            if series:
                self.series = series
            self.family_related_data = family
            self.seasonCountdown = len(seasons)
            for season in seasons:
                season.update({"episodes": []})
                self.disney.getSeriesEpisodes(season.get("seasonId"), self.backReadEpisode, season)
        else:
            self.stopTimerSpinner()

    def backReadEpisode(self, callback):
        self.seasonCountdown -= 1
        self.season_data.append(callback)
        if self.seasonCountdown is 0:
            self.season_data = sorted(self.season_data, key=lambda item: (item["seasonSequenceNumber"]))
            self.series.update({"season": self.season_data})
            self.series.update({"familyData": self.family_related_data})
            self.disney.getContinueWatchingSeries(self.series.get("encodedSeriesId"), self.callbackContinueWatchingSeries, self.series)

    def callbackContinueWatchingSeries(self, video):
        self.seasonCountdown = len(video["season"])
        for season in video["season"]:
            self.disney.getContinueWatchingSeason(self.callbackContinueWatchingSeason, season)

    def callbackContinueWatchingSeason(self, season):
        self.seasonCountdown -= 1
        if self.seasonCountdown is 0:
            self.stopTimerSpinner()
            item = {"video": self.data,
                    "familyData": self.family_data}
            self.reload_data.append(item)
            from disneyDetailsSeasonScreen import DisneyDetailsSeasonScreen
            self.session.openWithCallback(self.keyCancel, DisneyDetailsSeasonScreen, self.series, self.disney)

    def callbackWatchlist(self, data):
        self.data = data
        self.updatePlayList()

    def gotPlaybackUrl(self, licenseUrl, contentUrl):
        self.stopTimerSpinner()
        play = False
        is_extra = False
        if self.gui_focus is 0:
            self.data["licenseUrl"] = licenseUrl
            self.data["contentUrl"] = contentUrl
            self.content_type = "MOVIE"
            play = True
            #self.startTimerSpinner()
            #self.disney.getPlaybackMediaData(self.data, "MOVIE", self.backPlaybackMediaData)
        elif self.gui_focus is 2:
            if self.data.get("familyData", {}).get("extras"):
                self.data["familyData"]["extras"][self.details_video_index]["licenseUrl"] = licenseUrl
                self.data["familyData"]["extras"][self.details_video_index]["contentUrl"] = contentUrl
                self.content_type = "EXTRA"
                play = True
                is_extra = True
        if play:
            self.session.openWithCallback(self.backPlayer, disneyDreamPlayer, self.data, self.disney, continue_play=self.continue_play, extra_index=self.details_video_index, is_extra=is_extra, content_type=self.content_type)

    #def backPlaybackMediaData(self, data):
    #    self.stopTimerSpinner()
    #    self.session.openWithCallback(self.backPlayer, disneyDreamPlayer, self.data, self.disney, continue_play=self.continue_play, is_extra=False, content_type=self.content_type)

    def backPlayer(self, video):
        if self.gui_focus is 0:
            self.data = video
            self.play_list_index = 0
            self.updatePlayList()

    def keyUp(self):
        if self.data:
            if self.gui_focus is 1:
                self.gui_focus = 0
                self.details_index = 0
                self.updateDetailList()
                self.updateScreen()
                self["CoverSelect"].hide()
                self['DisneyDetailsLabel'].hide()
            if self.gui_focus is 2:
                self.gui_focus = 1
                self.details_video_index = 0
                self.moveSelectCover(0, None)
                self["CoverSelect"].hide()
                self['DisneyDetailsLabel'].hide()

    def keyDown(self):
        if self.data:
            if self.gui_focus is 0:
                self.gui_focus += 1
                self.updateScreen()
            elif self.gui_focus is 1:
                if self.details_index is 0 and self.related:
                    self.gui_focus += 1
                    self.loadSelectCoverList(self.details_video_index)
                    self.moveSelectCover(0, False)
                elif self.details_index is 1 and self.extras:
                    self.gui_focus += 1
                    self.loadSelectCoverList(self.details_video_index)
                    self.moveSelectCover(0, False)

    def showDisneyBackgroundPoster(self, item, png):
        if os.path.isfile(png):
            self["DisneyBackgroundPoster"].instance.setPixmapFromFile(png)
            if self.gui_focus is 0:
                self["DisneyBackgroundPoster"].show()

    def showDisneyLogo(self, item, png):
        if os.path.isfile(png):
            self["DisneyLogo"].instance.setPixmapFromFile(png)
            self["DisneyLogo"].show()

    def createSummary(self):
        return MyDisneySummary


def disney_details_label_entry(entry):
    res = [entry]
    title = entry[0].get("title")
    description = entry[0].get("description")
    if title:
        res.append(MultiContentEntryText(pos=(skinValueCalculate(10), 0),
                                         size=(skinValueCalculate(1720), skinValueCalculate(80)),
                                         flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                         font=0,
                                         text=getTxt(title),
                                         color=0xffffff,
                                         backcolor=0x000000))

    if description:
        res.append(MultiContentEntryText(pos=(skinValueCalculate(10), skinValueCalculate(120)),
                                         size=(skinValueCalculate(1700), skinValueCalculate(500)),
                                         flags=RT_HALIGN_LEFT | RT_WRAP,
                                         font=1,
                                         text=getTxt(description),
                                         color=0xffffff,
                                         backcolor=0x000000))
    return res


def disney_info_entry(entry):
    res = [entry]
    fsk = entry[0][0]
    txt = entry[0][1]
    if fsk:
        backcolor = 0xffffff
        if str(fsk) == "6":
            backcolor = 0xffc400
        elif str(fsk) == "12":
            backcolor = 0x1fb02c
        elif str(fsk) == "16":
            backcolor = 0x05a3df
        elif str(fsk) == "18":
            backcolor = 0xf52315
        res.append(MultiContentEntryText(pos=(0, 0),
                                         size=(skinValueCalculate(45), skinValueCalculate(38)),
                                         flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                         font=0,
                                         text=str(fsk),
                                         color=0x000000,
                                         backcolor=backcolor))

    width = skinValueCalculate(60) if entry[0] else 0
    res.append(MultiContentEntryText(pos=(width, 0),
                                     size=(skinValueCalculate(1000), skinValueCalculate(38)),
                                     flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                     font=0,
                                     text=getTxt(txt),
                                     color=0xffffff))
    return res


def disney_details_entry(entry):
    res = [entry]
    res.append(MultiContentEntryText(pos=(0, skinValueCalculate(60)),
                                     size=(skinValueCalculate(1720), skinValueCalculate(2)),
                                     flags=0 | 0,
                                     font=0,
                                     text="",
                                     backcolor=0x383839))

    width = 0
    for txt, select in entry[0]:
        txt_height = skinValueCalculate(50) if select else skinValueCalculate(40)
        txt_width = len(txt) * skinValueCalculate(25)
        txt_font = 0 if select else 1
        pos_height = 0 if select else skinValueCalculate(5)
        res.append(MultiContentEntryText(pos=(width, pos_height),
                                         size=(txt_width, txt_height),
                                         flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                         font=txt_font,
                                         text=getTxt(txt),
                                         color=0xffffff))

        # select
        if select:
            res.append(MultiContentEntryText(pos=(width, skinValueCalculate(58)),
                                             size=(txt_width, skinValueCalculate(4)),
                                             flags=0 | 0,
                                             font=0,
                                             text="",
                                             backcolor=0xffffff))

        width = width + txt_width + skinValueCalculate(15)

    return res


def disney_play_entry(entry):
    res = [entry]
    data = entry[0]
    video = entry[1]
    width = 0
    for txt, png, select, mode in data:
        png = LoadPixmap(png)
        png_width = png.size().width()
        png_height = png.size().height()
        pos_height = 0 if select else skinValueCalculate(5)
        res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, width, pos_height, png_width, png_height, png))
        if txt:
            txt_backcolor = 0xffffff if select else 0x808080
            txt_height = skinValueCalculate(60) if select else skinValueCalculate(50)
            txt_width = skinValueCalculate(200) if select else skinValueCalculate(170)
            txt_font = 0 if select else 1
            res.append(MultiContentEntryText(pos=(width + skinValueCalculate(60), pos_height),
                                             size=(txt_width, txt_height),
                                             flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                             font=txt_font,
                                             text=txt,
                                             color=0x000000,
                                             backcolor=txt_backcolor))

        if mode == "playAgain" and get_json_value(video.get("userMeta"), ["playhead"], default=0) > 0 and video.get("runtimeMillis"):
            p = get_json_value(video.get("userMeta"), ["playhead"], default=0) / ((video.get("runtimeMillis") / 1000) / 100) + 0.0
            len_width = skinValueCalculate(292) + 0.0 if select else skinValueCalculate(242) + 0.0
            len_watched = (len_width / 100) * p
            len_pos = skinValueCalculate(57) if select else skinValueCalculate(51)
            res.append(MultiContentEntryText(pos=(skinValueCalculate(4), len_pos),
                                             size=(int(round(len_watched)), skinValueCalculate(4)),
                                             flags=0 | 0,
                                             font=0,
                                             text="",
                                             backcolor=0xfffff))
        width = width + png_width + skinValueCalculate(15)

    return res
