from enigma import gFont, getDesktop, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP, RT_WRAP, ePicLoad, eTimer, ePoint, eSize
from Components.Pixmap import Pixmap
from Components.Label import Label
from Components.ActionMap import ActionMap
from Screens.Screen import Screen
from Components.MenuList import MenuList
from Tools.LoadPixmap import LoadPixmap
from Components.MultiContent import MultiContentEntryText
from Screens.MessageBox import MessageBox

from .disneyHelper import *
from .disneyHelper import _
from Screens.InputBox import InputBox

import os


class DisneyAddProfileSpinner:
    def __init__(self):
        # Spinner Timer
        self['TimerSpinner'] = Pixmap()
        self['TimerSpinner'].hide()
        self.timerSpinner = eTimer()
        self.timerSpinnerStatusSpinner = False
        self.timerSpinnerCounter = 1
        self.timerSpinner_conn = self.timerSpinner.timeout.connect(self.loadTimerSpinner)

    def stopTimerSpinner(self):
        self.timerSpinnerStatusSpinner = False

    def startTimerSpinner(self):
        self.timerSpinnerStatusSpinner = True
        self.loadTimerSpinner()

    def loadTimerSpinner(self):
        if self.timerSpinnerStatusSpinner:
            png = "%s/%s.png" % (DISNEY_SPINNER_DIRECTORY, str(self.timerSpinnerCounter))
            self.showTimerSpinner(png)
        else:
            self['TimerSpinner'].hide()

    def showTimerSpinner(self, png):
        self["TimerSpinner"].instance.setPixmapFromFile(png)
        self["TimerSpinner"].show()
        if self.timerSpinnerCounter is not 34:
            self.timerSpinnerCounter += 1
        else:
            self.timerSpinnerCounter = 1
        self.timerSpinner.start(10, True)


class DisneyAddProfileScreen(Screen, DisneyAddProfileSpinner):
    def __init__(self, session, disney, data, profile_title_list):
        # load skin
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen name="DisneyDream" backgroundColor="#002d3343" position="center,center" size="2560,1440" title="DisneyDream" flags="wfNoBorder">
                           <widget name="ProfileAvatarLabel" position="53,40" size="2507,87" font="DD;64" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="1" valign="center" halign="left"/>
                           <widget name="ProfileGuiText1" position="133,213" size="2400,53" font="DD;40" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="6" valign="center" halign="left"/>
                           <widget name="ProfileInfoText" position="133,347" size="2400,53" font="DD;40" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="6" valign="center" halign="left"/>
                           <widget name="Cover0" position="133,307" size="467,467" zPosition="1" />
                           <widget name="Cover1" position="640,307" size="467,467" zPosition="1" />
                           <widget name="Cover2" position="1147,307" size="467,467" zPosition="1" />
                           <widget name="Cover3" position="1653,307" size="467,467" zPosition="1" />
                           <widget name="Cover4" position="2160,307" size="467,467" zPosition="1" />
                           <widget name="CoverSelect" position="123,296" size="488,488" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/avatar_select_366x366.png" zPosition="2" />
                           <widget name="ProfileGuiText2" position="133,867" size="2400,53" font="DD;40" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="6" valign="center" halign="left"/>
                           <widget name="Cover5" position="133,960" size="467,467" zPosition="1" />
                           <widget name="Cover6" position="653,960" size="467,467" zPosition="1" />
                           <widget name="Cover7" position="1173,960" size="467,467" zPosition="1" />
                           <widget name="Cover8" position="1693,960" size="467,467" zPosition="1" />
                           <widget name="Cover9" position="2213,960" size="467,467" zPosition="1" />
                           <widget name="Avatar" position="1293,420" size="467,467" zPosition="2" />
                           <widget name="ProfileConfig" position="133,453" size="1067,400" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="1" transparent="0" />
                           <widget name="TimerSpinner" position="1233,673" size="93,93" zPosition="99" />
                           <ePixmap position="2240,1267" size="267,147" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/logo_200x110.png" zPosition="99" />
                           </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """<screen name="DisneyDream" backgroundColor="#002d3343" position="center,center" size="1920,1080" title="DisneyDream" flags="wfNoBorder">
                           <widget name="ProfileAvatarLabel" position="40,30" size="1880,65" font="DD;48" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="1" valign="center" halign="left"/>
                           <widget name="ProfileGuiText1" position="100,160" size="1800,40" font="DD;30" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="6" valign="center" halign="left"/>
                           <widget name="ProfileInfoText" position="100,260" size="1800,40" font="DD;30" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="6" valign="center" halign="left"/>  
                           <widget name="Cover0" position="100,230" size="350,350" zPosition="1" />
                           <widget name="Cover1" position="480,230" size="350,350" zPosition="1" />
                           <widget name="Cover2" position="860,230" size="350,350" zPosition="1" />
                           <widget name="Cover3" position="1240,230" size="350,350" zPosition="1" />
                           <widget name="Cover4" position="1620,230" size="350,350" zPosition="1" />
                           <widget name="CoverSelect" position="92,222" size="366,366" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/avatar_select_366x366.png" zPosition="2" />
                           <widget name="ProfileGuiText2" position="100,650" size="1800,40" font="DD;30" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="6" valign="center" halign="left"/>
                           <widget name="Cover5" position="100,720" size="350,350" zPosition="1" />
                           <widget name="Cover6" position="490,720" size="350,350" zPosition="1" />
                           <widget name="Cover7" position="880,720" size="350,350" zPosition="1" />
                           <widget name="Cover8" position="1270,720" size="350,350" zPosition="1" />
                           <widget name="Cover9" position="1660,720" size="350,350" zPosition="1" />
                           <widget name="Avatar" position="970,315" size="350,350" zPosition="2" />
                           <widget name="ProfileConfig" position="100,340" size="800,300" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="1" transparent="0" />
                           <widget name="TimerSpinner" position="925,505" size="70,70" zPosition="99" />
                           <ePixmap position="1680,950" size="200,110" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/logo_200x110.png" zPosition="99" />
                           </screen>
                        """
        else:
            self.skin = """<screen name="DisneyDream" backgroundColor="#002d3343" position="center,center" size="1280,720" title="DisneyDream" flags="wfNoBorder">
                           <widget name="ProfileAvatarLabel" position="26,20" size="1253,43" font="DD;32" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="1" valign="center" halign="left"/>
                           <widget name="ProfileGuiText1" position="66,106" size="1200,26" font="DD;20" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="6" valign="center" halign="left"/>
                           <widget name="ProfileInfoText" position="66,173" size="1200,26" font="DD;20" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="6" valign="center" halign="left"/>
                           <widget name="Cover0" position="66,153" size="233,233" zPosition="1" />
                           <widget name="Cover1" position="320,153" size="233,233" zPosition="1" />
                           <widget name="Cover2" position="573,153" size="233,233" zPosition="1" />
                           <widget name="Cover3" position="826,153" size="233,233" zPosition="1" />
                           <widget name="Cover4" position="1080,153" size="233,233" zPosition="1" />
                           <widget name="CoverSelect" position="61,148" size="244,244" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/avatar_select_244x244.png" zPosition="2" />
                           <widget name="ProfileGuiText2" position="66,433" size="1200,26" font="DD;20" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="6" valign="center" halign="left"/>
                           <widget name="Cover5" position="66,480" size="233,233" zPosition="1" />
                           <widget name="Cover6" position="326,480" size="233,233" zPosition="1" />
                           <widget name="Cover7" position="586,480" size="233,233" zPosition="1" />
                           <widget name="Cover8" position="846,480" size="233,233" zPosition="1" />
                           <widget name="Cover9" position="1106,480" size="233,233" zPosition="1" />
                           <widget name="Avatar" position="646,210" size="233,233" zPosition="2" />
                           <widget name="ProfileConfig" position="66,226" size="533,200" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="1" transparent="0" />
                           <widget name="TimerSpinner" position="616,336" size="46,46" zPosition="99" />
                           <ePixmap position="1120,633" size="133,73" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/logo_133x73.png" zPosition="99" />
                           </screen>
                        """

        Screen.__init__(self, session)

        self['actions'] = ActionMap(['DisneyDream_Actions'],
                                    {'ok': self.keyOK,
                                     'cancel': self.keyCancel,
                                     'left': self.keyLeft,
                                     'right': self.keyRight,
                                     'up': self.keyUp,
                                     'down': self.keyDown,
                                     'power': self.keyPower
                                     }, -1)

        DisneyAddProfileSpinner.__init__(self)

        # Disney Profile
        self.coverList1 = [("Cover0", skinValueCalculate(100), skinValueCalculate(230)),
                           ("Cover1", skinValueCalculate(480), skinValueCalculate(230)),
                           ("Cover2", skinValueCalculate(860), skinValueCalculate(230)),
                           ("Cover3", skinValueCalculate(1240), skinValueCalculate(230)),
                           ("Cover4", skinValueCalculate(1620), skinValueCalculate(230))]
        for skin_value, x, y in self.coverList1:
            self[skin_value] = Pixmap()

        self.coverList2 = [("Cover5", skinValueCalculate(100), skinValueCalculate(720)),
                           ("Cover6", skinValueCalculate(490), skinValueCalculate(720)),
                           ("Cover7", skinValueCalculate(880), skinValueCalculate(720)),
                           ("Cover8", skinValueCalculate(1270), skinValueCalculate(720)),
                           ("Cover9", skinValueCalculate(1660), skinValueCalculate(720))]
        for skin_value, x, y in self.coverList2:
            self[skin_value] = Pixmap()

        self.chooseDisneyConfig = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseDisneyConfig.l.setFont(0, gFont('DD', skinValueCalculate(34)))
        self.chooseDisneyConfig.l.setItemHeight(skinValueCalculate(300))
        self['ProfileConfig'] = self.chooseDisneyConfig
        self['ProfileConfig'].hide()

        self["CoverSelect"] = Pixmap()
        self["Avatar"] = Pixmap()
        self["Avatar"].hide()

        self["ProfileAvatarLabel"] = Label(DISNEY_CHOOSE_AVATAR_STR)
        self['ProfileInfoText'] = Label("")
        self['ProfileInfoText'].hide()

        self['ProfileGuiText1'] = Label("")
        self['ProfileGuiText2'] = Label("")

        self.avatar_index = 0
        self.avatar_gui_index = 0
        self.avatar_list_index = 0
        self.disney = disney
        self.focus = 0
        self.data = data
        self.callback_list1 = []
        self.callback_list2 = []
        self.dataCover1 = []
        self.dataCover2 = []
        self.last = None
        self.profile_title_list = profile_title_list
        self.profile_title = DISNEY_MAY_PROFILE_STR
        self.kids_mode = False

        self.onLayoutFinish.append(self.buildGui)

    def buildGui(self):
        self.avatar_index = 0
        self.last = None
        if self.data:
            #(title, refId, refType, avatars) = self.data[self.avatar_gui_index]
            self['ProfileGuiText1'].setText(getTxt(self.data[self.avatar_gui_index]["title"]))
            data = []
            for avatar in self.data[self.avatar_gui_index]["avatars"]:
                try:
                    file_destination = "%s/avatar-%s.png" % (DISNEY_TMP_DIRECTORY, str(avatar.get("avatarUrl").split("/")[-2])) if avatar.get("avatarUrl") else ""
                except Exception as error:
                    file_destination = DISNEY_DEFAULT_AVATAR_PNG
                item = {"png_destination": file_destination,
                        "url": avatar.get("avatarUrl"),
                        "x": 350,
                        "y": 350,
                        "type": "PNG"}
                data.append(item)
            self.setCoverList(data, 0)

            data = []
            if self.avatar_gui_index + 1 <= len(self.data) - 1:
                #(title, refId, refType, avatars) = self.data[self.avatar_gui_index + 1]
                self['ProfileGuiText2'].setText(getTxt(self.data[self.avatar_gui_index + 1]["title"]))
                max_range = 5 if len(self.data[self.avatar_gui_index + 1]["avatars"]) > 4 else len(self.data[self.avatar_gui_index + 1]["avatars"])
                data = []
                for i in range(max_range):
                    avatar = self.data[self.avatar_gui_index + 1]["avatars"][i]
                    try:
                        file_destination = "%s/avatar-%s.png" % (DISNEY_TMP_DIRECTORY, str(avatar.get("avatarUrl").split("/")[-2])) if avatar.get("avatarUrl") else ""
                    except Exception as error:
                        file_destination = DISNEY_DEFAULT_AVATAR_PNG
                    item = {"png_destination": file_destination,
                            "url": avatar.get("avatarUrl"),
                            "x": 350,
                            "y": 350,
                            "type": "PNG"}
                    data.append(item)
            else:
                self.last = True
                self['ProfileGuiText2'].setText("")
            self.setCoverList(data, 1)
            self.loadSelectCoverList(self.avatar_index)
            self.moveSelectCover(self.avatar_index, "-")
        else:
            self['ProfileGuiText1'].setText("")
            self['ProfileGuiText2'].setText("")

    def setCoverList(self, data, index):
        value_list = self.coverList1 if index == 0 else self.coverList2
        if index is 0:
            self.callback_list1 = []
            self.dataCover1 = data
            callback = self.loadCoverList1
        else:
            self.callback_list2 = []
            self.dataCover2 = data
            callback = self.loadCoverList2
        max = len(data)
        item = 0
        for skin_value, x, y in value_list:
            if max is not 0:
                png_data = data[item]
                png_data.update({"skin_value": skin_value})
                if index == 0:
                    self.callback_list1.append((png_data["skin_value"], png_data["png_destination"]))
                else:
                    self.callback_list2.append((png_data["skin_value"], png_data["png_destination"]))
                if os.path.isfile(png_data["png_destination"]):
                    self[png_data["skin_value"]].instance.setPixmapFromFile(png_data["png_destination"])
                    self[png_data["skin_value"]].show()
                else:
                    self[png_data["skin_value"]].instance.setPixmapFromFile(DISNEY_DEFAULT_AVATAR_PNG)
                    self[png_data["skin_value"]].show()
                    self.disney.contentDownloader(png_data["url"], png_data, callback=callback)
                max -= 1
            else:
                self[skin_value].hide()
            item += 1

    def loadSelectCoverList(self, index=0):
        if self.dataCover1:
            self.callback_list1 = []
            start = index - 3 if index >= 4 else 0
            max_range = 5 if len(self.dataCover1) - index >= 5 else len(self.dataCover1) - start
            for skin_value, x, y in self.coverList1:
                if max_range is not 0:
                    png_data = self.dataCover1[start]
                    png_data.update({"skin_value": skin_value})
                    self.callback_list1.append((png_data["skin_value"], png_data["png_destination"]))
                    if os.path.isfile(png_data["png_destination"]):
                        self[png_data["skin_value"]].instance.setPixmapFromFile(png_data["png_destination"])
                        self[png_data["skin_value"]].show()
                    else:
                        self[png_data["skin_value"]].instance.setPixmapFromFile(DISNEY_DEFAULT_AVATAR_PNG)
                        self[png_data["skin_value"]].show()
                        self.disney.contentDownloader(png_data["url"], png_data, callback=self.loadCoverList1)
                    max_range -= 1
                else:
                    self[skin_value].hide()
                start += 1

    def doHideAvatarCover(self):
        for skin_value, x, y in self.coverList1:
            self[skin_value].hide()
        for skin_value, x, y in self.coverList2:
            self[skin_value].hide()
        self["CoverSelect"].hide()

    def loadCoverList1(self, item, png):
        if (item["skin_value"], item["png_destination"]) in self.callback_list1 and png:
            self[item["skin_value"]].instance.setPixmapFromFile(png)
            self[item["skin_value"]].show() if self.focus is 0 else self[item["skin_value"]].hide()

    def loadCoverList2(self, item, png):
        if self.last:
            for skin_value, x, y in self.coverList2:
                self[skin_value].hide()
        else:
            if (item["skin_value"], item["png_destination"]) in self.callback_list2 and png:
                self[item["skin_value"]].instance.setPixmapFromFile(png)
                self[item["skin_value"]].show() if self.focus is 0 else self[item["skin_value"]].hide()

    def moveSelectCover(self, index, mode):
        if mode is None:
            for skin_value, x, y in self.coverList1:
                self[skin_value].instance.move(ePoint(x, y))
                self[skin_value].instance.resize(eSize(skinValueCalculate(350), skinValueCalculate(350)))
            return
        if index <= 3:
            skin_value = "Cover" + str(index)
            x = skinValueCalculate(92)
            for i in range(index):
                x = x + skinValueCalculate(380)
            self[skin_value].instance.move(ePoint(x, skinValueCalculate(222)))
            self[skin_value].instance.resize(eSize(skinValueCalculate(366), skinValueCalculate(366)))
            self["CoverSelect"].instance.move(ePoint(x, skinValueCalculate(222)))
            self["CoverSelect"].show()
            if mode == "+" and index is not 0:
                (skin_value, x, y) = self.coverList1[index - 1]
                self[skin_value].instance.move(ePoint(x, y))
                self[skin_value].instance.resize(eSize(skinValueCalculate(350), skinValueCalculate(350)))
            elif mode == "-":
                (skin_value, x, y) = self.coverList1[index + 1]
                self[skin_value].instance.move(ePoint(x, y))
                self[skin_value].instance.resize(eSize(skinValueCalculate(350), skinValueCalculate(350)))

    def updateAvatarList(self):
        my_list = [(self.profile_title, "title", None), (DISNEY_KIDS_STR, "kids", self.kids_mode), (DISNEY_FINISHED_STR, "save", None)]
        data = [self.avatar_list_index, my_list]
        if self.avatar_list_index is 0:
            self['ProfileInfoText'].setText(DISNEY_ENTER_PROFILE)
        elif self.avatar_list_index is 1:
            self['ProfileInfoText'].setText(DISNEY_KIDS_INFO_STR)
        else:
            self['ProfileInfoText'].setText("")
        self.chooseDisneyConfig.setList(list(map(disney_avatar_entry, [data])))
        self.chooseDisneyConfig.selectionEnabled(0)

    def keyOK(self, callback=None):
        if self.data:
            if self.focus is 0:
                self.focus = 1
                self['ProfileGuiText1'].hide()
                self['ProfileGuiText2'].hide()
                self["ProfileAvatarLabel"].setText(DISNEY_CONFIGURE_PROFILE_STR)
                self.doHideAvatarCover()
                avatar = self.data[self.avatar_gui_index]["avatars"][self.avatar_index]
                try:
                    file_destination = "%s/avatar-%s.png" % (DISNEY_TMP_DIRECTORY, str(avatar.get("avatarUrl").split("/")[-2])) if avatar.get("avatarUrl") else ""
                    self["Avatar"].instance.setPixmapFromFile(file_destination)
                    self["Avatar"].show()
                except Exception as error:
                    pass
                self['ProfileConfig'].show()
                self['ProfileInfoText'].show()
                self.updateAvatarList()
            elif self.focus is 1:
                if self.avatar_list_index is 0:
                    value = "" if self.profile_title == DISNEY_MAY_PROFILE_STR else self.profile_title
                    self.session.openWithCallback(self.backKeyboard, InputBox, title=DISNEY_MAY_NEW_PROFILE_STR, text=value)
                elif self.avatar_list_index is 1:
                    self.kids_mode = True if not self.kids_mode else False
                    self.updateAvatarList()
                elif self.avatar_list_index is 2:
                    avatar = self.data[self.avatar_gui_index]["avatars"][self.avatar_index]
                    self.disney.getAddProfile(self.profile_title, self.backAddProfile, self.kids_mode, avatar.get("avatarId"))

    def backAddProfile(self, profile):
        if profile:
            avatar = self.data[self.avatar_gui_index]["avatars"][self.avatar_index]
            try:
                file_destination = "%s/avatar-%s.png" % (DISNEY_TMP_DIRECTORY, str(avatar.get("avatarUrl").split("/")[-2])) if avatar.get("avatarUrl") else ""
            except Exception as error:
                file_destination = DISNEY_DEFAULT_AVATAR_PNG
            profile.update({"png_destination": file_destination})
            profile.update({"url": avatar.get("avatarUrl")})
            self.close(profile, False)
        else:
            self.session.open(MessageBox, DISNEY_ERROR_STR, windowTitle="Disney+ Dream", type=MessageBox.TYPE_ERROR)

    def backKeyboard(self, callback):
        if callback != None:
            if callback not in self.profile_title_list:
                self.profile_title = callback
                self.updateAvatarList()
            else:
                self.session.openWithCallback(self.keyOK, MessageBox, DISNEY_MAY_NEW_PROFILE_ERROR_STR, windowTitle="Disney+ Dream", type=MessageBox.TYPE_ERROR)

    def keyLeft(self):
        if self.focus is 0 and self.data:
            if self.avatar_index is not 0:
                self.avatar_index -= 1
                self.loadSelectCoverList(self.avatar_index)
                self.moveSelectCover(self.avatar_index, "-")
        elif self.focus is 1 and self.avatar_list_index is 1:
            self.kids_mode = True if not self.kids_mode else False
            self.updateAvatarList()

    def keyRight(self):
        if self.focus is 0 and self.data:
            if self.avatar_index < len(self.data[self.avatar_gui_index]["avatars"]) - 1:
                self.avatar_index += 1
                self.loadSelectCoverList(self.avatar_index)
                self.moveSelectCover(self.avatar_index, "+")
        elif self.focus is 1 and self.avatar_list_index is 1:
            self.kids_mode = True if not self.kids_mode else False
            self.updateAvatarList()

    def keyUp(self):
        if self.focus is 0:
            if self.avatar_gui_index is not 0:
                self.avatar_gui_index -= 1
                self.moveSelectCover(self.avatar_index, None)
                self.buildGui()
        elif self.focus is 1:
            if self.avatar_list_index is not 0:
                self.avatar_list_index -= 1
                self.updateAvatarList()

    def keyDown(self):
        if self.focus is 0:
            if self.avatar_gui_index < len(self.data) - 1:
                self.avatar_gui_index += 1
                self.moveSelectCover(self.avatar_index, None)
                self.buildGui()
        elif self.focus is 1:
            if self.avatar_list_index is not 2:
                self.avatar_list_index += 1
                self.updateAvatarList()

    def keyPower(self):
        self.close(None, True)

    def keyCancel(self):
        self.close(None, False)

    def createSummary(self):
        return MyDisneySummary


def disney_avatar_entry(entry):
    res = [entry]
    index = entry[0]
    data = entry[1]

    pos = 0
    x = 0
    for txt, mode, value in data:
        if mode == "title":
            png = LoadPixmap(DISNEY_PROFILE_TEXT_PNG)
            res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, skinValueCalculate(2), skinValueCalculate(2), skinValueCalculate(796), skinValueCalculate(46), png))
            res.append(MultiContentEntryText(pos=(skinValueCalculate(8), skinValueCalculate(2)),
                                             size=(skinValueCalculate(780), skinValueCalculate(46)),
                                             flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                             font=0,
                                             text=txt,
                                             color=0xffffff,
                                             backcolor=0x646464))
        elif mode == "kids":
            res.append(MultiContentEntryText(pos=(skinValueCalculate(8), skinValueCalculate(102)),
                                             size=(skinValueCalculate(632), skinValueCalculate(46)),
                                             flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                             font=0,
                                             text=txt,
                                             color=0xffffff))
            txt = DISNEY_ON_STR if value else DISNEY_OFF_STR
            res.append(MultiContentEntryText(pos=(skinValueCalculate(640), skinValueCalculate(102)),
                                             size=(skinValueCalculate(146), skinValueCalculate(46)),
                                             flags=RT_HALIGN_RIGHT | RT_VALIGN_CENTER,
                                             font=0,
                                             text=txt,
                                             color=0xffffff))
        elif mode == "save":
            res.append(MultiContentEntryText(pos=(skinValueCalculate(8), skinValueCalculate(202)),
                                             size=(skinValueCalculate(792), skinValueCalculate(46)),
                                             flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                             font=0,
                                             text=txt,
                                             color=0x381ef0))
        if x == index:
            png = LoadPixmap(DISNEY_CONFIG_SETTINGS_SELECT_PNG)
            res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, 0, skinValueCalculate(pos),
                        skinValueCalculate(800), skinValueCalculate(50), png))
        pos += 100
        x += 1
    return res
