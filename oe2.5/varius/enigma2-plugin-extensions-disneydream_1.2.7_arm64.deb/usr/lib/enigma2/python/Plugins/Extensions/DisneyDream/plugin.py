from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Screens.MessageBox import MessageBox
from enigma import addFont, eServiceReference, eTimer
from Screens.Console import Console
from Components.Pixmap import Pixmap
from Screens.Standby import TryQuitMainloop
from Components.config import config, ConfigSubsection, configfile, ConfigPassword, ConfigYesNo, ConfigText, NoSave, ConfigSelection
from twisted.internet import reactor, threads
import os

from .disneyAddProfileScreen import DisneyAddProfileScreen
from .disneyConfigScreen import DisneySettingsScreen
from .Disney import DisneyHelper
from .disneyHelper import *
from .disneyHelper import _
from .disneyMenu import DisneyMenu
from .disneyGui import DisneyGui
from .disneyProfileScreen import DisneyProfileScreen
from .disneyMovieScreen import DisneyMovieScreen
from .disneyDetailsMovieScreen import DisneyDetailsMovieScreen
from .disneyDetailsSeasonScreen import DisneyDetailsSeasonScreen
from .disneySearchScreen import DisneySearchScreen

VERSION = "1.2.7"
INFO = "Package: enigma2-plugin-extensions-disneydream\nVersion: " + VERSION + "\nWatch Disney+ content on DreamOS 64\nMaintainer: murxer <support@boxpirates.to>"

config.plugins.disneyDream = ConfigSubsection()
config.plugins.disneyDream.animation = ConfigYesNo(default=True)
config.plugins.disneyDream.animationVideo = ConfigYesNo(default=True)
config.plugins.disneyDream.cache = ConfigYesNo(default=True)
config.plugins.disneyDream.player_languages = ConfigYesNo(default=False)
config.plugins.disneyDream.languages_code = ConfigSelection(choices=[("default", _("Default")),
                                                                     ("de", _("German")),
                                                                     ("en", _("English")),
                                                                     ("es-ES", _("Spain")),
                                                                     ("ru", _("Russian")),
                                                                     ("pl", _("Polish")),
                                                                     ("tr", _("Turkish")),
                                                                     ("ja", _("Japan")),
                                                                     ("fr-FR", _("French")),
                                                                     ("it", _("Italian")),
                                                                     ("ko", _("Korean")),
                                                                     ("cs", _("Czech")),
                                                                     ("pt-BR", _("Portugal")),
                                                                     ("ro", _("Romania")),
                                                                     ("sk", _("Slovak")),
                                                                     ("hu", _("Korean"))],
                                                            default="default")

if not os.path.isdir(DISNEY_TMP_DIRECTORY):
    os.system("mkdir %s" % DISNEY_TMP_DIRECTORY)


class DisneyDream(Screen, DisneyMenu, DisneyGui):
    try:
        addFont("/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/font/OpenSans-Regular.ttf", "DD", 100, False)
    except Exception as ex:
        addFont("/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/font/OpenSans-Regular.ttf", "DD", 100, False,
                0)

    def __init__(self, session, contentId=None, contentType=None):
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen backgroundColor="#002d3343" flags="wfNoBorder" name="DisneyDream" position="center,center" size="2560,1440" title="DisneyDream">
                           <widget name="DisneyMenuBar" position="13,240" size="53,960" foregroundColor="#008c8181" backgroundColor="#002d3343" zPosition="98" transparent="0" enableWrapAround="1" />
                           <widget name="DisneyMenu" position="80,240" size="400,963" foregroundColor="#008c8181" backgroundColor="#002d3343" zPosition="99" transparent="0" enableWrapAround="1" />
                           <widget name="MenuBackground" gradient="#202d3343,#202d3343,horizontal" position="0,0" size="2560,1440" zPosition="97" />
                           <widget name="DisneyStartLogo" position="0,0" size="2560,1440" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/logo_1920x1080.png" zPosition="98" />
                           <widget name="DisneyHeroGui" cornerDia="40" position="167,40" size="2227,569" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/hero_1670x427.png" zPosition="3" />
                           <widget name="DisneyGuiText1" position="133,941" size="2400,53" font="DD;40" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="6" valign="center" halign="left"/>
                           <widget name="Cover0" cornerDia="40" position="133,1021" size="467,261" zPosition="5" />
                           <widget name="Cover1" cornerDia="40" position="653,1021" size="467,261" zPosition="5" />
                           <widget name="Cover2" cornerDia="40" position="1173,1021" size="467,261" zPosition="5" />
                           <widget name="Cover3" cornerDia="40" position="1693,1021" size="467,261" zPosition="5" />
                           <widget name="Cover4" cornerDia="40" position="2213,1021" size="467,261" zPosition="5" />
                           <widget name="CoverSelect" position="100,733" size="533,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/select_533x300.png"  zPosition="6" />
                           <widget name="DisneyGuiText2" position="133,1332" size="2400,53" font="DD;40" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="6" valign="center" halign="left"/>
                           <widget name="Cover5" cornerDia="40" position="133,1412" size="467,261" zPosition="5" />
                           <widget name="Cover6" cornerDia="40" position="653,1412" size="467,261" zPosition="5" />
                           <widget name="Cover7" cornerDia="40" position="1173,1412" size="467,261" zPosition="5" />
                           <widget name="Cover8" cornerDia="40" position="1693,1412" size="467,261" zPosition="5" />
                           <widget name="Cover9" cornerDia="40" position="2213,1412" size="467,261" zPosition="5" />
                           <widget name="DisneyBrandGui" position="173,693" size="2240,177" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="4" transparent="1" enableWrapAround="1" />
                           <widget name="TimerSpinner" position="1233,673" size="93,93" zPosition="99" />
                           </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """<screen backgroundColor="#002d3343" flags="wfNoBorder" name="DisneyDream" position="center,center" size="1920,1080" title="DisneyDream">
                           <widget name="DisneyMenuBar" position="10,180" size="40,720" foregroundColor="#008c8181" backgroundColor="#002d3343" zPosition="98" transparent="0" enableWrapAround="1" />
                           <widget name="DisneyMenu" position="60,180" size="300,720" foregroundColor="#008c8181" backgroundColor="#002d3343" zPosition="99" transparent="0" enableWrapAround="1" />
                           <widget name="MenuBackground" gradient="#202d3343,#202d3343,horizontal" position="0,0" size="1920,1080" zPosition="97" />
                           <widget name="DisneyStartLogo" position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/logo_1920x1080.png" zPosition="98" />  
                           <widget name="DisneyHeroGui" position="125,30" size="1670,427" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/hero_1670x427.png" zPosition="3" />                  
                           <widget name="DisneyGuiText1" position="100,706" size="1800,40" font="DD;30" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="6" valign="center" halign="left"/>
                           <widget name="Cover0" position="100,766" size="350,196" zPosition="5" />
                           <widget name="Cover1" position="490,766" size="350,196" zPosition="5" />
                           <widget name="Cover2" position="880,766" size="350,196" zPosition="5" />
                           <widget name="Cover3" position="1270,766" size="350,196" zPosition="5" />
                           <widget name="Cover4" position="1660,766" size="350,196" zPosition="5" />
                           <widget name="CoverSelect" position="75,550" size="400,225" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/select_400x225.png"  zPosition="6" />
                           <widget name="DisneyGuiText2" position="100,999" size="1800,40" font="DD;30" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="6" valign="center" halign="left"/>
                           <widget name="Cover5" position="100,1059" size="350,196" zPosition="5" />
                           <widget name="Cover6" position="490,1059" size="350,196" zPosition="5" />
                           <widget name="Cover7" position="880,1059" size="350,196" zPosition="5" />
                           <widget name="Cover8" position="1270,1059" size="350,196" zPosition="5" />
                           <widget name="Cover9" position="1660,1059" size="350,196" zPosition="5" />
                           <widget name="DisneyBrandGui" position="130,520" size="1680,133" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="4" transparent="1" enableWrapAround="1" />                  
                           <widget name="TimerSpinner" position="925,505" size="70,70" zPosition="99" />
                           </screen>
                        """
        else:
            self.skin = """<screen backgroundColor="#002d3343" flags="wfNoBorder" name="DisneyDream" position="center,center" size="1280,720" title="DisneyDream">
                           <widget name="DisneyMenuBar" position="6,120" size="26,480" foregroundColor="#008c8181" backgroundColor="#002d3343" zPosition="98" transparent="0" enableWrapAround="1" />
                           <widget name="DisneyMenu" position="40,120" size="200,480" foregroundColor="#008c8181" backgroundColor="#002d3343" zPosition="99" transparent="0" enableWrapAround="1" />
                           <widget name="MenuBackground" gradient="#202d3343,#202d3343,horizontal" position="0,0" size="1280,720" zPosition="97" />
                           <widget name="DisneyStartLogo" position="0,0" size="1280,720" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/logo_1280x720.png" zPosition="98" />
                           <widget name="DisneyHeroGui" position="83,20" size="1113,284" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/hero_1113x284.png" zPosition="3" />
                           <widget name="DisneyGuiText1" position="66,470" size="1200,26" font="DD;20" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="6" valign="center" halign="left"/>
                           <widget name="Cover0" position="66,510" size="233,132" zPosition="5" />
                           <widget name="Cover1" position="326,510" size="233,132" zPosition="5" />
                           <widget name="Cover2" position="586,510" size="233,132" zPosition="5" />
                           <widget name="Cover3" position="846,510" size="233,132" zPosition="5" />
                           <widget name="Cover4" position="1106,510" size="233,132" zPosition="5" />
                           <widget name="CoverSelect" position="50,368" size="266,150" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/select_266x150.png"  zPosition="6" />
                           <widget name="DisneyGuiText2" position="66,666" size="1200,26" font="DD;20" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="6" valign="center" halign="left"/>
                           <widget name="Cover5" position="66,706" size="233,132" zPosition="5" />
                           <widget name="Cover6" position="326,706" size="233,132" zPosition="5" />
                           <widget name="Cover7" position="586,706" size="233,132" zPosition="5" />
                           <widget name="Cover8" position="846,706" size="233,132" zPosition="5" />
                           <widget name="Cover9" position="1106,706" size="233,132" zPosition="5" />
                           <widget name="DisneyBrandGui" position="86,346" size="1120,88" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="4" transparent="1" enableWrapAround="1" />
                           <widget name="TimerSpinner" position="616,336" size="46,46" zPosition="99" />
                           </screen>
                        """
        Screen.__init__(self, session)
        self['actions'] = ActionMap(['DisneyDream_Actions'],
                                    {'ok': self.keyOk,
                                     'cancel': self.keyMenu,
                                     "menu": self.keyMenu,
                                     'left': self.keyLeft,
                                     'right': self.keyRight,
                                     'up': self.keyUp,
                                     'down': self.keyDown,
                                     'info': self.keyInfo,
                                     'power': self.keyExit,
                                     "record": self.keyRecord
                                     }, -1)

        DisneyMenu.__init__(self)
        DisneyGui.__init__(self)

        self['DisneyStartLogo'] = Pixmap()

        self.username = ""
        self.password = ""
        self.is_login = False

        self.disney = None
        self.homeCountdown = 0
        self.profilesCountdown = 0
        self.seasonCountdown = 0

        self.show_data = []
        self.profiles_data = []
        self.movie_data = []
        self.season_data = []

        self.contentId = contentId
        self.contentType = contentType

        self.onLayoutFinish.append(self.createSetup)

    def createSetup(self):
        self.username = config.vod.disney.username.value
        self.password = config.vod.disney.password.value
        self.disney = DisneyHelper(self.gotInitDataCallback)

    def gotInitDataCallback(self, success):
        if success:
            if self.disney is not None:
                self.disney.login(self.username, self.password, self.loggedInCallback)
        else:
            print("[VodDisney] Error while retrieving init data")

    def loggedInCallback(self, success):
        Check(self.session)
        if success:
            self.is_login = True
            self.profiles_data = []
            #self.disney.getAccData(self.backAccData)
            self.disney.getProfiles(self.backReadProfiles)
        else:
            self.session.openWithCallback(self.backSettings, DisneySettingsScreen, self.disney)

    def backAccData(self, callback):
        if callback:
            self.disney.getProfiles(self.backReadProfiles)

    def keyRecord(self):
        if self.is_login and self.disney.profile:
            info = self.disney.getAccInfo(self.disney.profile)
            self.session.open(MessageBox, windowTitle="Disney+ Dream", text=getTxt(info), type=MessageBox.TYPE_INFO)

    def keyMenu(self):
        self['DisneyStartLogo'].hide()
        if not self.disney_menu_show:
            self.key_menu()
        else:
            self.keyExit()

    def fasterExit(self, callback=None):
        if callback:
            self.keyExit()

    def keyExit(self, callback=None):
        if os.path.isdir(DISNEY_TMP_DIRECTORY) and config.plugins.disneyDream.cache.value:
            os.system("rm %s/*.png" % DISNEY_TMP_DIRECTORY)
        self.close(self.session, True)

    def keyOk(self):
        if self.disney_menu_show:
            value = self.key_ok_menu()
            self.buildMenu(value)
        elif self.disney_gui_focus is 0:
            if self.is_login:
                self.startTimerSpinner()
                self.disney.getCollectionBySlug(self.brand_gui_data[self.disney_brand_index][1], self.brand_gui_data[self.disney_brand_index][2], self.readMovieCategoryCallback)
        elif self.disney_gui_focus is 1:
            if self.video_list and self.is_login:
                (refType, video) = self.key_disney_gui_ok()
                self.series_video = video
                if video.get("mediaType") == "MOVIE" and not video.get("seriesId"):
                    if video.get("encodedFamilyId"):
                        self.startTimerSpinner()
                        self.disney.getVideoBundle(video.get("encodedFamilyId"), self.backReadFamilyId, video)
                elif video.get("mediaType") == "SERIES" or video.get("encodedSeriesId"):
                    self.startTimerSpinner()
                    self.disney.getSeriesBundle(video.get("encodedSeriesId"), self.backSeriesBundle)
                elif video.get("mediaType") == "COLLECTION":
                    self.startTimerSpinner()
                    self.disney.getCollectionBySlug(video.get("contentClass"), video.get("slugs"), self.readMovieCategoryCallback)

    def backSeriesBundle(self, seasons, family, series):
        if seasons:
            self.season_data = []
            self.family_data = family
            self.seasonCountdown = len(seasons)
            if series:
                self.series_video = series
            self.series_video.update({"familyData": family})
            for season in seasons:
                season.update({"episodes": []})
                self.disney.getSeriesEpisodes(season.get("seasonId"), self.backReadEpisode, season)
        else:
            self.stopTimerSpinner()

    def backReadEpisode(self, callback):
        self.seasonCountdown -= 1
        self.season_data.append(callback)
        if self.seasonCountdown is 0:
            self.season_data = sorted(self.season_data, key=lambda item: (item["seasonSequenceNumber"]))
            self.series_video.update({"season": self.season_data})
            # self.series_video.update({"familyData": self.family_data})
            self.disney.getContinueWatchingSeries(self.series_video.get("encodedSeriesId"), self.callbackContinueWatchingSeries, self.series_video)

    def backReadFamilyId(self, video):
        # video.update({"familyData": callback})
        self.disney.getContinueWatching(video.get("encodedFamilyId"), self.callbackContinueWatching, video)

    def callbackContinueWatching(self, video):
        self.stopTimerSpinner()
        (refType, data) = self.key_disney_gui_ok()
        continue_watching = True if refType == "ContinueWatchingSet" else False
        self.session.openWithCallback(self.backCheckJustWatch, DisneyDetailsMovieScreen, video, self.disney, continue_watching=continue_watching)

    def backCheckJustWatch(self, callback=None):
        if self.contentId and self.contentType or callback:
            self.keyExit()

    def callbackContinueWatchingSeries(self, video):
        self.seasonCountdown = len(video["season"])
        for season in video["season"]:
            self.disney.getContinueWatchingSeason(self.callbackContinueWatchingSeason, season)

    def callbackContinueWatchingSeason(self, season):
        self.seasonCountdown -= 1
        if self.seasonCountdown is 0:
            self.stopTimerSpinner()
            (refType, data) = self.key_disney_gui_ok()
            continue_watching = True if refType == "ContinueWatchingSet" else False
            self.session.openWithCallback(self.backCheckJustWatch, DisneyDetailsSeasonScreen, self.series_video, self.disney, continue_watching=continue_watching)

    def buildMenu(self, value):
        if value == DISNEY_SEARCH_STR:
            if self.is_login:
                self.session.openWithCallback(self.fasterExit, DisneySearchScreen, self.disney)
        elif value == DISNEY_HOME_STR:
            self.do_select_menu_active(value=DISNEY_HOME_STR)
            if self.is_login:
                self.startTimerSpinner()
                self.disney.getCollectionBySlug("home", "home", self.readCategoryCallback)
        elif value == DISNEY_ORIGINALS_STR:
            if self.is_login:
                self.startTimerSpinner()
                self.disney.getCollectionBySlug("originals", "originals", self.readMovieCategoryCallback)
        elif value == DISNEY_SHOW_STR:
            if self.is_login:
                self.startTimerSpinner()
                self.disney.getCollectionBySlug("contentType", "series", self.readMovieCategoryCallback)
        elif value == DISNEY_MOVIE_STR:
            if self.is_login:
                self.startTimerSpinner()
                self.disney.getCollectionBySlug("contentType", "movies", self.readMovieCategoryCallback)
        elif value == DISNEY_WATCH_STR:
            if self.is_login:
                self.startTimerSpinner()
                self.disney.getCollectionBySlug("watchlist", "watchlist", self.readMovieCategoryCallback)
        elif value == DISNEY_PROFILE_STR:
            if self.is_login:
                self.startTimerSpinner()
                self.profiles_data = []
                self.disney.getProfiles(self.backReadProfiles)
        elif value == DISNEY_SETTINGS_STR:
            self.session.openWithCallback(self.backSettings, DisneySettingsScreen, self.disney)
        else:
            self.keyExit()

    def backReadProfiles(self, data):
        if data:
            self.profilesCountdown = len(data)
            for profile in data:
                self.disney.getAvatarById(profile, self.backReadAvatarImage)
        else:
            self.stopTimerSpinner()
            self.session.openWithCallback(self.backAddProfile, DisneyAddProfileScreen, self.disney, self.avatars, self.profile_title_list)

    def backAddProfile(self, callback=None, faster_exit=None):
        if faster_exit:
            self.keyExit()
            return
        self.startTimerSpinner()
        self.profiles_data = []
        self.disney.getProfiles(self.backReadProfiles)

    def backReadAvatarImage(self, profile):
        self.profiles_data.append(profile)
        self.profilesCountdown -= 1
        if self.profilesCountdown is 0:
            self.stopTimerSpinner()
            self.session.openWithCallback(self.backProfile, DisneyProfileScreen, self.disney, self.profiles_data)

    def backProfile(self, callback, mode, faster_exit):
        if faster_exit:
            self.keyExit()
            return
        if callback and mode == "profile":
            if self.contentId and self.contentType:
                self.startTimerSpinner()
                if self.contentType == "MOVIE":
                    self.disney.getVideoDataFamily(self.contentId, self.readGetVideosCallback)
                else:
                    self.disney.getSeriesData(self.contentId, self.readGetVideosCallback)
            else:
                self.disney.hero_items = []
                self.do_select_menu_active(value=DISNEY_HOME_STR)
                self.startTimerSpinner()
                self.disney.getCollectionBySlug("home", "home", self.readCategoryCallback)
        elif mode == "reload":
            try:
                print("[DisneyDream] delete cookie")
                os.system("rm /var/lib/widevine/disney.storage")
            except Exception as error:
                pass
            self.close(self.session, False)
        else:
            if self.contentId and self.contentType:
                self.keyExit()

    def readGetVideosCallback(self, video):
        if video.get("mediaType") == "MOVIE" and not video.get("seriesId"):
            if video.get("encodedFamilyId"):
                self.startTimerSpinner()
                self.disney.getVideoBundle(video.get("encodedFamilyId"), self.backReadFamilyId, video)
        elif video.get("mediaType") == "SERIES" or video.get("encodedSeriesId"):
            self.startTimerSpinner()
            self.series_video = video
            self.disney.getSeriesBundle(video.get("encodedSeriesId"), self.backSeriesBundle)
        else:
            self.session.openWithCallback(self.keyExit, MessageBox, windowTitle="Disney+ Dream", text="No video found!", type=MessageBox.TYPE_ERROR)

    def readCategoryCallback(self, data):
        if data:
            self.video_list = []
            self.homeCountdown = len(data)
            for category in data:
                self.disney.getSetBySetId(category, self.updateHomeList)

    def readMovieCategoryCallback(self, data):
        if data:
            self.movie_data = []
            self.homeCountdown = len(data)
            for category in data:
                self.disney.getSetBySetId(category, self.updateMovieList)

    def updateMovieList(self, data, category):
        if data:
            category = self.disney.getCollectionItems(data, category)
            if category["videos"]:
                self.movie_data.append(category)
        self.homeCountdown -= 1
        if self.homeCountdown is 0:
            self.stopTimerSpinner()
            if self.movie_data:
                self.movie_data = sorted(self.movie_data, key=lambda item: int(item["index"]))
                self.session.openWithCallback(self.fasterExit, DisneyMovieScreen, self.disney, self.movie_data)

    def updateHomeList(self, data, category):
        if data:
            category = self.disney.getCollectionItems(data, category)
            if category["videos"]:
                self.video_list.append(category)
        self.homeCountdown -= 1
        if self.homeCountdown is 0:
            self.stopTimerSpinner()
            self['DisneyStartLogo'].hide()
            self.video_list = sorted(self.video_list, key=lambda item: int(item["index"]))
            self.buildGuiData(update=True)

    def backSettings(self, status):
        self['DisneyStartLogo'].hide()
        if status:
            if config.vod.disney.username.value == "" and config.vod.disney.password.value == "":
                self.is_login = False
                self.username = config.vod.disney.username.value
                self.password = config.vod.disney.password.value
                self.disney.login(self.username, self.password, self.loggedInCallback)
            else:
                self.is_login = True
                self.buildMenu(DISNEY_HOME_STR)

    def keyLeft(self):
        if self.disney_gui_focus == 1 and not self.disney_item_index == 0:
            self.key_disney_gui_left()
        elif self.disney_gui_focus == 0 and not self.disney_brand_index == 0:
            self.key_disney_gui_left()
        elif not self.disney_menu_show:
            self.keyMenu()

    def keyRight(self):
        if self.disney_menu_show:
            self.key_menu()
        else:
            self.key_disney_gui_right()

    def keyUp(self):
        if self.disney_menu_show:
            self.key_up_menu()
        else:
            self.key_disney_gui_up()

    def keyDown(self):
        if self.disney_menu_show:
            self.key_down_menu()
        else:
            self.key_disney_gui_down()

    def keyInfo(self):
        self.session.open(MessageBox, windowTitle="Disney+ Dream Info", text=INFO, type=MessageBox.TYPE_INFO)

    def createSummary(self):
        return MyDisneySummary


class Check:
    def __init__(self, session):
        self.session = session
        threads.deferToThread(self.readRelease, self.runMessage)

    def readRelease(self, callback):
        try:
            update = os.popen("apt-get update && apt list --upgradable")
            update = update.read()
            if update and "enigma2-plugin-extensions-disneydream" in update:
                message = _("DisneyDream update online.\nInstall update now?")
                reactor.callFromThread(callback, message)
        except Exception as error:
            print("DisneyDream update check error!")

    def runMessage(self, message=None):
        if message:
            try:
                self.session.openWithCallback(self.backMessageBox, MessageBox, message, MessageBox.TYPE_YESNO, default=False)
            except Exception as error:
                # modal open are allowed only from a screen which is modal
                print("DisneyDream update message error!")

    def backMessageBox(self, answer):
        if answer:
            cmd = 'apt-get update && apt-get -f -y --assume-yes install --only-upgrade enigma2-plugin-extensions-disneydream'
            self.session.openWithCallback(self.backConsole, Console, _('Update DisneyDream'), [cmd])

    def backConsole(self, callback=None):
        self.session.openWithCallback(self.backMessageBoxRestart, MessageBox, _("Enigma needs to restart?"), MessageBox.TYPE_YESNO, default=True)

    def backMessageBoxRestart(self, answer):
        if answer:
            self.session.open(TryQuitMainloop, 3)


def exit(session, result):
    if not result:
        session.openWithCallback(exit, DisneyDream)


def main(session, **kwargs):
    try:
        from Plugins.Extensions.VOD.Disney.Disney import Disney
        session.openWithCallback(exit, DisneyDream)
    except Exception as e:
        session.open(MessageBox, 'enigma2-plugin-vod not found', MessageBox.TYPE_ERROR, timeout=5)


def justWatch(session, contentId, contentType, **kwargs):
    try:
        from Plugins.Extensions.VOD.Disney.Disney import Disney
        session.open(DisneyDream, contentId, contentType)
    except Exception as e:
        session.open(MessageBox, 'enigma2-plugin-vod not found', MessageBox.TYPE_ERROR, timeout=5)


def Plugins(path, **kwwargs):
    return [
        PluginDescriptor(name='Disney+ Dream', description=_('Watch Disney+ content'),
                         where=[PluginDescriptor.WHERE_PLUGINMENU, PluginDescriptor.WHERE_EXTENSIONSMENU], fnc=main,
                         icon='plugin.png')]
