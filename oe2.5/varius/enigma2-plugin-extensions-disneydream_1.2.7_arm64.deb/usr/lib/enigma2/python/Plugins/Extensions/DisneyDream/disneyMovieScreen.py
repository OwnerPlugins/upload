from Components.AVSwitch import AVSwitch
from enigma import gFont, getDesktop, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP, RT_WRAP, ePicLoad, eTimer, ePoint, eSize
from Components.Pixmap import Pixmap
from Components.Label import Label
from Components.ActionMap import ActionMap
from Screens.Screen import Screen
from Components.config import config

from disneyHelper import *
from disneyHelper import _
from disneyDetailsMovieScreen import DisneyDetailsMovieScreen
from disneyDetailsSeasonScreen import DisneyDetailsSeasonScreen
from disneyHeroLogoAnimation import DisneyHeroLogoGuiAnimation
from disneyHeroAnimation import DisneyHeroGuiAnimation

import os


class DisneyMovieSpinner:
    def __init__(self):
        # Spinner Timer
        self['TimerSpinner'] = Pixmap()
        self['TimerSpinner'].hide()
        self.timerSpinner = eTimer()
        self.timerSpinnerStatusSpinner = False
        self.timerSpinnerCounter = 1
        self.timerSpinner_conn = self.timerSpinner.timeout.connect(self.loadTimerSpinner)

    def stopTimerSpinner(self):
        self.timerSpinnerStatusSpinner = False

    def startTimerSpinner(self):
        self.timerSpinnerStatusSpinner = True
        self.loadTimerSpinner()

    def loadTimerSpinner(self):
        if self.timerSpinnerStatusSpinner:
            png = "%s/%s.png" % (DISNEY_SPINNER_DIRECTORY, str(self.timerSpinnerCounter))
            self.showTimerSpinner(png)
        else:
            self['TimerSpinner'].hide()

    def showTimerSpinner(self, png):
        self["TimerSpinner"].instance.setPixmapFromFile(png)
        self["TimerSpinner"].show()
        if self.timerSpinnerCounter is not 34:
            self.timerSpinnerCounter += 1
        else:
            self.timerSpinnerCounter = 1
        self.timerSpinner.start(10, True)


class DisneyMovieScreen(Screen, DisneyMovieSpinner, DisneyHeroLogoGuiAnimation, DisneyHeroGuiAnimation):
    def __init__(self, session, disney, data):
        # load skin
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen name="DisneyDream" backgroundColor="#00000000" position="center,center" size="2560,1440" title="DisneyDream" flags="wfNoBorder">
                           <widget name="DisneyHeroGuiAnimation" position="0,0" size="2560,853" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/hero_default_movie_1920x640.png" zPosition="1" />
                           <widget name="DisneyHeroLogoAnimation" position="133,333" size="533,300" zPosition="2" />
                           <widget name="DisneyGuiText1" position="53,861" size="2400,53" font="DD;40" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="2" valign="center" halign="left"/>
                           <widget name="Cover0" cornerDia="40" position="53,941" size="467,261" zPosition="2" />
                           <widget name="Cover1" cornerDia="40" position="573,941" size="467,261" zPosition="2" />
                           <widget name="Cover2" cornerDia="40" position="1093,941" size="467,261" zPosition="2" />
                           <widget name="Cover3" cornerDia="40" position="1613,941" size="467,261" zPosition="2" />
                           <widget name="Cover4" cornerDia="40" position="2133,941" size="467,261" zPosition="2" />
                           <widget name="CoverSelect" position="20,1056" size="533,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/select_black_533x300.png"  zPosition="3" />
                           <widget name="DisneyGuiText2" position="53,1252" size="2400,53" font="DD;40" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="2" valign="center" halign="left"/>
                           <widget name="Cover5" cornerDia="40" position="53,1332" size="467,261" zPosition="2" />
                           <widget name="Cover6" cornerDia="40" position="573,1332" size="467,261" zPosition="2" />
                           <widget name="Cover7" cornerDia="40" position="1093,1332" size="467,261" zPosition="2" />
                           <widget name="Cover8" cornerDia="40" position="1613,1332" size="467,261" zPosition="2" />
                           <widget name="Cover9" cornerDia="40" position="2133,1332" size="467,261" zPosition="2" />
                           <widget name="TimerSpinner" position="1233,673" size="93,93" zPosition="99" />
                           </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """<screen name="DisneyDream" backgroundColor="#00000000" position="center,center" size="1920,1080" title="DisneyDream" flags="wfNoBorder">
                           <widget name="DisneyHeroGuiAnimation" position="0,0" size="1920,640" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/hero_default_movie_1920x640.png" zPosition="1" />                  
                           <widget name="DisneyHeroLogoAnimation" position="100,250" size="400,225" zPosition="2" />
                           <widget name="DisneyGuiText1" position="40,646" size="1800,40" font="DD;30" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="2" valign="center" halign="left"/>
                           <widget name="Cover0" position="40,706" size="350,196" zPosition="2" />
                           <widget name="Cover1" position="430,706" size="350,196" zPosition="2" />
                           <widget name="Cover2" position="820,706" size="350,196" zPosition="2" />
                           <widget name="Cover3" position="1210,706" size="350,196" zPosition="2" />
                           <widget name="Cover4" position="1600,706" size="350,196" zPosition="2" />
                           <widget name="CoverSelect" position="15,792" size="400,225" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/select_black_400x225.png"  zPosition="3" />                          
                           <widget name="DisneyGuiText2" position="40,939" size="1800,40" font="DD;30" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="2" valign="center" halign="left"/>
                           <widget name="Cover5" position="40,999" size="350,196" zPosition="2" />
                           <widget name="Cover6" position="430,999" size="350,196" zPosition="2" />
                           <widget name="Cover7" position="820,999" size="350,196" zPosition="2" />
                           <widget name="Cover8" position="1210,999" size="350,196" zPosition="2" />
                           <widget name="Cover9" position="1600,999" size="350,196" zPosition="2" />
                           <widget name="TimerSpinner" position="925,505" size="70,70" zPosition="99" />
                           </screen>
                        """
        else:
            self.skin = """<screen name="DisneyDream" backgroundColor="#00000000" position="center,center" size="1280,720" title="DisneyDream" flags="wfNoBorder">
                           <widget name="DisneyHeroGuiAnimation" position="0,0" size="1280,426" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/hero_default_movie_1280x426.png" zPosition="1" />
                           <widget name="DisneyHeroLogoAnimation" position="66,166" size="266,150" zPosition="2" />
                           <widget name="DisneyGuiText1" position="26,426" size="1200,26" font="DD;20" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="2" valign="center" halign="left"/>
                           <widget name="Cover0" position="26,470" size="233,130" zPosition="2" />
                           <widget name="Cover1" position="286,470" size="233,130" zPosition="2" />
                           <widget name="Cover2" position="546,470" size="233,130" zPosition="2" />
                           <widget name="Cover3" position="806,470" size="233,130" zPosition="2" />
                           <widget name="Cover4" position="1066,470" size="233,130" zPosition="2" />
                           <widget name="CoverSelect" position="10,528" size="266,150" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/select_black_266x150.png"  zPosition="3" />
                           <widget name="DisneyGuiText2" position="26,620" size="1200,26" font="DD;20" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="2" valign="center" halign="left"/>
                           <widget name="Cover5" position="26,666" size="233,130" zPosition="2" />
                           <widget name="Cover6" position="286,666" size="233,130" zPosition="2" />
                           <widget name="Cover7" position="546,666" size="233,130" zPosition="2" />
                           <widget name="Cover8" position="806,666" size="233,130" zPosition="2" />
                           <widget name="Cover9" position="1066,666" size="233,130" zPosition="2" />
                           <widget name="TimerSpinner" position="616,336" size="46,46" zPosition="99" />
                           </screen>
                        """

        Screen.__init__(self, session)

        self['actions'] = ActionMap(['DisneyDream_Actions'],
                                    {'ok': self.keyOk,
                                     'cancel': self.keyCancel,
                                     'left': self.keyLeft,
                                     'right': self.keyRight,
                                     'up': self.keyUp,
                                     'down': self.keyDown,
                                     'power': self.keyPower}, -1)

        DisneyMovieSpinner.__init__(self)
        DisneyHeroLogoGuiAnimation.__init__(self)
        DisneyHeroGuiAnimation.__init__(self)

        self.disney = disney

        self.coverList1 = [("Cover0", skinValueCalculate(40), skinValueCalculate(706)),
                           ("Cover1", skinValueCalculate(430), skinValueCalculate(706)),
                           ("Cover2", skinValueCalculate(820), skinValueCalculate(706)),
                           ("Cover3", skinValueCalculate(1210), skinValueCalculate(706)),
                           ("Cover4", skinValueCalculate(1600), skinValueCalculate(706))]
        for skin_value, x, y in self.coverList1:
            self[skin_value] = Pixmap()

        self.coverList2 = [("Cover5", skinValueCalculate(40), skinValueCalculate(999)),
                           ("Cover6", skinValueCalculate(430), skinValueCalculate(999)),
                           ("Cover7", skinValueCalculate(820), skinValueCalculate(999)),
                           ("Cover8", skinValueCalculate(1210), skinValueCalculate(999)),
                           ("Cover9", skinValueCalculate(1600), skinValueCalculate(999))]
        for skin_value, x, y in self.coverList2:
            self[skin_value] = Pixmap()

        self["CoverSelect"] = Pixmap()
        self["CoverSelect"].hide()

        self.disney = disney
        self.callback_list1 = []
        self.callback_list2 = []
        self.last = None

        self['DisneyGuiText1'] = Label("")
        self['DisneyGuiText2'] = Label("")

        self.item_index = 0
        self.genre_index = 0
        self.data = data
        self.callback_hero_index = 0
        self.callback_hero_logo_index = 0

        self.season_data = []
        self.seasonCountdown = 0
        self.family_data = []

        self.oldGuiData = []

        self.onLayoutFinish.append(self.buildGuiData)
        
    def buildGuiData(self):
        self.last = None
        if self.data:
            title = getTxt(self.data[self.genre_index]["title"])
            self['DisneyGuiText1'].setText(title)
            self.loadSelectCoverList(self.item_index)
            self.moveSelectCover(self.item_index, None)
            data = []
            if self.genre_index + 1 <= len(self.data) - 1:
                title = getTxt(self.data[self.genre_index + 1]["title"])
                video_data = self.data[self.genre_index+ 1]["videos"]
                self['DisneyGuiText2'].setText(title)
                max_range = 5 if len(video_data) > 4 else len(video_data)
                data = []
                for i in range(max_range):
                    video = video_data[i]
                    data.append(video)

            else:
                self.last = True
                self['DisneyGuiText2'].setText("")
            self.setCategoryList2(data)
            self.update_disney_hero_gui()
            self.update_disney_hero_logo()
        else:
            self['DisneyGuiText1'].setText("")
            self['DisneyGuiText2'].setText("")
            self.setCategoryList2([])
    
    def setCategoryList2(self, data):
        self.callback_list2 = []
        max = len(data)
        item = 0
        for skin_value, x, y in self.coverList2:
            if max is not 0:
                png_data = data[item]["cover"]
                png_data.update({"skin_value": skin_value})
                if os.path.isfile(getTxt(png_data["png_destination"])):
                    ptr = decodePic(png_data)
                    if ptr != None:
                        self[png_data["skin_value"]].instance.setPixmap(ptr)
                        self[png_data["skin_value"]].show()
                    else:
                        self[png_data["skin_value"]].instance.setPixmapFromFile(DISNEY_DEFAULT_COVER_PNG)
                        self[png_data["skin_value"]].show()
                else:
                    self.callback_list2.append((png_data["skin_value"], png_data["png_destination"]))
                    self[png_data["skin_value"]].instance.setPixmapFromFile(DISNEY_DEFAULT_COVER_PNG)
                    self[png_data["skin_value"]].show()
                    self.disney.contentDownloader(png_data["url"], png_data, callback=self.loadCoverList2)
                max -= 1
            else:
                self[skin_value].hide()
            item += 1

    def loadCoverList2(self, item, png):
        if self.last:
            for skin_value, x, y in self.coverList2:
                self[skin_value].hide()
        else:
            if (item["skin_value"], item["png_destination"]) in self.callback_list2 and png:
                ptr = decodePic(item)
                if ptr != None:
                    self[item["skin_value"]].instance.setPixmap(ptr)
                    self[item["skin_value"]].show()
                else:
                    self[item["skin_value"]].instance.setPixmapFromFile(DISNEY_DEFAULT_COVER_PNG)
                    self[item["skin_value"]].show()

    def setDefaultSelectCover(self):
        for skin_value, x, y in self.coverList1:
            self[skin_value].instance.move(ePoint(x, y))
            self[skin_value].instance.resize(eSize(skinValueCalculate(350), skinValueCalculate(196)))

    def moveSelectCover(self, index, mode):
        if mode is None:
            for skin_value, x, y in self.coverList1:
                self[skin_value].instance.move(ePoint(x, y))
                self[skin_value].instance.resize(eSize(skinValueCalculate(350), skinValueCalculate(196)))
        if index <= 3:
            skin_value = "Cover" + str(index)
            x = skinValueCalculate(15)
            for i in range(index):
                x = x + skinValueCalculate(390)
            self[skin_value].instance.move(ePoint(x, skinValueCalculate(692)))
            self[skin_value].instance.resize(eSize(skinValueCalculate(400), skinValueCalculate(225)))
            self["CoverSelect"].instance.move(ePoint(x, skinValueCalculate(692)))
            self["CoverSelect"].show()
            if mode == "+" and index is not 0:
                (skin_value, x, y) = self.coverList1[index - 1]
                self[skin_value].instance.move(ePoint(x, y))
                self[skin_value].instance.resize(eSize(skinValueCalculate(350), skinValueCalculate(196)))
            elif mode == "-":
                (skin_value, x, y) = self.coverList1[index + 1]
                self[skin_value].instance.move(ePoint(x, y))
                self[skin_value].instance.resize(eSize(skinValueCalculate(350), skinValueCalculate(196)))
        elif index > 3 and mode == "show":
            self["Cover3"].instance.move(ePoint(skinValueCalculate(1185), skinValueCalculate(692)))
            self["Cover3"].instance.resize(eSize(skinValueCalculate(400), skinValueCalculate(225)))
            self["CoverSelect"].instance.move(ePoint(skinValueCalculate(1185), skinValueCalculate(692)))
            self["CoverSelect"].show()

    def loadSelectCoverList(self, index):
        if self.data:
            select_category_videos = self.data[self.genre_index]["videos"]
            self.callback_list1 = []
            start = index - 3 if index >= 4 else 0
            max_range = 5 if len(select_category_videos) - index >= 5 else len(select_category_videos) - start
            for skin_value, x, y in self.coverList1:
                if max_range is not 0:
                    png_data = select_category_videos[start]["cover"]
                    png_data.update({"skin_value": skin_value})
                    self.callback_list1.append((png_data["skin_value"], png_data["png_destination"]))
                    if os.path.isfile(png_data["png_destination"]):
                        self[png_data["skin_value"]].instance.setPixmapFromFile(png_data["png_destination"])
                        self[png_data["skin_value"]].show()
                    else:
                        self[png_data["skin_value"]].instance.setPixmapFromFile(DISNEY_DEFAULT_COVER_PNG)
                        self[png_data["skin_value"]].show()
                        self.disney.contentDownloader(png_data["url"], png_data, callback=self.loadCoverList1)
                    max_range -= 1
                else:
                    self[skin_value].hide()
                start += 1

    def loadCoverList1(self, item, png):
        if (item["skin_value"], item["png_destination"]) in self.callback_list1 and png:
            ptr = decodePic(item)
            if ptr != None:
                self[item["skin_value"]].instance.setPixmap(ptr)
                self[item["skin_value"]].show()
            else:
                self[item["skin_value"]].instance.setPixmapFromFile(DISNEY_DEFAULT_COVER_PNG)
                self[item["skin_value"]].show()

    def update_disney_hero_gui(self):
        if self.data:
            self.stopTimerHeroGuiAnimation()
            try:
                video = self.data[self.genre_index]["videos"][self.item_index]
            except Exception as error:
                print("IndexError: list index out of range")
            else:
                url = video.get("background_hero_image")
                try:
                    png_destination = DISNEY_TMP_DIRECTORY + "/hero-brand-%s.png" % str(url.split("/")[-2])
                except Exception as error:
                    png_destination = ""
                if not os.path.isfile(png_destination) and url:
                    self.callback_hero_index += 1
                    item = {"png_destination": png_destination,
                            "callback": self.callback_hero_index,
                            "x": 1920,
                            "y": 640,
                            "type": "PNG"}
                    self.disney.contentDownloader(url, item, callback=self.showHeroGui)
                else:
                    if os.path.isfile(png_destination):
                        self.startTimerHeroGuiAnimation(png_destination, video.get("videoArt"))

    def showHeroGui(self, item, png):
        if os.path.isfile(png) and item.get("callback") == self.callback_hero_index:
            try:
                video = self.data[self.genre_index]["videos"][self.item_index]
            except Exception as error:
                print("IndexError: list index out of range")
            else:
                #self.startTimerHeroGuiAnimation(png)
                self.startTimerHeroGuiAnimation(png, video.get("videoArt"))

    def update_disney_hero_logo(self):
        self.hideHeroLogoGuiAnimation()
        if self.data:
            self.stopTimerHeroLogoGuiAnimation()
            try:
                video = self.data[self.genre_index]["videos"][self.item_index]
            except Exception as error:
                print("IndexError: list index out of range")
            else:
                url = video.get("title_logo")
                try:
                    png_destination = DISNEY_TMP_DIRECTORY + "/hero-logo-%s.png" % str(url.split("/")[-2]) if url else ""
                except:
                    png_destination = ""
                if not os.path.isfile(png_destination) and url:
                    self.callback_hero_logo_index += 1
                    item = {"png_destination": png_destination,
                            "callback": self.callback_hero_logo_index,
                            "x": 400,
                            "y": 225,
                            "type": "PNG"}
                    self.disney.contentDownloader(url, item, callback=self.showHeroLogo)
                else:
                    self.startTimerHeroLogoGuiAnimation(png_destination)

    def showHeroLogo(self, item, png):
        if os.path.isfile(png) and item.get("callback") == self.callback_hero_logo_index:
            self.startTimerHeroLogoGuiAnimation(png)
        else:
            self.stopTimerHeroLogoGuiAnimation()

    def keyOk(self):
        if self.data:
            self.heroGuiMoviePlayer = False
            self.stopHeroMoviePlayer()
            try:
                video = self.data[self.genre_index]["videos"][self.item_index]
            except Exception as error:
                print("IndexError: list index out of range")
            else:
                if video.get("mediaType") == "MOVIE" and not video.get("seriesId"):
                    if video.get("encodedFamilyId"):
                        self.startTimerSpinner()
                        self.disney.getVideoBundle(video.get("encodedFamilyId"), self.backReadFamilyId, video)
                elif video.get("mediaType") == "SERIES" or video.get("encodedSeriesId"):
                    self.startTimerSpinner()
                    self.series = video
                    self.disney.getSeriesBundle(video.get("encodedSeriesId"), self.backSeriesBundle)
                elif video.get("mediaType") == "COLLECTION":
                    self.startTimerSpinner()
                    self.disney.getCollectionBySlug(video.get("contentClass"), video.get("slugs"), self.readMovieCategoryCallback)

    def readMovieCategoryCallback(self, data):
        if data:
            self.movie_data = []
            self.homeCountdown = len(data)
            for category in data:
                self.disney.getSetBySetId(category, self.updateMovieList)

    def updateMovieList(self, data, category):
        if data:
            category = self.disney.getCollectionItems(data, category)
            if category["videos"]:
                self.movie_data.append(category)
        self.homeCountdown -= 1
        if self.homeCountdown is 0:
            self.stopTimerSpinner()
            if self.movie_data:
                self.movie_data = sorted(self.movie_data, key=lambda item: int(item["index"]))
                self.oldGuiData.append((self.item_index, self.genre_index, self.data, self.callback_hero_index, self.callback_hero_logo_index))
                self.item_index = 0
                self.genre_index = 0
                self.callback_hero_index = 0
                self.callback_hero_logo_index = 0
                self.data = self.movie_data
                self.setDefaultSelectCover()
                self.buildGuiData()

    def backSeriesBundle(self, seasons, family, series):
        if seasons:
            self.season_data = []
            self.family_data = family
            self.seasonCountdown = len(seasons)
            if series:
                self.series = series
            for season in seasons:
                season.update({"episodes": []})
                self.disney.getSeriesEpisodes(season.get("seasonId"), self.backReadEpisode, season)
        else:
            self.stopTimerSpinner()

    def backReadEpisode(self, callback):
        self.seasonCountdown -= 1
        self.season_data.append(callback)
        if self.seasonCountdown is 0:
            self.season_data = sorted(self.season_data, key=lambda item: (item["seasonSequenceNumber"]))
            self.series.update({"season": self.season_data})
            self.series.update({"familyData": self.family_data})
            self.disney.getContinueWatchingSeries(self.series.get("seriesId"), self.callbackContinueWatchingSeries, self.series)

    def backReadFamilyId(self, video):
        self.disney.getContinueWatching(video.get("encodedFamilyId"), self.callbackContinueWatching, video)

    def callbackContinueWatching(self, video):
        self.stopTimerSpinner()
        self.session.openWithCallback(self.fasterExit, DisneyDetailsMovieScreen, video, self.disney)

    def callbackContinueWatchingSeries(self, video):
        self.seasonCountdown = len(video["season"])
        for season in video["season"]:
            self.disney.getContinueWatchingSeason(self.callbackContinueWatchingSeason, season)

    def callbackContinueWatchingSeason(self, season):
        self.seasonCountdown -= 1
        if self.seasonCountdown is 0:
            self.stopTimerSpinner()
            self.session.openWithCallback(self.fasterExit, DisneyDetailsSeasonScreen, self.series, self.disney)

    def keyPower(self):
        self.close(True)

    def fasterExit(self, callback=None):
        if config.plugins.disneyDream.animationVideo.value:
            self.heroGuiMoviePlayer = True
        if callback:
            self.close(True)

    def keyLeft(self):
        if self.data:
            if self.item_index is not 0:
                self.item_index -= 1
                self.loadSelectCoverList(self.item_index)
                self.moveSelectCover(self.item_index, "-")
                self.update_disney_hero_gui()
                self.update_disney_hero_logo()

    def keyRight(self):
        if self.data:
            if self.item_index < len(self.data[self.genre_index]["videos"]) - 1:
                if self.data[self.genre_index].get("page") and self.data[self.genre_index].get("totalPages"):
                    if len(self.data[self.genre_index]["videos"]) - self.item_index == 4 and self.data[self.genre_index]["page"] < self.data[self.genre_index]["totalPages"]:
                        self.startTimerSpinner()
                        self.data[self.genre_index]["page"] += 1
                        self.disney.getSetBySetIdVideos(self.data[self.genre_index], callback=self.cbUpdateCategoryVideosList)
                        return
                self.item_index += 1
                self.loadSelectCoverList(self.item_index)
                self.moveSelectCover(self.item_index, "+")
                self.update_disney_hero_gui()
                self.update_disney_hero_logo()
       
    def cbUpdateCategoryVideosList(self, category):
        self.stopTimerSpinner()
        self.item_index += 1
        self.loadSelectCoverList(self.item_index)
        self.moveSelectCover(self.item_index, "+")
        self.update_disney_hero_gui()
        self.update_disney_hero_logo()

    def keyUp(self):
        if self.genre_index is not 0:
            self.genre_index -= 1
            self.item_index = 0
            self.buildGuiData()
            self.moveSelectCover(self.item_index, None)

    def keyDown(self):
        if self.genre_index + 1 <= len(self.data) - 1:
            self.genre_index += 1
            self.item_index = 0
            self.moveSelectCover(self.item_index, None)
            self.buildGuiData()

    def keyCancel(self):
        self.stopHeroMoviePlayer()
        if self.oldGuiData:
            self.item_index = self.oldGuiData[len(self.oldGuiData) - 1][0]
            self.genre_index = self.oldGuiData[len(self.oldGuiData) - 1][1]
            self.data = self.oldGuiData[len(self.oldGuiData) - 1][2]
            self.callback_hero_index = self.oldGuiData[len(self.oldGuiData) - 1][3]
            self.callback_hero_logo_index = self.oldGuiData[len(self.oldGuiData) - 1][4]
            self.oldGuiData.remove(self.oldGuiData[len(self.oldGuiData) - 1])
            self.setDefaultSelectCover()
            self.buildGuiData()
            self.moveSelectCover(self.item_index, "show")
        else:
            self.close(False)

    def createSummary(self):
        return MyDisneySummary


def decodePic(item, color="#ff111111"):
    ptr = None
    try:
        scale = AVSwitch().getFramebufferScale()
        picload = ePicLoad()
        picload.setPara((item["x"], item["y"], scale[0], scale[1], False, 1, color))
        picload.startDecode(getTxt(item["png_destination"]), False)
        ptr = picload.getData()
        if ptr != None:
            del picload
    except Exception as error:
        print("[DisneyDream]: decodePic %s error: %s" % (item, str(error)))
    return ptr