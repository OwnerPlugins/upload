from enigma import ePicLoad, eTimer, gPixmapPtr
from Components.Pixmap import Pixmap

from .disneyHelper import DISNEY_SPINNER_DIRECTORY


class DisneySpinner:
    def __init__(self):
        # Spinner Timer
        self['TimerSpinner'] = Pixmap()
        self['TimerSpinner'].hide()
        self.timerSpinner = eTimer()
        self.timerSpinnerStatusSpinner = False
        self.timerSpinnerCounter = 1
        self.timerSpinner_conn = self.timerSpinner.timeout.connect(self.loadTimerSpinner)

    def stopTimerSpinner(self):
        self.timerSpinnerStatusSpinner = False

    def startTimerSpinner(self):
        self.timerSpinnerStatusSpinner = True
        self.loadTimerSpinner()

    def loadTimerSpinner(self):
        if self.timerSpinnerStatusSpinner:
            png = "%s/%s.png" % (DISNEY_SPINNER_DIRECTORY, str(self.timerSpinnerCounter))
            self.showTimerSpinner(png)
        else:
            self['TimerSpinner'].hide()

    def showTimerSpinner(self, png):
        self["TimerSpinner"].instance.setPixmapFromFile(png)
        self["TimerSpinner"].show()
        if self.timerSpinnerCounter is not 34:
            self.timerSpinnerCounter += 1
        else:
            self.timerSpinnerCounter = 1
        self.timerSpinner.start(10, True)
