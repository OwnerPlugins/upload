from enigma import ePicLoad, eTimer, gPixmapPtr, ePoint, eSize, eConsoleAppContainer
from Components.Pixmap import Pixmap
from Components.config import config
from disneyHelper import *

import os


class DisneyHeroGuiAnimation():
    def __init__(self):
        # HeroGuiAnimation Timer
        self['DisneyHeroGuiAnimation'] = Pixmap()
        self['DisneyHeroGuiAnimation'].hide()
        self.movie_container = None
        self.timerHeroGuiAnimation = eTimer()
        self.timerSpinnerHeroGuiAnimationStatus = False
        self.timerHeroGuiAnimationCounter = 1
        self.timerHeroGuiAnimation_conn = self.timerHeroGuiAnimation.timeout.connect(self.showTimerHeroGuiAnimation)

        self.heroGuiMoviePlayer = True if config.plugins.disneyDream.animationVideo.value else False
        self.timerHeroGuiMovieAnimation = eTimer()
        self.timerHeroGuiMovieAnimation_conn = self.timerHeroGuiMovieAnimation.timeout.connect(self.startHeroMoviePlayer)

        self.timerCheckHeroGuiMovieAnimation = eTimer()
        self.timerCheckHeroGuiMovieAnimation_conn = self.timerCheckHeroGuiMovieAnimation.timeout.connect(self.checkHeroMoviePlayer)

        self.x_hero = 0
        self.movie_url = None

    def doHideHeroGuiAnimation(self):
        self["DisneyHeroGuiAnimation"].hide()

    def stopTimerHeroGuiAnimation(self):
        if self.timerHeroGuiAnimation is not None:
            self.timerHeroGuiAnimation.stop()
        self.timerHeroGuiAnimationCounter = 40
        self["DisneyHeroGuiAnimation"].hide()

    def startTimerHeroGuiAnimation(self, png, url=None):
        self.stopHeroMoviePlayer()
        self.movie_url = getTxt(url) if url else None
        self.timerSpinnerHeroGuiAnimationStatus = True
        self.timerHeroGuiAnimationCounter = 0
        self.x_hero = 150 if config.plugins.disneyDream.animation.value else 0
        self['DisneyHeroGuiAnimation'].instance.move(ePoint(skinValueCalculate(self.x_hero), 0))
        self["DisneyHeroGuiAnimation"].instance.setPixmapFromFile(png)
        self["DisneyHeroGuiAnimation"].show()
        if config.plugins.disneyDream.animation.value:
            self.timerHeroGuiAnimation.start(10, True)
        elif config.plugins.disneyDream.animationVideo.value and self.heroGuiMoviePlayer:
            self.timerHeroGuiMovieAnimation.start(2000, True)

    def showTimerHeroGuiAnimation(self):
        if self.timerHeroGuiAnimationCounter is not 15:
            self.x_hero -= 10
            self.timerHeroGuiAnimationCounter += 1
            self['DisneyHeroGuiAnimation'].instance.move(ePoint(skinValueCalculate(self.x_hero), 0))
            self.timerHeroGuiAnimation.start(10, True)
        elif config.plugins.disneyDream.animationVideo.value:
            self.timerHeroGuiMovieAnimation.start(2000, True)

    def startHeroMoviePlayer(self):
        # rgba - bgra
        pix_fmt = "bgra" if os.path.exists("/boot/dreamseven.dtb") else "rgba"
        w = skinValueCalculate(1920)
        crop_w = 1920
        h = skinValueCalculate(640)
        crop_h = 730
        x = 0
        y = 0
        if self.movie_container is None and self.movie_url is not None and self.heroGuiMoviePlayer:
            self.movie_container = eConsoleAppContainer()
            cmd = '/usr/bin/ffmpeg -re -analyzeduration 1 -i "%s" -movflags +faststart -vf "crop=%s:%s:0:0, scale=w=%s:h=%s" -pix_fmt %s -xoffset %s -yoffset %s -f fbdev /dev/fb0' % (self.movie_url, crop_w, crop_h, w, h, pix_fmt, x, y)
            print("start ffmpeg: %s" % cmd)
            self["DisneyHeroGuiAnimation"].hide()
            self.movie_container.execute(cmd)
            self.timerCheckHeroGuiMovieAnimation.start(100, True)

    def stopHeroMovieTimer(self):
        if self.timerHeroGuiMovieAnimation is not None:
            self.timerHeroGuiMovieAnimation.stop()

    def stopHeroMoviePlayer(self):
        self.stopHeroMovieTimer()
        if self.timerCheckHeroGuiMovieAnimation is not None:
            self.timerCheckHeroGuiMovieAnimation.stop()
        if self.movie_container:
            if not self.movie_container.getPID() < 0:
                print("stopping ffmpeg-static ...")
                self.movie_container.sendCtrlC()
            self["DisneyHeroGuiAnimation"].show()
        self.movie_container = None
        self.movie_url = None

    def checkHeroMoviePlayer(self):
        if self.movie_container is not None:
            if not self.movie_container.running():
                self["DisneyHeroGuiAnimation"].show()
            else:
                self.timerCheckHeroGuiMovieAnimation.start(100, True)
        else:
            if self.timerCheckHeroGuiMovieAnimation is not None:
                self.timerCheckHeroGuiMovieAnimation.stop()
