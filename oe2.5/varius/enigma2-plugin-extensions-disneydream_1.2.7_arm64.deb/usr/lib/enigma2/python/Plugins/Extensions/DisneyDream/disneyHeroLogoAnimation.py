from enigma import ePicLoad, eTimer, gPixmapPtr, ePoint, eSize
from Components.Pixmap import Pixmap
from Components.config import config

from .disneyHelper import *


class DisneyHeroLogoGuiAnimation:
    def __init__(self):
        # HeroGuiAnimation Timer
        self['DisneyHeroLogoAnimation'] = Pixmap()
        self['DisneyHeroLogoAnimation'].hide()
        self.timerHeroLogoGuiAnimation = eTimer()
        self.timerSpinnerHeroLogoGuiAnimationStatus = False
        self.timerHeroLogoGuiAnimationCounter = 1
        self.timerHeroLogoGuiAnimation_conn = self.timerHeroLogoGuiAnimation.timeout.connect(self.showTimerHeroLogoGuiAnimation)

        self.x_logo = 100
        self.y_logo = 250

    def showHeroLogoGuiAnimation(self):
        self['DisneyHeroLogoAnimation'].show()

    def hideHeroLogoGuiAnimation(self):
        self['DisneyHeroLogoAnimation'].hide()

    def stopTimerHeroLogoGuiAnimation(self):
        if self.timerHeroLogoGuiAnimation is not None:
            self.timerHeroLogoGuiAnimation.stop()
        self.timerHeroLogoGuiAnimationCounter = 40
        self["DisneyHeroLogoAnimation"].hide()

    def startTimerHeroLogoGuiAnimation(self, png):
        self.timerSpinnerHeroLogoGuiAnimationStatus = True
        self.timerHeroLogoGuiAnimationCounter = 0
        self.x_logo = 150 if config.plugins.disneyDream.animation.value else 100
        self.y_logo = 375 if config.plugins.disneyDream.animation.value else 250
        self['DisneyHeroLogoAnimation'].instance.move(ePoint(skinValueCalculate(self.x_logo), skinValueCalculate(self.y_logo)))
        self["DisneyHeroLogoAnimation"].instance.setPixmapFromFile(png)
        self["DisneyHeroLogoAnimation"].show()
        if config.plugins.disneyDream.animation.value:
            self.timerHeroLogoGuiAnimation.start(10, True)

    def showTimerHeroLogoGuiAnimation(self):
        if self.timerHeroLogoGuiAnimationCounter is not 20:
            self.x_logo -= 2.5
            self.y_logo -= 6.25
            self.timerHeroLogoGuiAnimationCounter += 1
            self['DisneyHeroLogoAnimation'].instance.move(ePoint(skinValueCalculate(self.x_logo), skinValueCalculate(self.y_logo)))
            self.timerHeroLogoGuiAnimation.start(10, True)
