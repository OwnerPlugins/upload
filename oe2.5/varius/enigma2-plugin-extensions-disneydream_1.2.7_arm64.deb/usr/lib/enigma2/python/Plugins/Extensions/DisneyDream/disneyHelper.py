#	-*-	coding:	utf-8	-*-
from enigma import getDesktop
from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_LANGUAGE, SCOPE_PLUGINS
from Screens.Screen import Screen

import gettext
from os import environ
import sys


lang = language.getLanguage()
environ["LANGUAGE"] = lang[:2]
gettext.bindtextdomain("enigma2", resolveFilename(SCOPE_LANGUAGE))
gettext.textdomain("enigma2")
gettext.bindtextdomain("DisneyDream", "%s%s" % (resolveFilename(SCOPE_PLUGINS), "Extensions/DisneyDream/locale/"))


def getTxt(value):
    if sys.version_info > (3, 0):
        return str(value)
    else:
        try:
            value = value.encode("utf-8")
        except Exception as error:
            value = str(value)
    return value


class MyDisneySummary(Screen):
    def __init__(self, session, parent):
        Screen.__init__(self, session)
        self.skin = """<screen name="DisneySummary" position="0,0" size="240,80">
                         <ePixmap position="56,5" size="128,70" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/logo_128x70.png" zPosition="1"/>
                        </screen>"""


def _(txt):
    t = gettext.dgettext("DisneyDream", txt)
    if t == txt:
        t = gettext.gettext(txt)
    return t


DISNEY_TMP_DIRECTORY = "/data/DisneyDream"
DISNEY_SPINNER_DIRECTORY = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/spinner"
DISNEY_STORAGE = "/var/lib/widevine/disney.storage"

DISNEY_HOME_STR = _("Home")
DISNEY_PLAYER_LANGUAGE = _("Preferred Language:")
DISNEY_PLAYER_MENU = _("Player Menu")
DISNEY_MENU = _("Menu")
DISNEY_MOVIE_STR = _("Movies")
DISNEY_SHOW_STR = _("Series")
DISNEY_WATCH_STR = _("My list")
DISNEY_SEARCH_STR = _("Search")
DISNEY_ORIGINALS_STR = _("Originals")
DISNEY_PROFILE_STR = _("Profiles")
DISNEY_SETTINGS_STR = _("Settings")
DISNEY_EXIT_STR = _("Exit")
DISNEY_SEARCH_RESULT_STR = _("Search for:")
DISNEY_CHOOSE_AVATAR_STR = _("Select profile picture")
DISNEY_KIDS_STR = _("Children's profiles")
DISNEY_KIDS_INFO_STR = _("Child-friendly user interface with only child-friendly content")
DISNEY_ENTER_PROFILE = _("Press OK to enter the profile name")
DISNEY_ENTER_MAIL = _("Press OK to enter the mail-address")
DISNEY_ENTER_PASS = _("Press OK to enter the password")
DISNEY_ENTER_LOGIN = _("Press OK to login")
DISNEY_ENTER_LOGOUT = _("Press OK to log out")
DISNEY_CONFIG_ANIMATION_STR = _("Animation")
DISNEY_CONFIG_ANIMATION_VIDEO_STR = _("Animation video")
DISNEY_CONFIG_CACHE_STR = _("Clear cache on exit")
DISNEY_FINISHED_STR = _("Finished")
DISNEY_CONFIG_MAIL_INFO_STR = _("Account-E-mail-address")
DISNEY_CONFIG_BACK_STR = _("Back")
DISNEY_CONFIG_MAIL_STR = _("Change account email address")
DISNEY_CONFIG_PASSWORD_STR = _("Change password")
DISNEY_CONFIG_MAIL_INPUT_STR = _("Enter your email")
DISNEY_CONFIG_PASSWORD_INPUT_STR = _("Enter your password")
DISNEY_CONFIG_PIN_INPUT_STR = _("Please enter your account password")
DISNEY_CONFIG_PASSWORD_CHECK_INPUT_STR = _("Please enter your current account password")
DISNEY_CONFIG_LANGUAGES_STR = _("Automatically select audio track (beta)")
DISNEY_CONFIG_LOGIN_STR = _("Login")
DISNEY_CONFIG_LOGOUT_STR = _("Log out")
WHO_PROFILE_STR = _("Who's is watching?")
ERROR_PROFILE_STR = _("Sorry, an error occurred while determining the profiles!")
DISNEY_ADD_PROFILE_STR = _("Create new profile")
DELETE_PROFILE_STR = _("Delete profile")
DISNEY_DELETE_PROFILE_STR = _("profile really delete?")
DISNEY_CONFIGURE_PROFILE_STR = _("Add profile")
DISNEY_MAY_PROFILE_STR = _("My profile")
DISNEY_MAY_NEW_PROFILE_STR = _("Enter the profile name")
DISNEY_MAY_NEW_PROFILE_ERROR_STR = _("This profile name already exists")
DISNEY_ON_STR = _("ON")
DISNEY_OFF_STR = _("OFF")
DISNEY_WATCH_AGAIN_STR = _("Watch again")
DISNEY_PLAY_STR = _("Watch")
DISNEY_PLAY_CONTINUE_STR = _("Continue")
DISNEY_RECOMMENDATIONS_STR = _("RECOMMENDATIONS")
DISNEY_EXTRAS_STR = _("EXTRAS")
DISNEY_DETAILS_STR = _("DETAILS")
DISNEY_EPISODES_STR = _("EPISODES")
DISNEY_SEASON_STR = _("Season")
DISNEY_EPISODES_SEASON_STR = _("Episodes")
DISNEY_EPISODE_STR = _("Episode")
DISNEY_ERROR_STR = _("Sorry there was an error, please try again later!")
DISNEY_ERROR_PIN_STR = _("An error occurred when changing profiles!")
YES_STR = _("Yes")
NO_STR = _("No")
STOP_PLAYBACK_STR = _("Stop playback?")
SKIP_INTRO_STR = _("Skip intro")
NEXT_EPISODE_STR = _("Next episode")
SKIP_SUMMARY = _("Skip summary")


DESKTOPSIZE = getDesktop(0).size()
if DESKTOPSIZE.width() > 1280:
    if DESKTOPSIZE.width() > 1920:
        DISNEY_PLAY_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/details/select_play_400x80.png"
        DISNEY_PLAY_NO_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/details/play_333x67.png"
        DISNEY_PLAY_AGAIN_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/details/select_play_again_400x80.png"
        DISNEY_PLAY_AGAIN_NO_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/details/play_again_333x67.png"
        DISNEY_IS_WATCHLIST_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/details/select_remove_watchlist_80x80.png"
        DISNEY_IS_WATCHLIST_NO_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/details/remove_watchlist_67x67.png"
        DISNEY_NOT_WATCHLIST_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/details/select_plus_watchlist_80x80.png"
        DISNEY_NOT_WATCHLIST_NO_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/details/plus_watchlist_67x67.png"
    else:
        DISNEY_PLAY_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/details/select_play_300x60.png"
        DISNEY_PLAY_NO_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/details/play_250x50.png"
        DISNEY_PLAY_AGAIN_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/details/select_play_again_300x60.png"
        DISNEY_PLAY_AGAIN_NO_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/details/play_again_250x50.png"
        DISNEY_IS_WATCHLIST_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/details/select_remove_watchlist_60x60.png"
        DISNEY_IS_WATCHLIST_NO_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/details/remove_watchlist_50x50.png"
        DISNEY_NOT_WATCHLIST_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/details/select_plus_watchlist_60x60.png"
        DISNEY_NOT_WATCHLIST_NO_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/details/plus_watchlist_50x50.png"

    desksize = "1920"
    # Config
    DISNEY_CONFIG_SETTINGS_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/config_select_800x50.png"

    # Gui

    # Menu
    DISNEY_HOME_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/home_38x38.png"
    DISNEY_SEARCH_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/search_38x38.png"
    DISNEY_MOVIE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/movie_38x38.png"
    DISNEY_SHOW_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/show_38x38.png"
    DISNEY_WATCH_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/watch_38x38.png"
    DISNEY_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/select_30x4.png"
    DISNEY_ORIGINALS_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/originals_38x38.png"
    DISNEY_PROFILE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/profile_38x38.png"
    DISNEY_SETTINGS_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/settings_38x38.png"
    DISNEY_EXIT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/exit_38x38.png"

    DISNEY_ARROW_LEFT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/arrow_left_25x44.png"

    DISNEY_BRAND_SELECT = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/select_brand_258x133.png"
    DISNEY_BRAND_MARVEL_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/brand_marvel_250x125.png"
    DISNEY_BRAND_DISNEY_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/brand_disney_250x125.png"
    DISNEY_BRAND_STAR_WARS_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/brand_star_wars_250x125.png"
    DISNEY_BRAND_NATIONAL_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/brand_national_250x125.png"
    DISNEY_BRAND_PIXAR_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/brand_pixar_250x125.png"
    DISNEY_BRAND_STAR_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/brand_star_250x125.png"

    DISNEY_DEFAULT_COVER_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/logo_350x198.png"
    DISNEY_DEFAULT_HERO_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/hero_1670x427.png"
    DISNEY_DEFAULT_HERO_MOVIE = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/hero_default_movie_1920x640.png"

    DISNEY_SELECT_COVER_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/select_400x230.png"

    DISNEY_DEFAULT_AVATAR_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/avatar_default_350x350.png"
    DISNEY_SELECT_AVATAR_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/avatar_select_366x366.png"
    DISNEY_ADD_AVATAR_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/avatar_plus_350x350.png"


    DISNEY_PROFILE_TEXT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/profile_text_background_796x46.png"

else:
    desksize = "1280"
    # Config
    DISNEY_CONFIG_SETTINGS_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/config_select_533x33.png"

    # Gui

    # Menu
    DISNEY_HOME_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/home_25x25.png"
    DISNEY_SEARCH_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/search_25x25.png"
    DISNEY_MOVIE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/movie_25x25.png"
    DISNEY_SHOW_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/show_25x25.png"
    DISNEY_WATCH_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/watch_25x25.png"
    DISNEY_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/select_20x2.png"
    DISNEY_ORIGINALS_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/originals_25x25.png"
    DISNEY_PROFILE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/profile_25x25.png"
    DISNEY_SETTINGS_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/settings_25x25.png"
    DISNEY_EXIT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/exit_25x25.png"

    DISNEY_ARROW_LEFT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/arrow_left_16x29.png"

    DISNEY_BRAND_SELECT = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/select_brand_172x88.png"
    DISNEY_BRAND_MARVEL_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/brand_marvel_166x83.png"
    DISNEY_BRAND_DISNEY_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/brand_disney_166x83.png"
    DISNEY_BRAND_STAR_WARS_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/brand_star_wars_166x83.png"
    DISNEY_BRAND_NATIONAL_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/brand_national_166x83.png"
    DISNEY_BRAND_PIXAR_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/brand_pixar_166x83.png"
    DISNEY_BRAND_STAR_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/brand_star_166x83.png"

    DISNEY_DEFAULT_COVER_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/logo_233x132.png"
    DISNEY_DEFAULT_HERO_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/hero_1113x284.png"
    DISNEY_DEFAULT_HERO_MOVIE = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/hero_default_movie_1280x426.png"

    DISNEY_SELECT_COVER_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/select_266x150.png"

    DISNEY_DEFAULT_AVATAR_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/avatar_default_350x350.png"
    DISNEY_SELECT_AVATAR_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/avatar_select_366x366.png"
    DISNEY_ADD_AVATAR_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/avatar_plus_350x350.png"

    DISNEY_PIN_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/pin_64x85.png"

    DISNEY_PLAY_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/details/select_play_200x40.png"
    DISNEY_PLAY_NO_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/details/play_165x33.png"
    DISNEY_PLAY_AGAIN_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/details/select_play_again_200x40.png"
    DISNEY_PLAY_AGAIN_NO_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/details/play_again_165x33.png"
    DISNEY_IS_WATCHLIST_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/details/select_remove_watchlist_40x40.png"
    DISNEY_IS_WATCHLIST_NO_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/details/remove_watchlist_33x33.png"
    DISNEY_NOT_WATCHLIST_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/details/select_plus_watchlist_40x40.png"
    DISNEY_NOT_WATCHLIST_NO_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/details/plus_watchlist_33x33.png"

    DISNEY_PROFILE_TEXT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/profile_text_background_529x30.png"


MENU_BAR_LIST = [(DISNEY_SEARCH_STR, DISNEY_SEARCH_PNG),
                 (DISNEY_HOME_STR, DISNEY_HOME_PNG),
                 (DISNEY_WATCH_STR, DISNEY_WATCH_PNG),
                 (DISNEY_MOVIE_STR, DISNEY_MOVIE_PNG),
                 (DISNEY_SHOW_STR, DISNEY_SHOW_PNG),
                 (DISNEY_ORIGINALS_STR, DISNEY_ORIGINALS_PNG),
                 (DISNEY_PROFILE_STR, DISNEY_PROFILE_PNG),
                 (DISNEY_SETTINGS_STR, DISNEY_SETTINGS_PNG),
                 (DISNEY_EXIT_STR, DISNEY_EXIT_PNG)]


def skinValueCalculate(value):
    if DESKTOPSIZE.width() > 1920:
        # 2560x1440
        skinFactor = 1.33333333333
        skinMultiply = True
    elif DESKTOPSIZE.width() == 1920:
        # 1920x1080
        skinFactor = 1
        skinMultiply = False
    else:
        # 1280x720
        skinFactor = 1.5
        skinMultiply = False
    if skinMultiply:
        return int(float(round(value * skinFactor)))
    else:
        return int(value / skinFactor)