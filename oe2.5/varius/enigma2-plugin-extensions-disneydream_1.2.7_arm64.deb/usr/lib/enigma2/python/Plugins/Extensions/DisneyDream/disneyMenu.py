from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from enigma import gFont, getDesktop, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP
from Tools.LoadPixmap import LoadPixmap
from Components.Pixmap import Pixmap

from .disneyHelper import *


class DisneyMenu:
    def __init__(self, mode=DISNEY_HOME_STR, index=1):
        # Disney Menu List
        self.chooseDisneyMenu = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseDisneyMenu.l.setFont(0, gFont('DD', skinValueCalculate(38)))
        self.chooseDisneyMenu.l.setItemHeight(skinValueCalculate(80))
        self['DisneyMenu'] = self.chooseDisneyMenu

        # Disney Menu Bar
        self.chooseDisneyMenuBar = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseDisneyMenuBar.l.setFont(0, gFont('DD', 1))
        self.chooseDisneyMenuBar.l.setItemHeight(skinValueCalculate(80))
        self['DisneyMenuBar'] = self.chooseDisneyMenuBar

        self['MenuBackground'] = Pixmap()

        self.disney_menu_index = index
        self.disney_menu_active = mode
        self.disney_menu_show = False

        self.onLayoutFinish.append(self.__do_hide_disney_menu_list)

    def __do_hide_disney_menu_list(self):
        self['DisneyMenu'].hide()
        self['MenuBackground'].hide()
        self['DisneyMenuBar'].show()
        self.disney_menu_show = False
        self.__build_menu()

    def __do_hide_disney_menu_bar(self):
        self['DisneyMenu'].show()
        self['MenuBackground'].show()
        self['DisneyMenuBar'].hide()
        self.disney_menu_show = True
        self.__build_menu()

    def key_ok_menu(self):
        text = MENU_BAR_LIST[self.disney_menu_index][0]
        self.key_menu()
        return text

    def key_menu(self):
        if self.disney_menu_show:
            self.__do_hide_disney_menu_list()
        else:
            self.__do_hide_disney_menu_bar()

    def key_up_menu(self):
        if self.disney_menu_show:
            self['DisneyMenu'].up()
            self.disney_menu_index = self['DisneyMenu'].getSelectionIndex()
            self.__build_menu()

    def key_down_menu(self):
        if self.disney_menu_show:
            self['DisneyMenu'].down()
            self.disney_menu_index = self['DisneyMenu'].getSelectionIndex()
            self.__build_menu()

    def do_select_menu_active(self, value):
        for x in range(len(MENU_BAR_LIST)):
            (text, pic) = MENU_BAR_LIST[x]
            if text == value:
                self.disney_menu_active = text
                self.disney_menu_index = x
        self.__build_menu()

    def __build_menu(self):
        bar_list = []
        for x in range(len(MENU_BAR_LIST)):
            (text, pic) = MENU_BAR_LIST[x]
            is_active = True if self.disney_menu_active == text else False
            is_select = True if x == self.disney_menu_index else False
            bar_list.append((text, pic, is_active, is_select))

        self.chooseDisneyMenuBar.setList(list(map(disney_menu_bar_entry, bar_list)))
        self.chooseDisneyMenuBar.selectionEnabled(0)
        self.chooseDisneyMenu.setList(list(map(disney_menu_entry, bar_list)))
        self.chooseDisneyMenu.selectionEnabled(0)


def disney_menu_bar_entry(entry):
    # text, pic, is_active, is_select
    res = [entry]

    # item png
    png = LoadPixmap(entry[1])
    res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, skinValueCalculate(0), skinValueCalculate(20),
                skinValueCalculate(38), skinValueCalculate(38), png))

    # select png
    if entry[2]:
        png = LoadPixmap(DISNEY_SELECT_PNG)
        res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, skinValueCalculate(4), skinValueCalculate(65),
                    skinValueCalculate(30), skinValueCalculate(4), png))

    return res


def disney_menu_entry(entry):
    # text, pic, is_active, is_select
    res = [entry]

    # select png
    if entry[2]:
        png = LoadPixmap(DISNEY_SELECT_PNG)
        res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, skinValueCalculate(4), skinValueCalculate(65),
                    skinValueCalculate(30), skinValueCalculate(4), png))

    if entry[3]:
        # text
        res.append(MultiContentEntryText(pos=(skinValueCalculate(60), skinValueCalculate(14)),
                                         size=(skinValueCalculate(240), skinValueCalculate(50)),
                                         font=0,
                                         flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                         text=entry[0],
                                         color=0xffffff))#,
                                         #backcolor=0x2d3343))
    else:
        # text
        res.append(MultiContentEntryText(pos=(skinValueCalculate(60), skinValueCalculate(14)),
                                         size=(skinValueCalculate(240), skinValueCalculate(50)),
                                         font=0,
                                         flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                         text=entry[0],
                                         color=0x5b5b5b))#,
                                         #backcolor=0x2d3343))

    # item png
    png = LoadPixmap(entry[1])
    res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, skinValueCalculate(0), skinValueCalculate(20),
                skinValueCalculate(38), skinValueCalculate(38), png))

    return res
