#	-*-	coding:	utf-8	-*-
from enigma import gFont, getDesktop, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP, RT_WRAP, ePicLoad, getPrevAsciiCode
from Components.MenuList import MenuList
from Screens.Screen import Screen
from Components.MultiContent import MultiContentEntryText, MultiContentEntryText, MultiContentEntryPixmapAlphaTest, \
    MultiContentEntryPixmapAlphaBlend
from Components.config import config, ConfigText, ConfigSubsection, configfile, ConfigPassword
from Tools.LoadPixmap import LoadPixmap
from Components.ActionMap import ActionMap
from Components.Label import Label
from Screens.MessageBox import MessageBox
from Screens.InputBox import InputBox

from .disneyHelper import *
from .disneyHelper import _

import os


class DisneySettingsScreen(Screen):
    def __init__(self, session, disney):
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen backgroundColor="#002d3343" flags="wfNoBorder" name="DisneyDream" position="center,center" size="2560,1440" title="DisneyDream">
                           <widget name="DisneySettings" position="93,133" size="1067,80" backgroundColor="#002d3343" transparent="0" foregroundColor="#00ffffff" zPosition="1" font="DD; 60" valign="top" halign="left" />
                           <widget name="DisneyMail" position="1333,133" size="1067,80" backgroundColor="#002d3343" transparent="0" foregroundColor="#00ffffff" zPosition="1" font="DD; 60" valign="top" halign="left" />
                           <widget name="DisneyMailValue" position="1333,227" size="1067,80" backgroundColor="#002d3343" transparent="0" foregroundColor="#00585858" zPosition="1" font="DD; 48" valign="top" halign="left" />
                           <widget name="DisneyPassValue" position="1333,320" size="1067,80" backgroundColor="#002d3343" transparent="0" foregroundColor="#00585858" zPosition="1" font="DD; 48" valign="top" halign="left" />
                           <widget name="DisneyInfoText" position="93,267" size="1067,53" font="DD;40" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="6" valign="center" halign="left"/>
                           <widget name="DisneyConfig" position="93,347" size="1067,533" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="1" transparent="0" />
                           <ePixmap position="2240,1267" size="267,147" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/logo_200x110.png" zPosition="99" />
                           </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """<screen backgroundColor="#002d3343" flags="wfNoBorder" name="DisneyDream" position="center,center" size="1920,1080" title="DisneyDream">
                           <widget name="DisneySettings" position="70,100" size="800,60" backgroundColor="#002d3343" transparent="0" foregroundColor="#00ffffff" zPosition="1" font="DD; 45" valign="top" halign="left" />
                           <widget name="DisneyMail" position="1000,100" size="800,60" backgroundColor="#002d3343" transparent="0" foregroundColor="#00ffffff" zPosition="1" font="DD; 45" valign="top" halign="left" />
                           <widget name="DisneyMailValue" position="1000,170" size="800,60" backgroundColor="#002d3343" transparent="0" foregroundColor="#00585858" zPosition="1" font="DD; 36" valign="top" halign="left" />
                           <widget name="DisneyPassValue" position="1000,240" size="800,60" backgroundColor="#002d3343" transparent="0" foregroundColor="#00585858" zPosition="1" font="DD; 36" valign="top" halign="left" />
                           <widget name="DisneyInfoText" position="70,200" size="800,40" font="DD;30" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="6" valign="center" halign="left"/>  
                           <widget name="DisneyConfig" position="70,260" size="800,400" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="1" transparent="0" />
                           <ePixmap position="1680,950" size="200,110" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/logo_200x110.png" zPosition="99" />
                           </screen>
                        """
        else:
            self.skin = """<screen backgroundColor="#002d3343" flags="wfNoBorder" name="DisneyDream" position="center,center" size="1280,720" title="DisneyDream">
                           <widget name="DisneySettings" position="46,66" size="533,40" backgroundColor="#002d3343" transparent="0" foregroundColor="#00ffffff" zPosition="1" font="DD; 30" valign="top" halign="left" />
                           <widget name="DisneyMail" position="666,66" size="533,40" backgroundColor="#002d3343" transparent="0" foregroundColor="#00ffffff" zPosition="1" font="DD; 30" valign="top" halign="left" />
                           <widget name="DisneyMailValue" position="666,113" size="533,40" backgroundColor="#002d3343" transparent="0" foregroundColor="#00585858" zPosition="1" font="DD; 24" valign="top" halign="left" />
                           <widget name="DisneyPassValue" position="666,159" size="533,40" backgroundColor="#002d3343" transparent="0" foregroundColor="#00585858" zPosition="1" font="DD; 24" valign="top" halign="left" />
                           <widget name="DisneyInfoText" position="46,133" size="533,26" font="DD;20" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="6" valign="center" halign="left"/>
                           <widget name="DisneyConfig" position="46,173" size="533,266" foregroundColor="#00ffffff" backgroundColor="#002d3343" zPosition="1" transparent="0" />
                           <ePixmap position="1120,634" size="133,73" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DisneyDream/images/logo_133x73.png" zPosition="99" />
                           </screen>
                           """
        Screen.__init__(self, session)
        self['actions'] = ActionMap(['DisneyDream_Actions'],
                                    {'ok': self.keyOk,
                                     'cancel': self.keyExit,
                                     'left': self.updateTrueFalse,
                                     'right': self.updateTrueFalse,
                                     'up': self.keyUp,
                                     'down': self.keyDown}, -1)

        self.chooseDisneyConfig = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseDisneyConfig.l.setFont(0, gFont('DD', skinValueCalculate(34)))
        self.chooseDisneyConfig.l.setItemHeight(skinValueCalculate(50))
        self['DisneyConfig'] = self.chooseDisneyConfig

        self['DisneyMail'] = Label(DISNEY_CONFIG_MAIL_INFO_STR)
        self['DisneyInfoText'] = Label("")
        self['DisneySettings'] = Label(DISNEY_SETTINGS_STR)
        self['DisneyMailValue'] = Label(config.vod.disney.username.value)
        self['DisneyPassValue'] = Label(config.vod.disney.password.value)

        self.index = 0
        self.config_list = []
        self.config_changed = False
        self.disney = disney

        self.onLayoutFinish.append(self.createSetup)

    def createSetup(self):
        self.config_list = []
        self.config_list.append((DISNEY_CONFIG_BACK_STR, True, None))
        self.config_list.append((DISNEY_CONFIG_LANGUAGES_STR, False, config.plugins.disneyDream.player_languages))
        if config.plugins.disneyDream.player_languages.value:
            pass
        self.config_list.append((DISNEY_CONFIG_ANIMATION_STR, False, config.plugins.disneyDream.animation))
        self.config_list.append((DISNEY_CONFIG_ANIMATION_VIDEO_STR, False, config.plugins.disneyDream.animationVideo))
        self.config_list.append((DISNEY_CONFIG_CACHE_STR, False, config.plugins.disneyDream.cache))
        self.config_list.append((DISNEY_CONFIG_MAIL_STR, False, config.vod.disney.username))
        self.config_list.append((DISNEY_CONFIG_PASSWORD_STR, False, config.vod.disney.password))
        if config.vod.disney.username.value and config.vod.disney.password.value:
            self.config_list.append((DISNEY_CONFIG_LOGIN_STR, None, None))
        if os.path.isfile(DISNEY_STORAGE):
            self.config_list.append((DISNEY_CONFIG_LOGOUT_STR, None, None))
        self.updateSetup()

    def updateSetup(self):
        data = []
        self.index = len(self.config_list) - 1 if self.index > len(self.config_list) - 1 else self.index
        for x in range(len(self.config_list)):
            (text, select, value) = self.config_list[x]
            if x == self.index:
                data.append((text, True, value))
            else:
                data.append((text, False, value))

        self.config_list = data

        if self.config_list[self.index][0] == DISNEY_CONFIG_MAIL_STR:
            self['DisneyInfoText'].setText(DISNEY_ENTER_MAIL)
        elif self.config_list[self.index][0] == DISNEY_CONFIG_PASSWORD_STR:
            self['DisneyInfoText'].setText(DISNEY_ENTER_PASS)
        elif self.config_list[self.index][0] == DISNEY_CONFIG_LOGIN_STR:
            self['DisneyInfoText'].setText(DISNEY_ENTER_LOGIN)
        elif self.config_list[self.index][0] == DISNEY_CONFIG_LOGOUT_STR:
            self['DisneyInfoText'].setText(DISNEY_ENTER_LOGOUT)
        else:
            self['DisneyInfoText'].setText("")

        self['DisneyMailValue'].setText(config.vod.disney.username.value)
        txt = "**********" if config.vod.disney.password.value else ""
        self['DisneyPassValue'].setText(txt)
        self.chooseDisneyConfig.setList(list(map(disney_config_entry, self.config_list)))
        self.chooseDisneyConfig.selectionEnabled(0)

    def keyOk(self):
        (text, select, value) = self.config_list[self.index]
        if text == DISNEY_CONFIG_BACK_STR:
            self.keyExit()
        elif text == DISNEY_CONFIG_MAIL_STR:
            input = DISNEY_CONFIG_MAIL_INPUT_STR
            value = config.vod.disney.username.value
            self.session.openWithCallback(self.backKeyboard, InputBox,  title=input, text=value)
        elif text == DISNEY_CONFIG_PASSWORD_STR:
            value = config.vod.disney.password.value
            input = DISNEY_CONFIG_PASSWORD_INPUT_STR
            self.session.openWithCallback(self.backKeyboard, InputBox, title=input, text=value)
        elif text == DISNEY_CONFIG_LOGIN_STR:
            self.disney.login(config.vod.disney.username.value, config.vod.disney.password.value, self.loggedInCallback)
        elif text == DISNEY_CONFIG_LOGOUT_STR:
            self.disney.doLogOut()
            if not os.path.isfile(DISNEY_STORAGE):
                info = _("Log out successful")
                self.session.open(MessageBox, info, windowTitle="Disney+ Dream", type=MessageBox.TYPE_INFO)
                self.config_changed = True
                self.clearLogin()
            else:
                info = _("Log out failed")
                self.session.open(MessageBox, info, windowTitle="Disney+ Dream", type=MessageBox.TYPE_ERROR)
            self.createSetup()
        elif text == DISNEY_CONFIG_ANIMATION_STR:
            config.plugins.disneyDream.animation.value = False if config.plugins.disneyDream.animation.value else True
            config.plugins.disneyDream.animation.save()
            configfile.save()
            self.createSetup()
        elif text == DISNEY_CONFIG_ANIMATION_VIDEO_STR:
            config.plugins.disneyDream.animationVideo.value = False if config.plugins.disneyDream.animationVideo.value else True
            config.plugins.disneyDream.animationVideo.save()
            configfile.save()
            self.createSetup()
        elif text == DISNEY_CONFIG_CACHE_STR:
            config.plugins.disneyDream.cache.value = False if config.plugins.disneyDream.cache.value else True
            config.plugins.disneyDream.cache.save()
            configfile.save()
            self.createSetup()
        elif text == DISNEY_CONFIG_LANGUAGES_STR:
            config.plugins.disneyDream.player_languages.value = False if config.plugins.disneyDream.player_languages.value else True
            config.plugins.disneyDream.player_languages.save()
            configfile.save()
            self.createSetup()

    def updateTrueFalse(self):
        (text, select, value) = self.config_list[self.index]
        if text == DISNEY_CONFIG_ANIMATION_STR:
            config.plugins.disneyDream.animation.value = False if config.plugins.disneyDream.animation.value else True
            config.plugins.disneyDream.animation.save()
            configfile.save()
            self.createSetup()
        elif text == DISNEY_CONFIG_CACHE_STR:
            config.plugins.disneyDream.cache.value = False if config.plugins.disneyDream.cache.value else True
            config.plugins.disneyDream.cache.save()
            configfile.save()
            self.createSetup()
        elif text == DISNEY_CONFIG_ANIMATION_VIDEO_STR:
            config.plugins.disneyDream.animationVideo.value = False if config.plugins.disneyDream.animationVideo.value else True
            config.plugins.disneyDream.animationVideo.save()
            configfile.save()
            self.createSetup()
        elif text == DISNEY_CONFIG_LANGUAGES_STR:
            config.plugins.disneyDream.player_languages.value = False if config.plugins.disneyDream.player_languages.value else True
            config.plugins.disneyDream.player_languages.save()
            configfile.save()
            self.createSetup()

    def loggedInCallback(self, success):
        if success:
            info = _("Login successful")
            self.session.open(MessageBox, info, windowTitle="Disney+ Dream", type=MessageBox.TYPE_INFO)
        else:
            info = _("Login failed")
            self.session.open(MessageBox, info, windowTitle="Disney+ Dream", type=MessageBox.TYPE_ERROR)
        self.createSetup()

    def backKeyboard(self, callback):
        if callback != None:
            self.config_changed = True
            config_value = self.config_list[self.index][2]
            config_value.value = callback
            config_value.save()
            configfile.save()
        self.createSetup()

    def clearLogin(self):
        config.vod.disney.username.value = ""
        config.vod.disney.password.value = ""
        config.vod.disney.username.save()
        config.vod.disney.password.save()
        configfile.save()

    def keyUp(self):
        if self.index == 0:
            self.index = len(self.config_list) - 1
        else:
            self.index -= 1
        self.updateSetup()

    def keyDown(self):
        if self.index == len(self.config_list) - 1:
            self.index = 0
        else:
            self.index += 1
        self.updateSetup()

    def keyExit(self):
        self.close(self.config_changed)

    def createSummary(self):
        return MyDisneySummary


def disney_config_entry(entry):
    res = [entry]
    if entry[1]:
        # Select
        png = LoadPixmap(DISNEY_CONFIG_SETTINGS_SELECT_PNG)
        res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, 0, 0,
                    skinValueCalculate(800), skinValueCalculate(50), png))
        color = 0xffffff

    else:
        color = 0x5b5b5b

    if entry[0] in [DISNEY_CONFIG_ANIMATION_STR, DISNEY_CONFIG_ANIMATION_VIDEO_STR, DISNEY_CONFIG_CACHE_STR, DISNEY_CONFIG_LANGUAGES_STR]:
        res.append(MultiContentEntryText(pos=(skinValueCalculate(20), skinValueCalculate(3)),
                                         size=(skinValueCalculate(624), skinValueCalculate(44)),
                                         flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                         font=0,
                                         text=entry[0],
                                         color=color,
                                         backcolor=0x2d3343))
        txt = DISNEY_ON_STR if entry[2].value else DISNEY_OFF_STR
        res.append(MultiContentEntryText(pos=(skinValueCalculate(644), skinValueCalculate(3)),
                                         size=(skinValueCalculate(146), skinValueCalculate(44)),
                                         flags=RT_HALIGN_RIGHT | RT_VALIGN_CENTER,
                                         font=0,
                                         text=txt,
                                         color=color))
    else:
        res.append(MultiContentEntryText(pos=(skinValueCalculate(20), skinValueCalculate(3)),
                                         size=(skinValueCalculate(770), skinValueCalculate(44)),
                                         flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                         font=0,
                                         text=entry[0],
                                         color=color,
                                         backcolor=0x2d3343))

    return res

