from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_PLUGINS, SCOPE_LANGUAGE
from gettext import bindtextdomain, dgettext, gettext
from os import environ
PluginLanguageDomain = 'MyAnimmenu'
PluginLanguagePath = 'Extensions/MyAnimmenu/locale'

def localeInit():
    #gettext.bindtextdomain(PluginLanguageDomain, resolveFilename(SCOPE_PLUGINS, PluginLanguagePath))
    environ["LANGUAGE"] = language.getLanguage()[:2]
    bindtextdomain(PluginLanguageDomain, resolveFilename(SCOPE_PLUGINS,PluginLanguagePath))

#def _(txt):
#    if gettext.dgettext(PluginLanguageDomain, txt):
#        return gettext.dgettext(PluginLanguageDomain, txt)
#    else:
#        print '[' + PluginLanguageDomain + '] fallback to default translation for ' + txt
#        return gettext.gettext(txt)

def _(txt):
	t = dgettext(PluginLanguageDomain, txt)
	if t == txt:
		t = gettext(txt)
	return t

#language.addCallback(localeInit())
localeInit()
language.addCallback(localeInit)
