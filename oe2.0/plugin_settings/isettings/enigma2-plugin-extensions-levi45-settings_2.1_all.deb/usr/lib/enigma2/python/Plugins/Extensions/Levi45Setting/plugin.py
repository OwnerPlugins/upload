# -*- coding: utf-8 -*-
import os
import sys
import json
import re
import shutil
import zipfile
from enigma import eDVBDB

# Version Information
VERSION = "2.1"

# Check Python Version for cross-compatibility (Python 2.7 & Python 3)
PY3 = sys.version_info[0] == 3

if PY3:
    import urllib.request as urllib_req
else:
    import urllib2 as urllib_req

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.config import config, ConfigSubsection, ConfigYesNo, configfile
from Components.ConfigList import ConfigListScreen

# Configure Enigma2 Settings Entry
config.plugins.Levi45Setting = ConfigSubsection()
config.plugins.Levi45Setting.show_in_mainmenu = ConfigYesNo(default=True)

# Target Directories & Paths
DEST_DIR = "/etc/enigma2/"
TMP_ZIP = "/tmp/channel_list.zip"
TMP_EXTRACT = "/tmp/channel_list_extracted"
PLUGIN_PATH = os.path.dirname(__file__)

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
}


class ChannelDownloaderSettingsScreen(ConfigListScreen, Screen):
    skin = """
    <screen position="center,center" size="600,200" title="Channel Downloader - Settings">
        <widget name="config" position="20,30" size="560,80" scrollbarMode="showOnDemand"/>
        <widget name="key_red" position="20,140" size="260,30" font="Regular;18" halign="center" backgroundColor="#00FF0000" />
        <widget name="key_green" position="320,140" size="260,30" font="Regular;18" halign="center" backgroundColor="#0000FF00" />
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session

        self.list = [
            ("Show Plugin in E2 Main Menu", config.plugins.Levi45Setting.show_in_mainmenu)
        ]
        ConfigListScreen.__init__(self, self.list)

        self["key_red"] = Label("Cancel")
        self["key_green"] = Label("Save")

        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "green": self.save,
            "red": self.cancel,
            "cancel": self.cancel,
        }, -1)

    def save(self):
        for x in self["config"].list:
            x[1].save()
        configfile.save()
        self.session.openWithCallback(
            self.close_settings,
            MessageBox,
            "Settings saved! Restart GUI to apply Main Menu changes.",
            MessageBox.TYPE_INFO
        )

    def cancel(self):
        for x in self["config"].list:
            x[1].cancel()
        self.close()

    def close_settings(self, result=None):
        self.close()


class ChannelDownloaderScreen(Screen):
    skin = """
    <screen position="center,center" size="820,580" title="Levi45 Channel List Downloader v%s">
        <widget name="status" position="20,10" size="780,30" font="Regular;20" halign="center" foregroundColor="#00FFC000"/>
        <widget name="list" position="20,50" size="780,320" scrollbarMode="showOnDemand"/>
        
        <!-- QR Code Images Container (Side by Side) -->
        <widget name="qr_paypal" position="240,380" size="130,130" alphatest="on" scale="1" />
        <widget name="qr_kofi" position="450,380" size="130,130" alphatest="on" scale="1" />

        <!-- Colored Action Buttons -->
        <widget name="key_red" position="20,530" size="180,30" font="Regular;18" halign="center" backgroundColor="#00FF0000" />
        <widget name="key_green" position="220,530" size="180,30" font="Regular;18" halign="center" backgroundColor="#0000FF00" />
        <widget name="key_yellow" position="420,530" size="180,30" font="Regular;18" halign="center" backgroundColor="#00FFFF00" />
        <widget name="key_blue" position="620,530" size="180,30" font="Regular;18" halign="center" backgroundColor="#000000FF" />
    </screen>
    """ % VERSION

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session

        self["status"] = Label("Select a provider:")
        self["key_red"] = Label("Exit")
        self["key_green"] = Label("Select")
        self["key_yellow"] = Label("Back")
        self["key_blue"] = Label("Settings")

        # QR Code Pixmap Elements
        self["qr_paypal"] = Pixmap()
        self["qr_kofi"] = Pixmap()

        self.current_mode = "PROVIDERS"
        self.file_items = []

        self["list"] = MenuList([])

        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "ok": self.handle_ok,
            "green": self.handle_ok,
            "yellow": self.load_providers,
            "blue": self.open_settings,
            "cancel": self.handle_cancel,
            "red": self.handle_cancel,
        }, -1)

        self.onLayoutFinish.append(self.load_images)
        self.load_providers()

    def load_images(self):
        paypal_path = os.path.join(PLUGIN_PATH, "paypal.png")
        kofi_path = os.path.join(PLUGIN_PATH, "kofi.png")

        if os.path.exists(paypal_path):
            self["qr_paypal"].instance.setPixmapFromFile(paypal_path)
        if os.path.exists(kofi_path):
            self["qr_kofi"].instance.setPixmapFromFile(kofi_path)

    def open_settings(self):
        self.session.open(ChannelDownloaderSettingsScreen)

    def load_providers(self):
        self.current_mode = "PROVIDERS"
        self["status"].setText("Select a provider:")
        providers = [
            "1. levi-45 Settings (GitHub Repository)",
            "2. ciefpsettings (GitHub Repository)",
            "3. morpheus883 Settings (GitHub Repository)",
            "4. Vhannibal Settings (Official Site)"
        ]
        self["list"].setList(providers)

    def handle_ok(self):
        if self.current_mode == "PROVIDERS":
            idx = self["list"].getSelectedIndex()
            if idx == 0:
                self.fetch_github_files("levi-45", "setting")
            elif idx == 1:
                self.fetch_github_files("ciefp", "ciefpsettings-enigma2-zipped")
            elif idx == 2:
                self.fetch_github_files("morpheus883", "enigma2-zipped")
            elif idx == 3:
                self.fetch_vhannibal_files()
        elif self.current_mode == "FILES":
            idx = self["list"].getSelectedIndex()
            if idx >= 0 and idx < len(self.file_items):
                name, url = self.file_items[idx]
                self.confirm_download(name, url)

    def handle_cancel(self):
        if self.current_mode == "FILES":
            self.load_providers()
        else:
            self.close()

    def fetch_github_files(self, owner, repo):
        self["status"].setText("Fetching file list from GitHub...")
        api_url = "https://api.github.com/repos/%s/%s/contents" % (owner, repo)
        
        try:
            req = urllib_req.Request(api_url, headers=HEADERS)
            resp = urllib_req.urlopen(req)
            content = resp.read()
            if PY3:
                content = content.decode('utf-8')
            data = json.loads(content)
            
            zip_files = []
            for item in data:
                file_name = str(item.get("name", ""))
                if item.get("type") == "file" and file_name.endswith(".zip"):
                    download_url = str(item.get("download_url", ""))
                    zip_files.append((file_name, download_url))
                elif item.get("type") == "dir":
                    dir_url = str(item.get("url", ""))
                    req_dir = urllib_req.Request(dir_url, headers=HEADERS)
                    resp_dir = urllib_req.urlopen(req_dir)
                    content_dir = resp_dir.read()
                    if PY3:
                        content_dir = content_dir.decode('utf-8')
                    dir_data = json.loads(content_dir)
                    for sub_item in dir_data:
                        sub_file_name = str(sub_item.get("name", ""))
                        if sub_file_name.endswith(".zip"):
                            display_title = "%s/%s" % (file_name, sub_file_name)
                            sub_download_url = str(sub_item.get("download_url", ""))
                            zip_files.append((str(display_title), sub_download_url))

            if not zip_files:
                raise Exception("No .zip files found in repository.")

            self.file_items = zip_files
            self.current_mode = "FILES"
            self["status"].setText("Select a ZIP file to install (%s/%s):" % (owner, repo))
            
            display_list = [str(item[0]) for item in zip_files]
            self["list"].setList(display_list)

        except Exception as e:
            self["status"].setText("Failed to load GitHub files.")
            self.session.open(MessageBox, "Error fetching files: %s" % str(e), MessageBox.TYPE_ERROR)

    def fetch_vhannibal_files(self):
        self["status"].setText("Fetching settings from Vhannibal.net...")
        url = "https://www.vhannibal.net/"

        try:
            req = urllib_req.Request(url, headers=HEADERS)
            resp = urllib_req.urlopen(req)
            html = resp.read()
            if PY3:
                html = html.decode('utf-8', errors='ignore')
            else:
                html = str(html)

            zip_files = []
            pattern = r'<tr[^>]*>.*?<a[^>]+href=["\']([^"\']*(?:download_setting\.php|download\.php|\.zip)[^"\']*)["\'][^>]*>(.*?)</a>.*?</tr>'
            matches = re.findall(pattern, html, re.DOTALL | re.IGNORECASE)

            for href, name in matches:
                clean_name = re.sub(r'<[^>]+>', '', name).strip()
                clean_name = ' '.join(clean_name.split())
                
                if clean_name and "picon" not in clean_name.lower():
                    full_url = href if href.startswith("http") else "https://www.vhannibal.net/" + href
                    zip_files.append((str(clean_name), str(full_url)))

            if not zip_files:
                direct_matches = re.findall(r'href=["\']([^"\']*(?:download_setting\.php\?id=\d+)[^"\']*)["\']', html, re.IGNORECASE)
                for idx, link in enumerate(direct_matches):
                    full_url = link if link.startswith("http") else "https://www.vhannibal.net/" + link
                    zip_files.append(("Vhannibal Settings List #%d" % (idx + 1), str(full_url)))

            if not zip_files:
                raise Exception("Could not parse channel list links from Vhannibal.")

            self.file_items = zip_files
            self.current_mode = "FILES"
            self["status"].setText("Select Vhannibal channel list:")
            
            display_list = [str(item[0]) for item in zip_files]
            self["list"].setList(display_list)

        except Exception as e:
            self["status"].setText("Failed to load Vhannibal lists.")
            self.session.open(MessageBox, "Error reading Vhannibal site: %s" % str(e), MessageBox.TYPE_ERROR)

    def confirm_download(self, name, download_url):
        self.session.openWithCallback(
            lambda res: self.process_download(res, download_url),
            MessageBox,
            "Download and install:\n%s?" % name,
            MessageBox.TYPE_YESNO
        )

    def process_download(self, confirmed, download_url):
        if not confirmed:
            return

        self["status"].setText("Downloading settings, please wait...")
        try:
            if os.path.exists(TMP_ZIP):
                os.remove(TMP_ZIP)
            if os.path.exists(TMP_EXTRACT):
                shutil.rmtree(TMP_EXTRACT)

            req = urllib_req.Request(download_url, headers=HEADERS)
            response = urllib_req.urlopen(req)
            with open(TMP_ZIP, 'wb') as out_file:
                shutil.copyfileobj(response, out_file)

            with zipfile.ZipFile(TMP_ZIP, 'r') as zip_ref:
                zip_ref.extractall(TMP_EXTRACT)

            target_folder = None
            for root, dirs, files in os.walk(TMP_EXTRACT):
                if "lamedb" in files or any(f.startswith("userbouquet.") for f in files):
                    target_folder = root
                    break

            if not target_folder:
                raise Exception("No valid Enigma2 settings (lamedb/userbouquet) found inside ZIP.")

            # Force Dreambox / DreamOS to allow multiple bouquets
            try:
                if hasattr(config.usage, "multibouquet"):
                    config.usage.multibouquet.value = True
                    config.usage.multibouquet.save()
                    configfile.save()
            except Exception:
                pass

            # Clean old bouquets and channel data
            for f in os.listdir(DEST_DIR):
                if f.startswith("userbouquet.") or f.startswith("bouquets.") or f == "lamedb":
                    try:
                        os.remove(os.path.join(DEST_DIR, f))
                    except Exception:
                        pass

            # Copy downloaded channel files
            userbouquet_files = []
            for item in os.listdir(target_folder):
                s = os.path.join(target_folder, item)
                d = os.path.join(DEST_DIR, item)
                
                if os.path.isfile(s):
                    if item.startswith("userbouquet.") or item.startswith("bouquets.") or item == "lamedb":
                        shutil.copy2(s, d)
                        if item.startswith("userbouquet.") and item.endswith(".tv"):
                            userbouquet_files.append(item)
                    elif item == "satellites.xml":
                        if os.path.exists("/etc/tuxbox/"):
                            shutil.copy2(s, "/etc/tuxbox/satellites.xml")
                        shutil.copy2(s, os.path.join(DEST_DIR, item))

            # Auto-generate bouquets.tv index if missing or incomplete for Dreambox (DreamOS)
            bouquets_tv_path = os.path.join(DEST_DIR, "bouquets.tv")
            if not os.path.exists(bouquets_tv_path) and userbouquet_files:
                userbouquet_files.sort()
                with open(bouquets_tv_path, "w") as bfile:
                    bfile.write("#NAME Bouquets (TV)\n")
                    for ub in userbouquet_files:
                        bfile.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % ub)

            # Cross-compatible Service & Bouquet Reload (Works on OE2.0, DreamOS OE2.2/2.5/2.6)
            db = eDVBDB.getInstance()
            if db:
                if hasattr(db, "reloadServicelist"):
                    db.reloadServicelist()
                if hasattr(db, "reloadBouquets"):
                    db.reloadBouquets()
                if hasattr(db, "load"):
                    db.load()

            self["status"].setText("Installed successfully!")
            self.session.open(MessageBox, "Channel list updated successfully!", MessageBox.TYPE_INFO)

        except Exception as e:
            self["status"].setText("Error installing list.")
            self.session.open(MessageBox, "Installation Error: %s" % str(e), MessageBox.TYPE_ERROR)

        finally:
            if os.path.exists(TMP_ZIP):
                os.remove(TMP_ZIP)
            if os.path.exists(TMP_EXTRACT):
                shutil.rmtree(TMP_EXTRACT)


def main(session, **kwargs):
    session.open(ChannelDownloaderScreen)


def menu_main(menuid, **kwargs):
    if menuid == "mainmenu":
        return [("Levi45 Channel List Downloader", main, "channel_downloader", 45)]
    return []


def Plugins(**kwargs):
    descriptors = [
        PluginDescriptor(
            name="Levi45 Channel List Downloader",
            description="Satellite-Forum.Com channel lists (v%s)" % VERSION,
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="plugin.png",
            fnc=main
        )
    ]

    if config.plugins.Levi45Setting.show_in_mainmenu.value:
        descriptors.append(
            PluginDescriptor(
                name="Levi45 Channel List Downloader",
                description="Satellite-Forum.Com channel lists (v%s)" % VERSION,
                where=PluginDescriptor.WHERE_MENU,
                fnc=menu_main
            )
        )

    return descriptors
