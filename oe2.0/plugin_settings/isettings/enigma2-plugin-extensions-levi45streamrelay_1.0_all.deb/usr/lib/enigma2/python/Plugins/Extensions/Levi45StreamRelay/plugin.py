# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from Components.config import config, configfile, ConfigSubsection, ConfigText, ConfigInteger, ConfigSelection, ConfigYesNo, getConfigListEntry
from Components.Label import Label
from Components.Pixmap import Pixmap
from enigma import eDVBDB, eServiceReference, eServiceCenter
from .relay import list_bouquets, create_bouquet, list_generated, delete_bouquet

VERSION = '1.0'
PLUGIN_NAME = 'Levi45StreamRelay v' + VERSION

if not hasattr(config.plugins, 'streamrelaymaker'):
    config.plugins.streamrelaymaker = ConfigSubsection()
    config.plugins.streamrelaymaker.host = ConfigText(default='127.0.0.1', fixed_size=False)
    config.plugins.streamrelaymaker.port = ConfigInteger(default=17999, limits=(1, 65535))
    config.plugins.streamrelaymaker.player = ConfigSelection(default='1', choices=[('1', 'DVB / Dreambox (1)'), ('4097', 'IPTV (4097)')])


# Register new preferences separately so upgrades keep existing settings.
if not hasattr(config.plugins.streamrelaymaker, 'showmainmenu'):
    config.plugins.streamrelaymaker.showmainmenu = ConfigYesNo(default=True)

def resolve_channel_name(reference):
    ref = eServiceReference(reference)
    info = eServiceCenter.getInstance().info(ref)
    return info.getName(ref) if info else None


class Levi45StreamRelay(Screen, ConfigListScreen):
    skin = """<screen name="Levi45StreamRelay" position="center,center" size="960,680" title="Levi45StreamRelay">
    <widget name="heading" position="25,18" size="910,45" font="Regular;32" />
    <widget name="config" position="25,75" size="910,240" font="Regular;28" itemHeight="48" scrollbarMode="showOnDemand" />
    <widget name="help" position="25,325" size="910,65" font="Regular;24" />
    <widget name="donate" position="25,400" size="910,35" font="Regular;26" halign="center" foregroundColor="#00e5e5" />
    <widget name="paypal" position="345,450" size="120,120" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Levi45StreamRelay/images/paypal.png" alphatest="blend" scale="1" />
    <widget name="kofi" position="495,450" size="120,120" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Levi45StreamRelay/images/kofi.png" alphatest="blend" scale="1" />
    <widget name="paypal_label" position="330,575" size="150,25" font="Regular;20" halign="center" />
    <widget name="kofi_label" position="480,575" size="150,25" font="Regular;20" halign="center" />
    <widget name="button_red" position="25,605" size="32,32" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Levi45StreamRelay/images/key_red.png" alphatest="blend" />
    <widget name="key_red" position="65,605" size="180,35" font="Regular;26" />
    <widget name="button_green" position="255,605" size="32,32" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Levi45StreamRelay/images/key_green.png" alphatest="blend" />
    <widget name="key_green" position="295,605" size="180,35" font="Regular;26" />
    <widget name="button_yellow" position="485,605" size="32,32" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Levi45StreamRelay/images/key_yellow.png" alphatest="blend" />
    <widget name="key_yellow" position="525,605" size="180,35" font="Regular;26" />
    <widget name="button_blue" position="715,605" size="32,32" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Levi45StreamRelay/images/key_blue.png" alphatest="blend" />
    <widget name="key_blue" position="755,605" size="180,35" font="Regular;26" />
    <widget name="keys" position="25,650" size="910,25" font="Regular;22" />
    </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self.setTitle(PLUGIN_NAME)
        self.settings = config.plugins.streamrelaymaker
        self.bouquets = list_bouquets('/etc/enigma2')
        choices = [(name, title) for title, name in self.bouquets] or [('', 'No bouquets found')]
        self.source = ConfigSelection(choices=choices)
        ConfigListScreen.__init__(self, [
            getConfigListEntry('Source bouquet', self.source),
            getConfigListEntry('Relay host', self.settings.host),
            getConfigListEntry('Relay port', self.settings.port),
            getConfigListEntry('Playback type', self.settings.player),
            getConfigListEntry('Show in main menu', self.settings.showmainmenu)], session=session)
        self['heading'] = Label(PLUGIN_NAME)
        self['donate'] = Label('If you like the plugin, scan to donate')
        self['paypal'] = Pixmap()
        self['kofi'] = Pixmap()
        self['paypal_label'] = Label('PayPal')
        self['kofi_label'] = Label('Ko-fi')
        self['help'] = Label('Creates a separate relay bouquet. Original channels are preserved. An existing stream relay server is required.')
        for colour, text in (('red', 'Cancel'), ('green', 'Create'), ('yellow', 'Delete'), ('blue', 'Save')):
            self['button_' + colour] = Pixmap()
            self['key_' + colour] = Label(text)
        self['keys'] = Label('LEFT/RIGHT: Change')
        self['actions'] = ActionMap(['SetupActions', 'ColorActions'], {
            'cancel': self.cancel, 'red': self.cancel, 'green': self.make, 'save': self.make, 'yellow': self.choose_delete, 'blue': self.save_and_close}, -2)

    def cancel(self):
        for item in (self.settings.host, self.settings.port, self.settings.player, self.settings.showmainmenu):
            item.cancel()
        self.close()

    def save_settings(self):
        for item in (self.settings.host, self.settings.port, self.settings.player, self.settings.showmainmenu):
            item.save()
        configfile.save()

    def save_and_close(self):
        self.save_settings()
        self.close()

    def choose_delete(self):
        try:
            bouquets = list_generated('/etc/enigma2')
        except Exception as error:
            self.session.open(MessageBox, 'Could not list relay bouquets: %s' % error, MessageBox.TYPE_ERROR)
            return
        if not bouquets:
            self.session.open(MessageBox, 'No bouquets created by this plugin were found.', MessageBox.TYPE_INFO)
            return
        choices = [('%s - %s' % (title, name), name) for title, name in bouquets]
        self.session.openWithCallback(self.confirm_delete, ChoiceBox,
            title='Delete a plugin-created bouquet', list=choices)

    def confirm_delete(self, choice):
        if choice is None:
            return
        name = choice[1]
        self.session.openWithCallback(lambda answer: self.remove_bouquet(answer, name),
            MessageBox, 'Delete this relay bouquet?\n%s\nThis permanently removes the generated bouquet.' % name,
            MessageBox.TYPE_YESNO, default=False)

    def remove_bouquet(self, confirmed, name):
        if not confirmed:
            return
        try:
            delete_bouquet('/etc/enigma2', name)
        except Exception as error:
            self.session.open(MessageBox, 'Could not delete bouquet: %s' % error, MessageBox.TYPE_ERROR)
            return
        message = 'Deleted %s.' % name
        try:
            eDVBDB.getInstance().reloadBouquets()
        except Exception:
            message += '\nRestart the Enigma2 GUI to refresh the bouquet list.'
        self.session.open(MessageBox, message, MessageBox.TYPE_INFO)

    def make(self):
        try:
            if not self.source.value:
                raise ValueError('No source bouquet available.')
            target, count = create_bouquet('/etc/enigma2', self.source.value,
                self.settings.host.value.strip(), self.settings.port.value, self.settings.player.value, resolve_channel_name)
        except Exception as error:
            self.session.open(MessageBox, 'Could not create bouquet: %s' % error, MessageBox.TYPE_ERROR)
            return
        self.save_settings()
        message = 'Created %s with %d relay channels.' % (target, count)
        try:
            eDVBDB.getInstance().reloadBouquets()
        except Exception:
            message += '\nRestart the Enigma2 GUI to load the bouquet.'
        self.session.open(MessageBox, message, MessageBox.TYPE_INFO)


def main(session, **kwargs):
    try:
        session.open(Levi45StreamRelay)
    except Exception as error:
        session.open(MessageBox, 'Levi45StreamRelay: %s' % error, MessageBox.TYPE_ERROR)


def menu(menuid, **kwargs):
    if menuid == 'mainmenu' and config.plugins.streamrelaymaker.showmainmenu.value:
        return [(PLUGIN_NAME, main, 'levi45streamrelay', 50)]
    return []


def Plugins(**kwargs):
    return [
        PluginDescriptor(name='Levi45StreamRelay', description='Create stream-relay copies of DVB bouquets (v%s)' % VERSION,
            where=PluginDescriptor.WHERE_PLUGINMENU, icon='images/plugin.png', fnc=main),
        PluginDescriptor(name=PLUGIN_NAME, description='Levi45StreamRelay main menu entry',
            where=PluginDescriptor.WHERE_MENU, fnc=menu)]
