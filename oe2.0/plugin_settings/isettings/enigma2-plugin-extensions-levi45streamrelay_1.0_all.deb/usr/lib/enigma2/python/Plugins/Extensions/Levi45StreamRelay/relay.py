# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import io
import os
import re
import tempfile


def read_text(path):
    with io.open(path, 'r', encoding='utf-8', errors='replace') as handle:
        return handle.read()


def atomic_write(path, text):
    fd, temporary = tempfile.mkstemp(prefix='.srm-', dir=os.path.dirname(path))
    try:
        with io.open(fd, 'w', encoding='utf-8') as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temporary, 0o644)
        os.rename(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def convert(text, host='127.0.0.1', port=17999, service_type='1', name_resolver=None):
    if not re.match(r'^[A-Za-z0-9.-]+$', host) or not 1 <= int(port) <= 65535:
        raise ValueError('Enter a hostname or IPv4 address and a valid port.')
    if service_type not in ('1', '4097'):
        raise ValueError('Unsupported playback service type.')
    output, count = [], 0
    lines = text.splitlines()
    for position, line in enumerate(lines):
        if line.startswith('#NAME '):
            output.append(line + ' (Stream Relay)')
        elif line.startswith('#SERVICE '):
            ref = line[9:].strip()
            parts = ref.split(':')
            # Only plain DVB services; preserve markers, alternatives and IPTV.
            try:
                valid = (len(parts) >= 11 and parts[0] == '1'
                         and int(parts[1], 16) == 0
                         and all(re.match(r'^[0-9a-fA-F]+$', x) for x in parts[:10])
                         and not ''.join(parts[10:]))
            except ValueError:
                valid = False
            if valid:
                original = ':'.join(parts[:10]) + ':'
                url = 'http://%s:%d/%s' % (host, int(port), original)
                # Enigma2 escapes URL colons in bouquet service references.
                outer = list(parts[:10])
                outer[0] = service_type
                # Distinguish the stream from its source DVB service. The URL
                # above must retain the real tuning identity.
                outer[4:7] = ['11', '22', '33']
                output.append('#SERVICE ' + ':'.join(outer) + ':' + url.replace(':', '%3a'))
                following = lines[position + 1] if position + 1 < len(lines) else ''
                if not following.startswith('#DESCRIPTION '):
                    name = name_resolver(original) if name_resolver else None
                    if isinstance(name, bytes):
                        name = name.decode('utf-8', 'replace')
                    name = (name or '').replace('\r', ' ').replace('\n', ' ').strip()
                    if not name or name == original:
                        raise ValueError('Cannot resolve channel name for %s; no bouquet was written.' % original)
                    output.append('#DESCRIPTION ' + name)
                count += 1
            else:
                output.append(line)
        else:
            output.append(line)
    return '\n'.join(output) + '\n', count


def safe_bouquet_filename(name):
    return (name not in ('bouquets.tv', 'bouquets.radio')
            and os.path.basename(name) == name and '/' not in name and '\\' not in name
            and name.endswith(('.tv', '.radio')))


def list_bouquets(directory):
    # Follow the receiver indexes instead of sorting files by their filenames.
    # TV and radio have separate indexes and must not be interleaved.
    result, seen = [], set()
    reference = re.compile(r'\bFROM BOUQUET\s+"([^"\r\n]+)"')

    def visit(name, radio):
        if (not safe_bouquet_filename(name) or name in seen
                or name.startswith('userbouquet.srm_')):
            return
        seen.add(name)
        try:
            text = read_text(os.path.join(directory, name))
        except (IOError, OSError):
            return
        title = next((x[6:] for x in text.splitlines() if x.startswith('#NAME ')), name)
        result.append((('[Radio] ' if radio else '') + title, name))
        # Also expose registered sub-bouquets without looping on cyclic links.
        for line in text.splitlines():
            match = reference.search(line) if line.startswith('#SERVICE ') else None
            if match:
                visit(match.group(1), radio)

    found_index = False
    for suffix in ('tv', 'radio'):
        index = os.path.join(directory, 'bouquets.' + suffix)
        if not os.path.isfile(index):
            continue
        found_index = True
        for line in read_text(index).splitlines():
            match = reference.search(line) if line.startswith('#SERVICE ') else None
            if match:
                visit(match.group(1), suffix == 'radio')
    if not found_index:
        # Fallback for older images/settings without bouquet indexes.
        names = sorted(os.listdir(directory))
        for suffix in ('tv', 'radio'):
            for name in names:
                if name.startswith('userbouquet.') and name.endswith('.' + suffix):
                    visit(name, suffix == 'radio')
    return result


def create_bouquet(directory, source, host, port, service_type, name_resolver=None):
    if not safe_bouquet_filename(source):
        raise ValueError('Invalid source bouquet.')
    output, count = convert(read_text(os.path.join(directory, source)), host, port, service_type, name_resolver)
    if not count:
        raise ValueError('No plain DVB channels found in this bouquet.')
    suffix = 'radio' if source.endswith('.radio') else 'tv'
    index_path = os.path.join(directory, 'bouquets.' + suffix)
    index = read_text(index_path)
    source_stem = source[:-(len(suffix) + 1)]
    if source_stem.startswith('userbouquet.'):
        source_stem = source_stem[len('userbouquet.'):]
    stem = 'userbouquet.srm_' + source_stem
    number = 1
    while True:
        target = '%s_%d.%s' % (stem, number, suffix)
        if not os.path.exists(os.path.join(directory, target)) and ('"' + target + '"') not in index:
            break
        number += 1
    atomic_write(os.path.join(directory, target), output)
    entry = '#SERVICE 1:7:%s:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % ('2' if suffix == 'radio' else '1', target)
    try:
        atomic_write(index_path, index.rstrip('\n') + '\n' + entry)
    except Exception:
        os.unlink(os.path.join(directory, target))
        raise
    return target, count


def generated_bouquet(directory, name):
    if (os.path.basename(name) != name
            or not re.match(r'^userbouquet\.srm_.+_[0-9]+\.(tv|radio)$', name)):
        return False
    path = os.path.join(directory, name)
    if os.path.islink(path) or not os.path.isfile(path):
        return False
    return any(line.startswith('#NAME ') and line.endswith(' (Stream Relay)')
               for line in read_text(path).splitlines())


def list_generated(directory):
    result = []
    for name in sorted(os.listdir(directory)):
        if generated_bouquet(directory, name):
            title = next(line[6:] for line in read_text(os.path.join(directory, name)).splitlines()
                         if line.startswith('#NAME '))
            result.append((title, name))
    return result


def delete_bouquet(directory, name):
    # Restrict deletion to the filename pattern AND title emitted by this plugin,
    # including legacy versions. Never follow a bouquet symlink.
    if not generated_bouquet(directory, name):
        raise ValueError('This is not a bouquet created by Levi45StreamRelay.')
    path = os.path.join(directory, name)
    suffix = 'radio' if name.endswith('.radio') else 'tv'
    index_path = os.path.join(directory, 'bouquets.' + suffix)
    original_index = read_text(index_path)
    pattern = re.compile(r'\bFROM BOUQUET\s+"' + re.escape(name) + r'"(?:\s|$)')
    lines = original_index.splitlines(True)
    updated_index = ''.join(line for line in lines
                            if not (line.startswith('#SERVICE ') and pattern.search(line)))
    atomic_write(index_path, updated_index)
    try:
        os.unlink(path)
    except Exception:
        atomic_write(index_path, original_index)
        raise
    return name
