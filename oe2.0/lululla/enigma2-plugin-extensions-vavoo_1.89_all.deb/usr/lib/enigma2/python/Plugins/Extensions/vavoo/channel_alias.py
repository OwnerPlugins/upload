# channel_alias.py
# -*- coding: utf-8 -*-

"""
Channel name normalization and EPG ID mapping for Italian channels.
Based on the logic from the original vavoo-player project.
"""

# ------------------------------------------------------------------------------
# RENAME RULES: apply these transformations to the raw channel name
# ------------------------------------------------------------------------------
RENAME_RULES = [
    # (original_pattern, canonical_name, optional_flags)
    # Special case: generic "RAI" is actually RAI 4K
    ("RAI", "RAI 4K"),
    ("RAI 4K", "RAI 4K"),
    ("LA 7", "LA7"),
    ("LA 5", "LA5"),
    ("8 TV", "TV8"),
    ("8TV", "TV8"),
    ("8", "TV8"),
    ("TV 8", "TV8"),
    ("CINE 34", "CINE34"),
    ("TV 2000", "TV2000"),
    ("TG COM 24", "TGCOM24"),
    ("TGCOM 24", "TGCOM24"),
    ("SKY TG 24", "SKY TG24"),
    ("SPORT ITALIA", "SPORTITALIA"),
    ("SPORTITALIA PLUS", "SPORTITALIA"),
    # "SPORTITALIA SOLOCALCIO" removed - it has its own dedicated
    # ALIAS_MAP entry ("SportitaliaSoloCalcio.it", a distinct
    # football-only spinoff channel), which this rule made permanently
    # unreachable by forcing it to plain SPORTITALIA's EPG before the
    # alias lookup ever ran.
    ("SUPER", "SUPER!"),
    ("RTL 1025", "RTL 102.5"),
    ("RTL1025", "RTL 102.5"),
    ("DISCOVERY NOVE", "NOVE"),
    ("DISCOVERY K2", "K2"),
    ("DISCOVERY FOCUS", "FOCUS"),
    ("MEDIASET IRIS", "IRIS"),
    ("MEDIASET ITALIA 2", "ITALIA 2"),
    ("SKY CINEMA UNO 24", "SKY CINEMA UNO"),
    # "SKY CRIME"/"PREMIUM CRIME" -> "TOP CRIME" removed - all three
    # have their own distinct, dedicated ALIAS_MAP entries
    # (SkyCrime.it / PremiumCrime.it / TOPcrime.it), so these two
    # rules made the first two permanently unreachable by forcing them
    # onto TOP Crime's EPG before the alias lookup ever ran.
    ("SKY SPORT MOTOGP", "SKY SPORT MOTO GP"),
    ("SKY SPORTS F1", "SKY SPORT F1"),
    ("SKY SUPER TENNIS", "SUPER TENNIS"),
    ("CANALE 27", "TWENTYSEVEN"),
    ("27", "TWENTYSEVEN"),
    ("TWENTYSEVEN", "TWENTYSEVEN"),
    ("TWENTY SEVEN", "TWENTYSEVEN"),
    ("27 TWENTY SEVEN", "TWENTYSEVEN"),
    ("27 TWENTYSEVEN", "TWENTYSEVEN"),
    ("CINE 34 MEDIASET", "CINE34"),
    ("MEDIASET 20", "20 MEDIASET"),
    # "MEDIASET 1" removed - it previously mapped here too, but
    # "Mediaset 1" (Canale 5's old branding) and "Mediaset 20" are
    # historically different channels; this looked like a copy-paste of
    # the rule above with only the source pattern changed. A raw
    # channel literally named "MEDIASET 1" now falls through to the
    # normal matching chain (Rytec/curated DB) instead of being
    # silently reassigned to the wrong channel.
    ("MOTORTREND", "MOTOR TREND"),
    # "CANALE 5" -> "CANALE5" removed - ALIAS_MAP's own key is
    # "CANALE 5" (with the space), so this rename only ever produced
    # "CANALE5", which matches nothing - making the "Canale5.it" entry
    # permanently unreachable for a raw channel literally named
    # "CANALE 5". The raw name now passes through unchanged and hits
    # that entry directly.
    ("LA 7 D", "LA7D"),
    ("RAI SPORT", "RAI SPORT"),  # keep as is, but we can add logo later
    # History channels
    ("HISTORY CHANNEL S", "HISTORY"),
    ("HISTORY  CHANNEL S", "HISTORY"),
]

# Some channel names may have prefixes like "HISTORY" but not exactly; we'll use
# a function that checks startswith and applies a rule if not already matched.
# ------------------------------------------------------------------------------
# EPG ID MAPPING: from canonical name to Rytec ID
# ------------------------------------------------------------------------------

ALIAS_MAP = {
    "20 MEDIASET": "Mediaset20.it",
    "20": "Mediaset20.it",
    "8": "TV8.it",
    "ACI SPORT TV": "ACISportTv.it",
    "AL JAZEERA": "AlJazeera.it",
    "ALMA TV": "AlmaTV.it",
    "ARRAMPICATA": "Arrampicata.it",
    "ATLETICA": "Atletica.it",
    "BABY TV": "BabyTV.it",
    "BBC WORLD NEWS": "BBCWorldNews.it",
    "BIKE": "Bike.it",
    "BLAZE": "Blaze.it",
    "BLOOMBERG": "Bloomberg.it",
    "BOING PLUS": "BoingPlus.it",
    "BOING": "Boing.it",
    "BOOMERANG + 1": "Boomerang+1.it",
    "BOOMERANG": "Boomerang.it",
    "CACCIA E PESCA": "CacciaPesca.it",
    "CANALE 5": "Canale5.it",
    "CARTOON NETWORK": "CartoonNetwork.it",
    "CARTOONITO": "CARTOONITO.it",
    "CIELO": "cielo.it",
    "CINE34": "Cine34.it",
    "CLASS-CNBC": "ClassCNBC.it",
    "CLASSICA HD": "Classica.it",
    "CN +1": "CN+1.it",
    "CNBC": "CNBC.it",
    "CNN INTL": "CNNIntl.it",
    "COMEDY +1": "Comedy+1.it",
    "COMEDY CENTRAL": "ComedyCentral.it",
    "CRICKET": "Cricket.it",
    "CRIME+ INV.": "Crime+Inv..it",
    "DAZN 1": "DAZN1.it",
    "DAZN 10": "DAZN10.it",
    "DAZN 11": "DAZN11.it",
    "DAZN 12": "DAZN12.it",
    "DAZN 13": "DAZN13.it",
    "DAZN 14": "DAZN14.it",
    "DAZN 15": "DAZN15.it",
    "DAZN 16": "DAZN16.it",
    "DAZN 17": "DAZN17.it",
    "DAZN 18": "DAZN18.it",
    "DAZN 19": "DAZN19.it",
    "DAZN 2": "DAZN2.it",
    "DAZN 20": "DAZN20.it",
    "DAZN 21": "DAZN21.it",
    "DAZN 3": "DAZN3.it",
    "DAZN 4": "DAZN4.it",
    "DAZN 5": "DAZN5.it",
    "DAZN 6": "DAZN6.it",
    "DAZN 7": "DAZN7.it",
    "DAZN 8": "DAZN8.it",
    "DAZN 9": "DAZN9.it",
    "DAZN": "DAZN.it",
    "DEA JUNIOR": "DeAJunior.it",
    "DEAKIDS": "DeAKids.it",
    "DEAKIDS+1": "DeAKids+1.it",
    "DEEJAY TV": "DeejayTV.it",
    "DISCOVERY CH +1": "Discovery+1.it",
    "DISCOVERY CHANNEL HD": "DiscoveryChannelHD.it",
    "DISCOVERY CHANNEL": "DiscoveryChannel.it",
    "DISCOVERY FOCUS": "Focus.it",
    "DISCOVERY K2": "K2.it",
    "DISCOVERY NOVE": "Nove.it",
    "DISCOVERY SCIENCE HD": "DiscoverySci.it",
    "DISCOVERY SCIENCE": "DiscoveryScience.it",
    "DISNEY CHANNEL": "DisneyChannel.ch",
    "DISNEY JUNIOR": "DisneyJuniorf.ch",
    "DMAX HD": "DMAXHD.it",
    "DMAX": "DMAX.it",
    "DONNATV": "DonnaTv.it",
    "EQUTV": "Equtv.it",
    "ER24 - EMILIA ROMAGNA 24": "EmiliaRomagna24.it",
    "EURONEWS": "Euronews.it",
    "EUROSPORT 1": "Eurosport1.it",
    "EUROSPORT 2": "Eurosport2.it",
    "EUROSPORT 2HD": "Eurosport.2.it",
    "EUROSPORT HD": "Eurosport.1.it",
    "FOCUS": "Focus.it",
    "FOOD NETWORK": "FoodNetwork.it",
    "FOX +1": "Fox+1.it",
    "FOX BUSINESS": "Fox.Business.it",
    "FOX NEWS": "Fox.News.it",
    "FOX": "Fox.it",
    "FRANCE 24 ENGLISH": "France24English.it",
    "FRANCE 24": "France24.it",
    "FRISBEE": "-frisbee-.it",
    "GAMBERO ROSSO HD": "GamberoRosso.it",
    "GIALLO": "Giallo.TV.it",
    "GINNASTICA": "Ginnastica.it",
    "HGTV - HOMEANDGARDEN": "HGTV.it",
    "HGTV": "HGTV.it",
    "HISTORY 1": "History.it",
    "HISTORY C": "History.it",
    "HISTORY CHANNEL S": "History.it",
    "HISTORY HD": "History.it",
    "HISTORY S": "History.it",
    "HISTORY": "History.it",
    "HORSE TV HD": "HorseTV.it",
    "I24NEWS": "i24news.it",
    "IL61": "IL61.it",
    "INTER TV HD": "InterTV.it",
    "INTER TV": "InterTV.it",
    "IRIS": "Iris.it",
    "ITALIA 1": "Italia1.it",
    "ITALIA 2": "Italia2.it",
    "ITALIA 7 GOLD": "Italia7Gold.it",
    "K2": "K2.it",
    "LA 1": "RSILA1.it",
    "LA 2": "RSILA2.it",
    "LA 7": "La7.it",
    "LA5": "La5.it",
    "LA7": "La7.it",
    "LA7D": "La7d.it",
    "LAZIO STYLE CHANNEL": "LazioStyleCh.it",
    "MARCOPOLO TRAVEL TV": "MarcopoloTravelTV.it",
    "MEDIASET EXTRA": "MediasetExtra.it",
    "MILAN TV": "MilanTV.it",
    "MOTOR TREND": "MotorTrend.it",
    "MTV HITS": "MTVHits.it",
    "MTV MUSIC": "MTVMusic.it",
    "MTV": "MTV.it",
    "NAT GEO WILD +1": "NatGeoWild+1.it",
    "NAT GEO WILD": "NatGeoWild.it",
    "NATIONAL GEOGRAPHIC +1": "NationalGeo+1.it",
    "NATIONAL GEOGRAPHIC WILD": "NatGeoWild.it",
    "NATIONAL GEOGRAPHIC": "NationalGeo.it",
    "NHK WORLD TV": "NHKWorldTV.it",
    "NICK JR+1": "NickJr+1.it",
    "NICK JUNIOR": "NickJr.it",
    "NICKELODEON + 1": "Nickelodeon+1.it",
    "NICKELODEON": "Nickelodeon.it",
    "NOVE": "Nove.it",
    "NUOTO": "Nuoto.it",
    "OLIMPIADI": "Olimpiadi.it",
    "PADEL": "Padel.it",
    "PALLANUOTO": "Pallanuoto.it",
    "PALLAVOLO": "Pallavolo.it",
    "PESCA E CACCIA": "PescaCaccia.it",
    "PREMIUM ACTION": "PremiumAction.it",
    "PREMIUM CINEMA 1": "PremiumCinema1.it",
    "PREMIUM CINEMA 2": "PremiumCinema2.it",
    "PREMIUM CINEMA 3": "PremiumCinema3.it",
    "PREMIUM CRIME": "PremiumCrime.it",
    "PREMIUM STORIES": "PremiumStories.it",
    "PRIMAFILA 1": "Primafila1.it",
    "PRIMAFILA 2": "Primafila2.it",
    "PRIMAFILA 3": "Primafila3.it",
    "PRIMAFILA 4": "Primafila4.it",
    "PRIMAFILA 5": "Primafila5.it",
    "QVC": "QVC.it",
    "R101": "R101.it",
    "RADIO 105": "Radio105.it",
    "RADIO FRECCIA": "RADIOFRECCIA.it",
    "RADIO ITALIA TV": "RadioItaliaTV.it",
    "RADIO MONTE CARLO": "RadioMonteCarlo.it",
    "RADIONORBA TV": "RADIONORBATV.it",
    "RAI 1": "Rai1.it",
    "RAI 2": "Rai2.it",
    "RAI 3": "Rai3.it",
    "RAI 4": "Rai4.it",
    "RAI 4K": "Rai4k.it",
    "RAI 5": "Rai5.it",
    "RAI GULP": "RaiGulp.it",
    "RAI MOVIE": "RaiMovie.it",
    "RAI NEWS 24": "RaiNews.it",
    "RAI PREMIUM": "RaiPremium.it",
    "RAI SCUOLA": "RaiScuola.it",
    "RAI SPORT": "RAISport.it",
    "RAI STORIA": "RaiStoria.it",
    "RAI YOYO": "RaiYoyo.it",
    "REAL TIME": "Real.Time.it",
    "RETE 4": "Rete4.it",
    "RSI LA 1": "RSILA1.it",
    "RSI LA 2": "RSILA2.it",
    "RT DOC HD": "RTDoc.it",
    "RTL 102.5 TV": "RTL1025.it",
    "RTL 102.5": "RTL1025.it",
    "RUGBY": "Rugby.it",
    "RUSSIA TODAY": "RussiaToday.it",
    "SCHERMA": "Scherma.it",
    "SKY ADVENTURE": "SkyAdventure.it",
    "SKY ARTE +1": "SkyArte+1.it",
    "SKY ARTE HD-400": "SkyArteHD-400.it",
    "SKY ARTE": "SkyArte.it",
    "SKY ATLANTIC +1": "SkyAtlantic+1.it",
    "SKY ATLANTIC": "SkyAtlantic.it",
    "SKY CINEMA ACTION": "SkyCinemaAction.it",
    "SKY CINEMA COLLECTION": "SkyCinemaCollection.it",
    "SKY CINEMA COMEDY": "SkyCinemaComedy.it",
    "SKY CINEMA DRAMA": "SkyCinemaDrama.it",
    "SKY CINEMA DUE +24": "SkyCinemaDue+24.it",
    "SKY CINEMA DUE": "SkyCinemaDue.it",
    "SKY CINEMA FAMILY": "SkyCinemaFamily.it",
    "SKY CINEMA ROMANCE": "SkyCinemaRomance.it",
    "SKY CINEMA SUSPENSE": "SkyCinemaSuspense.it",
    "SKY CINEMA UNO +24": "SkyCinemaUno+24.it",
    "SKY CINEMA UNO": "SkyCinemaUno.it",
    "SKY CRIME": "SkyCrime.it",
    "SKY DOCUMENTARIES +1": "SkyDocumentaries+1.it",
    "SKY DOCUMENTARIES": "SkyDocumentaries.it",
    "SKY INVESTIGATION +1": "SkyInvestigation+1.it",
    "SKY INVESTIGATION": "SkyInvestigation.it",
    "SKY METEO24": "SkyMeteo24.it",
    "SKY NATURE": "SkyNature.it",
    "SKY NEWS": "SkyNews.it",
    "SKY SERIE +1": "SkySerie+1.it",
    "SKY SERIE": "SkySerie.it",
    "SKY SPORT 24": "SkySport24.it",
    "SKY SPORT 251": "SkySport251.it",
    "SKY SPORT 252": "SkySport252.it",
    "SKY SPORT 253": "SkySport253.it",
    "SKY SPORT 254": "SkySport254.it",
    "SKY SPORT 255": "SkySport255.it",
    "SKY SPORT 256": "SkySport256.it",
    "SKY SPORT 257": "SkySport257.it",
    "SKY SPORT 258": "SkySport258.it",
    "SKY SPORT 259": "SkySport259.it",
    "SKY SPORT 260": "SkySport260.it",
    "SKY SPORT 261": "SkySport261.it",
    "SKY SPORT 4K": "SkySport4K.it",
    "SKY SPORT ACTION": "SkySportAction.it",
    "SKY SPORT ARENA": "SkySportArena.it",
    "SKY SPORT CALCIO": "SkySportCalcio.it",
    "SKY SPORT F1": "SkySportF1.it",
    "SKY SPORT GOLF": "SkySportGolf.it",
    "SKY SPORT MAX": "SkySportMax.it",
    "SKY SPORT MOTO GP": "SkySportMotoGP.it",
    "SKY SPORT MOTOGP": "SkySportMotoGP.it",
    "SKY SPORT NBA": "SkySportNBA.it",
    "SKY SPORT TENNIS": "SkySportTennis.it",
    "SKY SPORT UNO": "SkySportUno.it",
    "SKY SPORT24": "SkySport24.it",
    "SKY TG24": "SkyTG24.it",
    "SKY UNO +1": "SkyUno+.it",
    "SKY UNO": "SkyUno.it",
    "SMTV SAN MARINO": "SanMarinoRTV.it",
    "SPORTITALIA 10": "Sportitalia10.it",
    "SPORTITALIA 11": "Sportitalia11.it",
    "SPORTITALIA 12": "Sportitalia12.it",
    "SPORTITALIA 2": "Sportitalia2.it",
    "SPORTITALIA 3": "Sportitalia3.it",
    "SPORTITALIA 4": "Sportitalia4.it",
    "SPORTITALIA 5": "Sportitalia5.it",
    "SPORTITALIA 6": "Sportitalia6.it",
    "SPORTITALIA 7": "Sportitalia7.it",
    "SPORTITALIA 8": "Sportitalia8.it",
    "SPORTITALIA 9": "Sportitalia9.it",
    "SPORTITALIA SOLOCALCIO": "SportitaliaSoloCalcio.it",
    "SPORTITALIA": "Sportitalia.it",
    "SQUASH": "Squash.it",
    "SUPER TENNIS HD": "SuperTennisHD.it",
    "SUPER TENNIS": "SuperTennis.it",
    "SUPER!": "Super!.it",
    "SUPERTENNIS HD": "SuperTennisHD.it",
    "SUPERTENNIS": "SuperTennis.it",
    "TELECAMPIONE": "Telecampione.it",
    "TELECAPRI": "TeleCapri.it",
    "TELENORBA": "TeleNorba.it",
    "TELEPACE": "Telepace.it",
    "TG NORBA24": "TGNORBA24.it",
    "TGCOM24": "TgCom24.it",
    "TOP CALCIO 24": "TopCalcio24.it",
    "TOP CRIME": "TOPcrime.it",
    "TRM H24": "TRMh24.it",
    "TV 8": "TV8.it",
    "TV2000": "TV2000.it",
    "TV8": "TV8.it",
    "TVRS": "TVRS.it",
    "TWENTYSEVEN": "Mediaset27Twentyseven.it",
}


def normalize_channel_name(raw_name):
    """
    Apply rename rules to convert a raw channel name to its canonical form.
    """
    from re import sub, IGNORECASE
    # First, strip any trailing quality markers and clean up
    name = raw_name.upper().strip()
    # Remove common suffixes like .c, .s, .b, HD, FHD, etc. name is
    # already uppercased above, so these need IGNORECASE to actually
    # match. .b is a real Vavoo source/quality tag alongside .c/.s (e.g.
    # "HOLLYWOOD HD .b") - omitting it here meant any .b-suffixed
    # channel name never matched an ALIAS_MAP entry at all, since this
    # is the only place that strips it before the ALIAS_MAP lookup.
    # 4K is deliberately NOT stripped here: unlike HD/FHD/SD/HEVC/H265
    # (pure quality tags that collapse onto the same base channel),
    # "RAI 4K" and "SKY SPORT 4K" are their own distinct channels with
    # dedicated ALIAS_MAP entries - stripping it would silently merge
    # them into the wrong (non-4K) channel.
    name = sub(r'\s*\.(c|s|b)$', '', name, flags=IGNORECASE)
    # Only strip the quality suffix if the name doesn't already match a
    # dedicated ALIAS_MAP entry that keeps it (e.g. "DMAX HD" ->
    # DMAXHD.it is a different Rytec id than "DMAX" -> DMAX.it, same as
    # the "SUPER TENNIS HD"/"HORSE TV HD"/etc. entries below) -
    # stripping unconditionally silently reassigned the HD channel's
    # EPG to its SD sibling and made these dedicated entries
    # unreachable. Same reasoning "4K" is already exempted from
    # stripping, just data-driven here instead of a blanket exemption.
    if name not in ALIAS_MAP:
        name = sub(r'\s*(HD|FHD|SD|HEVC|H265)$', '', name, flags=IGNORECASE)
    # Apply explicit rename rules. Exact match, not substring: several
    # patterns are single digits or short generic words ("8", "27",
    # "RAI", "SUPER") meant to disambiguate a channel literally named
    # just that - "in name" would also match e.g. "DAZN 8" or "RAI 1",
    # silently renaming them to the wrong channel's alias.
    for pattern, canonical in RENAME_RULES:
        if name == pattern:
            return canonical
    # Special handling for HISTORY channels
    if name.startswith(
            "HISTORY") and "CHANNEL" not in name and name != "HISTORY":
        return "HISTORY"
    # If no rule matched, return the cleaned name
    return name
