#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function

import codecs
import ssl
import time
import threading
from difflib import SequenceMatcher
from os import listdir, unlink, remove, system as os_system
from os.path import exists as file_exists, join, isfile, getsize
from json import loads
from sys import version_info
from enigma import eDVBDB
import xml.etree.ElementTree as ET
import datetime
from twisted.internet import reactor

try:
    import requests
except Exception:
    requests = None

try:
    from requests.adapters import HTTPAdapter
except Exception:
    HTTPAdapter = None

try:
    from urllib3.util.retry import Retry
except Exception:
    try:
        from requests.packages.urllib3.util.retry import Retry
    except Exception:
        Retry = None

try:
    from Components.AVSwitch import AVSwitch
except ImportError:
    from Components.AVSwitch import eAVControl as AVSwitch

from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from Components.Label import Label
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryPixmapAlphaTest, MultiContentEntryText
from Components.Pixmap import Pixmap
from Components.ProgressBar import ProgressBar
from Components.ServiceEventTracker import ServiceEventTracker, InfoBarBase
from Components.config import (
    ConfigSelection,
    getConfigListEntry,
    ConfigSelectionNumber,
    ConfigClock,
    ConfigText,
    configfile,
    config,
    ConfigYesNo,
    ConfigEnableDisable,
    ConfigSubsection,
    NoSave
)
from enigma import (
    RT_HALIGN_LEFT,
    RT_VALIGN_CENTER,
    eListboxPythonMultiContent,
    ePicLoad,
    eServiceReference,
    eTimer,
    gFont,
    getDesktop,
    iPlayableService,
    loadPNG,
)

from Screens.InfoBarGenerics import (
    InfoBarSubtitleSupport,
    InfoBarMenu,
    InfoBarSeek,
    InfoBarAudioSelection,
    InfoBarNotifications,
)
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Tools.Directories import SCOPE_PLUGINS, SCOPE_CONFIG, resolveFilename
from Tools.NumericalTextInput import NumericalTextInput
from Plugins.Plugin import PluginDescriptor

from .vavoo_stats import (
    record_anonymous_startup, is_stats_enabled, start_heartbeat,
    stop_heartbeat, STATS_DISABLE_FILE
)
from . import vavoo_proxy
from .vavoo_proxy import (
    run_proxy_in_background, restart_proxy_in_background, is_proxy_booting,
    GROUP_ID_PREFIX
)
from . import (
    _, __author__, __version__, __license__, export_lock, PORT,
    PLUGIN_ROOT, PROXY_HOST, PROXY_BASE_URL, PROXY_STATUS_URL,
    PROXY_COUNTRIES_URL, PROXY_REFRESH_URL, FLAG_CACHE_DIR,
    EPGIMPORT_CONF, LOG_FILE, GROUP_NAME_SEPARATORS
)
from . import PY2, PY3, vUtils
from .bouquet_manager import (
    convert_bouquet,
    _update_favorite_file,
    reorganize_all_bouquets_position,
    remove_bouquets_by_name,
    export_bouquet_async,
    is_bouquet_exported,
    remove_favorite_entry,
    get_local_ip
)
from .vUtils import (
    debug,
    make_print,
    update_epg_sources,
    ensure_vavoo_epg_sources_enabled,
    get_epg_matcher,
    get_proxy_status,
    cleanup_old_temp_files,
    check_remote_installer_version,
    decodeHtml,
    download_picon_online,
    ensure_str,
    fix_cache_format,
    getUrl,
    get_country_code,
    get_picon_cache_path,
    initialize_cache_with_local_flags,
    is_proxy_ready,
    is_proxy_running,
    is_remote_version_newer,
    returnIMDB,
    remove_parentheses,
    ReloadBouquets,
    strip_control_chars,
    trace_error
)
from .Console import Console
"""
#########################################################
#                                                       #
#  Vavoo Stream Live Plugin                             #
#  Created by Lululla (https://github.com/Belfagor2005) #
#  License: CC BY-NC-SA 4.0                             #
#  https://creativecommons.org/licenses/by-nc-sa/4.0    #
#  Last Modified: 202600503                              #
#                                                       #
#  Credits:                                             #
#  - Original concept by Lululla                        #
#  - Background images by @oktus                        #
#  - Additional contributions by Qu4k3                  #
#  - Linuxsat-support.com & Corvoboys communities       #
#                                                       #
#  Usage of this code without proper attribution        #
#  is strictly prohibited.                              #
#  For modifications and redistribution,                #
#  please maintain this credit header.                  #
#########################################################
"""

# Import notification system
try:
    from .notification_system import init_notification_system, quick_notify
    NOTIFICATION_AVAILABLE = True
except ImportError as e:
    debug("Notification system not available: {}".format(e))
    NOTIFICATION_AVAILABLE = False

    def quick_notify(*args, **kwargs):
        pass

print = make_print("PLUGIN")


try:
    # Python 3
    from urllib.parse import quote as _url_quote, unquote as _url_unquote
except ImportError:
    # Python 2
    from urllib import quote as _url_quote, unquote as _url_unquote

try:
    text_type = unicode
    binary_type = str
except NameError:
    text_type = str
    binary_type = bytes

if version_info >= (2, 7, 9):
    try:
        ssl_context = ssl._create_unverified_context()
    except BaseException:
        ssl_context = None


def to_text(value, encoding="utf-8", errors="ignore"):
    """Return a text string under both Python 2 and Python 3."""
    if value is None:
        return text_type()

    if isinstance(value, text_type):
        return value

    if isinstance(value, binary_type):
        try:
            return value.decode(encoding, errors)
        except Exception:
            return value.decode("latin-1", "ignore")

    try:
        converted = str(value)
    except Exception:
        try:
            return text_type(value)
        except Exception:
            return text_type()

    if isinstance(converted, text_type):
        return converted

    try:
        return converted.decode(encoding, errors)
    except Exception:
        return converted.decode("latin-1", "ignore")


def url_quote(value, safe='/'):
    """Quote URL fragments in a Python 2/3 safe way. `safe` is passed
    straight through to urllib's quote() (characters left as-is)."""
    if PY2:
        value = to_text(value).encode("utf-8")
    else:
        value = to_text(value)

    return _url_quote(value, safe)


def url_unquote(value):
    """Unquote URL fragments and normalize text in a Python 2/3 safe way."""
    if value is None:
        return text_type()

    if PY2 and isinstance(value, text_type):
        value = value.encode("utf-8")
    elif PY3 and isinstance(value, binary_type):
        value = value.decode("utf-8", "ignore")

    decoded = _url_unquote(value)

    if PY2 and isinstance(decoded, binary_type):
        try:
            return decoded.decode("utf-8")
        except Exception:
            return decoded.decode("latin-1", "ignore")

    return decoded


try:
    aspect_manager = vUtils.AspectManager()
    current_aspect = aspect_manager.get_current_aspect()
except BaseException as e:
    debug("AspectManager init failed: {}".format(e))

try:
    from Components.UsageConfig import defaultMoviePath
    downloadfree = defaultMoviePath()
except BaseException:
    downloadfree = ('/media/hdd/movie/')


def get_enigma2_path():
    barry_active = '/media/ba/active/etc/enigma2'
    if file_exists(barry_active):
        return barry_active.rstrip('/')

    possible_paths = [
        '/autofs/sda1/etc/enigma2',
        '/autofs/sda2/etc/enigma2',
        '/etc/enigma2'
    ]
    for path in possible_paths:
        if file_exists(path):
            return path.rstrip('/')
    return '/etc/enigma2'


def _is_vavoo_already_open(session):
    try:
        # dialog_stack entries are usually tuples like (dialog, ...)
        for entry in getattr(session, "dialog_stack", []):
            dlg = entry[0] if isinstance(
                entry, (list, tuple)) and entry else entry
            if dlg is None:
                continue
            name = dlg.__class__.__name__
            if name in ("startVavoo", "MainVavoo", "vavoo"):
                return True
    except Exception as e:
        debug("_is_vavoo_already_open check failed: {}".format(e))
    return False


# set plugin
global HALIGN, BackPath
global screen_width

title_plug = 'Vavoo'
desc_plugin = ('..:: Vavoo by Lululla & Qu4k3 v.%s ::..' % __version__)
PLUGIN_PATH = PLUGIN_ROOT
PLUGLOGO = join(PLUGIN_PATH, 'plugin.png')
ENIGMA_PATH = get_enigma2_path()
CONFIG_FILE = resolveFilename(SCOPE_CONFIG, "settings")

_session = None
# Guards autostart() itself against re-scheduling delayed_boot_tasks() on
# repeat calls - kept separate from _session, which delayed_boot_tasks()
# uses to detect whether the user has actually opened a plugin screen.
_autostart_scheduled = False
auto_start_timer = None

# Per-country parsed EPG document + channel->programme index, shared
# across Playstream2 instances (module-level, not per-instance) so
# switching channels or reopening the player doesn't re-fetch/re-parse/
# re-index the same country's EPG document within the TTL window - see
# Playstream2.get_current_epg().
# country_code -> (timestamp, root, channel_index, display_name_index)
_epg_xml_cache = {}
_epg_result_cache = {}   # "epg_<name>_<country>" -> (timestamp, result_str)

# Safety-net caps: entries here are only ever added, never removed on
# their own (the 5-minute figure elsewhere is a reuse TTL, not an
# eviction one) - unlike vUtils.py's persistent EPG matcher cache (which
# already has its own size cap), these two are plain in-memory dicts
# that grow for the life of the process, one entry per unique
# channel+country (_epg_result_cache) or country (_epg_xml_cache) ever
# viewed. _epg_xml_cache is naturally small (bounded by distinct
# countries actually browsed), but capped too for consistency/safety.
_EPG_RESULT_CACHE_MAX = 500
_EPG_XML_CACHE_MAX = 50


def _cache_epg_result(cache_key, result):
    _epg_result_cache[cache_key] = (time.time(), result)
    if len(_epg_result_cache) > _EPG_RESULT_CACHE_MAX:
        oldest = sorted(
            _epg_result_cache, key=lambda k: _epg_result_cache[k][0]
        )[:len(_epg_result_cache) - _EPG_RESULT_CACHE_MAX]
        # pop(k, None), not del: this runs unlocked from whichever
        # per-channel EPG-fetch daemon thread last called
        # get_current_epg() (see Playstream2), so two threads can race
        # into eviction at once - the second one's `oldest` snapshot may
        # include a key the first already removed. del would raise
        # KeyError there; pop is a no-op instead.
        for k in oldest:
            _epg_result_cache.pop(k, None)


def _cache_epg_xml(country_code, root, channel_index, display_name_index):
    _epg_xml_cache[country_code] = (
        time.time(), root, channel_index, display_name_index)
    if len(_epg_xml_cache) > _EPG_XML_CACHE_MAX:
        oldest = sorted(
            _epg_xml_cache, key=lambda k: _epg_xml_cache[k][0]
        )[:len(_epg_xml_cache) - _EPG_XML_CACHE_MAX]
        for k in oldest:
            _epg_xml_cache.pop(k, None)


# Auto-update check state, shared between startVavoo (kicks off the
# background check) and MainVavoo (shows the popup once, after the main
# menu is open). See _start_update_check() /
# MainVavoo._check_update_popup_tick().
_update_check_started = False
_update_check_done = False
_update_check_result = None
_update_popup_shown = False


def _start_update_check():
    """Check installer.sh on GitHub for a newer plugin version, in the
    background, every time the plugin is launched (i.e. every time the
    splash screen runs, not just once per Enigma2 GUI process).

    Called from startVavoo so the check overlaps with the splash screen
    instead of adding to perceived load time. The result is only surfaced
    as a popup once MainVavoo (the main menu) is actually open - see
    MainVavoo._check_update_popup_tick(). Resets the shared state on
    every call so a closed-and-reopened plugin gets a fresh check and
    can show the popup again, instead of only ever on the first launch.
    """
    global _update_check_started, _update_check_done, _update_check_result, _update_popup_shown
    _update_check_started = True
    _update_check_done = False
    _update_check_result = None
    _update_popup_shown = False
    print("[Update] Starting background version check (local v{})".format(__version__))

    def _worker():
        global _update_check_result, _update_check_done
        _update_check_result = check_remote_installer_version()
        version, changelog, content = _update_check_result
        print("[Update] Check finished: remote_version={} changelog_len={} content_len={}".format(
            version, len(changelog) if changelog else 0, len(content) if content else 0))
        _update_check_done = True

    _update_thread = threading.Thread(target=_worker)
    _update_thread.daemon = True
    _update_thread.start()


# screen
HALIGN = RT_HALIGN_LEFT
screen_real = getDesktop(0).size()
screen_width = screen_real.width()
BackfPath = join(PLUGIN_PATH, "skin")


if screen_width == 2560:
    OVERLAY_WIDTH = 2560
    OVERLAY_HEIGHT_TOP = 70
    OVERLAY_HEIGHT_EPG = 300
    FONT_SIZE_TOP = 42
    FONT_SIZE_EPG = 36
    OVERLAY_Y_EPG = 80
    BackPath = join(BackfPath, 'images_new')
    skin_path = join(BackfPath, 'wqhd')
elif screen_width >= 1920:
    OVERLAY_WIDTH = 1920
    OVERLAY_HEIGHT_TOP = 60
    OVERLAY_HEIGHT_EPG = 250
    FONT_SIZE_TOP = 36
    FONT_SIZE_EPG = 32
    OVERLAY_Y_EPG = 70
    BackPath = join(BackfPath, 'images_new')
    skin_path = join(BackfPath, 'fhd')
else:
    OVERLAY_WIDTH = 1280
    OVERLAY_HEIGHT_TOP = 50
    OVERLAY_HEIGHT_EPG = 150
    FONT_SIZE_TOP = 28
    FONT_SIZE_EPG = 24
    OVERLAY_Y_EPG = 55
    BackPath = join(BackfPath, 'images')
    skin_path = join(BackfPath, 'hd')

# Box for the current channel's picon, bottom-left of the screen -
# over the stock MoviePlayer skin's own "cover" placeholder icon in
# that corner (self.skinName = 'MoviePlayer' reuses the box's own
# built-in skin section for that seek-bar/title strip, not one this
# plugin defines, so the placeholder itself can't be removed - this
# widget just draws on top of it at a higher zPosition). Width keeps
# the 3:2 aspect ratio used everywhere else in this plugin for icon
# boxes, sized up from a plain OVERLAY_HEIGHT_TOP-based box (too
# small next to the stock icon) to stand out as the main icon there.
OVERLAY_PICON_H = int(OVERLAY_HEIGHT_TOP * 1.8)
OVERLAY_PICON_W = int(OVERLAY_PICON_H * 1.5)
SCREEN_HEIGHT = screen_real.height()
OVERLAY_PICON_X = 10
# Position is a best-effort estimate (proportional to the real screen
# height so it scales across resolutions), calibrated from an
# on-screen photo: the first attempt (plain SCREEN_HEIGHT * 0.78, no
# extra offset) rendered about one icon-height too high - visibly
# stacked above the stock placeholder icon instead of over it -
# shifted down by that same amount (OVERLAY_HEIGHT_TOP, the old,
# smaller icon's own height) to compensate. Still an estimate, not a
# measurement - nudge it further if it's still not aligned.
OVERLAY_PICON_Y = int(SCREEN_HEIGHT * 0.78) + OVERLAY_HEIGHT_TOP

print('folder back: ', BackPath)


modemovie = [("4097", "4097")]
if file_exists("/usr/bin/gstplayer"):
    modemovie.append(("5001", "5001"))
if file_exists("/usr/bin/exteplayer3"):
    modemovie.append(("5002", "5002"))
if file_exists('/var/lib/dpkg/info'):
    modemovie.append(("8193", "8193"))


BakP = []
try:
    if file_exists(BackPath):
        for back_name in listdir(BackPath):
            back_name_path = join(BackPath, back_name)
            if back_name.endswith(".png"):
                if back_name.startswith("default"):
                    continue
                back_name = back_name[:-4]
                BakP.append((back_name, back_name))
except Exception as e:
    print(e)

print('final folder back: ', BackPath)


# Helper function for string conversion
def to_string(text):
    """Convert any input to proper string format for Enigma2 widgets"""
    if text is None:
        return ""

    # If it's already a unicode string (Python 2) or str (Python 3)
    if isinstance(text, text_type):
        return text.encode('utf-8', 'ignore') if PY2 else text

    # If it's bytes/binary
    if isinstance(text, binary_type):
        return text.decode('utf-8', 'ignore') if PY3 else text

    # For other types, convert to string
    return str(text)


# config section
class ConfigAction(ConfigSelection):
    """A config-list entry with a single, fixed choice, so left/right
    can't cycle it - used purely as a "press OK to trigger an action"
    row (gnm3u()'s dispatch below only checks which row is
    highlighted, never this value) instead of a Yes/No toggle that
    looks like a real setting but never actually gates anything.

    The choice's description is a plain, non-empty "OK" rather than an
    empty string - an earlier version used choices=[""] specifically
    to show a blank value column, but an empty-text list cell can fail
    to fully repaint over whatever the previous row (or a prior state
    of this one) had drawn there, visibly leaving old text showing
    through on real hardware. A short, fixed, always-the-same-length
    label repaints cleanly and still doesn't look like an actual
    setting."""

    def __init__(self):
        ConfigSelection.__init__(self, choices=[("ok", _("OK"))])


config.plugins.vavoo = ConfigSubsection()
cfg = config.plugins.vavoo
cfg.autobouquetupdate = ConfigEnableDisable(default=False)
cfg.genm3u = NoSave(ConfigAction())
cfg.show_log = NoSave(ConfigAction())
cfg.view_favourites = NoSave(ConfigAction())
# Which catalog/stream source vavoo_proxy.py's initialize_proxy()
# tries - "auto" keeps its default Geil-first/Vavoo-fallback
# order; "geil"/"vavoo" pin it to exactly one source, with no
# fallback to the other if it fails (an explicit choice is respected
# as-is). Read directly by vavoo_proxy.py via its own e2_config
# import, not this cfg reference (that would be a circular import).
cfg.catalog_source = ConfigSelection(
    default="auto",
    choices=[
        ("auto", _("Auto (Geil, fallback Vavoo)")),
        ("geil", _("Geil only")),
        ("vavoo", _("Vavoo/Kool only")),
    ])
cfg.services = ConfigSelection(default='4097', choices=modemovie)
cfg.epg_enabled = ConfigEnableDisable(default=False)
cfg.timetype = ConfigSelection(
    default="interval", choices=[
        ("interval", _("interval")), ("fixed time", _("fixed time"))])
cfg.updateinterval = ConfigSelectionNumber(
    default=360, min=5, max=3600, stepwidth=5)
cfg.fixedtime = ConfigClock(default=46800)
cfg.last_update = ConfigText(default="Never")
cfg.stmain = ConfigYesNo(default=True)
cfg.stats_enabled = ConfigYesNo(default=True)
cfg.debug_logging = ConfigYesNo(default=False)
cfg.debug_logging.addNotifier(
    lambda cfgelement: vUtils.set_debug_enabled(cfgelement.value),
    initial_call=True
)
# cfg.ipv6 = ConfigEnableDisable(default=False)
cfg.back = ConfigSelection(default='oktus', choices=BakP)
cfg.list_position = ConfigSelection(
    default="bottom",
    choices=[("bottom", _("Bottom")), ("top", _("Top"))]
)
cfg.playlist_key = ConfigText(default="")
cfg.parental_pin = ConfigText(default="")
cfg.parental_countries = ConfigText(default="")
cfg.proxy_startup_timeout = ConfigSelectionNumber(
    default=120, min=15, max=300, stepwidth=5)

# MainVavoo's proxy_monitor_timer/proxy_watchdog_timer are created and
# restarted from three different places (initial open, returning from
# config, returning from Playstream2) - use one shared constant per
# timer everywhere instead of separate literals, which had drifted out
# of sync with each other (and with their own "every N seconds"
# comments) at two of those six call sites.
PROXY_MONITOR_INTERVAL_MS = 10000
PROXY_WATCHDOG_INTERVAL_MS = 60000

# How many times vavoo.cat() asks the proxy for a country's channel
# list before reporting failure - see its own docstring.
CHANNEL_FETCH_ATTEMPTS = 3


def normalize_language_code(language):
    """Normalize Enigma2 language identifiers to a comparable short code."""
    if not language:
        return "en"

    language = to_text(language).strip().lower()
    if "_" in language:
        language = language.split("_", 1)[0]
    elif "-" in language:
        language = language.split("-", 1)[0]

    return language or "en"


try:
    from Components.config import config
    lng = normalize_language_code(config.osd.language.value)
except BaseException:
    lng = 'en'
    pass


# menulist
class m2list(MenuList):
    def __init__(self, items):
        super(m2list, self).__init__(items, False, eListboxPythonMultiContent)
        if screen_width == 2560:
            item_height = 60
            text_font_size = 38
        elif screen_width == 1920:
            item_height = 50
            text_font_size = 34
        else:
            item_height = 50
            text_font_size = 22
        self.l.setItemHeight(item_height)
        self.l.setFont(0, gFont('Regular', text_font_size))

    def buildEntry(self, entry):
        """Build list entry - entry should be [ (name, link), icon, text ]"""
        return entry


def show_list(name, link, is_category=False, is_channel=False, logo_url=None):
    """Build a MultiContent entry with icon and text."""

    safe_name = to_string(name)
    safe_link = to_string(link)

    res = [(safe_name, safe_link)]

    # Default icon
    default_icon = join(PLUGIN_PATH, 'skin/pics/vavoo_ico.png')
    icon_path = default_icon

    using_channel_picon = False
    if is_channel and logo_url:
        # Same convention as the flag icon below: only ever read the
        # cache here, never download synchronously inside this
        # function (called once per row while building a possibly
        # large list) - a channel's picon shows up once
        # _preload_channel_picons() has actually fetched it and
        # rebuilt the list, same lag the flag icons already have for
        # countries.
        try:
            cache_file = get_picon_cache_path(logo_url)
            if cache_file and file_exists(cache_file):
                if getsize(cache_file) > 100:
                    icon_path = cache_file
                    using_channel_picon = True
                else:
                    unlink(cache_file)
        except Exception as e:
            debug("Picon cache check failed for {}: {}".format(
                logo_url, e))

    if not is_channel and not is_category:
        country_name = safe_name.split('➾')[0].split(
            '⟾')[0].split('→')[0].split('->')[0].strip()
        if country_name:
            try:
                country_code = get_country_code(country_name)
                if country_code:
                    cache_file = "%s/%s.png" % (FLAG_CACHE_DIR,
                                                country_code.lower())

                    # Use cache if exists and valid
                    if file_exists(cache_file):
                        try:
                            if getsize(cache_file) > 100:
                                icon_path = cache_file
                            else:
                                unlink(cache_file)
                        except Exception as e:
                            debug("Flag cache check failed for {}: {}".format(
                                cache_file, e))

                    # If not in cache, use default icon (don't download here - use preloading)
                    # Download will happen in
                    # preload_flags_for_visible_countries()

            except Exception as e:
                debug("Flag icon resolution failed for {}: {}".format(
                    country_name, e))

    # icon_size used to be a flat (60, 40) at every resolution tier,
    # regardless of each tier's own item_height (m2list.__init__) -
    # 80% of the row height on the fhd/hd tiers, 66.7% on wqhd, and
    # visually dominant enough that channel/flag icons looked like the
    # main content instead of a small marker next to the name. A
    # follow-up pass pushed this down further to ~40% of item_height,
    # which went too far the other way: at that size even the plain
    # default icon (not just a detailed channel logo) rendered as an
    # indistinct blob, confirmed from an on-screen photo - a real
    # channel logo (unlike the bundled flags, simple bold national
    # flag art that stays legible even very small) needs more pixels
    # than that to read as anything at all. Settled at ~60% of
    # item_height instead - the one size in this box's history that
    # hasn't actually been shown broken - keeping the same 3:2 aspect
    # ratio the bundled flag PNGs (skin/cowntry/*.png, all exactly
    # 60x40) are already hand-cropped to, so they keep scaling
    # uniformly with zero distortion, and vertically centered in the
    # row ((item_height - icon_height) // 2) rather than the old
    # fixed y-offsets, which were tuned for the original, taller box.
    if screen_width >= 2560:
        icon_size = (54, 36)
        icon_pos = (10, 12)
        text_size = (750, 60)
        text_pos = (icon_size[0] + 20, 0)
    elif screen_width >= 1920:
        icon_size = (45, 30)
        icon_pos = (10, 10)
        text_size = (540, 50)
        text_pos = (icon_size[0] + 20, 0)
    else:
        icon_size = (45, 30)
        icon_pos = (10, 10)
        text_size = (380, 50)
        text_pos = (icon_size[0] + 20, 0)

    # Load the icon pixmap, already sized correctly for icon_size.
    #
    # Channel picons are cached at whatever native resolution the
    # third-party catalog serves them - unlike the default icon and
    # the bundled flags (both pre-sized to match icon_size exactly),
    # MultiContentEntryPixmapAlphaTest does NOT scale a mismatched
    # source to fit its size= box - it blits the image at its own
    # native resolution, clipped to that box. A same-size-or-larger
    # picon therefore only ever showed a small corner fragment of
    # itself (confirmed from an on-screen photo: mostly blank, with a
    # sliver of the real logo in one corner) - the earlier fix here
    # that computed a smaller pos/size never actually fixed anything,
    # since nothing was scaling the pixel data to match it either way.
    # ePicLoad actually resamples the source to the target size
    # (letterboxed, aspect-preserving - see setPara()'s own comment
    # below) before handing back a pixmap that's already the right
    # size - the same mechanism this file's own splash screen
    # (startVavoo.decodeImage()) and the playback overlay
    # (_update_overlay_picon()) already use for exactly this reason.
    png_data = None
    if using_channel_picon:
        try:
            picload = ePicLoad()
            av_scale = AVSwitch().getFramebufferScale()
            # Same setPara()/startDecode() shape as
            # startVavoo.decodeImage()/_update_overlay_picon() -
            # resize_mode=1 scales to fit while preserving aspect
            # ratio, padded with the given transparent background,
            # rather than mode=0 (plain stretch).
            picload.setPara([
                icon_size[0], icon_size[1],
                av_scale[0], av_scale[1], 0, 1, '#00000000'])
            if isfile("/var/lib/dpkg/status"):
                picload.startDecode(icon_path, False)
            else:
                picload.startDecode(icon_path, 0, 0, False)
            png_data = picload.getData()
        except Exception as e:
            debug("Picon decode failed for {}: {}".format(icon_path, e))
            png_data = None

    if not png_data:
        # Either not a channel picon (default icon / country flag,
        # both already pre-sized to exactly icon_size - no scaling
        # needed) or the decode above failed - either way, fall back
        # to a plain, un-scaled load of whichever asset is safe to
        # load natively at this size (never the oversized picon file
        # itself, which would reintroduce the clipping problem above).
        fallback_path = default_icon if using_channel_picon else icon_path
        try:
            png_data = loadPNG(fallback_path)
        except Exception:
            try:
                png_data = loadPNG(default_icon)
            except Exception:
                png_data = None

    if png_data:
        res.append(MultiContentEntryPixmapAlphaTest(
            pos=icon_pos,
            size=icon_size,
            png=png_data
        ))

    res.append(MultiContentEntryText(
        pos=text_pos,
        size=text_size,
        font=0,
        text=safe_name,
        flags=HALIGN | RT_VALIGN_CENTER
    ))

    return list(res)


class vavoo_config(Screen, ConfigListScreen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        skin = join(skin_path, 'vavoo_config.xml')
        if isfile('/var/lib/dpkg/status'):
            skin = skin.replace('.xml', '_cvs.xml')
        with codecs.open(skin, "r", encoding="utf-8") as f:
            self.skin = apply_selected_background(f.read())
        self.setup_title = ('Vavoo Config')

        self.old_back = cfg.back.value
        self.old_list_position = cfg.list_position.value
        self.old_catalog_source = cfg.catalog_source.value

        # So background M3U-fetch threads (_fetch_countries_async/
        # _fetch_channels_async) can notice this screen was left and
        # stop trying to pop dialogs on top of whatever the user has
        # since navigated to.
        self._closed = False
        self.onClose.append(self._mark_closed)

        self.list = []
        self.onChangedEntry = []
        self["version"] = Label()
        self['statusbar'] = Label()
        self["description"] = Label("")
        self["red"] = Label(_("Back"))
        self["green"] = Label(_("- - - -"))
        self['actions'] = ActionMap(['OkCancelActions', 'ColorActions', 'DirectionActions'], {
            "cancel": self.extnok,
            "left": self.keyLeft,
            "right": self.keyRight,
            "up": self.keyUp,
            "down": self.keyDown,
            "red": self.extnok,
            "green": self.save,
            "ok": self.gnm3u,
        }, -1)
        self.update_status()
        ConfigListScreen.__init__(
            self,
            self.list,
            session=self.session,
            on_change=self.changedEntry)
        self.createSetup()
        self.showhide()
        self.onLayoutFinish.append(self.layoutFinished)

    def _mark_closed(self):
        self._closed = True

    def update_status(self):
        if cfg.autobouquetupdate.value:
            self['statusbar'].setText(
                _("Last channel update: %s") %
                cfg.last_update.value)

    def layoutFinished(self):
        self.setTitle(self.setup_title)
        self['version'].setText('V.' + __version__)

    def createSetup(self):
        self.editListEntry = None
        self.list = []
        indent = "- "
        self.list.append(
            getConfigListEntry(
                _("Generate .m3u files (Ok for Exec)"),
                cfg.genm3u,
                _("Generate .m3u files and save to device %s.") %
                downloadfree))

        self.list.append(getConfigListEntry(
            _("Playlist Access Key (optional)"),
            cfg.playlist_key,
            _("If set, the live playlist at /playlist.m3u requires "
              "?key=<this value> - leave empty for no key. "
              "URL: http://%s:%d/playlist.m3u") % (PROXY_HOST, PORT)))

        self.list.append(
            getConfigListEntry(
                _("Catalog/Stream Source"),
                cfg.catalog_source,
                _("Which service to load channels and streams from. "
                  "Auto tries Geil first and falls back to Vavoo "
                  "if it's unavailable; the other two options pin it "
                  "to exactly that one source. Takes effect on save "
                  "(restarts the proxy if it's running).")
            )
        )

        self.list.append(getConfigListEntry(
            _("Proxy startup timeout (seconds)"),
            cfg.proxy_startup_timeout,
            _("Increase if proxy takes long due to VPN or slow connection.")))

        self.list.append(getConfigListEntry(
            _("Enable Vavoo EPG"),
            cfg.epg_enabled,
            _("Create the EPG source for EPGImport with Vavoo program data "
              "and enable it there after each export.")
        ))

        # Grouped with "Enable Vavoo EPG" above rather than left down by
        # the other bouquet-related entries below: this schedule drives
        # EPG refresh timing too, not just bouquet regeneration -
        # AutoStartTimer._update_bouquets() does Rytec matching, EPG
        # feed downloads, and bouquet file I/O as one combined cycle.
        self.list.append(
            getConfigListEntry(
                _("Scheduled EPG/Bouquet Update:"),
                cfg.autobouquetupdate,
                _("Periodically re-match EPG and refresh bouquets for your "
                  "favorited countries in the background.")))
        if cfg.autobouquetupdate.value is True:
            try:
                self.list.append(
                    getConfigListEntry(
                        indent + _("Schedule type:"),
                        cfg.timetype,
                        _("At an interval hours or fixed time")))
            except Exception as e:
                print("Error building 'Schedule type' config entry:", e)
            # Each sub-entry is wrapped independently: getConfigListEntry()
            # touches Enigma2 core config widgets (ConfigSelectionNumber/
            # ConfigClock) outside this repo, whose behavior can differ by
            # image/build (same class of issue as this session's wraparound-
            # navigation fix). createSetup() has no exception handling
            # anywhere else, and self["config"].l.setList(self.list) only
            # runs once at the very end - previously, a single entry
            # raising here silently aborted the ENTIRE rebuild, freezing
            # the screen on whatever it showed before with no visible
            # error, which is exactly what made "Update interval" (and
            # everything listed after it) appear to have vanished for one
            # user while working fine for another on a different image.
            if cfg.timetype.value == "interval":
                try:
                    self.list.append(
                        getConfigListEntry(
                            2 * indent + _("EPG/Bouquet update interval (minutes):"),
                            cfg.updateinterval,
                            _("How often to re-match EPG and refresh "
                              "bouquets, counting from now.")))
                except Exception as e:
                    print("Error building 'Update interval' config entry:", e)
            if cfg.timetype.value == "fixed time":
                try:
                    self.list.append(
                        getConfigListEntry(
                            2 *
                            indent +
                            _("Time to start EPG/bouquet update:"),
                            cfg.fixedtime,
                            _("Configure at a fixed time")))
                except Exception as e:
                    print(
                        "Error building 'Time to start update' config entry:", e)

        self.list.append(
            getConfigListEntry(
                _("Movie Services Reference"),
                cfg.services,
                _("Configure service Reference Iptv-Gstreamer-Exteplayer3")))

        self.list.append(
            getConfigListEntry(
                _("Bouquet Position in List"),
                cfg.list_position,
                _("Position of Vavoo bouquets in the main list"))
        )

        self.list.append(
            getConfigListEntry(
                _("Select Background"),
                cfg.back,
                _("Configure Main Background Image.")))

        self.list.append(
            getConfigListEntry(
                _('Link in Main Menu'),
                cfg.stmain,
                _("Link in Main Menu")))
        self.list.append(getConfigListEntry(_("Send Anonymous Statistics"), cfg.stats_enabled, _(
            "Anonymous startup/heartbeat ping only (session id, version, timestamp - no personal data). Disable to opt out.")))
        self.list.append(getConfigListEntry(_("Debug logging"), cfg.debug_logging, _(
            "Show verbose DEBUG-level messages in vavoo.log (UI lifecycle, per-request detail). Takes effect immediately - leave off unless troubleshooting.")))
        self.list.append(getConfigListEntry(
            _("Show Log (Ok to view)"),
            cfg.show_log,
            _("View the last 200 lines of %s.") % LOG_FILE))
        self.list.append(getConfigListEntry(
            _("View Favourites (Ok to open)"),
            cfg.view_favourites,
            _("Browse and play your starred channels. Star/unstar a "
              "channel with the INFO key while browsing.")))
        self.list.append(getConfigListEntry(
            _("Parental Control PIN"),
            cfg.parental_pin,
            _("Set a PIN to lock the countries below. Leave empty to "
              "disable parental control entirely.")))
        if cfg.parental_pin.value.strip():
            self.list.append(getConfigListEntry(
                _("Locked Countries"),
                cfg.parental_countries,
                _("Comma-separated country names (e.g. \"Italy, Spain\") "
                  "that require the PIN above to open.")))
        self["config"].list = self.list
        self["config"].l.setList(self.list)
        self.setInfo()

    def gnm3u(self):
        sel = self["config"].getCurrent()[1]
        if sel and sel == cfg.genm3u:
            self.session.openWithCallback(
                self.generate_m3u,
                MessageBox,
                _("Generate .m3u files and save to device %s?") %
                downloadfree,
                MessageBox.TYPE_YESNO,
                timeout=10,
                default=True)
        elif sel and sel == cfg.show_log:
            self.session.open(
                VavooLogViewer,
                title=_("Vavoo Log"),
                file_path=LOG_FILE,
                tail_lines=200)
        elif sel and sel == cfg.view_favourites:
            self.session.open(VavooFavourites)
        elif sel and sel in (
                cfg.playlist_key, cfg.parental_pin, cfg.parental_countries):
            # Plain ConfigText entries have nothing else wired to the
            # "ok" key in this screen (gnm3u() is its sole handler) -
            # without this, pressing OK on these did nothing and the
            # field could never actually be set.
            self.session.openWithCallback(
                lambda result: self._on_text_entry_result(sel, result),
                VirtualKeyBoard,
                title=self.getCurrentEntry(),
                text=sel.value)

    def _on_text_entry_result(self, config_element, result):
        if result is not None:
            config_element.setValue(result)
            config_element.save()
            self.createSetup()

    def generate_m3u(self, result):
        if result:
            # 1. Check if the proxy is active (non-blocking - proceeds to
            # step 2 via callback once ready, instead of freezing the GUI
            # thread while polling)
            self.check_and_start_proxy_async(
                self.show_m3u_ip_selection,
                self._m3u_proxy_unavailable)

    def _m3u_proxy_unavailable(self):
        self.session.open(
            MessageBox,
            _("Proxy not active. Unable to generate M3U file."),
            MessageBox.TYPE_ERROR,
            timeout=5
        )

    def show_m3u_ip_selection(self):
        """Ask whether the M3U links should use 127.0.0.1 (playable only
        on this box) or the box's LAN IP (playable from other devices on
        the network)."""
        from Screens.ChoiceBox import ChoiceBox

        network_ip = get_local_ip()

        choices = [
            (_("Local only (127.0.0.1) - this device only"),
             PROXY_HOST),
            (_("Network (%s) - other devices on the LAN") %
             network_ip,
             network_ip),
        ]

        self.session.openWithCallback(
            self.on_m3u_ip_selected,
            ChoiceBox,
            title=_("Select the IP address to use in the M3U links:"),
            list=choices
        )

    def on_m3u_ip_selected(self, result):
        """Callback for M3U host selection"""
        if result is None:
            return

        self._m3u_host = result[1]

        # 3. Get country list from proxy - in a background thread and
        # continue in a callback: get_countries_from_proxy()'s getUrl()
        # call can block for tens of seconds on a slow/unresponsive
        # proxy, and this method runs directly on Enigma2's single GUI
        # thread as a ChoiceBox callback - calling it here synchronously
        # would freeze the whole box for that long.
        self._fetch_countries_async(self._on_countries_for_mode_choice)

    def _on_countries_for_mode_choice(self, countries):
        try:
            if not countries:
                raise Exception("No countries available")

            # 4. ASK MODE: single country or all?
            from Screens.ChoiceBox import ChoiceBox

            choices = [
                (_("All countries (%d)") % len(countries), "all"),
                (_("Only one specific country"), "single"),
                (_("Cancel"), "cancel")
            ]

            self.session.openWithCallback(
                self.on_m3u_mode_selected,
                ChoiceBox,
                title=_("Select M3U export mode:"),
                list=choices
            )

        except Exception as e:
            print("[M3U Export] Error: %s" % str(e))
            self.session.open(
                MessageBox,
                _("Error: %s") % str(e),
                MessageBox.TYPE_ERROR,
                timeout=5
            )

    def on_m3u_mode_selected(self, result):
        """Callback for M3U mode selection"""
        if result is None or result[1] == "cancel":
            return

        mode = result[1]
        self._fetch_countries_async(
            lambda countries: self._on_countries_for_mode(mode, countries))

    def _on_countries_for_mode(self, mode, countries):
        try:
            if not countries:
                raise Exception("No countries available")

            if mode == "all":
                # Generate for all countries
                self.session.openWithCallback(
                    lambda confirm: self.generate_all_m3u_files(
                        confirm,
                        countries),
                    MessageBox,
                    _("Generate .m3u files for ALL %d countries?") %
                    len(countries),
                    MessageBox.TYPE_YESNO)
            elif mode == "single":
                # Show country list for single selection
                self.show_country_selection(countries)

        except Exception as e:
            print("[M3U Export] Error in mode selection: %s" % str(e))
            self.session.open(
                MessageBox,
                _("Error: %s") % str(e),
                MessageBox.TYPE_ERROR,
                timeout=5
            )

    def show_country_selection(self, countries):
        """Show country list for single selection"""
        from Screens.ChoiceBox import ChoiceBox

        # Create choice list
        choices = []
        for country in sorted(countries):
            choices.append((country, country))

        choices.append((_("Cancel"), "cancel"))

        self.session.openWithCallback(
            self.on_country_selected,
            ChoiceBox,
            title=_("Select country to export M3U:"),
            list=choices
        )

    def on_country_selected(self, result):
        """Callback for selected country"""
        if result is None or result[1] == "cancel":
            return

        selected_country = result[1]

        # Get channels for the selected country - in a background
        # thread, same reasoning as _fetch_countries_async().
        self._fetch_channels_async(
            selected_country,
            lambda channels: self._on_channels_for_country(
                selected_country, channels))

    def _on_channels_for_country(self, selected_country, channels):
        if not channels or len(channels) == 0:
            self.session.open(
                MessageBox,
                _("No channels found for: %s") % selected_country,
                MessageBox.TYPE_WARNING,
                timeout=5
            )
            return

        # Ask confirmation for single country
        part1 = _("Generate .m3u file for:")
        part2 = str(selected_country)
        part3 = _("(%d channels)?") % len(channels)
        message = part1 + "\n" + part2 + "\n" + part3
        self.session.openWithCallback(
            lambda confirm: self.generate_single_country_m3u(
                confirm,
                selected_country,
                channels),
            MessageBox,
            message,
            MessageBox.TYPE_YESNO)

    def generate_single_country_m3u(self, confirm, country_name, channels):
        """Generate M3U for a single country"""
        if not confirm:
            return

        try:
            # Generate .m3u file
            m3u_count = self.generate_single_m3u(country_name, channels)

            if m3u_count > 0:
                msg_parts = []
                msg_parts.append(_("M3U file generated successfully!"))
                msg_parts.append("")
                msg_parts.append(_("Country: %s") % country_name)
                msg_parts.append(_("Channels: %d") % m3u_count)
                msg_parts.append(_("Saved in: %s") % downloadfree)
                msg = "\n".join(msg_parts)
                self.session.open(
                    MessageBox,
                    msg,
                    MessageBox.TYPE_INFO,
                    timeout=5
                )
            else:
                self.session.open(
                    MessageBox,
                    _("No valid channels for: %s") % country_name,
                    MessageBox.TYPE_WARNING,
                    timeout=5
                )

        except Exception as e:
            print("[M3U Export] Error for %s: %s" % (country_name, str(e)))
            self.session.open(
                MessageBox,
                _("M3U generation error: %s") % str(e),
                MessageBox.TYPE_ERROR,
                timeout=5
            )

    def generate_all_m3u_files(self, confirm, countries):
        """Generate .m3u files for all countries - the actual work runs
        on a background thread. This is invoked directly as a MessageBox
        confirmation callback, which Enigma2 runs synchronously on the
        GUI thread; looping get_channels_for_country() (a blocking
        getUrl(timeout=15) call) once per country here would freeze the
        whole box for up to countries*15 seconds, exactly what every
        other channel-fetch path in this wizard already avoids via
        _fetch_countries_async()/_fetch_channels_async()."""
        if not confirm:
            return

        def task():
            total_channels = 0
            generated = 0
            failed = 0

            for country in countries:
                try:
                    # Get channels for this country
                    channels = self.get_channels_for_country(country)
                    if not channels:
                        failed += 1
                        continue

                    # Generate .m3u file
                    m3u_count = self.generate_single_m3u(country, channels)

                    if m3u_count > 0:
                        total_channels += m3u_count
                        generated += 1
                        print(
                            "[M3U Export] OK %s: %d channels" %
                            (country, m3u_count))
                    else:
                        failed += 1
                        print("[M3U Export] FAIL %s: no channels" % country)

                except Exception as e:
                    failed += 1
                    print("[M3U Export] Error %s: %s" % (country, str(e)))

            reactor.callFromThread(
                self._on_all_m3u_files_done,
                generated, failed, total_channels, len(countries))

        t = threading.Thread(target=task)
        t.daemon = True
        t.start()

    def _on_all_m3u_files_done(
            self, generated, failed, total_channels, total_countries):
        """Runs back on the GUI thread once generate_all_m3u_files()'s
        background loop finishes."""
        if getattr(self, "_closed", False):
            return

        try:
            # Show detailed result
            msg = _("M3U generation completed!")
            msg += "\n"
            msg += _("Countries: %(generated)d/%(total)d") % {
                'generated': generated, 'total': total_countries}
            msg += "\n"
            msg += _("Failed: %(failed)d") % {'failed': failed}
            msg += "\n"
            msg += _("Total channels: %(total_channels)d") % {
                'total_channels': total_channels}
            msg += "\n"
            msg += _("Saved in: %(path)s") % {'path': downloadfree}

            self.session.open(
                MessageBox,
                msg,
                MessageBox.TYPE_INFO,
                timeout=7
            )

        except Exception as e:
            print("[M3U Export] General error: %s" % str(e))
            self.session.open(
                MessageBox,
                _("M3U generation error: %s") % str(e),
                MessageBox.TYPE_ERROR,
                timeout=5
            )

    def generate_single_m3u(self, country_name, channels):
        """Generate a single .m3u file for a country"""
        try:
            # Sanitize filename
            safe_name = country_name.lower()
            safe_name = safe_name.replace(' ', '_')
            safe_name = safe_name.replace('➾', '_').replace('⟾', '_')
            safe_name = safe_name.replace('->', '_').replace('→', '_')

            m3u_filename = "vavoo_%s.m3u" % safe_name
            m3u_path = join(downloadfree, m3u_filename)

            # M3U header
            m3u_content = "#EXTM3U\n"

            host = getattr(self, '_m3u_host', None) or PROXY_HOST

            channel_count = 0
            for channel in channels:
                try:
                    if isinstance(channel, dict):
                        channel_name = channel.get('name', 'Unknown')
                        channel_id = channel.get('id', '')
                        if channel_id:
                            # Rebuild the proxy URL with the chosen host
                            # instead of the LAN IP the proxy always
                            # embeds in its /channels response.
                            # channel_id is catalog data too (same
                            # threat model as channel_name below) and
                            # is embedded directly into this line's
                            # URL, not just its text - url_quote()
                            # closes both the newline-injection gap and
                            # a stray "&"/"#"/space corrupting the URL
                            # itself. ensure_str(), not a plain str() -
                            # a grouped channel's id can carry a
                            # non-ASCII base name (clean_name_for_
                            # similarity() only strips punctuation, not
                            # non-ASCII letters), and plain str() on a
                            # Python 2 unicode value raises
                            # UnicodeEncodeError for any of those,
                            # silently dropping the channel (caught by
                            # this loop's own try/except below).
                            channel_url = "http://{}:{}/vavoo?channel={}".format(
                                host, PORT, url_quote(strip_control_chars(ensure_str(channel_id))))
                        else:
                            channel_url = strip_control_chars(channel.get('url', ''))

                        # Clean channel name
                        channel_name = decodeHtml(channel_name)
                        channel_name = remove_parentheses(channel_name)
                        # Catalog-sourced, already treated as
                        # attacker-influenceable elsewhere (bouquet
                        # #NAME/Favorite.txt lines) - an embedded
                        # newline would inject extra lines into the
                        # generated .m3u file.
                        channel_name = strip_control_chars(channel_name)

                        # Write M3U entry
                        m3u_content += "#EXTINF:-1,%s\n" % channel_name
                        m3u_content += "%s\n" % channel_url
                        channel_count += 1

                except Exception as e:
                    print("[M3U] Error processing channel: %s" % str(e))
                    continue

            if channel_count == 0:
                print("[M3U] No valid channels for %s" % country_name)
                return 0

            # Write file
            with codecs.open(m3u_path, 'w', encoding='utf-8') as f:
                f.write(m3u_content)
            print(
                "[M3U] File created: %s (%d channels)" %
                (m3u_path, channel_count))

            return channel_count

        except Exception as e:
            print(
                "[M3U] Error generating M3U for %s: %s" %
                (country_name, str(e)))
            return 0

    def get_channels_for_country(self, country_name):
        """Get channels for a country from the proxy"""
        try:
            encoded_country = url_quote(country_name)
            proxy_url = PROXY_BASE_URL + \
                "/channels?country={}".format(encoded_country)
            response = getUrl(proxy_url, timeout=15)
            if not response:
                print("[M3U] No response for %s" % country_name)
                return []

            channels = loads(ensure_str(response))
            return channels

        except Exception as e:
            print("[M3U] Error getting channels: %s" % str(e))
            return []

    def _fetch_countries_async(self, on_done):
        """Run get_countries_from_proxy() in a background thread and
        deliver the result to on_done() on the reactor/GUI thread.
        get_countries_from_proxy() is a synchronous getUrl() call that
        can block for tens of seconds on a slow/unresponsive proxy -
        every caller here is a ChoiceBox/ MessageBox callback, i.e.
        already running on Enigma2's single GUI thread, so calling it
        directly would freeze the whole box for that long."""
        def task():
            if self._closed:
                return
            countries = self.get_countries_from_proxy()
            if self._closed:
                return
            reactor.callFromThread(on_done, countries)
        t = threading.Thread(target=task)
        t.daemon = True
        t.start()

    def _fetch_channels_async(self, country_name, on_done):
        """Same as _fetch_countries_async(), for get_channels_for_country()."""
        def task():
            if self._closed:
                return
            channels = self.get_channels_for_country(country_name)
            if self._closed:
                return
            reactor.callFromThread(on_done, channels)
        t = threading.Thread(target=task)
        t.daemon = True
        t.start()

    def check_and_start_proxy_async(
            self, on_ready, on_failed, attempts_left=10):
        """Check and start the proxy if needed, then call on_ready()/
        on_failed() once known - polls via reactor.callLater instead of
        blocking the GUI thread with select.select()."""
        try:
            if not is_proxy_running():
                print("[M3U Export] Starting proxy...")
                if not run_proxy_in_background():
                    on_failed()
                    return
            self._poll_proxy_ready_for_m3u(on_ready, on_failed, attempts_left)
        except Exception as e:
            print(
                "[M3U Export][check_and_start_proxy] Proxy error: %s" %
                str(e))
            on_failed()

    def _poll_proxy_ready_for_m3u(self, on_ready, on_failed, attempts_left):
        if is_proxy_ready():
            on_ready()
            return
        if attempts_left <= 1:
            on_failed()
            return
        reactor.callLater(
            1,
            self._poll_proxy_ready_for_m3u,
            on_ready,
            on_failed,
            attempts_left - 1)

    def get_countries_from_proxy(self):
        """Get country list from the proxy"""
        try:
            response = getUrl(PROXY_COUNTRIES_URL, timeout=10)
            if response:
                return loads(response)

        except Exception as e:
            print("[M3U Export] Countries error: %s" % str(e))

        return []

    def manage_epg_source(self):
        # Just call the static function from vUtils
        # This will generate EPG from all existing bouquets
        # return generate_epg_files()
        return update_epg_sources()

    def setInfo(self):
        try:
            sel = self['config'].getCurrent()[2]
            if sel:
                self['description'].setText(str(sel))
            else:
                self['description'].setText(_('SELECT YOUR CHOICE'))
            return
        except Exception as e:
            print('error as:', e)
            trace_error()

    def changedEntry(self):
        for x in self.onChangedEntry:
            x()
        self['green'].instance.setText(
            _('Save') if self['config'].isChanged() else '- - - -')

    def getCurrentEntry(self):
        return self["config"].getCurrent()[0]

    def showhide(self):
        pass

    def getCurrentValue(self):
        return str(self["config"].getCurrent()[1].getText())

    def createSummary(self):
        from Screens.Setup import SetupSummary
        return SetupSummary

    def keyLeft(self):
        ConfigListScreen.keyLeft(self)
        self.createSetup()
        self.showhide()

    def keyRight(self):
        ConfigListScreen.keyRight(self)
        self.createSetup()
        self.showhide()

    def keyDown(self):
        self['config'].instance.moveSelection(self['config'].instance.moveDown)
        self.createSetup()
        self.showhide()

    def keyUp(self):
        self['config'].instance.moveSelection(self['config'].instance.moveUp)
        self.createSetup()
        self.showhide()

    def _reorganize_bouquets_position(self):
        """Reorganize all Vavoo bouquets to the new position"""
        if reorganize_all_bouquets_position(cfg.list_position.value):
            self.session.open(
                MessageBox,
                _("Bouquets reorganized successfully!"),
                MessageBox.TYPE_INFO,
                timeout=3)

    def schedule_epg_update(self):
        """Auto-enable Vavoo's EPG source(s) in EPGImport's own settings.

        EPGImport's own scheduler (its "wakeup"/"repeat import" settings,
        configured directly in EPGImport's own screen) is what actually
        runs periodic imports - this doesn't add a second, competing
        schedule. It just removes the friction of having to separately
        go enable the Vavoo source there yourself: an earlier version
        tried to do this by opening EPGIMPORT_CONF in text mode and
        appending a "sources=..." line to it, but that file is actually
        a binary serialized blob (not the plain-text format this
        assumed), so every append corrupted EPGImport's own config.
        ensure_vavoo_epg_sources_enabled() (vUtils.py) uses EPGImport's
        own save API instead, so it's safe to call here.
        """
        try:
            # Checks "Enable Vavoo EPG" itself; there is no separate
            # option for this any more (it used to hide behind a
            # second toggle named "Auto-update EPG", which sounded
            # like it scheduled something - it never did).
            ensure_vavoo_epg_sources_enabled()

        except Exception as e:
            print("[Vavoo] Error scheduling EPG update:", str(e))

    def save(self):
        if self["config"].isChanged():
            for x in self["config"].list:
                x[1].save()

            # Tracks whether this save() has already restarted the
            # proxy, so the "Manage EPG source" block further down
            # doesn't start it a second time.
            restart_handled = False

            if self.old_catalog_source != cfg.catalog_source.value:
                self.old_catalog_source = cfg.catalog_source.value
                # initialize_proxy() only reads catalog_source once, at
                # startup - restart the proxy so the new choice actually
                # takes effect. Stop + wait for the port + start all
                # happen off the GUI thread; calling shutdown_proxy()
                # and run_proxy_in_background() back to back right
                # here used to find the old server still listening and
                # skip the start altogether.
                restart_proxy_in_background()
                reactor.callLater(1, self._check_proxy_started)
                restart_handled = True

            # Sync the anonymous-stats opt-out file with this toggle -
            # is_stats_enabled() (vavoo_stats.py) checks for this file's
            # existence, but nothing ever created/removed it since there
            # was no actual UI control for it before this config entry.
            try:
                if cfg.stats_enabled.value:
                    if isfile(STATS_DISABLE_FILE):
                        remove(STATS_DISABLE_FILE)
                else:
                    if not isfile(STATS_DISABLE_FILE):
                        with open(STATS_DISABLE_FILE, 'w') as f:
                            f.write('1')
                    # Stop the running heartbeat immediately instead of
                    # letting it keep firing every 5 minutes until the
                    # plugin is next restarted.
                    stop_heartbeat()
            except Exception as e:
                print("[Config] Error syncing stats opt-out: " + str(e))

            # Manage EPG source - skipped if a restart already happened
            # above in this same save() (catalog_source changing).
            if cfg.epg_enabled.value and not is_proxy_running() and not restart_handled:
                run_proxy_in_background()
                # No sleep here – the proxy will become ready asynchronously

            # With the EPG on, make sure its source(s) are enabled in
            # EPGImport too.
            if cfg.epg_enabled.value:
                self.schedule_epg_update()

            # Apply any change to the scheduled bouquet auto-update timer
            # live, instead of requiring a reboot for it to take effect.
            check_configuring()

            if self.old_list_position != cfg.list_position.value:
                self._reorganize_bouquets_position()
                self.old_list_position = cfg.list_position.value

            configfile.save()

            try:
                config.loadFromFile(configfile.CONFIG_FILE)
            except Exception as e:
                print("Config reload error (safe mode): " + str(e))
                self._safe_config_reload()

            back_changed = self.old_back != cfg.back.value
            bakk = str(cfg.back.getValue()) + '.png'
            add_skin_back(bakk)

            message = _("Configuration saved successfully!")
            if back_changed:
                # apply_selected_background() makes freshly-opened screens
                # point at the actual selected file, avoiding Enigma2's
                # pixmap cache entirely - but the MainVavoo screen
                # currently open behind this config screen was already
                # loaded before this change, so it still needs to be
                # closed and reopened once to pick up the new skin text.
                message += "\n\n" + \
                    _("Exit and reopen the plugin to see the new background.")
                self.old_back = cfg.back.value

            self.session.open(
                MessageBox,
                message,
                MessageBox.TYPE_INFO,
                timeout=5
            )

            self.close()

    def _check_proxy_started(self, attempts=0):
        """Callback to verify proxy has started (non‑blocking).

        Capped by cfg.proxy_startup_timeout instead of retrying every 2s
        forever - previously, if the proxy never came up (missing
        binary, crash-loop, blocked network), this rescheduled itself
        indefinitely for the life of the Enigma2 process, keeping this
        (by then already-closed, since save() closes the screen right
        after scheduling this) vavoo_config instance alive forever."""
        try:
            timeout_secs = int(cfg.proxy_startup_timeout.value)
        except (TypeError, ValueError):
            timeout_secs = 30
        max_attempts = max(1, timeout_secs // 2)
        if not is_proxy_running():
            if attempts >= max_attempts:
                print(
                    "[Config] Proxy still not ready after {}s, giving up".format(
                        timeout_secs))
                return
            print("[Config] Proxy not yet ready, will check later")
            reactor.callLater(
                2, lambda: self._check_proxy_started(attempts + 1))
        else:
            print("[Config] Proxy is ready")

    def _safe_config_reload(self):
        """Safe configuration reload"""
        try:
            if not hasattr(config.plugins, 'vavoo'):
                config.plugins.vavoo = ConfigSubsection()
                print("Recreated vavoo config section")

            config.loadFromFile(configfile.CONFIG_FILE)
        except Exception as e:
            print("Safe config reload failed: " + str(e))

    def extnok(self, answer=None):
        if answer is None:
            if self['config'].isChanged():
                self.session.openWithCallback(
                    self.extnok, MessageBox, _("Really close without saving settings?"))
            else:
                self.close()
        elif answer:
            for x in self["config"].list:
                x[1].cancel()
            self.close()
        else:
            return


class startVavoo(Screen):
    # ── animated splash configuration ────────────────────────────────────────
    # These messages are cosmetic progress flavor only; the screen does not
    # actually close until the proxy reports itself ready (or the
    # configured startup timeout elapses) - see _check_ready()/_finish().
    STATUS_STEPS = [
        (0, "Connecting to 127.0.0.1:4323 ..."),
        (18, "Loading channel catalog ..."),
        (42, "Authenticating Vavoo servers ..."),
        (68, "Renewing stream tokens ..."),
        (86, "Finalizing startup ..."),
    ]
    TOTAL_MS = 1200   # time for the cosmetic bar to reach SOFT_CAP
    TICK_MS = 30     # timer interval in ms
    HOLD_MS = 250    # pause at 100 % before closing
    POLL_MS = 400    # how often we check real proxy readiness
    # Cosmetic progress never claims 100% on its own - only once the proxy
    # actually reports "initialized" (or we give up after the timeout) do
    # we jump to 100% and close.
    SOFT_CAP = 92

    def __init__(self, session):

        global _session, first
        self.session = session
        _session = session
        first = True
        Screen.__init__(self, session)
        skin = join(skin_path, 'Plgnstrt.xml')
        with codecs.open(skin, "r", encoding="utf-8") as f:
            self.skin = f.read()

        # existing widgets (kept for skin compatibility)
        self["poster"] = Pixmap()
        self["version"] = Label()

        # new animated-splash widgets
        self["title"] = Label("VAVOO STREAM LIVE")
        self["subtitle"] = Label("ENIGMA2 PLUGIN")
        self["progress_label"] = Label("INITIALIZING PROXY")
        self["progress_pct"] = Label("0 %")
        self["progress"] = ProgressBar()
        self["status"] = Label(self.STATUS_STEPS[0][1])
        self["author"] = Label("by Lululla & Qu4k3")
        self["skip_hint"] = Label("Press OK or EXIT to skip")

        self['actions'] = ActionMap(
            ['OkCancelActions'], {
                'ok': self.clsgo, 'cancel': self.clsgo}, -1)

        # animation state
        self._pct = 0
        self._msg_idx = 0
        self._steps = max(1, int(self.TOTAL_MS / self.TICK_MS))
        self._tick_no = 0

        # real-readiness state
        self._elapsed_ms = 0
        self._channels_count = 0
        max_wait_secs = 30
        try:
            max_wait_secs = int(cfg.proxy_startup_timeout.value)
        except Exception as e:
            debug(
                "Invalid proxy_startup_timeout config value, using default: {}".format(e))
        self._max_wait_ms = max(1000, max_wait_secs * 1000)

        self.onLayoutFinish.append(self.loadDefaultImage)

    # ── image decode (DreamOS-compatible, unchanged logic) ──────────────────
    def decodeImage(self):
        try:
            pixmapx = self.fldpng
            if isfile(pixmapx):
                size = self['poster'].instance.size()
                self.picload = ePicLoad()
                self.scale = AVSwitch().getFramebufferScale()
                self.picload.setPara(
                    [size.width(), size.height(),
                     self.scale[0], self.scale[1], 0, 1, '#00000000'])
                if isfile("/var/lib/dpkg/status"):
                    self.picload.startDecode(pixmapx, False)
                else:
                    self.picload.startDecode(pixmapx, 0, 0, False)
                ptr = self.picload.getData()
                if ptr is not None:
                    self['poster'].instance.setPixmap(ptr)
                    self['poster'].show()
        except Exception as e:
            print("[startVavoo] decodeImage error: " + str(e))
        try:
            self["version"].setText(to_string("V." + __version__))
        except Exception:
            pass

    # ── smoothstep progress tick (cosmetic only, capped at SOFT_CAP) ────────
    def _tick(self):
        self._tick_no += 1
        t = min(1.0, self._tick_no / float(self._steps))
        smooth = t * t * (3.0 - 2.0 * t)          # ease-in-out curve
        self._pct = min(self.SOFT_CAP, int(round(smooth * self.SOFT_CAP)))

        # ProgressBar.setValue() already no-ops safely if its instance
        # isn't bound yet - going through it (instead of the raw
        # .instance.setValue() + silent try/except used before) means a
        # real failure here can't silently freeze the bar while the
        # percentage/status text next to it keeps advancing.
        self["progress"].setValue(self._pct)
        self["progress_pct"].setText("%d %%" % self._pct)

        # advance status messages
        while self._msg_idx < len(self.STATUS_STEPS):
            threshold, msg = self.STATUS_STEPS[self._msg_idx]
            if self._pct >= threshold:
                self["status"].setText(msg)
                self._msg_idx += 1
            else:
                break
        # Completion is decided by _check_ready(), not by this cosmetic
        # timer - it just stops advancing once it hits SOFT_CAP.

    # ── real readiness check (drives when the splash actually closes) ──────
    def _check_ready(self):
        self._elapsed_ms += self.POLL_MS

        # The proxy's HTTP port only opens once the whole catalog has
        # loaded, so every connection is refused until then. Check the
        # port cheaply first (near-instant) and only pay for the HTTP
        # round trip - with a single attempt, no retry/backoff - once it
        # is actually listening. Skipping this would make every poll
        # block for seconds at a time via getUrl()'s retry logic, on the
        # reactor thread, for the entire catalog-load duration.
        data = None
        if is_proxy_running():
            try:
                response = getUrl(PROXY_STATUS_URL, timeout=0.5, retries=1)
                data = loads(ensure_str(response)) if response else None
            except Exception:
                data = None

        if data and data.get("initialized"):
            self._channels_count = data.get("channels_count", 0) or 0
            self._finish()
            return

        if self._elapsed_ms >= self._max_wait_ms:
            print(
                "[startVavoo] Proxy not ready after {}s, continuing anyway".format(
                    self._max_wait_ms // 1000))
            self._finish(timed_out=True)

    def _finish(self, timed_out=False):
        try:
            self._ready_timer.stop()
        except Exception:
            pass
        try:
            self._anim_timer.stop()
        except Exception:
            pass

        self._pct = 100
        self["progress"].setValue(100)
        self["progress_pct"].setText("100 %")

        if timed_out:
            msg = _("Continuing, proxy still syncing...")
        elif self._channels_count:
            msg = _("Proxy online - {} channels  ✓").format(
                self._channels_count)
        else:
            msg = "Proxy online  ✓"
        self["status"].setText(msg)

        self._hold_timer.start(self.HOLD_MS, True)   # single-shot hold

    # ── proxy kickoff (non-blocking - see run_proxy_in_background) ──────────
    def _start_proxy_if_needed(self):
        try:
            if is_proxy_running() and is_proxy_ready(timeout=0.5):
                return
            run_proxy_in_background()
        except Exception as e:
            print("[startVavoo] proxy start error: " + str(e))

    # ── timer setup (called once layout is ready) ───────────────────────────
    def loadDefaultImage(self):
        self.fldpng = resolveFilename(
            SCOPE_PLUGINS,
            "Extensions/{}/skin/pics/presplash.png".format('vavoo'))

        self._start_proxy_if_needed()
        _start_update_check()

        # image-decode timer (unchanged, fires once at 500 ms)
        self.timer = eTimer()
        if isfile('/var/lib/dpkg/status'):
            self.timer.timeout.connect(self.decodeImage)
        else:
            self.timer.callback.append(self.decodeImage)
        self.timer.start(500, True)

        # animation tick timer (repeating, 30 ms interval, cosmetic only)
        self["progress"].setValue(0)
        self._anim_timer = eTimer()
        if isfile('/var/lib/dpkg/status'):
            self._anim_timer.timeout.connect(self._tick)
        else:
            self._anim_timer.callback.append(self._tick)
        self._anim_timer.start(self.TICK_MS, False)

        # readiness-poll timer – repeating, decides when we actually finish
        self._ready_timer = eTimer()
        if isfile('/var/lib/dpkg/status'):
            self._ready_timer.timeout.connect(self._check_ready)
        else:
            self._ready_timer.callback.append(self._check_ready)
        self._ready_timer.start(self.POLL_MS, False)

        # hold timer – single-shot, started by _finish() once actually ready
        self._hold_timer = eTimer()
        if isfile('/var/lib/dpkg/status'):
            self._hold_timer.timeout.connect(self.clsgo)
        else:
            self._hold_timer.callback.append(self.clsgo)

    def clsgo(self):
        global first
        # stop any running timers safely
        try:
            self.timer.stop()
        except Exception:
            pass
        try:
            self._anim_timer.stop()
        except Exception:
            pass
        try:
            self._ready_timer.stop()
        except Exception:
            pass
        try:
            self._hold_timer.stop()
        except Exception:
            pass
        if first is True:
            first = False
            self.session.open(MainVavoo)
        self.close()


class UpdatePopup(Screen):
    """Yes/No dialog for a newly-found plugin update, skinned to match
    the splash screen (Plgnstrt.xml) instead of a generic MessageBox."""

    def __init__(self, session, remote_version, changelog):
        Screen.__init__(self, session)
        skin = join(skin_path, 'UpdatePopup.xml')
        with codecs.open(skin, "r", encoding="utf-8") as f:
            self.skin = f.read()

        self["title"] = Label(_("Update Available"))
        self["subtitle"] = Label(
            _("v{} -> v{}").format(__version__, remote_version))
        # Plain Label, not ScrollLabel: two different ScrollLabel setups
        # (setText() deferred to onLayoutFinish, then constructing it
        # with the real text directly) both rendered a completely empty
        # box on real hardware (confirmed on OpenATV 7.6), even though
        # every other widget on this same screen - including this one's
        # own changelog_label right above it - renders fine. Label is
        # the one widget type known to actually work here (it's what
        # showed the changelog, truncated, before scrolling was added).
        # Do our own manual pagination instead of relying on a
        # component that isn't reliably rendering anything.
        self._changelog_text = changelog or _("No changelog provided.")
        changelog_lines = self._changelog_text.split('\n')
        lines_per_page = 8
        self._changelog_pages = [
            '\n'.join(changelog_lines[i:i + lines_per_page])
            for i in range(0, len(changelog_lines), lines_per_page)
        ] or ['']
        self._changelog_page_index = 0
        self["changelog_label"] = Label(self._changelogLabelText())
        self["changelog"] = Label(self._changelog_pages[0])
        self["key_red"] = Label(_("Cancel"))
        self["key_green"] = Label(_("Yes, update now"))

        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "DirectionActions"],
            {
                "ok": self.confirm,
                "green": self.confirm,
                "cancel": self.deny,
                "red": self.deny,
                "up": self._changelogPageUp,
                "down": self._changelogPageDown,
                "left": self._changelogPageUp,
                "right": self._changelogPageDown,
            }, -1
        )

    def _changelogLabelText(self):
        if len(self._changelog_pages) > 1:
            return _("Changelog: ({}/{}, use up/down)").format(
                self._changelog_page_index + 1, len(self._changelog_pages))
        return _("Changelog:")

    def _changelogPageUp(self):
        if self._changelog_page_index > 0:
            self._changelog_page_index -= 1
            self["changelog"].setText(
                self._changelog_pages[self._changelog_page_index])
            self["changelog_label"].setText(self._changelogLabelText())

    def _changelogPageDown(self):
        if self._changelog_page_index < len(self._changelog_pages) - 1:
            self._changelog_page_index += 1
            self["changelog"].setText(
                self._changelog_pages[self._changelog_page_index])
            self["changelog_label"].setText(self._changelogLabelText())

    def confirm(self):
        self.close(True)

    def deny(self):
        self.close(False)


def _shared_update_proxy_status_display(screen):
    """Update the 'proxy_status' widget on screen (MainVavoo/vavoo share
    this verbatim - kept in one place instead of two independently
    maintained copies, which already drifted out of sync once before
    for a sibling pair of constants, see PROXY_MONITOR_INTERVAL_MS
    above)."""
    try:
        if is_proxy_running():
            try:
                # retries=1: this runs synchronously on the GUI/reactor
                # thread from a repeating 10s eTimer (MainVavoo and
                # vavoo both have one) - getUrl()'s default retries=3
                # with backoff could block the ENTIRE UI for up to
                # ~18s on a slow/unresponsive proxy, out of every 10s
                # window. is_proxy_ready() right next to this call's
                # own callers already caps itself at a single attempt
                # for exactly this reason - this call just hadn't
                # matched it.
                response = getUrl(
                    PROXY_STATUS_URL, timeout=5, retries=1)
                if response:
                    status_data = loads(ensure_str(response))

                    # Geil (the default catalog source - see
                    # vavoo_proxy.py's catalog_source) needs no
                    # addonSig token at all, so addon_sig_valid is
                    # always False while running on it - requiring it
                    # unconditionally here showed "Proxy Error" on an
                    # otherwise perfectly healthy Geil proxy.
                    token_required = status_data.get(
                        "catalog_source", "vavoo") != "geil"
                    if status_data.get("initialized", False) and (
                            not token_required or status_data.get(
                                "addon_sig_valid", False)):
                        if not token_required:
                            status_text = "✓ Proxy OK (Geil)"
                        else:
                            token_age = status_data.get("addon_sig_age", 0)

                            if token_age < 300:
                                status_text = "✓ Proxy OK"
                            elif token_age < 540:
                                ttl = 600 - token_age
                                status_text = "✓ Proxy (" + \
                                    str(int(ttl)) + "s)"
                            else:
                                status_text = "Proxy (expiring)"
                    else:
                        status_text = "✗ Proxy Error"
                else:
                    status_text = "? Proxy Unknown"
            except Exception:
                status_text = "✓ Proxy Running"
        else:
            status_text = "✗ Proxy Offline"

        screen['proxy_status'].setText(status_text)

    except Exception as e:
        print("[ProxyStatus] Error updating proxy status: " + str(e))
        screen['proxy_status'].setText(_("✗ Error"))


def _shared_reload_bouquets_with_popup(screen):
    """Reload bouquets with confirmation popup (MainVavoo/vavoo share
    this verbatim)."""
    debug("reload_bouquets_with_popup called")
    screen.session.openWithCallback(
        screen._confirm_reload_bouquets,
        MessageBox,
        _("Reload bouquets and service list?"),
        MessageBox.TYPE_YESNO,
        timeout=10,
        default=True
    )


def _shared_confirm_reload_bouquets(screen, result):
    """Callback after user confirmation (MainVavoo/vavoo share this
    verbatim)."""
    if result:
        debug("User confirmed reload")
        try:
            db = eDVBDB.getInstance()
            db.reloadBouquets()
            db.reloadServicelist()
            print("Bouquets reloaded successfully")
        except Exception as e:
            print("Error during service reload: " + str(e))
            ReloadBouquets(500)
        try:
            screen.session.open(
                MessageBox,
                _("Bouquets reload scheduled."),
                MessageBox.TYPE_INFO,
                timeout=2
            )
        except Exception as e:
            print("[MessageBox] Error:", e)
    else:
        debug("User cancelled reload")


def _is_country_locked(country_name):
    """True if `country_name` is in the parental-control locked-country
    list and a PIN is actually configured (an empty PIN means the
    feature is off, same as every other opt-in cfg string in this
    plugin). Module-level so both MainVavoo (opening a country's
    channel list) and VavooFavourites (playing a favourite channel
    that remembers which country it came from) can gate on it, instead
    of only the former - a favourite from a locked country used to
    play with no PIN prompt at all."""
    pin = cfg.parental_pin.value.strip()
    if not pin or not country_name:
        return False
    locked = [
        c.strip().lower()
        for c in cfg.parental_countries.value.split(',') if c.strip()
    ]
    return country_name.strip().lower() in locked


def _require_parental_pin(session, screen, country_name, on_success):
    """If country_name is locked, prompt for the PIN and call
    on_success() only on a correct match; otherwise call on_success()
    immediately. `screen` is the calling Screen instance, checked for
    `_closed` before acting on the PIN result, since the prompt is an
    async callback that can outlive a screen the user has since left."""
    if not _is_country_locked(country_name):
        on_success()
        return

    def _on_result(result):
        if getattr(screen, '_closed', False):
            return
        if result is not None and result == cfg.parental_pin.value:
            on_success()
        else:
            session.open(
                MessageBox,
                _("Incorrect PIN"),
                MessageBox.TYPE_ERROR,
                timeout=3)

    session.openWithCallback(
        _on_result,
        VirtualKeyBoard,
        title=_("Enter parental control PIN"))


class MainVavoo(Screen):
    def __init__(self, session):
        self.session = session
        global _session
        _session = session

        # So a background flag-download thread still in flight when the
        # user exits (closex()) can notice and skip re-arming timers /
        # touching UI on a screen that's no longer executing.
        self._closed = False

        Screen.__init__(self, session)
        init_notification_system(session)
        if NOTIFICATION_AVAILABLE:
            print('notify started')
            quick_notify(_("Welcome to Vavoo Proxy with EPG support"), 5)

        skin = join(skin_path, 'defaultListScreen.xml')
        if isfile('/var/lib/dpkg/status'):
            skin = skin.replace('.xml', '_cvs.xml')
        with codecs.open(skin, "r", encoding="utf-8") as f:
            self.skin = apply_selected_background(f.read())

        if is_stats_enabled():
            record_anonymous_startup()
            start_heartbeat()

        self._initialize_labels()
        self._initialize_actions()
        self["menulist"].onSelectionChanged.append(self._update_selection_name)
        self.currentList = 'menulist'
        # How many times in a row the country list came back empty -
        # see _on_countries_response().
        self._country_load_failures = 0

        self.start_vavoo_proxy()

        # Watchdog timer - check every 60 seconds
        self.proxy_watchdog_timer = eTimer()
        try:
            self.proxy_watchdog_timer.timeout.connect(
                self._proxy_watchdog_check
            )
        except BaseException:
            self.proxy_watchdog_timer.callback.append(
                self._proxy_watchdog_check
            )

        self.proxy_watchdog_timer.start(PROXY_WATCHDOG_INTERVAL_MS)

        # Monitor timer - check proxy status every 10 seconds
        self.proxy_monitor_timer = eTimer()
        try:
            self.proxy_monitor_timer.timeout.connect(
                self._check_and_update_proxy_status
            )
        except BaseException:
            self.proxy_monitor_timer.callback.append(
                self._check_and_update_proxy_status
            )

        self.proxy_monitor_timer.start(PROXY_MONITOR_INTERVAL_MS)

        # proxy_monitor_timer's first tick is still PROXY_MONITOR_INTERVAL_MS
        # (10s) away, so without this the label would sit on "Checking
        # proxy..." for up to 10 seconds even though the splash screen
        # already confirmed (or gave up on) proxy readiness moments ago -
        # refresh it immediately instead of leaving that stale placeholder.
        self['proxy_status'].setText(_("Checking proxy..."))
        self._update_proxy_status_display()
        self.cat()

        # Poll for the update check started during the splash screen to
        # finish, then show the popup (if a newer version was found) now
        # that the main menu is actually open - see _check_update_popup_tick().
        self._update_popup_timer = eTimer()
        if isfile('/var/lib/dpkg/status'):
            self._update_popup_timer.timeout.connect(
                self._check_update_popup_tick)
        else:
            self._update_popup_timer.callback.append(
                self._check_update_popup_tick)
        self._update_popup_timer.start(1000, False)

    def _initialize_labels(self):
        """Initialize the labels on the screen."""
        self.menulist = []
        self['menulist'] = m2list([])
        self['red'] = Label(_('Exit'))
        # Bound to msgdeleteBouquets, which deletes every Vavoo bouquet
        # (country + category + container, see its own confirmation
        # text) - not a single favourite. The `vavoo` screen's own
        # green button is correctly labeled "Remove Fav" for its
        # genuinely per-item action; reusing that exact caption here
        # primed a user familiar with one screen to misread the other.
        self['green'] = Label(_('Remove ALL'))
        self['yellow'] = Label()
        if cfg.epg_enabled.value:
            self['yellow'].setText(_("Fix Cache"))
        self["blue"] = Label(_('Reload Bouqet'))
        self['name'] = Label('Loading...')
        self['version'] = Label()
        self['proxy_status'] = Label('Wait...')

    def _initialize_actions(self):
        """Initialize the actions for buttons."""
        actions = {
            'prevBouquet': self.chDown,
            'nextBouquet': self.chUp,
            'up': self.moveUp,
            'down': self.moveDown,
            'ok': self.ok,
            'mainMenu': self.goConfig,
            'menu': self.goConfig,
            'green': self.msgdeleteBouquets,
            'blue': self.reload_bouquets_with_popup,
            'cancel': self.closex,
            'red': self.closex,
            'epg': self.manual_epg_update,
            'info': self.info,
            'InfoPressed': self.info,
            'infoLong': self._fix_cache_format,
            'yellow': self._fix_cache_format,
            'text': self.refresh_proxy,
        }
        actions_list = [
            'MenuActions',
            'OkCancelActions',
            'ButtonSetupActions',
            'InfobarEPGActions',
            'EPGSelectActions',
            'ColorActions',
            'DirectionActions'
        ]
        self['actions'] = ActionMap(actions_list, actions, -1)

    def _fix_cache_format(self, result=None):
        if result is None:
            message_lines = []
            message_lines.append(_("Do you want to fix the cache format?"))
            message_lines.append(_("This will:"))
            message_lines.append(_("  - Add missing fields to all entries"))
            message_lines.append(_("  - Remove duplicate entries"))
            message_lines.append(_("  - Clean up the cache file"))
            message = "\n".join(message_lines)

            self.session.openWithCallback(
                self._fix_cache_format,
                MessageBox,
                message,
                MessageBox.TYPE_YESNO
            )
            return

        if not result:
            debug("fix_cache_format cancelled by user")
            return

        # An in-progress export's EPG-matching phase writes the same
        # cache file (see bouquet_manager.process_epg_matching_background)
        # with no lock of its own - share export_lock so the two can't
        # interleave and corrupt/clobber each other's write.
        # threading.Lock.acquire() only accepts blocking as a
        # positional argument on Python 2 (the C implementation there
        # doesn't support keyword arguments at all) - acquire(False)
        # works identically on both Python 2 and 3.
        if not export_lock.acquire(False):
            if NOTIFICATION_AVAILABLE:
                quick_notify(
                    _("An export is in progress. Please wait before fixing the cache."), 4)
            return

        try:
            if NOTIFICATION_AVAILABLE:
                quick_notify(_("Fixing cache format..."), 2)

            # fixed, removed = fix_cache_format(remove_duplicates=True, remove_unmatched=True)
            fixed, removed = fix_cache_format(
                remove_duplicates=True, remove_unmatched=True, remove_invalid=True)

            if fixed == 0 and removed == 0:
                message = _(
                    "Cache is already in correct format. No changes needed.")
            else:
                message_lines = []
                message_lines.append(_("Cache format fix completed:"))
                if fixed > 0:
                    message_lines.append(
                        _("  - {} entries updated").format(fixed))
                if removed > 0:
                    message_lines.append(
                        _("  - {} duplicate entries removed").format(removed))
                message = "\n".join(message_lines)

            self.session.open(
                MessageBox,
                message,
                MessageBox.TYPE_INFO,
                timeout=5
            )
            debug(
                "fix_cache_format completed: fixed={}, removed={}".format(
                    fixed, removed))

        except Exception as e:
            debug("Error in fix_cache_format: {}".format(e))
            self.session.open(
                MessageBox,
                _("Error fixing cache: {}").format(str(e)),
                MessageBox.TYPE_ERROR,
                timeout=5
            )
        finally:
            export_lock.release()

    def reload_bouquets_with_popup(self):
        """Reload bouquets with confirmation popup"""
        _shared_reload_bouquets_with_popup(self)

    def _confirm_reload_bouquets(self, result):
        """Callback after user confirmation"""
        _shared_confirm_reload_bouquets(self, result)

    def closex(self):
        debug("Exit from plugin. Cleaning up plugin timers...")
        self._closed = True
        if is_stats_enabled():
            stop_heartbeat()
            print("[Stats] Heartbeat fermato")

        try:
            if hasattr(self, 'proxy_monitor_timer'):
                self.proxy_monitor_timer.stop()
            if hasattr(self, 'proxy_watchdog_timer'):
                self.proxy_watchdog_timer.stop()
            if hasattr(self, '_update_popup_timer'):
                self._update_popup_timer.stop()
            if hasattr(self, '_country_retry_timer'):
                self._country_retry_timer.stop()
        except Exception as e:
            print("[Close] Error stopping timers: %s" % str(e))

        try:
            cleaned = cleanup_old_temp_files(max_age_hours=1)
            print("[Cleanup] Removed %d temporary files" % cleaned)
        except Exception as e:
            print("[Cleanup] Error: %s" % str(e))

        # Reload bouquets in background without popup
        try:
            db = eDVBDB.getInstance()
            db.reloadBouquets()
            db.reloadServicelist()
            print("Bouquets reloaded successfully")
        except Exception as e:
            print("Error during service reload: " + str(e))
            ReloadBouquets(500)

        self.close()

    def _proxy_watchdog_check(self):
        """Watchdog to check if the proxy is still alive"""
        try:
            if not is_proxy_running():
                print("[Watchdog] Proxy not running, attempting restart...")
                self['proxy_status'].setText(_(" Restarting..."))

                # Try restart
                success = run_proxy_in_background()

                if success:
                    print("[Watchdog] Proxy restarted successfully")
                    self['proxy_status'].setText(_("✓ Restarted"))
                else:
                    print("[Watchdog] Proxy restart failed")
                    self['proxy_status'].setText(_("✗ Restart Failed"))

        except Exception as e:
            print("[Watchdog] Error: " + str(e))

    def _check_and_update_proxy_status(self):
        """Check and update the proxy status periodically"""
        try:
            if not is_proxy_ready(timeout=2):
                self.proxy_needs_attention = True
                print("[MainVavoo] Proxy needs attention")
            else:
                self.proxy_needs_attention = False

            self._update_proxy_status_display()
            # self.update_proxy_status_display()
        except Exception as e:
            print(
                "[MainVavoo][_check_and_update_proxy_status] Error in proxy monitor: " +
                str(e))
            self['proxy_status'].setText(_("✗ Proxy Error"))

    def update_proxy_status(self):
        """Public method to update proxy status (can be called manually)"""
        self._update_proxy_status_display()

    def _update_proxy_status_display(self):
        """Internal method to update proxy status display"""
        _shared_update_proxy_status_display(self)

    def refresh_proxy(self):
        """Force proxy refresh"""
        try:
            self.session.openWithCallback(
                self._refresh_proxy_callback,
                MessageBox,
                _("Force proxy refresh?") + "\n" +
                _("This will refresh the authentication token."),
                MessageBox.TYPE_YESNO)
        except Exception as e:
            print("[MainVavoo][refresh_proxy] Refresh proxy error: " + str(e))

    def _refresh_proxy_callback(self, result):
        """Callback for proxy refresh"""
        if result:
            try:
                # Try to refresh the token
                response = getUrl(
                    PROXY_REFRESH_URL, timeout=5)
                if response:
                    data = loads(ensure_str(response))
                    if data.get("status") == "success":
                        self.session.open(
                            MessageBox,
                            _("Proxy token refreshed successfully"),
                            MessageBox.TYPE_INFO,
                            timeout=3
                        )
                        self._update_proxy_status_display()
                    else:
                        self.session.open(
                            MessageBox,
                            _("Failed to refresh proxy token"),
                            MessageBox.TYPE_ERROR,
                            timeout=3
                        )
            except Exception as e:
                print("[Refresh Proxy] Error: " + str(e))
                self.session.open(
                    MessageBox,
                    _("Failed to refresh proxy: ") + str(e),
                    MessageBox.TYPE_ERROR,
                    timeout=3
                )

    def _check_update_popup_tick(self):
        """Poll for the background update check (kicked off during the
        splash screen by _start_update_check()) to finish, then show the
        popup - once per launch, and only if an actual update is found -
        now that the main menu is open. Silent otherwise: no "already
        latest" / "check failed" noise on every plugin start.
        """
        global _update_popup_shown
        if not _update_check_done:
            return
        self._update_popup_timer.stop()
        if _update_popup_shown:
            print("[Update] Popup tick fired but popup already shown - skipping")
            return
        _update_popup_shown = True

        remote_version, changelog, content = _update_check_result or (
            None, None, None)
        newer = bool(remote_version) and is_remote_version_newer(
            __version__, remote_version)
        print("[Update] Popup tick: local=v{} remote={} newer={}".format(
            __version__, remote_version, newer))
        if not newer:
            return
        print("[Update] Opening update popup")

        # Stashed for _on_update_confirmed() so a Yes doesn't need a
        # second fetch of the same file.
        self._pending_installer_content = content
        try:
            self.session.openWithCallback(
                self._on_update_confirmed,
                UpdatePopup,
                remote_version,
                changelog
            )
        except Exception as e:
            # UpdatePopup's skin file may be missing/corrupt on this
            # install (e.g. a manually-deployed copy that skipped the
            # skin/ folder) - fall back to a plain MessageBox rather than
            # taking down the main menu over a cosmetic dialog.
            print(
                "[Update] UpdatePopup failed to open ({}), falling back to MessageBox".format(e))
            message = _("New version available: v{}").format(remote_version)
            message += "\n" + _("(you have v{})").format(__version__)
            if changelog:
                message += "\n\n" + _("Changelog:") + "\n" + changelog
            message += "\n\n" + _("Update now?")
            self.session.openWithCallback(
                self._on_update_confirmed,
                MessageBox,
                message,
                MessageBox.TYPE_YESNO,
                default=False
            )

    def _on_update_confirmed(self, result):
        content = getattr(self, '_pending_installer_content', None)
        self._pending_installer_content = None
        if not result or not content:
            return

        installer_path = "/tmp/vavoo_installer_update.sh"
        try:
            with open(installer_path, 'w') as f:
                f.write(content)
        except Exception as e:
            print("[MainVavoo] Error writing installer script: " + str(e))
            self.session.open(
                MessageBox,
                _("Could not save the installer script."),
                MessageBox.TYPE_ERROR,
                timeout=5
            )
            return

        self.session.open(
            Console,
            title=_("Updating Vavoo Stream Live..."),
            cmdlist=["chmod +x '{0}' && '{0}'".format(installer_path)]
        )

    def start_vavoo_proxy(self):
        # If the proxy is already active and working, do nothing
        if is_proxy_running() and is_proxy_ready(timeout=1):
            print("[MainVavoo] Proxy already ready")
            self._update_proxy_status_display()
            return True

        # If it is running but not ready, let it stabilize
        if is_proxy_running():
            print("[MainVavoo] Proxy running but not ready, waiting...")
            self._wait_for_proxy()
            return True

        print("[MainVavoo] Starting proxy...")
        success = run_proxy_in_background()
        if success:
            self._wait_for_proxy()
        return success

    def _wait_for_proxy(self, attempts=0):
        if self._closed:
            return
        # ConfigSelectionNumber.value has been confirmed (via a user log)
        # to come back as a str rather than an int on at least some
        # images/Python versions - "str" * 2 doesn't raise, it silently
        # repeats the string ("30" -> "3030"), which then compares
        # against attempts (always an int) in a way that never behaves
        # as the intended numeric timeout.
        try:
            timeout_secs = int(cfg.proxy_startup_timeout.value)
        except (TypeError, ValueError):
            timeout_secs = 30
        max_attempts = timeout_secs * 2   # ogni 0.5 sec
        if attempts > max_attempts:
            print(
                "[MainVavoo] Proxy not ready after {} seconds".format(timeout_secs))
            return
        if is_proxy_ready(timeout=0.5):
            print("[MainVavoo] Proxy ready")
            self._update_proxy_status_display()
        else:
            reactor.callLater(0.5, lambda: self._wait_for_proxy(attempts + 1))

    def _restart_proxy(self):
        """Restart the proxy without blocking the GUI - stopping the
        old one, waiting for its port and starting the new one all
        happen in vavoo_proxy's own helper thread."""
        try:
            restart_proxy_in_background()
        except Exception as e:
            print("[Restart] Error: {0}".format(e))

    def cat(self):
        """
        Load and display the country list.
        Uses the local proxy if available, otherwise waits and retries.
        """
        self.cat_list = []
        self.items_tmp = []

        # If proxy is not ready yet, schedule a quick retry. "Booting"
        # counts as not ready even while the port still answers: right
        # after a restart was requested (e.g. a changed catalog source
        # in the settings), the old proxy keeps serving its old
        # catalog for a moment before it goes down.
        if is_proxy_booting() or not is_proxy_ready(timeout=0.5):
            print("[MainVavoo] Proxy not ready, will retry shortly")
            self._retry_cat_later()
            return

        # getUrl() below can block for tens of seconds (default
        # retries=3 with backoff) on a slow/unresponsive proxy -
        # fetch it off the GUI/reactor thread (same pattern
        # _fetch_countries_async() already proves out for the M3U
        # wizard) so a flaky proxy can't freeze the whole box while
        # the main menu is loading, same as every other screen opening
        # for the first time.
        def _task():
            if self._closed:
                return
            exc = None
            response = None
            try:
                response = getUrl(PROXY_COUNTRIES_URL, timeout=10)
            except Exception as e:
                exc = e
            if self._closed:
                return
            reactor.callFromThread(self._on_countries_response, response, exc)

        t = threading.Thread(target=_task)
        t.daemon = True
        t.start()

    def _retry_cat_later(self):
        """Run cat() again in 500ms (single shot)."""
        if not hasattr(self, '_country_retry_timer'):
            self._country_retry_timer = eTimer()
            try:
                self._country_retry_timer.callback.append(self.cat)
            except Exception:
                # Fallback in case the callback attribute does not exist
                self._country_retry_timer.timeout.connect(self.cat)
        self._country_retry_timer.start(500, True)

    def _on_countries_response(self, response, exc):
        if self._closed:
            return
        try:
            if exc is not None:
                raise exc
            if response:
                countries = loads(ensure_str(response))
                print(
                    "[MainVavoo] Got {} countries from proxy".format(
                        len(countries)))
                for country in sorted(countries):
                    self.cat_list.append(show_list(country, country))
                self._update_ui()
                self["version"].setText(to_string("V." + __version__))
                self._country_load_failures = 0
                # Clear the retry timer if it exists
                if hasattr(self, '_country_retry_timer'):
                    self._country_retry_timer.stop()
                    del self._country_retry_timer
                return
            else:
                # The proxy is the only source of the country list -
                # ask it again a few times before giving up. (This
                # used to fall back to vavoo.to/kool.to's old
                # "/channels" listing, which no longer exists - both
                # answer 404 - so all it did was add ~10 seconds
                # before showing nothing.)
                self._country_load_failures += 1
                print("[MainVavoo] Proxy countries request failed "
                      "(attempt {})".format(self._country_load_failures))
                if self._country_load_failures < 5:
                    self._retry_cat_later()
                else:
                    self._country_load_failures = 0
                    self["name"].setText(
                        _("Could not load the country list from the proxy"))
        except Exception as e:
            print("[MainVavoo] Error in cat(): %s" % str(e))
            trace_error()
            self["name"].setText(to_string("Error loading data"))

    def ok(self):
        try:
            current_item = self['menulist'].getCurrent()
            if not current_item or len(current_item) == 0:
                print("DEBUG: No current item selected or item is empty")
                return

            name = current_item[0][0]  # Country name (e.g., "Italy")
            print("[MainVavoo] Selected: " + str(name))

            _require_parental_pin(
                self.session, self, name,
                lambda: self._open_country(name))

        except Exception as e:
            print("Error in ok method: " + str(e))
            trace_error()

    def _open_country(self, name):
        # Pass ONLY the country name to the vavoo class
        # The vavoo class will handle the proxy internally
        try:
            if not is_proxy_running():
                self.session.open(
                    MessageBox,
                    _("Proxy is not running. Please start the proxy first.") +
                    "\n" +
                    _("You can start it from the menu or by pressing the TEXT button."),
                    MessageBox.TYPE_WARNING,
                    timeout=5)
                return

            # Pass ONLY the country name to the vavoo class
            self.session.open(vavoo, name, None)
        except Exception as e:
            print("Error opening vavoo screen: " + str(e))
            trace_error()

    def manual_epg_update(self):
        """Manually trigger EPG update"""
        if not cfg.epg_enabled.value:
            self.session.open(
                MessageBox,
                _("EPG is disabled. Please enable it in Vavoo settings first."),
                MessageBox.TYPE_INFO)
            return

        # Check if Vavoo EPG source file exists
        vavoo_sources = "/etc/epgimport/vavoo.sources.xml"
        if not isfile(vavoo_sources):
            self.session.open(
                MessageBox,
                _("Vavoo EPG source not found. Please export at least one bouquet first."),
                MessageBox.TYPE_INFO)
            return

        # Check if the source is enabled in EPGImport config. EPGIMPORT_CONF
        # is a binary serialized blob (EPGImport's own internal format, not
        # plain text), so it can't be read line-by-line, and it never
        # contains the source's filename ("vavoo.sources.xml") - EPGImport
        # records each enabled source by its <description> text instead,
        # which for every Vavoo-generated source starts with "Vavoo "
        # (write_epg_mapping_file() / update_epg_sources() in vUtils.py).
        # A raw substring search for that prefix is format-agnostic and
        # works regardless of the underlying serialization.
        source_enabled = False
        if isfile(EPGIMPORT_CONF):
            try:
                with open(EPGIMPORT_CONF, 'rb') as f:
                    source_enabled = b'Vavoo' in f.read()
            except Exception as e:
                print("[EPG] Error reading epgimport.conf: {}".format(e))

        if not source_enabled:
            self.session.open(
                MessageBox,
                _("Vavoo EPG source is not enabled in EPGImport. Please enable it in EPGImport settings."),
                MessageBox.TYPE_WARNING,
                timeout=5)
            return

        self.session.openWithCallback(
            self._epg_update_callback,
            MessageBox,
            _("Start EPG update now?"),
            MessageBox.TYPE_YESNO
        )

    def _epg_update_callback(self, answer):
        if not answer:
            return
        # There is no "epgimport" CLI binary on a normal Enigma2 image -
        # EPGImport is a GUI plugin, not a command-line tool, and
        # EPGImport.EPGImport itself isn't a Screen either - it's a plain
        # importer class. Plugins/Extensions/EPGImport/plugin.py (every
        # Enigma2 plugin has a lowercase plugin.py as its required entry
        # point) keeps a module-level startImport() that's the exact same
        # function EPGImport's own UI button calls, using a
        # already-constructed singleton importer - calling it directly
        # runs a real import with no screen/dialog of ours or theirs
        # involved. It kicks off its own async work (threads/reactor)
        # internally, same as EPGImport's own button does, so this can be
        # called directly from here without our own threading.
        try:
            from Plugins.Extensions.EPGImport.plugin import (
                epgimport, startImport, CONFIG_PATH)
            from Plugins.Extensions.EPGImport import EPGConfig
            if epgimport.isImportRunning():
                if NOTIFICATION_AVAILABLE:
                    quick_notify(_("EPG import already running"), 3)
                return
            # epgimport.beginImport() (called by startImport()) requires
            # epgimport.sources to already be populated - its own
            # docstring says so ("Set self.sources before calling
            # this"). EPGImport's own UI only ever calls startImport()
            # from EPGImportConfig.doimport(), which builds that list
            # from the user's enabled-sources settings first; calling
            # startImport() directly skips that step, so with an empty
            # source list nextImport() just closes the import right
            # away - "0 events imported" with no error, since nothing
            # was actually queued to import in the first place.
            epg_user_cfg = EPGConfig.loadUserSettings()
            sources = list(
                EPGConfig.enumSources(
                    CONFIG_PATH, filter=epg_user_cfg["sources"]))
            if not sources:
                self.session.open(
                    MessageBox,
                    _("No active EPG sources found in EPGImport. "
                      "Please enable the Vavoo source in EPGImport settings."),
                    MessageBox.TYPE_INFO,
                    timeout=5)
                return
            sources.reverse()
            epgimport.sources = sources
            startImport()
            if NOTIFICATION_AVAILABLE:
                quick_notify(_("EPG import started"), 3)
        except ImportError as e:
            print("[Vavoo] EPG update error:", str(e))
            self.session.open(
                MessageBox,
                _("EPGImport plugin not found: {}").format(str(e)),
                MessageBox.TYPE_ERROR)
        except Exception as e:
            print("[Vavoo] EPG update error:", str(e))
            self.session.open(
                MessageBox, _("Error starting EPG update: {}").format(
                    str(e)), MessageBox.TYPE_ERROR)

    def msgdeleteBouquets(self):
        message_parts = []
        message_parts.append(_("Remove ALL Vavoo bouquets?"))
        message_parts.append(_("This will remove:"))
        message_parts.append(_("- Country bouquets"))
        message_parts.append(_("- Category bouquets"))
        message_parts.append(_("- Container bouquets"))
        message = "\n".join(message_parts)

        self.session.openWithCallback(
            self.deleteBouquets,
            MessageBox,
            message,
            MessageBox.TYPE_YESNO,
            timeout=10,
            default=True)

    def deleteBouquets(self, result):
        """Delete all Vavoo bouquets"""
        if result:
            # Same lock message2()'s export uses - deleting every bouquet
            # while an export's background thread is still writing one of
            # them can corrupt it.
            if not export_lock.acquire(False):
                if NOTIFICATION_AVAILABLE:
                    quick_notify(
                        _("An export for another country is already in progress. Please wait."), 4)
                return
            try:
                removed_count = remove_bouquets_by_name()

                # Remove Favorite.txt
                favorite_path = join(PLUGIN_PATH, 'Favorite.txt')
                if isfile(favorite_path):
                    remove(favorite_path)
                    print("✓ Removed Favorite.txt")

                # Build message safely for translation
                message = _("Vavoo bouquets removed successfully!")
                message += "\n"
                message += _("(%s files deleted)") % removed_count

                self.session.open(
                    MessageBox,
                    message,
                    MessageBox.TYPE_INFO,
                    timeout=5
                )
                try:
                    db = eDVBDB.getInstance()
                    db.reloadBouquets()
                    db.reloadServicelist()
                    print("Bouquets reloaded successfully")
                except Exception as e:
                    print("Error during service reload: " + str(e))
                    ReloadBouquets(500)

            except Exception as e:
                print("Error in deleteBouquets: " + str(e))
            finally:
                export_lock.release()

    def goConfig(self):
        self.session.openWithCallback(self._on_config_closed, vavoo_config)

    def _on_config_closed(self, *args, **kwargs):
        """Back from the settings screen: make sure the proxy is up,
        restart the status timers and reload the country list (the
        catalog source may have changed)."""
        try:
            self.start_vavoo_proxy()
            self.proxy_watchdog_timer.start(PROXY_WATCHDOG_INTERVAL_MS)
            self.proxy_monitor_timer.start(PROXY_MONITOR_INTERVAL_MS)

            self["proxy_status"].setText(_("Checking proxy..."))
            try:
                self._update_proxy_status_display()
            except Exception as e:
                debug("_update_proxy_status_display failed, label may "
                      "stay stuck on 'Checking proxy...': {}".format(e))

            self.cat()
        except Exception as e:
            print("[MainVavoo] Error refreshing after settings: " + str(e))

    def info(self):
        """Display plugin information"""
        message_parts = []
        message_parts.append(_("Vavoo Stream Live Plugin"))
        message_parts.append("=" * 40)

        message_parts.append(_("Version: ") + str(__version__))
        message_parts.append(_("Author: ") + str(__author__))
        message_parts.append(_("License: ") + str(__license__))
        message_parts.append("")

        message_parts.append(_("Technical Features:"))
        message_parts.append(_("- HTTP Live Streaming"))
        message_parts.append(_("- TS/M3U8 formats"))
        message_parts.append(_("- Service references: 4097, 5001, 5002"))
        message_parts.append(_("- Automatic bouquet generation"))
        message_parts.append(
            _("- Automatic Epg generation with Service Reference"))
        message_parts.append(_("- Integrated proxy system"))
        message_parts.append(_("- Auto token refresh every 9 minutes"))
        message_parts.append("")

        message_parts.append(_("Credits:"))
        message_parts.append(_("- Graphics: @oktus"))
        message_parts.append(
            _("- Technical support: Qu4k3, @KiddaC, @giorbak"))
        message_parts.append(
            _("- Community: Linuxsat-support.com, Corvoboys.org Forum"))
        message_parts.append("")

        message_parts.append(_("Important Notes:"))
        message_parts.append(_("- Free content only"))
        message_parts.append(_("- Streams from public sources"))
        message_parts.append(_("- No direct server hosting"))
        message_parts.append("")

        message_parts.append(_("License: CC BY-NC-SA 4.0"))
        message_parts.append(_("- Redistribution must maintain attribution"))
        message_parts.append(_("- Commercial use is strictly prohibited"))

        info_text = "\n".join(message_parts)

        aboutbox = self.session.open(
            MessageBox,
            info_text,
            MessageBox.TYPE_INFO
        )
        aboutbox.setTitle(_('Vavoo Stream Live - Information'))

    def chUp(self):
        """Handle page up and update name"""
        try:
            if self.cat_list:
                self['menulist'].pageUp()
                print("DEBUG chUp: " + self['name'].getText())
        except Exception as e:
            print("Error in chUp:", e)

    def chDown(self):
        """Handle page down and update name"""
        try:
            if self.cat_list:
                self['menulist'].pageDown()
                print("DEBUG chDown: " + self['name'].getText())
        except Exception as e:
            print("Error in chDown:", e)

    def moveUp(self):
        """Move selection up, wrapping from the first entry to the last."""
        if not self.cat_list:
            return
        idx = self['menulist'].getSelectedIndex()
        self['menulist'].moveToIndex((idx - 1) % len(self.cat_list))

    def moveDown(self):
        """Move selection down, wrapping from the last entry to the first."""
        if not self.cat_list:
            return
        idx = self['menulist'].getSelectedIndex()
        self['menulist'].moveToIndex((idx + 1) % len(self.cat_list))

    def _update_ui(self):
        """Update the UI with current list"""
        try:
            if self.cat_list and len(self.cat_list) > 0:
                self["menulist"].l.setList(self.cat_list)
                self._update_selection_name()
            else:
                self["name"].setText(_("No items available"))
                self.cat_list = []
        except Exception as e:
            print("Error updating UI:", e)
            self["name"].setText(_("Error"))
            self.cat_list = []

    def _update_selection_name(self):
        """Update the name label with current selection"""
        try:
            current = self['menulist'].getCurrent()
            if current and len(current) > 0:
                name = current[0][0]
                self['name'].setText(to_string(name))
                print("MainVavoo _update_selection_name: " + to_string(name))
            else:
                self['name'].setText(_("No selection"))  # fallback
        except Exception as e:
            print("Error in MainVavoo _update_selection_name:", e)
            self['name'].setText(_("Error"))


class vavoo(Screen):
    def __init__(self, session, name, url, option_value=None):
        self.session = session
        global _session
        _session = session

        # So a bouquet-export background thread still running when the
        # user exits this screen (Screen.close() doesn't clear
        # self.session, so that alone can't be used to detect this) can
        # notice and skip touching this screen's UI/state afterward.
        self._closed = False

        Screen.__init__(self, session)
        init_notification_system(session)
        self._load_skin()
        self._initialize_labels()
        self._initialize_actions()
        self["menulist"].onSelectionChanged.append(self._update_selection_name)
        self.currentList = 'menulist'

        # Store country name properly
        self.country_name = name
        self.name = name
        self.url = url
        self.option_value = option_value
        self._update_export_button_label()

        # (name, url, logo_url) per currently-listed channel, parallel
        # to cat_list - lets _refresh_channel_list_with_picons()
        # rebuild the list once more picons have been cached, without
        # re-fetching the channel data over the network.
        self._channel_entries = []
        self.picon_refresh_timer = eTimer()
        try:
            self.picon_refresh_timer.callback.append(
                self._refresh_channel_list_with_picons)
        except Exception:
            self.picon_refresh_timer.timeout.connect(
                self._refresh_channel_list_with_picons)

        # Do NOT try to initialize proxy here - it should already be running
        # Just verify it's ready
        self._verify_proxy_ready()

        self._initialize_timer()
        self._initialize_proxy_status_timer()

    def _initialize_proxy_status_timer(self):
        """Keep the proxy_status label live while this screen is open.

        Unlike MainVavoo (which refreshes every 10s via
        proxy_monitor_timer), this screen previously only set the label
        once in _verify_proxy_ready() and never again, so it went stale
        the moment the user opened a country.
        """
        self.proxy_status_timer = eTimer()
        try:
            self.proxy_status_timer.timeout.connect(
                self._update_proxy_status_display)
        except BaseException:
            self.proxy_status_timer.callback.append(
                self._update_proxy_status_display)
        self.proxy_status_timer.start(10000)

    def _verify_proxy_ready(self):
        """Verify that the proxy is ready without attempting to start it"""
        try:
            if not is_proxy_ready(timeout=2):
                print(
                    "[vavoo] Warning: Proxy not ready for %s" %
                    self.country_name)
                # Do not start the proxy here – let the cat() method handle the
                # fallback
            self["proxy_status"].setText(_("Checking proxy..."))
            try:
                self._update_proxy_status_display()
            except Exception as e:
                debug("_update_proxy_status_display failed, label may "
                      "stay stuck on 'Checking proxy...': {}".format(e))
        except Exception as e:
            print("[vavoo] Error checking proxy: %s" % str(e))

    def _load_skin(self):
        """Load the skin file."""
        skin = join(skin_path, 'defaultListScreen.xml')
        if isfile('/var/lib/dpkg/status'):
            skin = skin.replace('.xml', '_cvs.xml')
        with codecs.open(skin, "r", encoding="utf-8") as f:
            self.skin = apply_selected_background(f.read())

    def _initialize_labels(self):
        """Initialize the labels on the screen."""
        self.menulist = []
        self['menulist'] = m2list([])
        self['red'] = Label(_('Back'))
        self['green'] = Label(_('Export') + ' Fav')
        self['yellow'] = Label(_('Search'))
        self["blue"] = Label(_('Reload Bouqet'))
        self['name'] = Label('Loading ...')
        self['version'] = Label()
        self["version"].setText(to_string("V." + __version__))
        self['proxy_status'] = Label('...')

    def _initialize_actions(self):
        """Initialize the actions for buttons."""
        self["actions"] = ActionMap(
            [
                'MenuActions',
                'OkCancelActions',
                'ButtonSetupActions',
                'InfobarEPGActions',
                'EPGSelectActions',
                'ColorActions',
                'DirectionActions'
            ],
            {
                "prevBouquet": self.chDown,
                "nextBouquet": self.chUp,
                "up": self.moveUp,
                "down": self.moveDown,
                "ok": self.ok,
                "green": self.message1,
                "yellow": self.search_vavoo,
                "blue": self.reload_bouquets_with_popup,
                "cancel": self.backhome,
                "menu": self.goConfig,
                "info": self.toggle_favourite,
                "red": self.backhome
            },
            -1
        )

    def _initialize_timer(self):
        """Initialize the timer with proper timeout handling"""
        self.timer = eTimer()
        try:
            self.timer.callback.append(self.cat)
        except BaseException:
            self.timer.timeout.connect(self.cat)
        self.timer.start(500, True)

    def cat(self):
        """Load this country's channels from the proxy.

        The fetch is a blocking getUrl() call and this runs from a
        GUI-thread eTimer every time a country is opened, so it runs
        in a background thread (same pattern _fetch_countries_async()
        already proves out for the M3U wizard) and only the actual
        list-building is marshalled back to the reactor thread.

        The proxy is the only source there is: a slow or empty answer
        is simply asked for again (CHANNEL_FETCH_ATTEMPTS short tries
        instead of one long one - a healthy proxy answers this from
        memory in milliseconds, so a try that hasn't answered within
        a few seconds isn't going to). This used to give up after a
        single 10-second timeout and fall back to vavoo.to/kool.to's
        old "/channels" listing, which no longer exists (both answer
        404) - so one hiccup cost about 20 seconds and ended on an
        empty screen, where simply asking again would have worked.
        """
        debug("vavoo.cat() called for country: " + str(self.country_name))

        def _task():
            if self._closed:
                return
            try:
                country_encoded = url_quote(self.country_name)
                proxy_url = PROXY_BASE_URL + \
                    "/channels?country={}".format(country_encoded)

                channels_data = None
                for attempt in range(CHANNEL_FETCH_ATTEMPTS):
                    if self._closed:
                        return
                    debug("Fetching from proxy: " + proxy_url)
                    try:
                        content = ensure_str(
                            getUrl(proxy_url, timeout=5, retries=1))
                        if content and content.strip() and content != "null":
                            channels_data = loads(content)
                            break
                    except Exception as proxy_error:
                        debug("[cat] Proxy error: " + str(proxy_error))
                    print("[vavoo] No channel list from proxy (attempt "
                          "{}/{})".format(attempt + 1, CHANNEL_FETCH_ATTEMPTS))
                    if attempt < CHANNEL_FETCH_ATTEMPTS - 1:
                        time.sleep(1)

                if self._closed:
                    return
                if channels_data is None:
                    reactor.callFromThread(self._on_channels_unavailable)
                else:
                    reactor.callFromThread(
                        self._build_channel_list, channels_data)

            except Exception as e:
                print("[ERROR] CRITICAL in cat(): " + str(e))
                trace_error()
                if not self._closed:
                    reactor.callFromThread(self._handle_cat_error, e)

        t = threading.Thread(target=_task)
        t.daemon = True
        t.start()

    def _on_channels_unavailable(self):
        """cat() got nothing from the proxy after all its tries."""
        if self._closed:
            return
        self['name'].setText(
            _("Could not load channels - proxy not responding"))

    def _build_channel_list(self, channels_data):
        """Build channel list from proxy data"""
        # cat()'s background _task() already checks self._closed before
        # scheduling this via reactor.callFromThread, but that only
        # queues the call - the user can still press Back/Cancel (which
        # sets self._closed and tears the screen down) in the gap
        # before the reactor actually runs it. Every sibling path that
        # can land here the same way (_on_channels_unavailable(),
        # MainVavoo._on_countries_response()) already re-checks this as
        # its first line - this one was missing it.
        if self._closed:
            return
        self.cat_list = []
        self._channel_entries = []

        if not isinstance(channels_data, list):
            print("[vavoo] Invalid channels data type: " +
                  str(type(channels_data)))
            return

        for channel in channels_data:
            if isinstance(channel, dict):
                channel_name = channel.get("name", "Unknown")
                channel_url = channel.get("url", "")
                # Already fixed up (Geil/Vavoo) by our own proxy's
                # /channels endpoint - no need to run it through
                # fix_logo_url() again here.
                logo = channel.get("logo", "")

                self._channel_entries.append(
                    (channel_name, channel_url, logo))
                self.cat_list.append(
                    show_list(
                        channel_name, channel_url, is_channel=True,
                        logo_url=logo)
                )

        if not self.cat_list:
            self['name'].setText(to_string("No proxy URLs built."))
            return

        self.itemlist = [
            item[0][0] + "###" + item[0][1] for item in self.cat_list
        ]
        self.update_menu()
        self._preload_channel_picons()
        debug("List built with " + str(len(self.cat_list)) + " items.")

    def _preload_channel_picons(self):
        """Download picons for this country's channel list in the
        background (see show_list()'s logo_url handling), then
        refresh the list once they land.

        Entirely on a background thread, including the first batch -
        this runs right after _build_channel_list() on the
        GUI/reactor thread itself, so a
        synchronous network call here would block the UI exactly the
        way this session's getUrl()-on-the-GUI-thread fixes were
        about avoiding. Downloads a first batch and refreshes the
        list so the visible screenful gets its picons quickly, then
        keeps going through the rest with one final refresh.
        """
        entries = [
            entry for entry in self._channel_entries if entry[2]
        ]
        if not entries:
            return

        first_batch_size = 20

        def _download_batch(batch):
            count = 0
            for name, url, logo in batch:
                if self._closed:
                    break
                try:
                    success, _unused = download_picon_online(logo)
                    if success:
                        count += 1
                except Exception as e:
                    debug("Picon download failed for {}: {}".format(
                        name, e))
            return count

        def _worker():
            first = _download_batch(entries[:first_batch_size])
            if first > 0 and not self._closed:
                reactor.callFromThread(
                    self.picon_refresh_timer.start, 500, True)
            if len(entries) > first_batch_size and not self._closed:
                rest = _download_batch(entries[first_batch_size:])
                if rest > 0 and not self._closed:
                    reactor.callFromThread(
                        self.picon_refresh_timer.start, 500, True)

        t = threading.Thread(target=_worker)
        t.daemon = True
        t.start()

    def _refresh_channel_list_with_picons(self):
        """Rebuild the channel list from the already-fetched channel
        data (no new network fetch) so rows whose picon finished
        downloading since the list was first built pick it up."""
        self.picon_refresh_timer.stop()
        if self._closed or not self._channel_entries:
            return
        try:
            # setList() below replaces the whole list - preserve
            # wherever the user had scrolled to instead of silently
            # snapping back to the top under them.
            try:
                selected_index = self['menulist'].getSelectedIndex()
            except Exception:
                selected_index = None

            self.cat_list = [
                show_list(name, url, is_channel=True, logo_url=logo)
                for name, url, logo in self._channel_entries
            ]
            self.itemlist = [
                item[0][0] + "###" + item[0][1] for item in self.cat_list
            ]
            self.update_menu()

            if selected_index is not None and self.cat_list:
                try:
                    self['menulist'].moveToIndex(
                        min(selected_index, len(self.cat_list) - 1))
                except Exception:
                    pass
        except Exception as e:
            print("[vavoo] Error refreshing picon list: %s" % str(e))

    def _handle_cat_error(self, e):
        """Handle cat() method errors"""
        print("[vavoo] Handling cat error: " + str(e))
        self['name'].setText(to_string("Error: " + str(e)))

        # Show message to user
        try:
            self.session.open(
                MessageBox,
                "Error loading channels: " + str(e)[:100],
                MessageBox.TYPE_ERROR,
                timeout=5
            )
        except Exception:
            pass

    def _update_proxy_status_display(self):
        """Internal method to update proxy status display"""
        _shared_update_proxy_status_display(self)

    def reload_bouquets_with_popup(self):
        """Reload bouquets with confirmation popup"""
        _shared_reload_bouquets_with_popup(self)

    def _confirm_reload_bouquets(self, result):
        """Callback after user confirmation"""
        _shared_confirm_reload_bouquets(self, result)

    def ok(self):
        try:
            i = self['menulist'].getSelectedIndex()
            self.currentindex = i
            selection = self['menulist'].l.getCurrentSelection()
            if selection is not None:
                item = self.cat_list[i][0]
                name = item[0]
                url = item[1]
            else:
                print("No selection available")
                return

            # Parallel to cat_list (see _channel_entries' own
            # declaration comment) - lets Playstream2 show this
            # channel's picon on its playback overlay without a
            # second network fetch, the same way country_codes lets
            # it keep EPG lookups matched to the right country.
            logo_urls = [entry[2] for entry in self._channel_entries]
            logo_url = (
                self._channel_entries[i][2]
                if 0 <= i < len(self._channel_entries) else None)

            self.play_that_shit(
                url,
                name,
                self.currentindex,
                item,
                self.cat_list,
                logo_url,
                logo_urls)
        except Exception as e:
            print('error as:', e)
            trace_error()

    def play_that_shit(
            self, url, name, index, item, cat_list,
            logo_url=None, logo_urls=None):
        try:
            country_code = get_country_code(self.country_name)
            self.session.open(
                Playstream2,
                name, url, index, item, cat_list,
                country_code=country_code,
                logo_url=logo_url,
                logo_urls=logo_urls
            )
        except Exception as e:
            print("Error in play_that_shit: {}".format(e))
            trace_error()
            self.session.open(
                MessageBox,
                _("Error starting channel"),
                MessageBox.TYPE_ERROR,
                timeout=3
            )

    def toggle_favourite(self):
        """Star/unstar the highlighted channel - same selection lookup
        ok() uses, bound to the 'info' key (free in this screen: no
        info() method exists here, unlike MainVavoo's unrelated one)."""
        try:
            i = self['menulist'].getSelectedIndex()
            selection = self['menulist'].l.getCurrentSelection()
            if selection is None:
                return
            item = self.cat_list[i][0]
            name = item[0]
            url = item[1]
        except Exception as e:
            print('[vavoo] toggle_favourite selection error:', e)
            return

        now_favourite = vUtils.toggle_favourite(
            name, url,
            country_name=self.country_name,
            country_code=get_country_code(self.country_name))
        if now_favourite is None:
            if NOTIFICATION_AVAILABLE:
                quick_notify(_("Could not update favourites"), 3)
            return
        if NOTIFICATION_AVAILABLE:
            if now_favourite:
                quick_notify(_("Added to favourites: {}").format(name), 3)
            else:
                quick_notify(_("Removed from favourites: {}").format(name), 3)

    def _update_export_button_label(self):
        """Green button reads 'Remove Fav' if this bouquet is already
        exported, 'Export Fav' otherwise."""
        try:
            if is_bouquet_exported(self.name):
                self['green'].setText(_('Remove') + ' Fav')
            else:
                self['green'].setText(_('Export') + ' Fav')
        except Exception as e:
            debug("_update_export_button_label failed: {}".format(e))

    def message1(self, answer=None):
        """Green button: export this bouquet, or offer to remove it if
        it's already exported."""
        if is_bouquet_exported(self.name):
            self.session.openWithCallback(
                self._confirm_remove_fav,
                MessageBox,
                _("Remove the exported bouquet for this country/category?") +
                "\n" + self.name,
                MessageBox.TYPE_YESNO
            )
        else:
            # Show confirmation message before export
            self.session.openWithCallback(
                self._confirm_export_fav,
                MessageBox,
                _("Do you want to export this bouquet?") + "\n" + self.name,
                MessageBox.TYPE_YESNO
            )

    def _confirm_export_fav(self, answer):
        if answer is True:
            self.message2(self.name, self.url, True)
        else:
            print("Export cancelled by user")

    def _confirm_remove_fav(self, answer):
        if not answer:
            print("Remove favorite cancelled by user")
            return
        # Same lock message2()'s export uses - removing a bouquet while
        # its own (or another country's) export background thread is
        # still writing the same files/Favorite.txt can corrupt them.
        if not export_lock.acquire(False):
            if NOTIFICATION_AVAILABLE:
                quick_notify(
                    _("An export for another country is already in progress. Please wait."), 4)
            return
        try:
            removed = remove_bouquets_by_name(self.name)
            if removed > 0:
                remove_favorite_entry(self.name)
                if NOTIFICATION_AVAILABLE:
                    quick_notify(
                        _("Removed exported bouquet: {}").format(self.name), 3)
                self._confirm_reload_bouquets(True)
            else:
                if NOTIFICATION_AVAILABLE:
                    quick_notify(
                        _("Nothing to remove for: {}").format(
                            self.name), 3)
        except Exception as e:
            print("[vavoo] Error removing favorite: {}".format(e))
            if NOTIFICATION_AVAILABLE:
                quick_notify(_("Remove failed: {}").format(str(e)), 4)
        finally:
            export_lock.release()
        self._update_export_button_label()

    def message2(self, name, url, response):
        # threading.Lock.acquire() only accepts blocking as a
        # positional argument on Python 2 (the C implementation there
        # doesn't support keyword arguments at all) - acquire(False)
        # works identically on both Python 2 and 3.
        if not export_lock.acquire(False):
            if NOTIFICATION_AVAILABLE:
                quick_notify(
                    _("An export for another country is already in progress. Please wait."), 4)
            return

        self._export_type = "hierarchical" if any(
            sep in name for sep in GROUP_NAME_SEPARATORS) else "flat"

        try:
            export_bouquet_async(
                name,
                self._export_type,
                self,
                self._on_export_complete,
                cfg.services.value,
                cfg.list_position.value,
                lock=export_lock)
            if NOTIFICATION_AVAILABLE:
                quick_notify(
                    _("Export started. Bouquet will be available shortly."), 3)

        except Exception as e:
            export_lock.release()
            if NOTIFICATION_AVAILABLE:
                quick_notify(_("Bouquet creation error: {}").format(str(e)), 5)

    def _on_export_complete(self, success, ch_count, message):
        """Callback for bouquet export completion"""
        debug(
            "_on_export_complete CALLED - success=%s, ch_count=%s, message='%s'" %
            (success, ch_count, message))

        try:
            if not success:
                # Export failed
                if NOTIFICATION_AVAILABLE:
                    quick_notify(_("Export failed: {}").format(message), 5)
                return

            # Success - two cases:
            if message == "Bouquet created":
                # First callback - base bouquet ready
                debug("Bouquet ready with {} channels".format(ch_count))
                if NOTIFICATION_AVAILABLE:
                    quick_notify(
                        _("Bouquet ready with {} channels").format(ch_count), 3)
                # Notifying is fine even if the user has since left this
                # screen (quick_notify() is session-global), but touching
                # this screen's own widgets after close() is not.
                if not self._closed:
                    self._update_export_button_label()
                # Register with Favorite.txt so "Scheduled List" auto-update
                # (AutoStartTimer) picks this bouquet up going forward -
                # that feature only ever re-updates bouquets already listed
                # there, it never adds new ones on its own.
                try:
                    _update_favorite_file(
                        self.name, self.url,
                        getattr(self, '_export_type', 'flat'))
                except Exception as e:
                    print("[vavoo] Error updating Favorite.txt: {}".format(e))

            elif message == "EPG processing completed":
                # Second callback - EPG completed
                debug("EPG completed for {} channels".format(ch_count))
                if NOTIFICATION_AVAILABLE:
                    if ch_count > 0:
                        quick_notify(
                            _("EPG processing completed for {} channels").format(ch_count), 4)
                    else:
                        quick_notify(
                            _("EPG processing completed (no matches)"), 3)

            else:
                # Other messages
                debug("Export completed: {}".format(message))
                if NOTIFICATION_AVAILABLE:
                    quick_notify(message, 3)

        except Exception as e:
            # Intentionally swallowed so a UI-touching failure here (e.g.
            # _update_export_button_label() on a screen the user has
            # since left) can't crash the export callback - but that
            # means it's log-only, with no user-visible indication.
            print("[Bouquet] Error in _on_export_complete: %s" % e)

    def search_vavoo(self):
        self.session.openWithCallback(
            self.onSearchResult, VavooSearch, self, self.itemlist)

    def onSearchResult(self, selected_item=None):
        """Callback with the channel selected by the search"""
        if selected_item:
            name, url = selected_item
            self.session.open(
                Playstream2,
                name,
                url,
                0,
                [name, url],
                [[[name, url]]]
            )

    def goConfig(self):
        self.session.open(vavoo_config)

    def chUp(self):
        """Handle page up and update name"""
        try:
            if self.cat_list:
                self['menulist'].pageUp()
                print("vavoo chUp: " + str(self['name'].getText()))
        except Exception as e:
            print("Error in vavoo chUp:", e)

    def chDown(self):
        """Handle page down and update name"""
        try:
            if self.cat_list:
                self['menulist'].pageDown()
                print("vavoo chDown: " + str(self['name'].getText()))
        except Exception as e:
            print("Error in vavoo chDown:", e)

    def moveUp(self):
        """Move selection up, wrapping from the first entry to the last."""
        if not self.cat_list:
            return
        idx = self['menulist'].getSelectedIndex()
        self['menulist'].moveToIndex((idx - 1) % len(self.cat_list))

    def moveDown(self):
        """Move selection down, wrapping from the last entry to the first."""
        if not self.cat_list:
            return
        idx = self['menulist'].getSelectedIndex()
        self['menulist'].moveToIndex((idx + 1) % len(self.cat_list))

    def _update_selection_name(self):
        """Update the name label with current selection"""
        try:
            current = self['menulist'].getCurrent()
            if current and len(current) > 0:
                name = current[0][0]
                self['name'].setText(to_string(name))
                print("vavoo _update_selection_name: " + to_string(name))
        except Exception as e:
            print("Error in vavoo _update_selection_name:", e)
            self['name'].setText("")

    def update_menu(self):
        try:
            if self.cat_list:
                self['menulist'].l.setList(self.cat_list)
                # self['menulist'].moveToIndex(0)
            else:
                self['name'].setText(_("No channels found"))
        except Exception as e:
            print("Error updating menu:", e)
            self['name'].setText(_("Error"))

    def close(self, *args, **kwargs):
        self._closed = True
        try:
            self.timer.stop()
            try:
                if hasattr(self.timer, 'callback'):
                    try:
                        self.timer.callback.remove(self.cat)
                    except ValueError:
                        pass  # already removed or method identity changed
            except AttributeError:
                pass
            try:
                if hasattr(self.timer, 'timeout'):
                    self.timer.timeout.disconnect(self.cat)
            except AttributeError:
                pass
        except Exception as e:
            print("Error stopping timer: " + str(e))
        try:
            if hasattr(self, 'proxy_status_timer'):
                self.proxy_status_timer.stop()
        except Exception as e:
            print("Error stopping proxy_status_timer: " + str(e))
        try:
            if hasattr(self, 'picon_refresh_timer'):
                self.picon_refresh_timer.stop()
        except Exception as e:
            print("Error stopping picon_refresh_timer: " + str(e))
        return Screen.close(self, *args, **kwargs)

    def backhome(self):
        # search_ok (previously gating an alternate self.cat() branch
        # here) was always False and never set True anywhere in this
        # file - VavooSearch now uses a direct openWithCallback/
        # return-value pattern instead. Removed as dead code.
        self.close()


class VavooFavourites(Screen):
    """Browse and play starred channels (see vUtils.toggle_favourite()/
    load_favourites()). Deliberately minimal compared to the `vavoo`
    class: no country/proxy fetching, no auto-update timer - just a
    static list built once from the favourites file. Reuses
    defaultListScreen.xml (the same skin `vavoo`/`MainVavoo` already
    load) so there's no new skin XML to keep in sync across
    resolutions."""

    def __init__(self, session):
        self.session = session
        Screen.__init__(self, session)
        skin = join(skin_path, 'defaultListScreen.xml')
        if isfile('/var/lib/dpkg/status'):
            skin = skin.replace('.xml', '_cvs.xml')
        with codecs.open(skin, "r", encoding="utf-8") as f:
            self.skin = apply_selected_background(f.read())

        init_notification_system(session)
        self._closed = False
        self.onClose.append(self._mark_closed)

        self.cat_list = []
        self['menulist'] = m2list([])
        self['name'] = Label(_('Favourites'))
        self['version'] = Label(to_string("V." + __version__))
        self['proxy_status'] = Label('')
        self['red'] = Label(_('Back'))
        self['green'] = Label(_('Remove'))
        self['yellow'] = Label()
        self['blue'] = Label()

        self['actions'] = ActionMap(
            ['OkCancelActions', 'ColorActions', 'DirectionActions'],
            {
                "up": self.moveUp,
                "down": self.moveDown,
                "ok": self.ok,
                "green": self.remove_selected,
                "cancel": self.close,
                "red": self.close,
            },
            -1
        )
        self.onLayoutFinish.append(self._build_list)

    def _mark_closed(self):
        self._closed = True

    def _build_list(self):
        favourites = vUtils.load_favourites()
        # Kept as a parallel list (same order/indices as cat_list) so
        # ok()/remove_selected() can look up each row's country_name/
        # country_code - show_list()'s (name, url) tuple has no room
        # for them, and they're needed for the parental-control check
        # and for EPG matching in Playstream2.
        self.favourite_entries = sorted(
            favourites.values(), key=lambda e: e.get('name', ''))
        self.cat_list = [
            show_list(entry['name'], entry['url'], is_channel=True)
            for entry in self.favourite_entries
        ]
        if self.cat_list:
            self['menulist'].l.setList(self.cat_list)
        else:
            self['menulist'].l.setList([])
            self['name'].setText(_('No favourites yet'))

    def moveUp(self):
        if not self.cat_list:
            return
        idx = self['menulist'].getSelectedIndex()
        self['menulist'].moveToIndex((idx - 1) % len(self.cat_list))

    def moveDown(self):
        if not self.cat_list:
            return
        idx = self['menulist'].getSelectedIndex()
        self['menulist'].moveToIndex((idx + 1) % len(self.cat_list))

    def _current_selection(self):
        """Returns (index, item, name, url) for the highlighted row, or
        (None, None, None, None) if nothing is selected."""
        if not self.cat_list:
            return None, None, None, None
        i = self['menulist'].getSelectedIndex()
        selection = self['menulist'].l.getCurrentSelection()
        if selection is None:
            return None, None, None, None
        item = self.cat_list[i][0]
        return i, item, item[0], item[1]

    def ok(self):
        try:
            i, item, name, url = self._current_selection()
            if name is None:
                return
            entry = self.favourite_entries[i]
            country_name = entry.get('country_name')
            country_code = entry.get('country_code')

            # Parallel to self.cat_list - favourites can mix channels
            # from several countries (unlike every other Playstream2
            # caller's single-country list), so channel-surfing
            # (nextitem()/previousitem()) needs a country_code per
            # entry to keep EPG lookups matched to the right country
            # instead of staying stuck on this first channel's one.
            country_codes = [
                e.get('country_code') for e in self.favourite_entries]

            def _play():
                self.session.open(
                    Playstream2,
                    name, url, i, item, self.cat_list,
                    country_code=country_code,
                    country_codes=country_codes
                )
            # A favourite from a locked country used to play with no
            # PIN prompt at all, since this screen never checked
            # parental control - see MainVavoo.ok()'s own use of the
            # same helper for the channel-browsing path.
            _require_parental_pin(self.session, self, country_name, _play)
        except Exception as e:
            print('[VavooFavourites] Error opening channel:', e)
            trace_error()

    def remove_selected(self):
        _i, _item, name, url = self._current_selection()
        if name is None:
            return
        now_favourite = vUtils.toggle_favourite(name, url)
        if now_favourite is None:
            if NOTIFICATION_AVAILABLE:
                quick_notify(_("Could not update favourites"), 3)
            return
        if NOTIFICATION_AVAILABLE:
            quick_notify(_("Removed from favourites: {}").format(name), 3)
        self._build_list()


class VavooLogViewer(Screen):
    """Dedicated log-tail viewer with real up/down/page scrolling -
    Console.py (used for this previously) has none at all: its text
    widget is a plain Label that always shows just the last ~13 lines
    of whatever's been printed, by design (built for live
    install-script output, where only the latest line matters - fine
    there, useless for browsing a static multi-hundred-line log file
    where most of it is further back than that).

    Reuses Console's own skin (the exact same inline XML, picked for
    the current resolution once at Console's class-definition time -
    no new skin file to keep in sync across hd/fhd/wqhd) but not
    Console's class or ActionMap: this reads the file directly in
    Python (no eConsoleAppContainer/shell command needed for a plain
    file read) and binds OkCancelActions - the convention every other
    screen in this file actually uses - instead of Console's
    WizardActions/"exit", which nothing else here relies on."""

    VISIBLE_LINES = Console.VISIBLE_LINES

    def __init__(self, session, title, file_path, tail_lines=200):
        Screen.__init__(self, session)
        # Same skin, minus the two things that don't apply to a
        # read-only log view: the static "Command execution..."
        # header and the green "Restart GUI" caption (no green key
        # bound here at all - same reasoning as Console.py's own
        # allow_restart=False path).
        self.skin = Console.skin.replace(
            'Command execution...', title
        ).replace('text="Restart GUI"', 'text=""')
        self._closed = False
        self.onClose.append(self._mark_closed)

        try:
            with codecs.open(
                    file_path, 'r', encoding='utf-8',
                    errors='replace') as f:
                self.lines = [
                    line.rstrip('\n') for line in f.readlines()[-tail_lines:]]
        except Exception as e:
            self.lines = ["Could not read {}: {}".format(file_path, e)]

        # Start scrolled to the most recent lines (what "tail" means),
        # same as the command this replaced - up/page-up reach
        # earlier ones.
        self.offset = max(0, len(self.lines) - self.VISIBLE_LINES)

        self['text'] = Label('')
        self['key_red'] = Label(_('Close'))
        self['actions'] = ActionMap(
            ['OkCancelActions', 'ColorActions', 'DirectionActions'],
            {
                "ok": self.close,
                "cancel": self.close,
                "red": self.close,
                "up": self.moveUp,
                "down": self.moveDown,
                "left": self.pageUp,
                "right": self.pageDown,
            },
            -1
        )
        self.onLayoutFinish.append(self._render)

    def _mark_closed(self):
        self._closed = True

    def _max_offset(self):
        return max(0, len(self.lines) - self.VISIBLE_LINES)

    def _render(self):
        window = self.lines[self.offset:self.offset + self.VISIBLE_LINES]
        self['text'].setText('\n'.join(window))

    def moveUp(self):
        if self.offset > 0:
            self.offset -= 1
            self._render()

    def moveDown(self):
        if self.offset < self._max_offset():
            self.offset += 1
            self._render()

    def pageUp(self):
        self.offset = max(0, self.offset - self.VISIBLE_LINES)
        self._render()

    def pageDown(self):
        self.offset = min(self._max_offset(), self.offset + self.VISIBLE_LINES)
        self._render()


# --- Live search screen ---
class VavooSearch(Screen):
    def __init__(self, session, parentScreen, itemlist):
        self.session = session
        self.parentScreen = parentScreen
        self.itemlist = itemlist
        self.filteredList = []
        self.selectedIndex = 0
        self.search_text = ""
        self.current_input = ""
        skin = join(skin_path, 'vavoo_search.xml')
        if isfile('/var/lib/dpkg/status'):
            skin = skin.replace('.xml', '_cvs.xml')
        with codecs.open(skin, "r", encoding="utf-8") as f:
            self.skin = f.read()
        Screen.__init__(self, session)
        self["search_label"] = Label(_("Search Channels:"))
        self["search_text"] = Label("")
        self['version'] = Label()
        self["input_info"] = Label(
            _("Press GREEN to type, YELLOW to delete"))
        self["channel_list"] = m2list([])
        self["status"] = Label(_("Enter text to search..."))
        self["key_red"] = Label(_("Clear All"))
        self["key_green"] = Label(_("Keyboard"))
        self["key_yellow"] = Label(_("Backspace"))
        self["key_blue"] = Label(_("Space"))
        self["actions"] = ActionMap(
            ["OkCancelActions", "DirectionActions", "ColorActions", "NumberActions"],
            {
                "ok": self.onOk,
                "cancel": self.onCancel,
                "up": self.moveUp,
                "down": self.moveDown,
                "left": self.moveLeft,
                "right": self.moveRight,
                "red": self.clearSearch,
                "green": self.openKeyboard,
                "yellow": self.deleteChar,
                "blue": self.addSpace,
                "1": lambda: self.keyNumber(1),
                "2": lambda: self.keyNumber(2),
                "3": lambda: self.keyNumber(3),
                "4": lambda: self.keyNumber(4),
                "5": lambda: self.keyNumber(5),
                "6": lambda: self.keyNumber(6),
                "7": lambda: self.keyNumber(7),
                "8": lambda: self.keyNumber(8),
                "9": lambda: self.keyNumber(9),
                "0": lambda: self.keyNumber(0),
            }, -1)

        self.numericalInput = NumericalTextInput(
            nextFunc=self.searchWithString)
        self.input_active = False
        self.upper_case = False
        self.last_key = None
        self.search_text = ""
        self.last_key_time = 0

        self.updateFilteredList()

    def keyNumber(self, number):
        key_chars = {
            2: "abc2", 3: "def3", 4: "ghi4", 5: "jkl5", 6: "mno6",
            7: "pqrs7", 8: "tuv8", 9: "wxyz9", 0: " 0", 1: "1"
        }
        if number in key_chars:
            chars = key_chars[number]
            current_time = time.time()
            if hasattr(
                    self,
                    'last_key') and self.last_key == number and current_time - self.last_key_time < 1.0:
                if self.search_text and self.search_text[-1] in chars:
                    current_index = chars.index(self.search_text[-1])
                    next_index = (current_index + 1) % len(chars)
                    self.search_text = self.search_text[:-
                                                        1] + chars[next_index]
                else:
                    self.search_text += chars[0]
            else:
                self.search_text += chars[0]

            self["search_text"].setText(self.search_text)
            self.updateFilteredList()

            self.last_key = number
            self.last_key_time = current_time

    def searchWithString(self):
        """Callback called by NumericalTextInput - nothing to do"""
        pass

    def deleteChar(self):
        """Delete the last character"""
        if self.search_text:
            self.search_text = self.search_text[:-1]
            self["search_text"].setText(self.search_text)
            self.numericalInput.nextKey()  # Reset NumericalTextInput
            self.updateFilteredList()

    def clearSearch(self):
        """Clear the entire search"""
        self.search_text = ""
        self["search_text"].setText("")
        self.numericalInput.nextKey()
        self.updateFilteredList()

    def addSpace(self):
        """Add a space"""
        self.search_text += " "
        self["search_text"].setText(self.search_text)
        self.updateFilteredList()

    def openKeyboard(self):
        self.session.openWithCallback(
            self.onKeyboardClosed,
            VirtualKeyBoard,
            title=_("Search..."),
            text=self.search_text)

    def onKeyboardClosed(self, result):
        if result is not None:
            self.search_text = result
            self["search_text"].setText(self.search_text)
            self.updateFilteredList()

    def toggleCase(self):
        """Toggle between uppercase and lowercase"""
        self.upper_case = not self.upper_case
        case_text = _("UPPERCASE") if self.upper_case else _("lowercase")
        self["status"].setText(_("Case: {}").format(case_text))

    def updateStatusText(self):
        """Update status text"""
        if self.search_text:
            # Separa in parti senza virgolette
            part1 = _("Search:")
            part2 = _('Found: {} channels').format(len(self.filteredList))
            message = '{0} "{1}" - {2}'.format(part1, self.search_text, part2)
            self["status"].setText(message)
        else:
            self["status"].setText(
                _("Showing all channels: {}").format(len(self.filteredList)))

    def updateFilteredList(self):
        text = self.search_text.lower().strip()

        if not text:
            self.filteredList = self.itemlist[:]
            self["status"].setText(
                _("Showing all channels: {}").format(len(self.filteredList)))
        else:
            self.filteredList = []
            for item in self.itemlist:
                try:
                    name = item.split('###')[0].lower()
                    if text in name:
                        self.filteredList.append(item)
                except Exception:
                    continue

            if self.filteredList:
                # Build message parts without embedding quotes in translations
                part1 = _("Search:")
                part2 = _("Found: {} channels").format(len(self.filteredList))

                message = '{} "{}" - {}'.format(
                    part1,
                    self.search_text,
                    part2
                )
                self["status"].setText(message)
            else:
                # Build message parts without embedding quotes in translations
                part1 = _("Search:")
                part2 = _("No channels found")

                message = '{} "{}" - {}'.format(
                    part1,
                    self.search_text,
                    part2
                )
                self["status"].setText(message)

        self.updateChannelList()

        if self.filteredList:
            self.selectedIndex = 0
            self["channel_list"].moveToIndex(self.selectedIndex)
        else:
            self.selectedIndex = -1

        self["version"].setText(to_string("V." + __version__))

    def updateChannelList(self):
        display_list = []
        for item in self.filteredList:
            try:
                name = item.split('###')[0]
                url = item.split('###')[1].replace(
                    '%0a', '').replace(
                    '%0A', '').strip("\r\n")
                # Without is_channel=True, show_list() takes its
                # "this is a country name" branch for every search
                # result - running get_country_code()'s full linear
                # scan + substring match (and a disk stat) against
                # the whole country table for each row, on every
                # single keystroke, and occasionally resolving a
                # channel name to a bogus flag icon by accident.
                display_list.append(show_list(name, url, is_channel=True))
            except Exception:
                continue
        self["channel_list"].l.setList(display_list)

    def moveUp(self):
        if self.filteredList:
            self.selectedIndex = max(0, self.selectedIndex - 1)
            self["channel_list"].moveToIndex(self.selectedIndex)

    def moveDown(self):
        if self.filteredList:
            self.selectedIndex = min(
                len(self.filteredList) - 1, self.selectedIndex + 1)
            self["channel_list"].moveToIndex(self.selectedIndex)

    def moveLeft(self):
        self.moveUp()

    def moveRight(self):
        self.moveDown()

    def onOk(self):
        if self.filteredList and 0 <= self.selectedIndex < len(
                self.filteredList):
            channel_item = self.filteredList[self.selectedIndex]
            name = channel_item.split('###')[0]
            url = channel_item.split('###')[1].replace(
                '%0a', '').replace('%0A', '').strip("\r\n")
            self.close((name, url))
        else:
            self.close(None)

    def onCancel(self):
        """Return to the Vavoo screen without opening the player"""
        print("DEBUG: Search cancelled, returning to Vavoo main screen")
        self.close()

    def close(self, *args, **kwargs):
        """Cleanup when the screen is closed"""
        try:
            # Reset input
            if hasattr(self, 'numericalInput'):
                self.numericalInput.nextKey()
        except Exception as e:
            print("[VavooSearch] Error in close: {0}".format(e))

        return Screen.close(self, *args, **kwargs)


class TvInfoBarShowHide():
    """
    InfoBar show/hide control – toggles both the standard Enigma2 infobar
    and the custom overlays (help + EPG) simultaneously on OK press.
    At stream start, both are shown; custom overlays auto‑hide after 5s,
    but the standard infobar stays until toggled off.
    """
    STATE_HIDDEN = 0
    STATE_HIDING = 1
    STATE_SHOWING = 2
    STATE_SHOWN = 3
    # FLAG_CENTER_DVB_SUBS = 2048
    skipToggleShow = False

    def __init__(self):
        debug("TvInfoBarShowHide.__init__ START")
        self["ShowHideActions"] = ActionMap(
            ["InfobarShowHideActions"],
            {
                "toggleShow": self.OkPressed,
                "hide": self.hide
            },
            0
        )
        self.__event_tracker = ServiceEventTracker(
            screen=self, eventmap={
                iPlayableService.evStart: self.serviceStarted})

        self.__state = self.STATE_SHOWN
        self.__locked = 0
        debug("TvInfoBarShowHide.__init__ state={}")

        # Current channel's picon, bottom-left of the screen (see
        # OVERLAY_PICON_W/H/X/Y's own comment) - populated read-only
        # from the on-disk picon cache by show_help_overlay(), same
        # "only ever read the cache, never download here" rule
        # show_list() follows for the channel list. Only
        # vavoo.ok()/play_that_shit() passes a logo_url into
        # Playstream2 today, so this stays empty/hidden for
        # Favourites/Search playback. zPosition=99 draws it above the
        # stock MoviePlayer skin's own placeholder icon in that
        # corner.
        self.channelPicon = Pixmap()
        self.channelPicon.skinAttributes = [
            ("position", "{},{}".format(OVERLAY_PICON_X, OVERLAY_PICON_Y)),
            ("size", "{},{}".format(OVERLAY_PICON_W, OVERLAY_PICON_H)),
            ("zPosition", "99"),
        ]
        self["channelPicon"] = self.channelPicon
        self["channelPicon"].hide()

        # Top overlay: controls + proxy status - full width, the
        # picon above no longer shares this bar.
        self.helpOverlay = Label("")
        self.helpOverlay.skinAttributes = [
            ("position", "0,0"),
            ("size", "{},{}".format(OVERLAY_WIDTH, OVERLAY_HEIGHT_TOP)),
            ("font", "Regular;{}".format(FONT_SIZE_TOP)),
            ("halign", "center"),
            ("valign", "center"),
            ("foregroundColor", "#00ffffff"),
            ("backgroundColor", "#80000000"),
            ("transparent", "0"),
            ("zPosition", "99")
        ]
        self["helpOverlay"] = self.helpOverlay
        self["helpOverlay"].hide()

        # EPG overlay (below the help overlay)
        self.epgOverlay = Label("")
        self.epgOverlay.skinAttributes = [
            ("position", "0,{}".format(OVERLAY_Y_EPG)),
            ("size", "{},{}".format(OVERLAY_WIDTH, OVERLAY_HEIGHT_EPG)),
            ("font", "Regular;{}".format(FONT_SIZE_EPG)),
            ("halign", "center"),
            ("valign", "center"),
            ("foregroundColor", "#00ffffff"),
            ("backgroundColor", "#80000000"),
            ("transparent", "0"),
            ("zPosition", "99")
        ]
        self["epgOverlay"] = self.epgOverlay
        self["epgOverlay"].hide()

        # Timer to update proxy status every 30s while overlays are visible
        self.proxy_update_timer = eTimer()
        try:
            self.proxy_update_timer.timeout.connect(
                self.update_proxy_status_overlay)
        except BaseException:
            self.proxy_update_timer.callback.append(
                self.update_proxy_status_overlay)

        # Timer to auto‑hide custom overlays after 5 seconds
        self.hideTimer = eTimer()
        try:
            self.hideTimer.timeout.connect(self.doTimerHide)
        except BaseException:
            self.hideTimer.callback.append(self.doTimerHide)

        # Timer for delayed start (to ensure infobar is rendered)
        self.delayed_start_timer = eTimer()
        try:
            self.delayed_start_timer.timeout.connect(self._delayed_start)
        except BaseException:
            self.delayed_start_timer.callback.append(self._delayed_start)

        # Timer to retry serviceStarted if execing is False
        self.retry_start_timer = eTimer()
        try:
            self.retry_start_timer.timeout.connect(self._retry_start)
        except BaseException:
            self.retry_start_timer.callback.append(self._retry_start)
        self.onShow.append(self.__onShow)
        self.onHide.append(self.__onHide)
        debug("TvInfoBarShowHide.__init__ END")

    def get_current_epg(self):
        """Method to be overridden by child class (Playstream2)."""
        return "EPG not available"

    def _update_overlay_picon(self):
        """Show the current channel's picon on the help overlay, if
        one is already cached - read-only, same rule show_list()
        follows for the channel list: never download synchronously
        here. Relies on the channel-list screen's own background
        preload (_preload_channel_picons()) having already fetched it
        while the user was browsing; if it hasn't yet, this channel's
        overlay just shows no picon for this viewing - no retry/
        refresh is attempted here.

        Uses ePicLoad to decode AND scale/letterbox the picon to this
        widget's own size in one step - the same mechanism
        startVavoo.decodeImage() already uses for the splash image in
        this exact file. loadPNG() (used by show_list() for the
        channel list) decodes a PNG at its own native pixel size with
        no scaling at all; that's fine there because
        MultiContentEntryPixmapAlphaTest's own size= argument scales
        list-cell content into its box, but a standalone Pixmap
        widget's setPixmap() has no such behavior - it just paints
        the pixmap's native pixels, so a picon larger than the box
        was only ever showing its clipped top-left corner, and a
        smaller one sat un-scaled instead of filling it.
        """
        try:
            logo_url = getattr(self, 'current_logo_url', None)
            if not logo_url:
                self["channelPicon"].hide()
                return

            cache_file = get_picon_cache_path(logo_url)
            if not cache_file or not file_exists(cache_file) \
                    or getsize(cache_file) <= 100:
                self["channelPicon"].hide()
                return

            size = self["channelPicon"].instance.size()
            picload = ePicLoad()
            scale = AVSwitch().getFramebufferScale()
            # Same setPara()/startDecode() shape as
            # startVavoo.decodeImage() - width, height, the display's
            # own aspect-correction factors, and resize_mode=1 (scale
            # to fit, preserving the image's own aspect ratio, padded
            # with the given transparent background) rather than
            # mode=0 (plain stretch).
            picload.setPara([
                size.width(), size.height(),
                scale[0], scale[1], 0, 1, '#00000000'])
            if isfile("/var/lib/dpkg/status"):
                picload.startDecode(cache_file, False)
            else:
                picload.startDecode(cache_file, 0, 0, False)
            ptr = picload.getData()
            if ptr is None:
                self["channelPicon"].hide()
                return

            self["channelPicon"].instance.setPixmap(ptr)
            self["channelPicon"].show()
            # Keep the ePicLoad instance alive for as long as its
            # decoded pixmap is on screen - same reason
            # startVavoo.decodeImage() keeps self.picload around
            # rather than letting it go out of scope right after this
            # call returns.
            self._channel_picload = picload
        except Exception as e:
            debug("Overlay picon update failed: {}".format(e))
            try:
                self["channelPicon"].hide()
            except Exception:
                pass

    def show_help_overlay(self):
        """Show custom overlays and start the auto‑hide timer."""
        debug("show_help_overlay START")
        try:
            # Prepare help overlay text (controls + proxy details)
            if is_proxy_running():
                status = get_proxy_status()
                if status:
                    token_age = status.get("addon_sig_age", 0)
                    channels = status.get("channels_count", 0)

                    if token_age < 300:
                        proxy_msg = _("✓ Proxy OK")
                    elif token_age < 420:
                        ttl = 600 - token_age
                        proxy_msg = _("✓ Proxy ({0}s)").format(int(ttl))
                    else:
                        proxy_msg = _("✗ Proxy Expired")

                    channels_text = _("Channels")
                    proxy_details = "{} | {}: {}".format(
                        proxy_msg, channels_text, channels)
                else:
                    proxy_details = _("? Proxy Unknown")
            else:
                proxy_details = _("✗ Proxy Offline")

            controls = _(
                "CH±=Change | OK=Toggle | INFO=IMDb | YELLOW=Source | STOP=Exit")
            credit = "by Lululla & Qu4k3"
            help_text = "{} | {} | {}".format(controls, proxy_details, credit)
            self["helpOverlay"].setText(help_text)
            self["helpOverlay"].show()
            debug("show_help_overlay helpOverlay shown")

            # Show EPG (initially "Loading...")
            self["epgOverlay"].setText(_("Loading EPG..."))
            self["epgOverlay"].show()
            debug("show_help_overlay epgOverlay shown")

            self._update_overlay_picon()

            # Start timer to update proxy status every 30s
            if not self.proxy_update_timer.isActive():
                self.proxy_update_timer.start(30000, True)
                debug("show_help_overlay proxy_update_timer started")

            def _fetch_epg_async():
                # The fetch below can take a long time on a slow/flaky
                # network. If the user has already left this channel by
                # the time it finishes, self is a torn-down screen -
                # don't touch it any further.
                if self._closed:
                    return
                # Snapshot which channel this fetch is actually for -
                # nextitem()/previousitem() can switch channels while
                # this fetch is still in flight (a surfed-past
                # channel's slow cache-miss fetch can finish AFTER a
                # later, faster one started after it), so without
                # this, the overlay could show stale programme info
                # for whichever fetch happens to finish last instead
                # of the channel actually playing.
                fetch_url = self.url
                try:
                    epg_text = self.get_current_epg()
                except Exception as e:
                    print("[Show Help] Async EPG fetch error: " + str(e))
                    return
                if self._closed:
                    return

                def _apply_epg_text():
                    try:
                        if (not self._closed and self["helpOverlay"].visible
                                and self.url == fetch_url):
                            self["epgOverlay"].setText(epg_text)
                            debug("show_help_overlay EPG updated: {}".format(
                                epg_text[:50]))
                    except Exception as e:
                        debug("Applying EPG overlay text failed: {}".format(e))
                reactor.callFromThread(_apply_epg_text)

            _epg_fetch_thread = threading.Thread(target=_fetch_epg_async)
            _epg_fetch_thread.daemon = True
            _epg_fetch_thread.start()

        except Exception as e:
            print("[Show Help] Error: " + str(e))
        debug("show_help_overlay END")

    def update_proxy_status_overlay(self):
        """Update the helpOverlay text with current proxy status."""
        if self["helpOverlay"].visible:
            try:
                current_text = self["helpOverlay"].getText()
                parts = current_text.split("|")
                if len(parts) > 2:
                    controls_part = parts[0].strip()
                    credit_part = parts[-1].strip()

                    if is_proxy_running():
                        status = get_proxy_status()
                        if status:
                            token_age = status.get("addon_sig_age", 0)
                            channels = status.get("channels_count", 0)
                            if token_age < 300:
                                proxy_msg = _("✓ Proxy OK")
                            elif token_age < 420:
                                ttl = 600 - token_age
                                proxy_msg = _(
                                    "✓ Proxy ({0}s)").format(int(ttl))
                            else:
                                proxy_msg = _("✗ Proxy Expired")
                            channels_text = _("Channels")
                            proxy_details = "{} | {}: {}".format(
                                proxy_msg, channels_text, channels)
                        else:
                            proxy_details = _("? Proxy Unknown")
                    else:
                        proxy_details = _("✗ Proxy Offline")

                    new_text = "{} | {} | {}".format(
                        controls_part, proxy_details, credit_part)
                    self["helpOverlay"].setText(new_text)
            except Exception as e:
                print("[Update Proxy Overlay] Error: " + str(e))

    def hide_help_overlay(self):
        """Hide both overlays and stop timer"""
        debug("hide_help_overlay START")
        self.hideTimer.stop()
        self.proxy_update_timer.stop()
        if self["helpOverlay"].visible:
            self["helpOverlay"].hide()
            self["epgOverlay"].hide()
            self["channelPicon"].hide()
            debug("hide_help_overlay overlays hidden")
        debug("hide_help_overlay END")

    def __onShow(self):
        debug("__onShow called, old state={}".format(self.__state))
        self.__state = self.STATE_SHOWN
        debug("__onShow new state={}".format(self.__state))

    def __onHide(self):
        debug("__onHide called, old state={}".format(self.__state))
        self.__state = self.STATE_HIDDEN
        debug("__onHide new state={}".format(self.__state))

    def doShow(self):
        debug("doShow START, state={}".format(self.__state))
        self.hideTimer.stop()
        self.show()
        self.startHideTimer()
        debug("doShow END")

    def doHide(self):
        debug("doHide START, state={}".format(self.__state))
        self.hideTimer.stop()
        self.hide()
        self.hide_help_overlay()
        self.startHideTimer()
        debug("doHide END")

    def startHideTimer(self):
        debug(
            "startHideTimer START, state={}, locked={}".format(
                self.__state,
                self.__locked))
        if self.__state == self.STATE_SHOWN and not self.__locked:
            self.hideTimer.stop()
            self.hideTimer.start(10000, True)
            debug("startHideTimer timer started (5s)")
        else:
            debug(
                "startHideTimer NOT starting: state={}, locked={}".format(
                    self.__state, self.__locked))
        debug("startHideTimer END")

    def doTimerHide(self):
        if self._closed:
            return
        debug("doTimerHide START, state={}".format(self.__state))
        self.hideTimer.stop()
        if self.__state == self.STATE_SHOWN:
            debug("doTimerHide hiding infobar and overlays")
            self.hide()
            self.hide_help_overlay()
        else:
            debug("doTimerHide state is HIDDEN, not hiding")
        debug("doTimerHide END")

    def toggleShow(self):
        debug(
            "toggleShow START, state={}, skipToggleShow={}".format(
                self.__state,
                self.skipToggleShow))
        if not self.skipToggleShow:
            if self.__state == self.STATE_HIDDEN:
                debug("toggleShow calling doShow()")
                self.doShow()
            else:
                debug("toggleShow calling doHide()")
                self.doHide()
        else:
            debug("toggleShow skipToggleShow is True, resetting")
            self.skipToggleShow = False
        debug("toggleShow END")

    def lockShow(self):
        debug("lockShow START")
        try:
            self.__locked += 1
        except BaseException:
            self.__locked = 0
        if self.execing:
            self.show()
            self.hideTimer.stop()
            self.skipToggleShow = False
        debug("lockShow END, locked={}".format(self.__locked))

    def unlockShow(self):
        debug("unlockShow START")
        try:
            self.__locked -= 1
        except BaseException:
            self.__locked = 0
        if self.__locked < 0:
            self.__locked = 0
        if self.execing:
            self.startHideTimer()
        debug("unlockShow END, locked={}".format(self.__locked))

    def _do_show_all(self):
        """Show infobar and overlays, start hide timer"""
        debug("_do_show_all CALLED")
        self.doShow()                  # Shows infobar
        self.show_help_overlay()       # Shows overlays
        self.delayed_start_timer.start(
            500, True)  # Start hide timer after 500ms
        debug("_do_show_all END")

    def _retry_start(self):
        """Retry serviceStarted if execing is False"""
        debug("_retry_start CALLED")
        self.retry_start_timer.stop()
        if self.execing:
            debug("_retry_start execing is now True, calling _do_show_all()")
            self._do_show_all()
        else:
            debug("_retry_start execing still False, will retry in 500ms")
            self.retry_start_timer.start(500, True)

    def _delayed_start(self):
        """Delayed start callback - starts the hide timer after infobar is rendered"""
        debug("_delayed_start CALLED")
        self.delayed_start_timer.stop()
        debug("_delayed_start starting hideTimer (5s)")
        self.hideTimer.start(5000, True)
        debug("_delayed_start END")

    def serviceStarted(self):
        debug("========== serviceStarted CALLED ==========")
        debug("serviceStarted execing={}".format(self.execing))
        if self.execing:
            debug("serviceStarted execing is True, calling _do_show_all()")
            self._do_show_all()
        else:
            debug("serviceStarted execing is False, will retry in 500ms")
            self.retry_start_timer.start(500, True)
        debug("========== serviceStarted END ==========")

    def OkPressed(self):
        """Toggle both infobar and overlays together"""
        debug("========== OkPressed CALLED ==========")
        debug(
            "OkPressed helpOverlay.visible={}".format(
                self["helpOverlay"].visible))
        if self["helpOverlay"].visible:
            debug("OkPressed hiding overlays")
            self.hide_help_overlay()
        else:
            debug("OkPressed showing overlays")
            self.show_help_overlay()
        debug("OkPressed calling toggleShow()")
        self.toggleShow()
        debug("========== OkPressed END ==========")


class Playstream2(
        InfoBarBase,
        InfoBarMenu,
        InfoBarSeek,
        InfoBarAudioSelection,
        InfoBarSubtitleSupport,
        InfoBarNotifications,
        TvInfoBarShowHide,
        Screen):
    STATE_IDLE = 0
    STATE_PLAYING = 1
    STATE_PAUSED = 2
    ENABLE_RESUME_SUPPORT = True
    ALLOW_SUSPEND = True
    screen_timeout = 5000

    def __init__(
            self,
            session,
            name,
            url,
            index,
            item,
            cat_list,
            country_code=None,
            country_codes=None,
            logo_url=None,
            logo_urls=None):
        Screen.__init__(self, session)
        self.session = session
        init_notification_system(session)
        self.skinName = 'MoviePlayer'

        self.stream_running = False
        self.is_streaming = False
        # Set once cancel() starts closing this screen, so a background
        # EPG fetch already in flight from a channel the user has since
        # left (show_help_overlay's _fetch_epg_async) can notice and
        # stop touching self instead of running against a torn-down
        # screen.
        self._closed = False
        self.currentindex = index
        self.item = item
        self.itemscount = len(cat_list)
        self.list = cat_list
        self.country_code = country_code
        # Parallel to cat_list, one country_code per entry - only
        # VavooFavourites passes this (its list can mix channels from
        # several countries, unlike every other caller's single-
        # country list). nextitem()/previousitem() use it to keep
        # self.country_code correct as the user channel-surfs, so EPG
        # lookups (get_current_epg()) stay matched to the right
        # country instead of staying stuck on whichever country the
        # very first channel happened to belong to.
        self.country_codes = country_codes
        self.current_logo_url = logo_url
        # Parallel to cat_list, like country_codes above - only
        # vavoo.ok()/play_that_shit() passes this today (the main
        # channel-list playback path). Favourites/Search leave it
        # None, so self.current_logo_url simply stays None for those
        # and the overlay picon area just stays empty for them.
        self.logo_urls = logo_urls
        self.name = name
        self.url = url.replace('%0a', '').replace('%0A', '')
        self.state = self.STATE_PLAYING
        self.srefInit = self.session.nav.getCurrentlyPlayingServiceReference()

        for x in (
            InfoBarBase,
            InfoBarMenu,
            InfoBarSeek,
            InfoBarAudioSelection,
            InfoBarSubtitleSupport,
            InfoBarNotifications,
            TvInfoBarShowHide
        ):
            x.__init__(self)

        self['actions'] = ActionMap(
            [
                'MoviePlayerActions',
                'MovieSelectionActions',
                'MediaPlayerActions',
                'EPGSelectActions',
                'OkCancelActions',
                'InfobarShowHideActions',
                'InfobarActions',
                'DirectionActions',
                'InfobarSeekActions',
                'ColorActions'
            ],
            {
                "stop": self.leavePlayer,
                "cancel": self.cancel,
                "channelDown": self.previousitem,
                "channelUp": self.nextitem,
                "down": self.previousitem,
                "up": self.nextitem,
                "back": self.cancel,
                'epg': self.showIMDB,
                "info": self.showIMDB,
                # YELLOW: pick which physical source (Vavoo/Geil's
                # ".b"/".c"/".s" convention) plays a channel that has
                # more than one - see chooseStreamSource()'s own
                # docstring.
                "yellow": self.chooseStreamSource,
            },
            -1
        )

        self.__event_tracker = ServiceEventTracker(
            screen=self,
            eventmap={
                iPlayableService.evEOF: self.__evEOF,
                # iPlayableService.evStart: self.__serviceStarted,
                # iPlayableService.evStopped: self.__evStopped,
            }
        )

        try:
            for screen in self.session.dialog_stack:
                if hasattr(screen[0], 'proxy_monitor_timer'):
                    screen[0].proxy_monitor_timer.stop()
                    print("[Playstream2] Stopped proxy monitor timer")
                if hasattr(screen[0], 'proxy_watchdog_timer'):
                    screen[0].proxy_watchdog_timer.stop()
                    print("[Playstream2] Stopped proxy watchdog timer")
        except Exception as e:
            print("[Playstream2] Error stopping timers: {}".format(e))

        self.eof_recovery_timer = eTimer()
        # Handle for restartAfterEOF()'s second-stage reactor.callLater -
        # see _do_restart_after_eof()/cancel() for why this needs to be
        # cancellable too, not just eof_recovery_timer itself.
        self._eof_restart_call = None

        self.onFirstExecBegin.append(lambda: self.startStream())
        self.onClose.append(self.cancel)

    def showIMDB(self):
        # get_current_epg() can block for well over a minute when the
        # EPG feed fetch stalls (e.g. flaky DNS) - the getUrl() timeout
        # passed to it only bounds the socket connect/read, not name
        # resolution. Run it off the main/reactor thread so a stall
        # here doesn't freeze the whole GUI, and marshal the actual
        # IMDb-opening (touches self.session) back onto the reactor.
        if not cfg.epg_enabled.value:
            print("[IMDB] No EPG available for current channel")
            if NOTIFICATION_AVAILABLE:
                quick_notify(_("No programme info available"), 3)
            return

        def _openForEpgText(epg_text, fetch_url):
            if self._closed or self.url != fetch_url:
                # Either torn down, or the user has already changed
                # channel since INFO was pressed - this fetch's result
                # belongs to a channel that isn't playing any more,
                # opening IMDb/TMDB for it would search the wrong
                # programme.
                return
            try:
                # get_current_epg() returns several distinct "EPG ..."
                # error strings ("EPG not available (no country code)",
                # "EPG not available (ID not found)", "EPG parsing
                # error", "EPG error", ...), not just "EPG not
                # available" - matching only that one exact string let
                # every other error variant fall through and get passed
                # to returnIMDB() as a search title instead of showing
                # "No programme info available".
                if epg_text and not epg_text.startswith(
                        "EPG ") and epg_text != "No programme found":
                    if " - " in epg_text:
                        title = epg_text.split(" - ")[0].strip()
                        if " " in title and title[2] == ":":
                            parts = title.split(" ", 1)
                            if len(parts) > 1:
                                title = parts[1].strip()
                    else:
                        title = epg_text

                    print("[IMDB] Searching for: %s" % title)

                    if returnIMDB(title, self.session):
                        print(
                            '[Playstream2] TMDB/IMDb opened for programme: %s' %
                            title)
                    else:
                        print('[Playstream2] No TMDB/IMDb plugin found')
                        if NOTIFICATION_AVAILABLE:
                            print('notify started')
                            quick_notify(_("No IMDb/TMDB plugin found"), 4)
                else:
                    print("[IMDB] No EPG available for current channel")
                    if NOTIFICATION_AVAILABLE:
                        print('notify started')
                        quick_notify(_("No programme info available"), 3)

            except Exception as e:
                print('[Playstream2] Error opening IMDb/TMDB: %s' % e)

        def _fetchEpgThenOpen():
            # Mirrors _fetch_epg_async()'s _closed check above - the
            # user may have already left this channel by the time this
            # slow fetch finishes.
            if self._closed:
                return
            fetch_url = self.url
            try:
                epg_text = self.get_current_epg()
            except Exception as e:
                print('[Playstream2] Error fetching EPG for IMDb: %s' % e)
                epg_text = ""
            if self._closed:
                return
            reactor.callFromThread(_openForEpgText, epg_text, fetch_url)

        epg_thread = threading.Thread(target=_fetchEpgThenOpen)
        epg_thread.daemon = True
        epg_thread.start()

    def _update_country_code_for_index(self, i):
        if self.country_codes is not None and 0 <= i < len(self.country_codes):
            self.country_code = self.country_codes[i]

    def _update_logo_url_for_index(self, i):
        if self.logo_urls is not None and 0 <= i < len(self.logo_urls):
            self.current_logo_url = self.logo_urls[i]

    def nextitem(self):
        """Switch to next channel"""
        self.stopStream(restore_original=False)
        currentindex = int(self.currentindex) + 1
        if currentindex == self.itemscount:
            currentindex = 0
        self.currentindex = currentindex
        i = self.currentindex
        item = self.list[i][0]
        self.name = item[0]
        self.url = item[1]
        self._update_country_code_for_index(i)
        self._update_logo_url_for_index(i)
        self.startStream()

    def previousitem(self):
        """Switch to previous channel"""
        self.stopStream(restore_original=False)
        currentindex = int(self.currentindex) - 1
        if currentindex < 0:
            currentindex = self.itemscount - 1
        self.currentindex = currentindex
        i = self.currentindex
        item = self.list[i][0]
        self.name = item[0]
        self.url = item[1]
        self._update_country_code_for_index(i)
        self._update_logo_url_for_index(i)
        self.startStream()

    def isSeekable(self):
        """Live TV is never seekable - InfoBarSeek (a base class of
        this screen, for its EOF/evUpdatedInfo plumbing, not because
        this content is actually seekable) binds LEFT/RIGHT to
        seekBack()/seekFwd() by default and only guards them with
        this exact check. Without overriding it, pressing LEFT/RIGHT
        during live playback tried to seek a stream with no real
        duration/seek support - the backend stalls audio attempting
        it, and needs a second press (itself swallowed by the same
        broken seek attempt, which is what actually clears the
        stall) to recover. Returning False here makes InfoBarSeek's
        own seek methods no-ops instead, exactly as intended for a
        continuous live stream."""
        return False

    def doEofInternal(self, playing):
        """Handle end of file (stream ended).

        InfoBarSeek (a base class of this screen) independently listens
        for iPlayableService.evEOF and calls this as its own extension
        hook - and __evEOF() below is ALSO explicitly wired to that same
        raw event. Both fire for a single real EOF, so the actual
        counting/restart logic lives in _handleEofEvent(), which
        debounces near-simultaneous calls so one real EOF is only
        counted once.
        """
        print('[Playstream2] doEofInternal, playing:', playing)
        if self.execing and playing:
            self._handleEofEvent("doEofInternal")

    def __evEOF(self):
        """Event: End of file reached (see doEofInternal for why this
        duplicates that hook)."""
        print('[Playstream2] __evEOF')
        self._handleEofEvent("__evEOF")

    def _handleEofEvent(self, source):
        """Shared EOF bookkeeping/restart logic for doEofInternal() and
        __evEOF(), which both fire for the same underlying event."""
        current_time = time.time()

        if not hasattr(self, 'eof_count'):
            self.eof_count = 0
            self.last_eof_time = 0

        time_since_last_eof = current_time - self.last_eof_time

        # doEofInternal() and __evEOF() both fire for the same real EOF,
        # typically within the same event-loop tick - a gap this short
        # means this is the other handler for the event just processed,
        # not a second, genuinely separate EOF. (0 <=, not 0 <: two
        # calls landing on the very same clock reading are exactly
        # that duplicate, and last_eof_time's initial 0 can never
        # produce a gap this small.)
        if 0 <= time_since_last_eof < 1.5:
            print(
                "[Playstream2] Ignoring duplicate EOF signal from " +
                source)
            return

        self.last_eof_time = current_time

        # The retry backoff below waits 0-4s ((eof_count-1) * 2, capped
        # at eof_count==3) before the next restart attempt, plus
        # whatever the resolve+reconnect itself takes (typically a
        # couple more seconds) - a 10s "frequent" window was shorter
        # than that combined delay could easily run, so a stream that
        # kept failing immediately on every restart still measured each
        # EOF as more than 10s after the previous one and reset
        # eof_count back to 1 every time. That meant the "give up after
        # 3 quick retries" safety net below could never actually
        # trigger - a persistently broken stream would retry forever
        # instead of eventually returning to the channel list. 45s
        # comfortably covers the worst-case backoff+resolve time with
        # margin, while still resetting correctly for a stream that
        # played fine for a real stretch before an unrelated one-off
        # EOF.
        if time_since_last_eof < 45:
            self.eof_count += 1
            print(
                "[Playstream2] Frequent EOF #" +
                str(self.eof_count) +
                " (" + source + "), time: " +
                "%.1f" % time_since_last_eof +
                "s"
            )
        else:
            self.eof_count = 1

        # Whatever the proxy was answering with for this channel just
        # ended - have it drop that address (and, for a multi-source
        # channel, decide whether to stay on the same source) before
        # the restart below asks it again. Reported here, once per
        # real EOF - never as a parameter on the stream address,
        # which the player would repeat on every playlist refresh
        # (see playProxyStream()'s own docstring).
        self._report_stream_failure()

        # Restart based on EOF frequency. The first retry is
        # immediate - a fresh address usually fixes it, and waiting
        # on general backoff principle only makes the common case
        # slower. The escalating delay only kicks in for a 2nd/3rd
        # retry, i.e. when the fresh address ALSO failed fast.
        if self.eof_count <= 3:  # Allow up to 3 quick retries
            delay = (self.eof_count - 1) * 2  # 0, 2, 4 seconds
            print(
                "[Playstream2] Restarting stream in " +
                str(delay) +
                " seconds (EOF #" +
                str(self.eof_count) +
                ")"
            )
            self.restartStreamDelayed(delay * 1000)
        else:
            print("[Playstream2] Too many EOFs, stopping auto-restart")
            error_msg = _("Stream ended. Too many connection issues.") + \
                "\n" + _("Returning to channel list.")
            # Giving up on auto-restart used to just show this message
            # and leave the player screen sitting dead (no video, no
            # further retries) once it closed on its own after the
            # timeout - the user had to notice and press cancel/back
            # themselves to get back to the channel list. Close the
            # player automatically instead.
            self.session.openWithCallback(
                lambda result=None: self.cancel(),
                MessageBox,
                error_msg,
                MessageBox.TYPE_ERROR,
                timeout=5
            )

    def __serviceStarted(self):
        """Service started playing"""
        print("Playback started successfully")
        self.state = self.STATE_PLAYING

    def startStream(self, is_retry=False):
        """Start the stream - proxy handles authentication.

        is_retry=True is a restart of the channel that is already
        selected (after an EOF or a source pick - see
        restartAfterEOF()): it goes ahead even though a stream is
        marked as running, and keeps the EOF/retry counters."""
        if self.stream_running and not is_retry:
            return

        print("[Playstream2] Starting stream: " + str(self.name))
        print("[Playstream2] URL: " + str(self.url))

        self.stream_running = True
        self.is_streaming = True

        if not is_retry:
            # Fresh channel selection - start its EOF/retry tracking clean.
            # A retry is a restart of the SAME channel (see
            # restartAfterEOF); eof_count must survive that, or the
            # "give up after N quick retries" limit never engages
            # since every retry would reset its own counter to 0 first.
            self.eof_count = 0
            self.last_eof_time = 0

        # Clean up URL
        if "/live2/play/" in self.url and self.url.endswith(".ts"):
            print("[Playstream2] Converting to proxy format")
            channel_id = self.url.split("/live2/play/")[1].replace(".ts", "")
            self.url = PROXY_BASE_URL + "/vavoo?channel=" + channel_id

        self.playProxyStream()

    def restartStreamDelayed(self, delay_ms):
        """Restart stream after a delay"""
        try:
            # Stop any existing timer
            if hasattr(self, 'eof_recovery_timer'):
                self.eof_recovery_timer.stop()

            self.eof_recovery_timer = eTimer()
            try:
                self.eof_recovery_timer.callback.append(self.restartAfterEOF)
            except BaseException:
                self.eof_recovery_timer.timeout.connect(self.restartAfterEOF)

            self.eof_recovery_timer.start(delay_ms, True)
        except Exception as e:
            print('[Playstream2] Error setting up restart timer:', e)
            # Immediate restart as fallback
            self.restartAfterEOF()

    def restartAfterEOF(self):
        """Stop and (after a short, cancellable delay) restart the
        current stream - despite the name, not EOF-specific: also
        reused by _onStreamSourceChosen() for a manual source pick,
        which needs the exact same deferred-restart safety this
        already has."""
        print("[Playstream2] Restarting stream (non-blocking)")
        self.stopStream(restore_original=False)
        # Stored so cancel() can cancel it - previously this handle was
        # discarded, so a STOP/BACK press during this 0.5s window closed
        # the screen but couldn't stop the pending restart, which then
        # fired startStream() on a torn-down screen, silently hijacking
        # whatever the user navigated back to.
        self._eof_restart_call = reactor.callLater(
            0.5, self._do_restart_after_eof)

    def _do_restart_after_eof(self):
        if self._closed:
            return
        self.startStream(is_retry=True)

    def get_current_epg(self):
        """
        Get current EPG program for the playing channel.
        Results are cached for 5 minutes to avoid repeated lookups.
        """
        start_time = time.time()

        try:
            if not self.country_code:
                return "EPG not available (no country code)"

            # Clean channel name for better matching
            clean_name = decodeHtml(self.name)
            clean_name = remove_parentheses(clean_name)

            # Create cache key
            cache_key = "epg_{}_{}".format(clean_name, self.country_code)

            # Check if we have cached result (5 minutes TTL)
            if cache_key in _epg_result_cache:
                cached_time, cached_result = _epg_result_cache[cache_key]
                if time.time() - cached_time < 300:  # 5 minutes
                    elapsed = time.time() - start_time
                    if elapsed > 0.05:
                        print(
                            "[EPG] Cache HIT for {} (took {:.3f}s)".format(
                                clean_name, elapsed))
                    return cached_result

            # Get matcher (singleton, already loaded)
            matcher = get_epg_matcher()

            # Extract channel ID from URL (same as playProxyStream()) -
            # find_match()'s curated-channel-db lookup only returns a
            # hit when channel_id is given (it's needed to build a
            # collision-free synthetic sref via unique_fallback_sref()),
            # so without this the curated DB - the primary EPG source
            # for countries with weak Rytec coverage like Spain/Poland/
            # Turkey - was silently never consulted here, even though
            # bouquet export (which does pass channel_id) uses it fine.
            # The sref this call gets back is discarded either way
            # (_unused below), so this doesn't add any collision risk.
            channel_id = None
            if self.url and "vavoo?channel=" in self.url:
                channel_id = self.url.split("vavoo?channel=")[1]
            if channel_id and '?' in channel_id:
                channel_id = channel_id.split('?')[0]

            # Find Rytec ID - this is the expensive part
            match_start = time.time()
            rytec_id, _unused, _unused_source = matcher.find_match(
                clean_name, country_code=self.country_code,
                channel_id=channel_id)
            match_time = time.time() - match_start

            if match_time > 0.1:
                print(
                    "[EPG] Slow match for {}: {:.3f}s".format(
                        clean_name, match_time))

            if not rytec_id:
                result = "EPG not available (ID not found)"
                _cache_epg_result(cache_key, result)
                return result

            # The whole country's EPG document (all channels, potentially
            # thousands of <programme> entries across all channels/days)
            # is what's slow to fetch, parse, and scan - not any single
            # channel's lookup. Reuse a recently parsed copy, and a
            # channel->programmes index built alongside it, across
            # channels in the same country instead of re-downloading,
            # re-parsing, and re-scanning the whole thing from scratch on
            # every single channel view.
            xml_cached = _epg_xml_cache.get(self.country_code)
            if xml_cached and (time.time() - xml_cached[0] < 300):
                root, channel_index, display_name_index = (
                    xml_cached[1], xml_cached[2], xml_cached[3])
            else:
                # Build EPG URL
                epg_url = "http://{}:{}/epg/{}.xml".format(
                    PROXY_HOST, PORT, self.country_code or "")

                # Fetch XML data
                fetch_start = time.time()
                # Reduced timeout to 3 seconds
                xml_data = getUrl(epg_url, timeout=3)
                fetch_time = time.time() - fetch_start

                if fetch_time > 0.5:
                    print(
                        "[EPG] Slow fetch from {}: {:.3f}s".format(
                            epg_url, fetch_time))

                if not xml_data:
                    result = "EPG not available"
                    _cache_epg_result(cache_key, result)
                    return result

                try:
                    root = ET.fromstring(xml_data)
                except Exception as e:
                    print("[EPG] XML parsing error: {}".format(e))
                    result = "EPG parsing error"
                    _cache_epg_result(cache_key, result)
                    return result

                # Index once per document: channel id (dots stripped, to
                # match id_match()'s old comparison) -> its own programme
                # entries, so a single channel's lookup only ever scans
                # that channel's handful of entries instead of every
                # <programme> in the whole country.
                index_start = time.time()
                channel_index = {}
                for prog in root.findall('programme'):
                    prog_channel = prog.get('channel')
                    if not prog_channel:
                        continue
                    channel_index.setdefault(
                        prog_channel.replace('.', ''), []).append(prog)
                index_time = time.time() - index_start
                if index_time > 0.1:
                    print(
                        "[EPG] Slow index build: {:.3f}s ({} channels)".format(
                            index_time, len(channel_index)))

                # Secondary, display-only index: cleaned <display-name>
                # text -> channel id, used as a fallback (see below) when
                # the primary rytec_id lookup finds nothing - some
                # country feeds use their own id convention (e.g.
                # "Canal.Hollywood.HD.pt", "RTP.1.HD.pt") that diverges
                # from the separate Rytec matching database's ids for
                # the same real channel, even though this feed has
                # perfectly good programme data under its own id.
                display_name_index = {}
                for chan in root.findall('channel'):
                    chan_id = chan.get('id')
                    if not chan_id:
                        continue
                    for dn in chan.findall('display-name'):
                        dn_text = (dn.text or '').strip()
                        if not dn_text:
                            continue
                        clean_dn = matcher._clean_name_for_similarity(
                            dn_text)
                        if clean_dn:
                            display_name_index[clean_dn] = chan_id

                _cache_epg_xml(
                    self.country_code, root, channel_index,
                    display_name_index)

            # Find current programme
            parse_start = time.time()
            try:
                import calendar
                now = time.time()

                def _current_in(programmes):
                    for prog in programmes:
                        start_str = prog.get('start')
                        stop_str = prog.get('stop')
                        if not start_str or not stop_str:
                            continue
                        try:
                            # Parse dates without timezone for speed
                            start_clean = start_str.split(' ')[0]
                            stop_clean = stop_str.split(' ')[0]
                            start_dt = datetime.datetime.strptime(
                                start_clean, "%Y%m%d%H%M%S")
                            stop_dt = datetime.datetime.strptime(
                                stop_clean, "%Y%m%d%H%M%S")
                            start_ts = calendar.timegm(start_dt.timetuple())
                            stop_ts = calendar.timegm(stop_dt.timetuple())
                            if start_ts <= now <= stop_ts:
                                return prog
                        except Exception:
                            continue
                    return None

                rid_key = rytec_id.replace('.', '')
                current_prog = _current_in(channel_index.get(rid_key, []))

                # Fallback: the matched rytec_id has no coverage in this
                # feed (a different id scheme for the same real channel,
                # e.g. matcher assigns "rtp1.pt" but this feed uses
                # "RTP.1.HD.pt") - try matching this channel's own name
                # directly against the feed's <display-name> tags
                # instead. Display-only: never touches matcher.cache,
                # dvb_ref, or anything bouquet-export/satellite-EPG
                # relies on - purely a better answer for this overlay.
                if current_prog is None and display_name_index:
                    clean_for_fallback = matcher._clean_name_for_similarity(
                        clean_name)
                    if clean_for_fallback:
                        best_score = 0.0
                        best_id = None
                        sm = SequenceMatcher(None, clean_for_fallback)
                        for dn_key, dn_id in display_name_index.items():
                            sm.set_seq2(dn_key)
                            score = sm.ratio()
                            if score > best_score:
                                best_score = score
                                best_id = dn_id
                        if best_id and best_score >= matcher.similarity_threshold:
                            fallback_key = best_id.replace('.', '')
                            current_prog = _current_in(
                                channel_index.get(fallback_key, []))
                            if current_prog is not None:
                                print(
                                    "[EPG] Fallback name match: '{}' -> {} "
                                    "(score={:.2f})".format(
                                        clean_name, best_id, best_score))

                parse_time = time.time() - parse_start
                if parse_time > 0.1:
                    print("[EPG] Slow parse: {:.3f}s".format(parse_time))

                if current_prog is not None:
                    title = current_prog.findtext('title', '')
                    desc = current_prog.findtext('desc', '')

                    # Extract start/stop times for display
                    start_str = current_prog.get('start')
                    stop_str = current_prog.get('stop')

                    try:
                        start_dt = datetime.datetime.strptime(
                            start_str.split(' ')[0], "%Y%m%d%H%M%S")
                        stop_dt = datetime.datetime.strptime(
                            stop_str.split(' ')[0], "%Y%m%d%H%M%S")

                        start_local = start_dt.strftime('%H:%M')
                        end_local = stop_dt.strftime('%H:%M')

                        result = "{}-{} {} - {}".format(
                            start_local, end_local, title, desc)
                    except Exception:
                        result = "{} - {}".format(title, desc)
                else:
                    result = "No programme found"

                # Cache the result
                _cache_epg_result(cache_key, result)
                return result

            except Exception as e:
                print("[EPG] Programme matching error: {}".format(e))
                result = "EPG parsing error"
                _cache_epg_result(cache_key, result)
                return result

        except Exception as e:
            print("[EPG] Exception in get_current_epg: {}".format(e))
            trace_error()
            return "EPG error"

    def _current_channel_id(self):
        """The catalog id (or "grp:<country>:<key>" group id - see
        vavoo_proxy.py's make_group_id()) this screen is playing,
        taken from self.url's "vavoo?channel=<id>", or None if
        self.url isn't a proxy stream address at all.

        Decoded: self.url carries the id URL-quoted (/channels'
        own response already quotes it - "grp%3Aitaly%3A...", not
        "grp:italy:..."), and everything this is handed to
        (report_stream_failure(), get_group_sources(),
        set_group_source()) takes the real id."""
        if "vavoo?channel=" not in self.url:
            return None
        channel_id = self.url.split("vavoo?channel=")[1]
        for separator in ('&', '?', '#'):
            if separator in channel_id:
                channel_id = channel_id.split(separator)[0]
        if not channel_id:
            return None
        return url_unquote(channel_id)

    def _current_group_channel_id(self):
        """_current_channel_id() if it is a grouped (multi-source)
        channel, else None."""
        channel_id = self._current_channel_id()
        if channel_id and channel_id.startswith(GROUP_ID_PREFIX):
            return channel_id
        return None

    def playProxyStream(self):
        """Play self.url's channel through the local proxy.

        The address handed to the player is always the plain
        http://127.0.0.1:<PORT>/vavoo?channel=<id> and nothing else.
        The player does not request it once: /vavoo answers with a
        302, so it comes back to this same address on every playlist
        refresh, about every 10 seconds, for as long as the channel
        is watched. Earlier versions put one-off instructions into
        it ("&force=1" after an EOF, "&keep=1", "&source=<id>" after
        a source pick), and every one of them was then repeated on
        every refresh - a fresh upstream address every few seconds,
        and on a multi-source channel a different source every other
        time, which is what kept ending streams. A failed stream or
        a source pick is now reported to the proxy once, directly
        (_handleEofEvent(), _onStreamSourceChosen()), and the proxy
        keeps answering with the same address in between.
        """
        try:
            channel_id = self._current_channel_id()
            if not channel_id:
                print("[Playstream2] Could not extract channel ID")
                self._notify_cannot_play()
                return

            proxy_url = "http://{}:{}/vavoo?channel={}".format(
                PROXY_HOST, PORT, url_quote(channel_id, safe=''))
            print("[Playstream2] Proxy URL: " + proxy_url)

            # Add User-Agent as fragment
            stream_url_with_ua = proxy_url + "#User-Agent=VAVOO/2.6"

            # Encode for Enigma2
            encoded_url = stream_url_with_ua.replace(":", "%3a")
            encoded_name = self.name.replace(":", "%3a")

            # Use the configured player service type ("Server for Player
            # Used" in settings - 4097/5001/5002/8193) instead of always
            # hardcoding 4097 - bouquet export already respects this
            # setting (see cfg.services.value usage there), but this
            # in-plugin player was silently ignoring it, always using
            # 4097's backend regardless of what the user picked.
            ref = (
                cfg.services.value + ":0:1:0:0:0:0:0:0:0:" +
                encoded_url +
                ":" +
                encoded_name
            )
            print("[Playstream2] Service reference: " + ref)
            sref = eServiceReference(ref)
            sref.setName(self.name)
            self.sref = sref

            try:
                # Read through the module, not a plain `from .vavoo_proxy
                # import proxy` value binding - vavoo_proxy.start_proxy()
                # reassigns its own module-level `proxy` on every restart,
                # which a one-time value import would never see, silently
                # accounting this stream against a dead, orphaned instance.
                vavoo_proxy.proxy.stream_started()
                print("[Playstream2] Notified proxy: stream started")
            except Exception as e:
                print("[Playstream2] Failed to notify proxy: {}".format(e))

            # Play the stream
            self.session.nav.stopService()
            self.session.nav.playService(self.sref)
            print("[Playstream2] Proxy stream started successfully")

        except Exception as e:
            print("[Playstream2] playProxyStream error: " + str(e))
            trace_error()

    def _notify_cannot_play(self):
        """self.url isn't something the proxy can play (a damaged
        favourite, say) - tell the user instead of sitting on a black
        screen. Every channel list in this plugin comes from the
        proxy, so there is no other playback path to fall back to."""
        self.stream_running = False
        self.is_streaming = False
        if NOTIFICATION_AVAILABLE:
            quick_notify(_("This channel cannot be played"), 4)

    def _report_stream_failure(self):
        """Tell the proxy the stream it gave us for this channel just
        ended - see VavooProxy.report_stream_failure() for what it
        does with that. Called once per real EOF, right before the
        restart that follows it."""
        channel_id = self._current_channel_id()
        if not channel_id:
            return
        try:
            vavoo_proxy.proxy.report_stream_failure(channel_id)
        except Exception as e:
            print("[Playstream2] Failed to report stream failure: {}".format(e))

    def chooseStreamSource(self):
        """YELLOW: let the user manually pick which physical source
        (Vavoo/Geil's ".b"/".c"/".s" convention - see
        vavoo_proxy.py's _group_key()/_strip_source_suffix()) plays a
        channel that has more than one, instead of leaving the choice
        to automatic selection/failure-recovery - the companion
        Android app offers the same choice in its own player menu.
        Only meaningful for a grouped channel; a single-source one has
        nothing to choose between.
        """
        group_id = self._current_group_channel_id()
        data = None
        if group_id:
            try:
                # In-process (the proxy is a thread of this same
                # Enigma2, like stream_started() above) - a couple of
                # dict lookups, no network, so the menu opens at once.
                data = vavoo_proxy.proxy.get_group_sources(group_id)
            except Exception as e:
                print(
                    "[Playstream2] Error reading stream sources: {}".format(e))

        members = (data or {}).get("members") or []
        if len(members) < 2:
            if NOTIFICATION_AVAILABLE:
                quick_notify(_("Only one source available for this channel"), 3)
            return

        current = data.get("current")
        choices = []
        for member in members:
            # to_string(): the label is the source's catalog name,
            # which on Python 2 is unicode - joining that with a
            # translated (byte string) "(current)" would fail on any
            # non-ASCII character in either.
            label = to_string(member.get("label", ""))
            if member.get("id") == current:
                label = label + " " + _("(current)")
            choices.append((label, member.get("id")))

        from Screens.ChoiceBox import ChoiceBox
        self.session.openWithCallback(
            self._onStreamSourceChosen,
            ChoiceBox,
            title=_("Choose Stream Source"),
            list=choices
        )

    def _onStreamSourceChosen(self, choice):
        if self._closed or not choice or not choice[1]:
            return
        group_id = self._current_group_channel_id()
        if not group_id:
            return
        print("[Playstream2] Source chosen: " + str(choice[1]))
        try:
            if not vavoo_proxy.proxy.set_group_source(group_id, choice[1]):
                return
        except Exception as e:
            print("[Playstream2] Error setting stream source: {}".format(e))
            return
        # restartAfterEOF() stops the current stream and defers the
        # actual restart by 0.5s rather than doing it synchronously -
        # not EOF-specific despite the name, and needed here too: this
        # runs as the ChoiceBox's own close callback, while the screen
        # stack is still settling back from that dialog closing.
        # Tearing down and recreating the service right then was
        # observed to leave self.execing False for several seconds
        # instead of the usual well under one, stalling
        # serviceStarted()'s 500ms retry loop
        # (TvInfoBarShowHide._retry_start()) and the overlay/EPG
        # refresh that depends on it - the stream looked frozen even
        # though it likely wasn't. Reusing this also means a STOP/
        # BACK press in that 0.5s window correctly cancels the
        # pending restart (see cancel()'s own handling of
        # self._eof_restart_call), exactly as it already does for a
        # real EOF.
        self.restartAfterEOF()

    def stopStream(self, restore_original=True):
        """Stop the stream and cleanup.

        restore_original=False is used when this is a transient stop
        (switching to another Vavoo channel, or an EOF auto-restart) that
        will immediately start a new stream - restoring srefInit (the
        channel that was playing before this player opened) here would
        otherwise briefly flash back to it on every channel change/retry.
        """
        if self.stream_running:
            self.stream_running = False
            self.is_streaming = False
            print("[Playstream2] Stream stopped")

            try:
                vavoo_proxy.proxy.stream_ended()
                print("[Playstream2] Notified proxy: stream ended")
            except Exception as e:
                print("[Playstream2] Failed to notify proxy: {}".format(e))
        # Stop recovery timer
        if hasattr(self, 'eof_recovery_timer'):
            self.eof_recovery_timer.stop()

        # Stop current service
        try:
            self.session.nav.stopService()
            if restore_original and self.srefInit:
                self.session.nav.playService(self.srefInit)
        except BaseException as e:
            print("[Playstream2] Failed to stop/restore service: {}".format(e))

    def cancel(self):
        """Close the player"""
        # Reachable both from the cancel/back action bindings and from
        # onClose (added below in __init__), which both fire on a normal
        # user-initiated close - guard against running the cleanup twice.
        if self._closed:
            return
        print("[Playstream2] Closing player...")
        self._closed = True

        # Stop this screen's own timers - previously only stopped by whichever
        # timer's own callback happened to run first; a screen closed before
        # that could leave one re-arming itself against a torn-down instance.
        for timer_name in ("proxy_update_timer", "hideTimer",
                            "delayed_start_timer", "retry_start_timer",
                            "eof_recovery_timer"):
            timer = getattr(self, timer_name, None)
            if timer is not None:
                try:
                    timer.stop()
                except Exception as e:
                    print("[Playstream2] Error stopping {}: {}".format(
                        timer_name, e))

        # restartAfterEOF()'s second-stage reactor.callLater isn't an
        # eTimer, so it needs its own cancellation - previously left
        # running, so a STOP press during its 0.5s window still fired
        # startStream() on this now-closed screen.
        if self._eof_restart_call is not None:
            try:
                if self._eof_restart_call.active():
                    self._eof_restart_call.cancel()
            except Exception as e:
                print("[Playstream2] Error cancelling EOF restart: {}".format(e))

        self.stopStream()
        try:
            for screen in self.session.dialog_stack:
                if hasattr(screen[0], 'proxy_monitor_timer'):
                    screen[0].proxy_monitor_timer.start(
                        PROXY_MONITOR_INTERVAL_MS)
                    print("[Playstream2] Restarted proxy monitor timer")
                if hasattr(screen[0], 'proxy_watchdog_timer'):
                    screen[0].proxy_watchdog_timer.start(
                        PROXY_WATCHDOG_INTERVAL_MS)
                    print("[Playstream2] Restarted proxy watchdog timer")
        except Exception as e:
            print("[Playstream2] Error restarting timers: {}".format(e))

        # Reset EOF counter
        if hasattr(self, 'eof_count'):
            self.eof_count = 0

        # Cleanup temp files
        if isfile("/tmp/hls.avi"):
            remove("/tmp/hls.avi")

        # Restore aspect ratio
        try:
            aspect_manager.restore_aspect()
        except BaseException as e:
            debug("aspect_manager.restore_aspect() failed: {}".format(e))

        self.close()

    def leavePlayer(self):
        """Alternative close method (STOP button) - runs the exact same
        cleanup as cancel() instead of skipping it (previously set
        _closed early, which made cancel()'s own dedupe guard skip its
        entire cleanup body when it ran via onClose)."""
        self.cancel()


class AutoStartTimer(object):
    def __init__(self):
        print("*** AutoStartTimer Vavoo ***")

        # self.timer must always exist after __init__ - check_configuring()
        # can call update() on an already-constructed instance later (e.g.
        # after a subsequent, unrelated config Save), and update()/on_timer()
        # unconditionally call self.timer.stop(). Previously this attribute
        # was only set below the early-return, so an instance created before
        # any bouquet was ever exported/favorited would crash the *next*
        # config Save with an AttributeError - silently aborting save()
        # before it persisted the user's settings.
        self.timer = eTimer()
        try:
            self.timer.callback.append(self.on_timer)
        except BaseException:
            self.timer.timeout.connect(self.on_timer)

        # The actual intended fire time, persisted across on_timer()
        # calls instead of recomputed fresh each time - see update()/
        # on_timer() for why: get_wake_time() for "interval" mode
        # always returns now + interval*60 relative to whenever it's
        # called, so calling it fresh at check-time can never look
        # "due" the way it needs to for on_timer() to detect that the
        # real target has actually been reached.
        self.next_wake_time = None

        # Check if there are bouquets to update
        favorite_channel = join(PLUGIN_PATH, 'Favorite.txt')

        if not isfile(favorite_channel):
            print("[AutoStartTimer] No Favorite.txt yet - timer created but idle")
            return

        print("[AutoStartTimer] Favorite.txt found, starting timer...")
        self.timer.start(100, True)
        self.update()

    def on_timer(self):
        """Timer callback - triggered when timer expires.

        update()'s eTimer schedule is capped at 3600s even when the
        real target is further out (a safety re-check, e.g. across
        suspend/resume or a clock change) - so this can fire well
        before the actual configured interval/fixed-time target. Must
        check elapsed wall-clock time against the real persisted
        target (self.next_wake_time), not just treat "the timer fired"
        as "it's time" - the previous version did exactly that for
        "interval" mode (never checked at all), which was why it ran
        every ~60 minutes regardless of the configured interval.
        """
        print("[AutoStartTimer] Timer triggered")
        self.timer.stop()

        now = int(time.time())
        wake = self.next_wake_time if self.next_wake_time is not None else now
        constant = 0

        if wake - now < 60:
            try:
                self.startMain()
                constant = 60
                localtime = time.asctime(time.localtime(time.time()))
                cfg.last_update.value = localtime
                cfg.last_update.save()
            except Exception as e:
                print("[AutoStartTimer] Error in startMain:", e)
                trace_error()

        self.update(constant)

    def get_wake_time(self):
        if cfg.autobouquetupdate.value is True:
            if cfg.timetype.value == "interval":
                interval = int(cfg.updateinterval.value)
                nowt = time.time()
                return int(nowt) + interval * 60
            if cfg.timetype.value == "fixed time":
                ftc = cfg.fixedtime.value
                now = time.localtime(time.time())
                fwt = int(time.mktime((
                    now.tm_year,
                    now.tm_mon,
                    now.tm_mday,
                    ftc[0],
                    ftc[1],
                    now.tm_sec,
                    now.tm_wday,
                    now.tm_yday,
                    now.tm_isdst
                )))
                return fwt
            # cfg.timetype only ever offers "interval"/"fixed time"
            # today, but fall back safely instead of implicitly
            # returning None (which would TypeError in update()'s
            # `if wake > 0`) if that ever changes.
            return -1
        else:
            return -1

    def update(self, constant=0):
        """Schedule the next timer wake-up.

        Only computes a fresh target via get_wake_time() when none is
        persisted yet (first run, or scheduling was disabled) -
        otherwise reuses self.next_wake_time so a capped, early
        re-check (see on_timer()) doesn't lose track of the real
        target and reschedule based on a brand new one every time it
        wakes up. When on_timer() just ran because the persisted
        target was actually reached (constant=60), the `wake < nowt +
        constant` branch below is what advances next_wake_time to the
        following cycle - not a separate reset.
        """
        self.timer.stop()
        # Not just "is None": get_wake_time() returns -1 while
        # scheduling is disabled (autobouquetupdate off) - must keep
        # recomputing in that case too, or re-enabling it later would
        # get stuck reusing a stale -1 forever instead of picking up
        # a real target.
        if not self.next_wake_time or self.next_wake_time <= 0:
            self.next_wake_time = self.get_wake_time()
        wake = self.next_wake_time
        nowt = time.time()
        if wake > 0:
            if wake < nowt + constant:
                if cfg.timetype.value == "interval":
                    interval = int(cfg.updateinterval.value)
                    wake += interval * 60
                elif cfg.timetype.value == "fixed time":
                    wake += 86400
                self.next_wake_time = wake
            next_time = wake - int(nowt)
            if next_time > 3600:
                next_time = 3600
            if next_time <= 0:
                next_time = 60
            self.timer.startLongTimer(next_time)
        else:
            wake = -1
        return wake

    def startMain(self):
        favorite_channel = join(PLUGIN_PATH, 'Favorite.txt')
        if not isfile(favorite_channel):
            print("Favorite.txt not found - no bouquets to update")
            return

        try:
            # 1. Read bouquets
            bouquets_to_update = []
            with codecs.open(favorite_channel, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if line and '|' in line:
                        parts = line.split('|')
                        if len(parts) >= 3 and parts[0].strip(
                        ) and parts[2].strip():
                            name = parts[0].strip()
                            url = parts[1].strip() if len(
                                parts) > 1 and parts[1].strip() else ""
                            export_type = parts[2].strip()
                            bouquets_to_update.append((name, url, export_type))

            if not bouquets_to_update:
                print("No valid bouquets found in Favorite.txt")
                return

            print("[AutoStartTimer] Updating " +
                  str(len(bouquets_to_update)) + " bouquets")

            # 2. Ensure proxy is running
            if not is_proxy_running():
                print("[AutoStartTimer] Starting proxy...")
                if not run_proxy_in_background():
                    print("[AutoStartTimer] Failed to start proxy")
                    return

            # 3. Wait for proxy to be ready - polls via reactor.callLater
            # instead of blocking this thread with select.select(), which
            # would otherwise freeze the whole Enigma2 GUI (e.g. while the
            # user is watching TV) for up to 10s during this unattended
            # scheduled update.
            self._wait_for_proxy_then_update(bouquets_to_update, 10)

        except Exception as e:
            print("[AutoStartTimer] Error: " + str(e))
            import traceback
            traceback.print_exc()

    def _wait_for_proxy_then_update(self, bouquets_to_update, attempts_left):
        if is_proxy_ready(timeout=3) or attempts_left <= 1:
            # _update_bouquets() does the real work: Rytec matching, EPG
            # feed downloads, and bouquet file I/O for every favorited
            # country, all synchronous - easily minutes for a multi-country
            # update. This method runs via reactor.callLater, i.e. on
            # Enigma2's single main/GUI thread (same one this class was
            # already careful about above, for the much shorter proxy
            # wait) - calling it directly here would freeze the whole box,
            # unattended, for however long the update takes. Run it in a
            # background thread instead, same pattern export_bouquet_async()
            # already uses for the manual export path.
            #
            # export_lock: _update_bouquets() ends up writing the same
            # vavoo_epg_cache.json a manual export (message2()) or the
            # cache-fix button (_fix_cache_format()) can also be writing -
            # both of those already hold this lock for their whole run
            # (see _fix_cache_format()'s own comment on why). Before this
            # method ran in the background, that overlap was impossible -
            # a synchronous scheduled update blocked the whole GUI, so the
            # user couldn't trigger a manual export at the same time.
            # Running here now makes that overlap real, so join the same
            # lock: skip this cycle non-blockingly if one's already in
            # progress rather than risk two concurrent read-modify-write
            # cycles silently losing each other's cache updates.
            if not export_lock.acquire(False):
                print(
                    "[AutoStartTimer] Export already in progress, "
                    "skipping this scheduled update")
                return
            t = threading.Thread(
                target=self._update_bouquets, args=(bouquets_to_update,))
            t.daemon = True
            t.start()
            return
        print("[AutoStartTimer] Waiting for proxy (" +
              str(11 - attempts_left) + "/10)")
        reactor.callLater(
            1,
            self._wait_for_proxy_then_update,
            bouquets_to_update,
            attempts_left - 1)

    def _update_bouquets(self, bouquets_to_update):
        try:
            # 4. Update each bouquet
            successful_updates = 0
            for name, url, export_type in bouquets_to_update:
                print("[AutoStartTimer] Updating: " + name)

                # Remove old bouquet
                removed = remove_bouquets_by_name(name)
                if removed > 0:
                    print(
                        "[AutoStartTimer] Removed " +
                        str(removed) +
                        " old bouquet files")

                # Create new bouquet (proxy only)
                ch = convert_bouquet(
                    cfg.services.value,
                    name,
                    url,  # Can be empty
                    export_type,
                    cfg.list_position.value
                )

                if ch > 0:
                    successful_updates += 1
                    print("[AutoStartTimer] ✓ Updated: " +
                          name + " (" + str(ch) + " channels)")
                    _update_favorite_file(name, url, export_type)
                else:
                    print("[AutoStartTimer] ✗ Failed: " + name)

            # 5. Update timestamp
            if successful_updates > 0:
                localtime = time.asctime(time.localtime(time.time()))

                def _save_last_update():
                    cfg.last_update.value = localtime
                    cfg.last_update.save()
                reactor.callFromThread(_save_last_update)
                print("[AutoStartTimer] Updated " +
                      str(successful_updates) +
                      "/" +
                      str(len(bouquets_to_update)) +
                      " bouquets")

        except Exception as e:
            print("[AutoStartTimer] Error: " + str(e))
            import traceback
            traceback.print_exc()
        finally:
            export_lock.release()


delayed_start_timer = None


def delayed_boot_tasks():
    global auto_start_timer
    try:
        # If the plugin has already been opened, do not start the proxy
        # here
        if _session is not None:
            print("[Vavoo] Plugin already opened, boot tasks skipped")
            return
        if not is_proxy_running():
            print("[Vavoo] Starting proxy at boot...")
            run_proxy_in_background()
        else:
            print("[Vavoo] Proxy already running at boot")

        if cfg.autobouquetupdate.value:
            if auto_start_timer is None:
                auto_start_timer = AutoStartTimer()

    except Exception as e:
        print("[Vavoo] Delayed boot tasks error: " + str(e))


def autostart(reason, session=None, **kwargs):
    global _autostart_scheduled, delayed_start_timer

    # NOTE: this must NOT set the module-level _session - that's how
    # delayed_boot_tasks() (below) tells whether the user has actually
    # opened a plugin screen since boot. It used to be set here too,
    # which meant delayed_boot_tasks() always saw it as non-None (this
    # function had just set it moments earlier) and always skipped
    # starting the proxy at boot, regardless of whether the plugin was
    # ever opened - the proxy would only exist in a half-initialized
    # state (token monitor thread running, since that starts at module
    # import) with no actual HTTP server listening.
    if reason == 0 and not _autostart_scheduled and session is not None:
        _autostart_scheduled = True

        delayed_start_timer = eTimer()
        try:
            delayed_start_timer.callback.append(delayed_boot_tasks)
        except BaseException:
            delayed_start_timer.timeout.connect(delayed_boot_tasks)

        delayed_start_timer.startLongTimer(30)   # run 30 seconds after boot


def check_configuring():
    """React to a live change of the scheduled auto-update settings,
    instead of requiring a reboot for them to take effect."""
    global auto_start_timer
    if cfg.autobouquetupdate.value is True:
        if auto_start_timer is None:
            auto_start_timer = AutoStartTimer()
        else:
            auto_start_timer.update()
    else:
        timer = getattr(auto_start_timer, 'timer', None)
        if timer is not None:
            timer.stop()
        return


def get_next_wakeup():
    return -1


def add_skin_back(bakk):
    if isfile(join(BackPath, str(bakk))):
        baknew = join(BackPath, str(bakk))
        cmd = 'cp -f ' + str(baknew) + ' ' + BackPath + '/default.png'
        os_system(cmd)
        os_system('sync')


def apply_selected_background(skin_text):
    """Point a skin's hardcoded default.png background reference at the
    actually-selected background file instead.

    add_skin_back() copies the selected image's content onto default.png
    on disk, but Enigma2 caches pixmaps by file path - re-showing a
    skin that references that same "default.png" path just returns the
    previously-cached bitmap (e.g. selecting "oktus" still visually
    shows "kiddac") until the whole GUI process restarts and re-reads
    it fresh. Referencing the real, distinctly-named file instead (e.g.
    "oktus.png") means a newly-selected background is a cache miss and
    gets loaded fresh immediately, no restart needed.
    """
    try:
        selected = join(BackPath, str(cfg.back.value) + '.png')
        if isfile(selected):
            default_path = join(BackPath, 'default.png')
            skin_text = skin_text.replace(default_path, selected)
    except Exception as e:
        print("[Background] Error applying selected background: " + str(e))
    return skin_text


def add_skin_font():
    print('**********addFont')
    from enigma import addFont
    FNT_Path = join(PLUGIN_PATH, "fonts")
    # addFont(join(FNT_Path, 'Lcdx.ttf'), 'Lcdx', 100, 0)
    addFont(join(FNT_Path, 'MavenPro-Medium.ttf'), 'cvfont', 100, 0)


def cfgmain(menuid, **kwargs):
    if menuid == "mainmenu":
        return [(_('Vavoo Stream Live'), main, 'Vavoo', 11)]
    else:
        return []


def checkInternet():
    try:
        import socket
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            s.settimeout(0.5)
            s.connect(('8.8.8.8', 53))
            return True
        finally:
            s.close()
    except BaseException:
        return False


def main(session, **kwargs):
    try:
        if _is_vavoo_already_open(session):
            session.open(
                MessageBox,
                _("Vavoo is already running."),
                MessageBox.TYPE_INFO,
                timeout=5
            )
            return
        if not checkInternet():
            session.open(
                MessageBox,
                _("No Internet connection detected. Please check your network."),
                MessageBox.TYPE_INFO)
            return
        # if isfile(LOG_FILE):
            # remove(LOG_FILE)
        add_skin_font()
        try:
            initialize_cache_with_local_flags()
            cleanup_old_temp_files()
        except Exception as e:
            print("Cache initialization error: %s" % str(e))
        session.open(startVavoo)
    except Exception as e:
        print('error as:', e)
        trace_error()


def Plugins(**kwargs):
    plugin_name = title_plug
    plugin_description = _('Vavoo Stream Live')
    plugin_icon = PLUGLOGO

    main_descriptor = PluginDescriptor(
        name=plugin_name,
        description=plugin_description,
        where=PluginDescriptor.WHERE_MENU,
        icon=plugin_icon,
        fnc=cfgmain
    )

    plugin_menu_descriptor = PluginDescriptor(
        name=plugin_name,
        description=plugin_description,
        where=PluginDescriptor.WHERE_PLUGINMENU,
        icon=plugin_icon,
        fnc=main
    )

    autostart_descriptor = PluginDescriptor(
        name=plugin_name,
        description=plugin_description,
        where=[
            PluginDescriptor.WHERE_AUTOSTART,
            PluginDescriptor.WHERE_SESSIONSTART],
        fnc=autostart,
        wakeupfnc=get_next_wakeup)

    result = [plugin_menu_descriptor, autostart_descriptor]

    if cfg.stmain.value:
        result.append(main_descriptor)

    return result
