# -*- coding: utf-8 -*-
"""Server list (the .txt files of the playlist folder, /etc/enigma2/xc by default) with background checks.
Every row shows "Checking..." at once, then updates itself with icon and details:
account status, expiry, connections, response time."""

import hashlib
import json
import os
import time

from enigma import (
    eListboxPythonMultiContent,
    gFont,
    RT_HALIGN_LEFT,
    RT_HALIGN_RIGHT,
    RT_VALIGN_CENTER)
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText

try:
    from Components.MultiContent import MultiContentEntryPixmapAlphaBlend as _PixEntry
except ImportError:
    from Components.MultiContent import MultiContentEntryPixmapAlphaTest as _PixEntry
try:
    from Tools.LoadPixmap import LoadPixmap
except ImportError:
    LoadPixmap = None

from .help import open_help
from . import _, core
from .api import XtreamClient, AuthError, LimitError, state_label
from .net import run_async
from .ui import (
    T,
    sc,
    scale_skin,
    footer,
    clock,
    new_timer,
    PLUGIN_DIR,
    BG,
    PANEL,
    TEXT,
    DIM,
    ACCENT,
    SEL,
    GOLD,
    C_TEXT,
    C_DIM,
    C_GOLD,
    C_WHITE)

CHECK_TIMEOUT = 6
BATCH = 20                  # checks queued at a time
BATCH_MS = 150              # pause between groups: the GUI stays responsive

C_GREEN, C_RED, C_AMBER = 0x3fb950, 0xe0443e, 0xe3b341


# ------------------------------------------------------------------
# Disk cache: {key: {"t": check time, "res": result}}
# Survives reboots, so the list opens at once with the last state.
# ------------------------------------------------------------------
def _cache_file():
    return os.path.join(core.DATA_DIR, "server_cache.json")


def _key(srv):
    raw = u"%s|%s|%s" % (srv["server"].rstrip(
        "/").lower(), srv["username"], srv["password"])
    # no plain passwords in the file
    return hashlib.md5(raw.encode("utf-8")).hexdigest()


def load_cache():
    try:
        with open(_cache_file()) as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (IOError, OSError, ValueError):
        return {}


def save_cache(cache, servers):
    """Save only servers still in the files, so the cache does not grow forever."""
    keep = set(_key(s) for s in servers)
    data = dict((k, v) for k, v in cache.items() if k in keep)
    try:
        tmp = _cache_file() + ".tmp"
        with open(tmp, "w") as f:
            json.dump(data, f)
        os.rename(tmp, _cache_file())
    except (IOError, OSError):
        pass


def max_age():
    """Seconds after which a result is checked again (0 = manually only)."""
    hours = int(core.cfg.server_check.value)
    return hours * 3600


def check_server(srv):
    """Runs in a thread. Returns a dictionary with the server state.
    state: on (active) | warn (expired, disabled, unknown) | ban (banned) | off (refused, unreachable).
    Reasons are stored as codes and translated when shown."""
    start = time.time()
    try:
        acc = XtreamClient(
            srv["server"],
            srv["username"],
            srv["password"],
            timeout=CHECK_TIMEOUT).account()
        ms = int((time.time() - start) * 1000)
        account = acc.get("state", "unknown")
        state = {"active": "on", "banned": "ban"}.get(account, "warn")
        return {
            "state": state,
            "account": account,
            "status": acc["status"],
            "expires": acc["expires"],
            "connections": acc["connections"],
            "trial": acc["trial"],
            "ms": max(
                1,
                ms)}
    except AuthError as e:
        return {"state": "ban" if e.state ==
                "banned" else "off", "status": e.state}
    except LimitError:
        return {"state": "warn", "status": "limit"}
    except Exception:
        return {"state": "off", "status": "unreachable"}


def off_reason(code):
    reasons = {
        "auth": _("Wrong credentials"),
        "unreachable": _("Unreachable"),
        "error": _("Error"),
        "limit": _("Too many requests: the server asked to wait"),
        "banned": _("Banned"),
        "disabled": _("Disabled"),
        "expired": _("Expired")}
    return reasons.get(code, code)


def _when(ts):
    """'today 13:50', 'yesterday 09:12' or '25/11 18:00'"""
    if not ts:
        return u""
    lt = time.localtime(ts)
    today = time.localtime()
    if lt[:3] == today[:3]:
        return _("today %s") % time.strftime("%H:%M", lt)
    if time.localtime(ts + 86400)[:3] == today[:3]:
        return _("yesterday %s") % time.strftime("%H:%M", lt)
    return time.strftime("%d/%m %H:%M", lt)


class ServerList(MenuList):
    """Tall two-level rows: icon | name + details | response time."""

    def __init__(self):
        MenuList.__init__(self, [], False, eListboxPythonMultiContent)
        self.l.setFont(0, gFont("Regular", sc(32)))
        self.l.setFont(1, gFont("Regular", sc(24)))
        self.l.setItemHeight(sc(104))
        self.icons = {}
        if LoadPixmap:
            for name in ("on", "off", "warn", "wait", "ban"):
                path = os.path.join(
                    PLUGIN_DIR,
                    "icons",
                    "status_%s.png" %
                    name)
                self.icons[name] = LoadPixmap(
                    path) if os.path.exists(path) else None

    def row(self, index, srv, res, current):
        try:
            width = self.instance.size().width()
        except Exception:
            width = sc(1680)
        h = sc(104)
        state = res.get("state", "wait") if res else "wait"
        title = srv["name"] + \
            ((u"   \u2713 " + _("in use")) if current else u"")
        user = _("User %s") % srv["username"]
        if not res:
            detail, detail_color, right = user + \
                u"   \u2022   " + _("Checking..."), C_DIM, u""
        elif state in ("off", "ban") or "expires" not in res:
            color = C_RED if state in ("off", "ban") else C_AMBER
            detail, detail_color, right = user + u"   \u2022   " + \
                off_reason(res["status"]), color, u""
        else:
            label = state_label(
                res["account"]) if res.get("account") not in (
                None, "unknown") else res["status"]
            parts = [user, label +
                     ((u" (%s)" %
                       _("trial")) if res.get("trial") else u""), _("Expires %s") %
                     res["expires"], _("Connections %s") %
                     res["connections"]]
            detail = u"   \u2022   ".join(parts)
            detail_color = C_GREEN if state == "on" else C_AMBER
            right = u"%d ms" % res["ms"]
        entry = [index]
        icon = self.icons.get(state)
        if icon is not None:
            entry.append(
                _PixEntry(
                    pos=(
                        sc(20),
                        (h - sc(48)) // 2),
                    size=(
                        sc(48),
                        sc(48)),
                    png=icon))
        x = sc(90)
        entry.append(
            MultiContentEntryText(
                pos=(
                    x,
                    sc(10)),
                size=(
                    width - x - sc(180),
                    sc(48)),
                font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                text=T(title),
                color=C_TEXT if not current else C_GOLD,
                color_sel=C_WHITE))
        entry.append(
            MultiContentEntryText(
                pos=(
                    x,
                    sc(56)),
                size=(
                    width - x - sc(40),
                    sc(38)),
                font=1,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                text=T(detail),
                color=detail_color,
                color_sel=detail_color))
        if right:
            entry.append(
                MultiContentEntryText(
                    pos=(
                        width - sc(180),
                        sc(10)),
                    size=(
                        sc(150),
                        sc(48)),
                    font=1,
                    flags=RT_HALIGN_RIGHT | RT_VALIGN_CENTER,
                    text=T(right),
                    color=C_DIM,
                    color_sel=C_DIM))
        return entry


class ServerScreen(Screen):
    skin = scale_skin("""
    <screen name="XCDServers" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="%(bg)s">
        <widget name="header" position="60,30" size="1200,60" font="Regular;44" foregroundColor="%(text)s" backgroundColor="%(bg)s" transparent="1" />
        <widget name="count" position="560,42" size="1080,40" font="Regular;28" halign="right" noWrap="1" foregroundColor="%(dim)s" backgroundColor="%(bg)s" transparent="1" />
        %(clock)s
        <eLabel position="60,110" size="1800,2" backgroundColor="%(panel)s" />
        <widget name="list" position="60,130" size="1140,832" itemHeight="104" backgroundColor="%(bg)s" backgroundColorSelected="%(sel)s" scrollbarMode="showOnDemand" transparent="1" />
        <widget name="empty" position="60,300" size="1140,300" font="Regular;30" halign="center" foregroundColor="%(dim)s" backgroundColor="%(bg)s" transparent="1" />
        <eLabel position="1240,130" size="2,832" backgroundColor="%(panel)s" />
        <widget name="webif_title" position="1280,150" size="580,28" font="Regular;24" foregroundColor="%(dim)s" backgroundColor="%(bg)s" transparent="1" />
        <widget name="webif_addr" position="1280,184" size="580,50" font="Regular;40" foregroundColor="%(text)s" backgroundColor="%(bg)s" transparent="1" />
        <widget name="webif_qr" position="1280,262" size="340,340" alphatest="blend" />
        <widget name="webif_token" position="1280,624" size="580,34" font="Regular;26" foregroundColor="%(gold)s" backgroundColor="%(bg)s" transparent="1" />
        <widget name="webif_hint" position="1280,672" size="580,150" font="Regular;22" foregroundColor="%(dim)s" backgroundColor="%(bg)s" transparent="1" />
        %(footer)s
    </screen>""" % dict(bg=BG, panel=PANEL, text=TEXT, dim=DIM, accent=ACCENT, sel=SEL, gold=GOLD,
                        clock=clock(), footer=footer()))

    def __init__(self, session):
        Screen.__init__(self, session)
        self.alive = True
        self.servers = []
        self.results = {}          # {index: result} shown in the list
        self.cache = load_cache()
        self.pending = 0           # checks still running
        self.round = 0
        self.todo = []             # indexes still to queue
        self["header"] = Label(T(_("Servers")))
        self["count"] = Label("")
        self["list"] = ServerList()
        self["empty"] = Label("")
        self["webif_title"] = Label("")
        self["webif_addr"] = Label("")
        self["webif_token"] = Label("")
        self["webif_hint"] = Label("")
        self["webif_qr"] = Pixmap()
        self["key_red"] = Label(T(_("Back")))
        self["key_green"] = Label(T(_("Use this one")))
        self["key_yellow"] = Label(T(_("Check all again")))
        self["key_blue"] = Label(T(_("Reload files")))
        self["actions"] = ActionMap(["OkCancelActions",
                                     "ColorActions",
                                     "DirectionActions",
                                     "XCDActions"],
                                    {"ok": self.use,
                                     "green": self.use,
                                     "cancel": self.close,
                                     "red": self.close,
                                     "yellow": lambda: self.check(force=True),
                                     "blue": self.reload,
                                     "menu": self.menu,
                                     "help": lambda: open_help(self.session,
                                                               "servers"),
                                     "up": lambda: self._move("up"),
                                     "down": lambda: self._move("down"),
                                     "pageUp": lambda: self._move("pageUp"),
                                     "pageDown": lambda: self._move("pageDown"),
                                     },
                                    -1)
        self.dispatch_timer = new_timer(self._dispatch)
        self.onLayoutFinish.append(self.reload)
        self.onLayoutFinish.append(self._webif_panel)
        self.onClose.append(self._closed)

    def _webif_panel(self):
        """Show the address + token + QR to manage the accounts from a phone/computer."""
        try:
            from . import webif
            from . import qr
            webif.start()                      # idempotent; makes sure it is listening
            nfo = webif.info()
            self["webif_title"].setText(T(_("FROM YOUR PHONE OR COMPUTER")))
            self["webif_addr"].setText(T(u"%s:%d" % (nfo["ip"], nfo["port"])))
            self["webif_token"].setText(
                T(u"%s:%d/?t=%s" % (nfo["ip"], nfo["port"], nfo["token"])))
            self["webif_hint"].setText(T(_("Scan the QR, or type this address in the browser, "
                                           "to add, edit or activate accounts.")))
            png = os.path.join(core.DATA_DIR, "webif_qr.png")
            qr.save_png(nfo["url"], png, scale=8, border=4)
            pix = LoadPixmap(png) if LoadPixmap else None
            if pix is not None:
                self["webif_qr"].instance.setPixmap(pix)
        except Exception as e:
            print("[XCDiamond] webif panel: %s" % e)
            self["webif_title"].setText("")
            self["webif_hint"].setText(T(_("Web interface not available.")))

    def _closed(self):
        self.alive = False
        self.dispatch_timer.stop()
        if self.servers:
            save_cache(self.cache, self.servers)

    def _move(self, direction):
        inst = self["list"].instance
        if inst is not None:
            inst.moveSelection({"up": inst.moveUp,
                                "down": inst.moveDown,
                                "pageUp": inst.pageUp,
                                "pageDown": inst.pageDown}[direction])

    # ------------------------------------------------------------------
    def reload(self):
        self.servers = core.read_servers()
        if not self.servers:
            self["list"].setList([])
            self["empty"].setText(
                T(
                    _(
                        "No servers in %s\n\nMENU: add a server with the remote,\n"
                        "or write one per line in %s\nand press BLUE to reload.") %
                    (core.server_dir(), core.server_file())))
            self["count"].setText("")
            return
        self["empty"].setText("")
        self.check(force=False)

    def _is_current(self, srv):
        c = core.cfg
        return (srv["server"].rstrip("/") == c.server.value.rstrip("/")
                and srv["username"] == c.username.value and srv["password"] == c.password.value)

    def _redraw(self):
        """Draw the whole list: only when opening and when the files change."""
        lst = self["list"]
        index = lst.getSelectedIndex() if lst.list else 0
        lst.setList([lst.row(i, s, self.results.get(i), self._is_current(s))
                    for i, s in enumerate(self.servers)])
        if self.servers:
            lst.moveToIndex(min(index, len(self.servers) - 1))
        self._update_count()

    def _update_row(self, i):
        """Redraw row i only (with 500 servers redrawing everything on each answer is heavy)."""
        lst = self["list"]
        if not (0 <= i < len(lst.list)):
            return
        lst.list[i] = lst.row(
            i,
            self.servers[i],
            self.results.get(i),
            self._is_current(
                self.servers[i]))
        try:
            lst.l.invalidateEntry(i)
        except Exception:
            current = lst.getSelectedIndex()
            lst.setList(lst.list)
            lst.moveToIndex(current)

    def _update_count(self):
        total = len(self.servers)
        online = len([r for r in self.results.values()
                     if r.get("state") == "on"])
        if self.pending:
            text = _(u"%d servers   \u2022   checking %d/%d") % (total,
                                                                 total - self.pending, total)
        else:
            times = [v.get("t", 0) for v in self.cache.values()]
            last = _when(max(times)) if times else u""
            text = _(u"%d servers   \u2022   %d online") % (total, online)
            if last:
                text += u"   \u2022   " + _("checked %s") % last
            text += u"   \u2022   MENU"
        self["count"].setText(T(text))

    def check(self, force=False):
        """Show cached results at once; check again only old ones (or all with force)."""
        self.round += 1
        self.dispatch_timer.stop()
        self.results = {}
        limit = max_age()
        now = time.time()
        todo = []
        for i, srv in enumerate(self.servers):
            hit = self.cache.get(_key(srv))
            fresh = hit and (limit == 0 or now - hit.get("t", 0) < limit)
            if hit and not force:
                # visible at once, even if checked again
                self.results[i] = hit["res"]
            if force or not fresh:
                todo.append(i)
        self.pending = len(todo)
        self.todo = todo
        self._redraw()                               # first the list, then the checks
        if todo:
            self.dispatch_timer.start(BATCH_MS, False)

    def _dispatch(self):
        """Queue one group of checks at a time (twisted pool, 10 in parallel)."""
        if not self.alive:
            return
        rnd = self.round
        batch, self.todo = self.todo[:BATCH], self.todo[BATCH:]
        for i in batch:
            run_async(
                check_server, (self.servers[i],), callback=lambda res, i=i: self._result(
                    rnd, i, res), errback=lambda e, i=i: self._result(
                    rnd, i, {
                        "state": "off", "status": "error"}))
        if not self.todo:
            self.dispatch_timer.stop()

    def _result(self, rnd, index, res):
        if not self.alive or rnd != self.round:
            return
        self.results[index] = res
        self.cache[_key(self.servers[index])] = {
            "t": int(time.time()), "res": res}
        self.pending -= 1
        self._update_row(index)
        self._update_count()
        if not self.pending:
            save_cache(self.cache, self.servers)

    def current(self):
        row = self["list"].getCurrent()
        return self.servers[row[0]] if row is not None and row[0] < len(
            self.servers) else None

    def use(self):
        srv = self.current()
        if srv is None:
            return
        core.apply_server(srv)
        self.close(True)

    # ---------- add / edit / rename / remove (MENU) ----------
    def menu(self):
        from Screens.ChoiceBox import ChoiceBox
        srv = self.current()
        choices = [(T(_("Add a server")), "add")]
        if srv is not None:
            choices += [(T(_("Edit address, username and password")), "edit"),
                        (T(_("Rename")), "rename"),
                        (T(_("Remove")), "remove")]
        choices.append(
            (T(_("Playlist folder") + u":  " + core.server_dir()), "folder"))

        def done(choice):
            if not choice or not self.alive:
                return
            if choice[1] == "add":
                self._ask_server(None)
            elif choice[1] == "edit":
                self._ask_server(srv)
            elif choice[1] == "rename":
                self._keyboard(
                    _("Server name"),
                    srv["name"],
                    lambda name: self._save(
                        core.rename_server,
                        srv,
                        name))
            elif choice[1] == "remove":
                self.session.openWithCallback(
                    lambda yes: yes and self._save(
                        core.remove_server, srv), MessageBox, T(
                        _("Remove the server %s from %s?") %
                        (srv["name"], os.path.basename(
                            srv["file"]))), MessageBox.TYPE_YESNO, default=False)
            else:
                choose_playlist_folder(
                    self.session, lambda: self.alive and self.reload())
        self.session.openWithCallback(
            done, ChoiceBox, title=T(
                _("Servers")), list=choices)

    def _keyboard(self, title, text, then):
        from Screens.VirtualKeyBoard import VirtualKeyBoard
        self.session.openWithCallback(
            lambda value: value is not None and self.alive and then(
                value.strip()),
            VirtualKeyBoard,
            title=T(title),
            text=text or u"")

    def _ask_server(self, srv):
        """Address, username, password and name, one keyboard after the other."""
        values = {}
        old = srv or {
            "server": u"http://",
            "username": u"",
            "password": u"",
            "name": u""}

        def got_name(name):
            values["name"] = name
            if srv is None:
                self._save(
                    lambda: core.add_server(
                        values["name"],
                        values["server"],
                        values["user"],
                        values["pwd"]))
            else:
                self._save(
                    core.edit_server,
                    srv,
                    values["name"],
                    values["server"],
                    values["user"],
                    values["pwd"])

        def got_pwd(pwd):
            values["pwd"] = pwd
            default = old["name"] if srv and old["name"] != old["server"].split(
                "://")[-1] else u""
            self._keyboard(_("Server name (optional)"), default, got_name)

        def got_user(user):
            values["user"] = user
            self._keyboard(_("Password"), old["password"], got_pwd)

        def got_server(server):
            parsed = core.parse_server_line(
                server) if "username=" in server else None
            if parsed:                       # a whole get.php link was typed: nothing else to ask
                values.update(
                    server=parsed["server"],
                    user=parsed["username"],
                    pwd=parsed["password"])
                return self._keyboard(
                    _("Server name (optional)"), u"", got_name)
            if server in (u"", u"http://"):
                return
            values["server"] = server
            self._keyboard(_("Username"), old["username"], got_user)
        self._keyboard(
            _("Server address (e.g. http://myserver.com:8080) or full get.php link"),
            old["server"],
            got_server)

    def _save(self, func, *args):
        try:
            func(*args)
        except Exception as e:
            return self.session.open(
                MessageBox, T(
                    _("Cannot write the file: %s") %
                    e), MessageBox.TYPE_ERROR)
        self.reload()


def choose_playlist_folder(session, then=None):
    """Folder that holds playlist.txt (and the XC xclink.txt): a folder browser, saved at once."""
    def done(path):
        if not path:
            return
        core.cfg.playlist_dir.value = path.rstrip("/") or "/"
        core.cfg.playlist_dir.save()
        core.save_configfile()
        core.read_servers()            # creates playlist.txt there when missing
        if then:
            then()
    try:
        from Screens.LocationBox import LocationBox
        session.openWithCallback(
            done,
            LocationBox,
            text=T(
                _("Folder of playlist.txt")),
            currDir=core.server_dir() +
            "/",
            minFree=None)
    except Exception as e:
        print("[XCDiamond] folder browser: %s" % e)
