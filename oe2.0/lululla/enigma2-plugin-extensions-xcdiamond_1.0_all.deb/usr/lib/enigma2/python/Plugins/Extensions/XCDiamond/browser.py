# -*- coding: utf-8 -*-
"""Browsing: categories on the left, content in the middle, quick details on the right.
Live: logo + now/next EPG. Movies and series: poster, rating and plot from TMDB."""

import time

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.ProgressBar import ProgressBar

from .help import open_help
from . import _, ngettext, core
from .api import LIVE, VOD, SERIES
from .net import run_async
from .vodseries import organize, summary, SEP, GROUP
from .epg import progress
from .tmdb import clean_title
from .ui import (
    T,
    XCDList,
    ImageLoader,
    icon,
    scale_skin,
    footer,
    clock,
    new_timer,
    merge_info,
    meta_line,
    BG,
    PANEL,
    TEXT,
    DIM,
    ACCENT,
    SEL,
    GOLD,
    C_GOLD,
    C_DIM,
    C_ACCENT,
    C_TEXT)


def titles():
    return {
        LIVE: _("Live channels"),
        VOD: _("Movies"),
        SERIES: _("TV series"),
        "fav": _("Favorites"),
        "search": _("Search")}


def search_kinds():
    return [(LIVE, _("Channels")), (VOD, _("Movies")),
            (SERIES, _("TV series"))]


def fav_kinds():
    return [(LIVE, _("Live channels")),
            (VOD, _("Movies")), (SERIES, _("TV series"))]


class BrowserScreen(Screen):
    skin = scale_skin("""
    <screen name="XCDBrowser" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="%(bg)s">
        <widget name="header" position="60,30" size="1300,60" font="Regular;44" foregroundColor="%(text)s" backgroundColor="%(bg)s" transparent="1" />
        <widget name="count" position="1000,42" size="640,40" font="Regular;28" halign="right" foregroundColor="%(dim)s" backgroundColor="%(bg)s" transparent="1" />
        %(clock)s
        <eLabel position="60,110" size="1800,2" backgroundColor="%(panel)s" />
        <widget name="cats" position="60,130" size="460,840" itemHeight="60" backgroundColor="%(bg)s" backgroundColorSelected="%(sel)s" scrollbarMode="showOnDemand" transparent="1" />
        <eLabel position="535,130" size="2,840" backgroundColor="%(panel)s" />
        <widget name="items" position="555,130" size="760,840" itemHeight="60" backgroundColor="%(bg)s" backgroundColorSelected="%(sel)s" scrollbarMode="showOnDemand" transparent="1" />
        <eLabel position="1335,130" size="525,840" backgroundColor="%(panel)s" zPosition="-1" />
        <widget name="poster" position="1447,145" size="300,450" alphatest="blend" zPosition="2" />
        <widget name="p_title" position="1360,604" size="480,44" font="Regular;32" noWrap="1" foregroundColor="%(text)s" backgroundColor="%(panel)s" transparent="1" />
        <widget name="p_meta" position="1360,650" size="480,32" font="Regular;24" noWrap="1" foregroundColor="%(gold)s" backgroundColor="%(panel)s" transparent="1" />
        <widget name="progress" position="1360,688" size="480,8" foregroundColor="%(accent)s" backgroundColor="#00303a4a" zPosition="2" />
        <widget name="p_extra" position="1360,702" size="480,116" font="Regular;22" foregroundColor="%(text)s" backgroundColor="%(panel)s" transparent="1" />
        <widget name="p_plot" position="1360,824" size="480,140" font="Regular;22" foregroundColor="%(dim)s" backgroundColor="%(panel)s" transparent="1" />
        %(footer)s
    </screen>""" % dict(bg=BG, panel=PANEL, text=TEXT, dim=DIM, accent=ACCENT, sel=SEL, gold=GOLD,
                        clock=clock(), footer=footer()))

    def __init__(self, session, kind, favorites_only=False, search=None):
        Screen.__init__(self, session)
        core.load_keymap()
        self.alive = True
        self.kind = kind
        self.fav_mode = favorites_only
        self.continue_mode = False          # "Continue watching" category open
        self.search_query = search          # "Search" results screen
        self.search_results = {}
        self.focus = "cats"
        self.items_all = []      # content of the loaded category
        self.items_view = []     # the visible part (after search/sorting)
        self.category_name = ""
        self.search_text = ""
        self.sort_mode = core.sort_config(
            "live" if favorites_only else kind).value
        self.info_cache = {}
        self.load_token = 0

        self["header"] = Label(T(titles()[self._mode()]))
        self["count"] = Label("")
        self["cats"] = XCDList(font_size=30, item_height=60)
        self["items"] = XCDList(font_size=30, item_height=60)
        self["poster"] = Pixmap()
        self["p_title"] = Label("")
        self["p_meta"] = Label("")
        self["p_extra"] = Label("")
        self["p_plot"] = Label("")
        self["progress"] = ProgressBar()
        self["key_red"] = Label(T(_("Back")))
        self["key_green"] = Label(T(_("Play")))
        self["key_yellow"] = Label(T(_("Search")))
        self["key_blue"] = Label(T(u"\u2665 " + _("Favorite")))
        self.poster = ImageLoader(self, "poster", fallback="poster")
        self.panel_timer = new_timer(self._fill_panel)
        self.cat_timer = new_timer(lambda: self._load_category(auto=True))
        # moves the programme bars forward
        self.minute_timer = new_timer(self._tick_epg)
        # moving dots while searching
        self.wait_timer = new_timer(self._wait_tick)
        self.wait_step = 0
        self.loaded_cat = None     # category shown now (so it is not reloaded)

        self["epg_keys"] = ActionMap(["NumberActions"], {"7": lambda: self._epg_shift(
            -1), "8": lambda: self._epg_shift(0), "9": lambda: self._epg_shift(1), }, -1)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions", "XCDActions"], {
            "ok": self.ok, "cancel": self.back, "red": self.back,
            "green": self.play_direct, "yellow": self.search, "blue": self.toggle_fav,
            "info": self.open_details, "menu": self.menu, "help": lambda: open_help(self.session, "lists"),
            # TEXT: search everywhere (YELLOW: in this category)
            "search": lambda: core.open_search(self.session),
            "up": lambda: self.move("up"), "down": lambda: self.move("down"),
            "pageUp": lambda: self.move("pageUp"), "pageDown": lambda: self.move("pageDown"),
            "left": self.focus_cats, "right": self.right,
        }, -1)
        self.onLayoutFinish.append(self._start)
        self.onClose.append(self._closed)

    def _mode(self):
        return "search" if self.search_query else (
            "fav" if self.fav_mode else self.kind)

    def _closed(self):
        self.alive = False
        self.panel_timer.stop()
        self.cat_timer.stop()
        self.minute_timer.stop()
        self.wait_timer.stop()
        core.stop_epg_updates(self._epg_changed)

    # ------------------------------------------------------------------
    # Categories
    # ------------------------------------------------------------------
    def _start(self):
        self["progress"].hide()
        self["poster"].hide()
        self._set_focus("cats")
        if self.kind == LIVE or self.fav_mode or self.search_query:
            # full guide in the background
            core.ensure_epg(self._epg_changed)
            self.minute_timer.start(60000, False)
        if self.search_query:
            self["cats"].set_entries([self["cats"].entry(
                None, u"%s  (\u2026)" % label, color=C_DIM) for _kind, label in search_kinds()])
            self["header"].setText(T(_("Search") +
                                     u"  \u203a  \u201c%s\u201d" %
                                     self.search_query))
            self._wait_tick()
            self.wait_timer.start(400, False)
            run_async(core.search_all, (self.search_query,),
                      callback=self._search_ok, errback=self._search_failed)
            return
        if self.fav_mode:
            self["cats"].set_entries([self["cats"].entry({"special": "continue"},
                                                         u"\u25b6  " + _("Continue watching"),
                                                         color=C_GOLD)] + [self["cats"].entry({"fav": k},
                                                                                              u"\u2665  " + n) for k,
                                                                           n in fav_kinds()],
                                     1)
            self._load_category()
            return
        self["cats"].set_entries([self["cats"].entry(
            None, _("Loading categories..."), color=C_DIM)])
        run_async(core.client().categories, (self.kind,),
                  callback=self._cats_ok, errback=self._error)

    def _wait_tick(self):
        """'Searching...' with moving dots: shows that it is working."""
        self.wait_step = (self.wait_step + 1) % 4
        dots = u"." * self.wait_step + u" " * (3 - self.wait_step)
        self["items"].set_entries(
            [
                self["items"].entry(
                    None,
                    _("Searching") + dots,
                    color=C_GOLD),
                self["items"].entry(
                    None,
                    _("The first time it downloads the full server lists:"),
                    color=C_DIM),
                self["items"].entry(
                    None,
                    _("with many titles it takes a few seconds."),
                    color=C_DIM)])
        self["count"].setText(T(_("Searching") + dots))

    def _search_failed(self, err):
        self.wait_timer.stop()
        self._error(err)

    def _search_ok(self, results):
        self.wait_timer.stop()
        if not self.alive:
            return
        self.search_results = results
        cl = self["cats"]
        entries = [cl.entry({"search": k}, u"%s  (%d)" % (label, len(results.get(
            k, []))), color=C_TEXT if results.get(k) else C_DIM) for k, label in search_kinds()]
        first = next(
            (i for i, (k, _l) in enumerate(
                search_kinds()) if results.get(k)), 0)
        cl.set_entries(entries, first)
        total = sum(len(v) for v in results.values())
        self["count"].setText(T(_("%d results") % total))
        if total:
            self._load_category()
        else:
            self["items"].set_entries(
                [self["items"].entry(None, _("No results"), color=C_DIM)])

    def _cats_ok(self, cats):
        if not self.alive:
            return
        cl = self["cats"]
        entries = [cl.entry({"special": "fav"},
                            u"\u2665  " + _("Favorites"),
                            color=C_ACCENT)]
        if self.kind in (VOD, SERIES):
            entries.append(cl.entry(
                {"special": "continue"}, u"\u25b6  " + _("Continue watching"), color=C_GOLD))
        entries.append(cl.entry({"special": "all"}, _("All")))
        self.all_index = len(entries) - 1
        self.categories = cats
        entries += [self._cat_entry(c) for c in cats]
        cl.set_entries(entries, self.all_index + 1 if cats else self.all_index)
        self["count"].setText(T(_("%d categories") % len(cats)))
        # show the titles of the first category right away
        self.cat_timer.start(500, True)

    def _cat_entry(self, cat):
        """Category row; with a padlock when it is PIN protected."""
        cl = self["cats"]
        if core.is_protected(self.kind, cat):
            return cl.entry(
                cat, cat["name"], icon=icon(
                    "lock", 32), icon_size=32)
        return cl.entry(cat, cat["name"])

    def _cat_locked(self, cat):
        return bool(
            cat.get("id")) and "special" not in cat and core.locked() and core.is_protected(
            self.kind, cat)

    @staticmethod
    def _cat_key(cat):
        return cat.get("search") or cat.get(
            "fav") or cat.get("special") or cat.get("id")

    def _load_category(self, auto=False):
        """auto=True: loaded because the cursor stopped on it (focus stays on the categories)."""
        self.cat_timer.stop()
        cat = self["cats"].current()
        if cat is None:
            return
        if self._cat_locked(cat):
            if auto:                                    # passing over it does not open it: the PIN is needed
                self.loaded_cat = None
                self.items_all = self.items_view = []
                self["items"].set_entries([self["items"].entry(
                    None, _("Protected category: press OK and enter the PIN"), color=C_DIM)])
                self._clear_panel()
                return
            return core.ask_pin(
                self.session,
                lambda ok: ok and self.alive and self._unlocked())
        key = self._cat_key(cat)
        if key == self.loaded_cat and self.items_all:
            if not auto:
                self._set_focus("items")
            return
        self.loaded_cat = key
        self.auto_load = auto
        self.load_token += 1
        token = self.load_token
        self.search_text = ""
        if "search" in cat:                                 # "Search" results
            self.kind = cat["search"]
            self.sort_mode = core.sort_config(self.kind).value
            self.category_name = dict(search_kinds())[self.kind]
            self._items_ok(list(self.search_results.get(self.kind, [])), token)
            return
        self.continue_mode = cat.get("special") == "continue"
        if self.continue_mode:                              # "Continue watching": from the resume points
            kinds = {
                VOD: (
                    "vod",), SERIES: (
                    "episode",)}.get(
                self.kind) if not self.fav_mode else None
            self.category_name = _("Continue watching")
            self._items_ok(core.resume.recent(kinds), token)
            return
        if "fav" in cat:                                    # Favorites screen
            self.kind = cat["fav"]
            self.sort_mode = core.sort_config(self.kind).value
            self.category_name = dict(fav_kinds())[self.kind]
        elif cat.get("special") == "fav":
            self.category_name = _("Favorites")
        if "fav" in cat or cat.get("special") == "fav":
            # favorites from protected categories stay locked too
            kind = self.kind
            run_async(
                core.filter_locked,
                (kind,
                 core.favorites.items(kind)),
                callback=lambda items: self._items_ok(
                    items,
                    token),
                errback=self._error)
            return
        self.category_name = _("All") if cat.get(
            "special") == "all" else cat["name"]
        self["items"].set_entries(
            [self["items"].entry(None, _("Loading..."), color=C_DIM)])
        kind, cat_id = self.kind, cat.get("id")
        run_async(
            lambda: core.filter_locked(
                kind, core.client().items(
                    kind, cat_id)), callback=lambda items: self._items_ok(
                items, token), errback=self._error)

    def _unlocked(self):
        """Right PIN: redraw the categories without the closed padlock and open the chosen one."""
        self.loaded_cat = None
        self._load_category()

    def _items_ok(self, items, token):
        if not self.alive or token != self.load_token:
            return
        items = items or []
        if self.kind == VOD and not getattr(self, "continue_mode", False):
            # "==...==" headers and series inside VOD grouped
            items = organize(items)
        self.items_all = items
        live = self.kind == LIVE and not getattr(self, "continue_mode", False)
        self["items"].set_item_height(
            84 if live else 60)   # channels have 2 lines
        self._refresh_items()
        if self.items_all and not getattr(self, "auto_load", False):
            self._set_focus("items")
        self._schedule_panel()

    # ------------------------------------------------------------------
    # Content list
    # ------------------------------------------------------------------
    def _refresh_items(self, keep_index=False):
        items = self.items_all
        if self.search_text or self.sort_mode != "server":
            # headers only make sense in the server order
            items = [i for i in items if i.get("kind") != SEP]
        if self.search_text:
            needle = self.search_text.lower()
            items = [
                i for i in items if needle in (
                    i.get("name") or "").lower()]
        if self.sort_mode == "az":
            items = sorted(items, key=_sort_name)
        elif self.sort_mode == "za":
            items = sorted(items, key=_sort_name, reverse=True)
        elif self.sort_mode == "year":
            items = sorted(
                items,
                key=lambda i: (
                    i.get("year") or "0000",
                    _sort_name(i)),
                reverse=True)
        elif self.sort_mode == "new":
            items = sorted(
                items,
                key=lambda i: i.get("added") or "",
                reverse=True)
        elif self.sort_mode == "rating":
            items = sorted(
                items,
                key=lambda i: float(
                    self._tmdb_rating(i) or 0),
                reverse=True)
        self.items_view = items
        lst = self["items"]
        index = lst.getSelectedIndex() if keep_index else 0
        if not items:
            msg = (_(u"No results for \u201c%s\u201d") %
                   self.search_text) if self.search_text else _("No content")
            lst.set_entries([lst.entry(None, msg, color=C_DIM)])
        else:
            lst.set_entries([self._entry(i) for i in items], index)
        title = titles()[self._mode()] + u"  \u203a  " + (u"\u201c%s\u201d  \u203a  %s" %
                                                          (self.search_query, self.category_name) if self.search_query else self.category_name)
        if self.search_text:
            title += u"  \u203a  \u201c%s\u201d" % self.search_text
        self["header"].setText(T(title))
        self._update_count()

    def _update_count(self):
        """'13 titles • A → Z  (MENU)': how many and in which order."""
        n = len([i for i in self.items_view if i.get("kind") != SEP])
        label = _("Relevance") if (
            self.search_query and self.sort_mode == "server") else core.sort_label(
            self.sort_mode)
        self["count"].setText(
            T(_(u"%d titles   \u2022   %s  (MENU)") % (n, label)))

    def _key(self, item):
        return "%s:%s" % (item.get("kind"), item.get("id"))

    def _entry(self, item):
        lst = self["items"]
        if item.get("kind") == LIVE:
            cur, nxt = core.epg().now_next(item.get("epg_id"))
            event = cur or nxt
            sub = (
                u"%s  %s" %
                (_hm(
                    event["start"]),
                    event["title"])) if event else u""
            return lst.entry_two(
                item,
                self._label(item),
                sub,
                progress(cur) if cur else None)
        if item.get("kind") == SEP:
            return lst.entry(
                item,
                u"\u2014  %s  \u2014" %
                item["name"],
                color=C_DIM)
        return lst.entry(item, self._label(item), self._right(item), C_GOLD)

    def _label(self, item):
        if item.get("resume_entry"):
            sub = item.get("subtitle")
            return (item.get("name") or u"") + ((u"   " + sub) if sub else u"")
        heart = u"\u2665 " if core.favorites.contains(item) else u""
        prefix = u"\u25a3 " if item.get("kind") == GROUP else u""
        return heart + prefix + (item.get("name") or "")

    def _tmdb_rating(self, item):
        info = self.info_cache.get(self._key(item))
        return info.get("rating", "") if info else ""

    def _right(self, item):
        """Right column: TMDB rating (as soon as it is known), otherwise year or number of episodes."""
        kind = item.get("kind")
        if item.get("resume_entry") or (kind in (VOD, SERIES)
                                        and core.resume.percent(item)):
            pct = core.resume.percent(item)
            return (u"\u25b6 %d%%" % pct) if pct else u""
        if kind in (LIVE, SEP):
            return u""
        rating = self._tmdb_rating(item)
        if kind == GROUP:
            return summary(item)
        if rating:
            return u"\u2605 %s" % rating
        return item.get("year") or u""

    def _update_row(self, key):
        """Update only the row of that item (e.g. when the TMDB rating arrives)."""
        for index, item in enumerate(self.items_view):
            if self._key(item) == key:
                self["items"].update_entry(index, self._entry(item))
                break

    # ------------------------------------------------------------------
    # Navigation
    # ------------------------------------------------------------------
    def _set_focus(self, which):
        self.focus = which
        self["cats"].focus(which == "cats")
        self["items"].focus(which == "items")

    def move(self, direction):
        self[self.focus].move(direction)
        if self.focus == "items":
            self._schedule_panel()
        else:
            # half a second on a category: it loads by itself
            self.cat_timer.start(500, True)

    def focus_cats(self):
        self._set_focus("cats")

    def right(self):
        if self.focus == "cats":
            self._load_category()
        elif self.items_view:
            self._set_focus("items")

    def ok(self):
        if self.focus == "cats":
            self._load_category()
        else:
            self.open_details()

    def back(self):
        if self.search_text:
            self.search_text = ""
            self._refresh_items()
            self._schedule_panel()
        elif self.focus == "items":
            self._set_focus("cats")
        else:
            self.close()

    def current_item(self):
        item = self["items"].current() if self.focus == "items" else None
        return None if (item and item.get("kind") == SEP) else item

    # ------------------------------------------------------------------
    # Actions
    # ------------------------------------------------------------------
    def open_details(self):
        item = self.current_item()
        if not item:
            return
        if item.get("resume_entry"):
            return self.play_direct()
        if item["kind"] == LIVE:
            return self.play_direct()
        # hand the details page what the quick panel already found (poster at
        # once, no waiting)
        info = self.info_cache.get(self._key(item))
        if item["kind"] == VOD:
            from .details import MovieScreen
            self.session.openWithCallback(
                self._after_details, MovieScreen, item, info)
        else:
            from .details import SeriesScreen
            self.session.openWithCallback(
                self._after_details, SeriesScreen, item, info)

    def _after_details(self, *args):
        if not self.alive:
            return
        if getattr(
            self,
            "continue_mode",
                False):    # positions changed: rebuild the list
            self.items_all = core.resume.recent({VOD: ("vod",), SERIES: (
                "episode",)}.get(self.kind) if not self.fav_mode else None)
        # update hearts and resume marks
        self._refresh_items(keep_index=True)

    def play_direct(self):
        item = self.current_item()
        if not item:
            return
        from .player import XCDPlayer
        if item.get(
                "resume_entry"):                # continue where it stopped (the player asks)
            return self.session.openWithCallback(
                self._after_details, XCDPlayer, [dict(item)], 0)
        if item["kind"] in (SERIES, GROUP):
            return self.open_details()
        if item["kind"] == LIVE:
            playlist = [i for i in self.items_view if i.get("kind") == LIVE]
            index = playlist.index(item) if item in playlist else 0
            self.session.open(XCDPlayer, playlist, index, self._after_zap)
        else:
            # the player shows poster and details (INFO key) with the data
            # already found
            self.session.openWithCallback(
                self._after_details, XCDPlayer, [
                    dict(
                        item, info=self.info_cache.get(
                            self._key(item)))], 0)

    def _after_zap(self, index):
        """After zapping, move the list to the last watched channel."""
        if self.alive and 0 <= index < len(self.items_view):
            self["items"].moveToIndex(index)
            self._schedule_panel()

    def toggle_fav(self):
        item = self.current_item()
        if not item:
            return
        added = core.favorites.toggle(item)
        if self.fav_mode or (
                self["cats"].current() or {}).get("special") == "fav":
            self.items_all = core.favorites.items(self.kind)
        self._refresh_items(keep_index=True)
        self.session.open(MessageBox, T(_("Added to favorites") if added else _(
            "Removed from favorites")), MessageBox.TYPE_INFO, timeout=2)

    def search(self):
        def done(text):
            if text is None:
                return
            self.search_text = text.strip()
            if not self.items_all and not self.fav_mode:
                # no category open: search in "All"
                self["cats"].moveToIndex(getattr(self, "all_index", 1))
                self.load_token += 1
                token = self.load_token
                self.category_name = _("All")
                search = self.search_text
                run_async(
                    core.client().items,
                    (self.kind,
                     None),
                    callback=lambda items: self._search_loaded(
                        items,
                        token,
                        search),
                    errback=self._error)
                return
            self._refresh_items()
            self._set_focus("items")
            self._schedule_panel()
        self.session.openWithCallback(
            done, VirtualKeyBoard, title=T(
                _("Search in the title")), text=self.search_text)

    def _search_loaded(self, items, token, search):
        self._items_ok(items, token)
        self.search_text = search
        self._refresh_items()

    def menu(self):
        """MENU: on categories sort or PIN-protect; on titles sort (and catchup/download)."""
        item = self.current_item()
        if self.focus == "items" and item and (
                item.get("archive") or item.get("kind") == VOD or item.get("resume_entry")):
            return self.item_menu(item)
        cat = self["cats"].current() if self.focus == "cats" else None
        if not cat or not cat.get(
                "id") or "special" in cat or self.search_query:
            return self.sort_menu()
        protected = core.is_protected(self.kind, cat)
        choices = [(T(_("Sort the list...")), "sort"), (T(_("Remove the PIN protection")
                                                          if protected else _("Protect this category with the PIN")), "pin")]

        def done(choice):
            if not choice:
                return
            if choice[1] == "sort":
                return self.sort_menu()
            if not core.parental_active():
                return self.session.open(
                    MessageBox, T(
                        _("First enable parental control and choose a PIN in Settings.")), MessageBox.TYPE_INFO)

            def toggle(ok):
                if not ok or not self.alive:
                    return
                core.protection().set_protected(
                    core.server_key(), self.kind, cat, not protected)
                index = self["cats"].getSelectedIndex()
                self["cats"].update_entry(index, self._cat_entry(cat))
            # removing a protection always asks for the PIN, even when already
            # unlocked
            if protected:
                core.protection().unlocked = False
            core.ask_pin(self.session, toggle)
        self.session.openWithCallback(
            done, ChoiceBox, title=T(
                cat["name"]), list=choices)

    def item_menu(self, item):
        choices = []
        if item.get("resume_entry") or core.resume.get(item):
            choices.append((T(_("Remove from Continue watching")), "forget"))
        if item.get("archive"):
            choices.append((T(_("Catchup (archive of %d days)") %
                           item.get("archive_days", 0)), "catchup"))
        if item.get("kind") == VOD and not item.get("resume_entry"):
            choices.append((T(_("Add to downloads")), "download"))
        choices.append((T(_("Sort the list...")), "sort"))

        def done(choice):
            if not choice or not self.alive:
                return
            if choice[1] == "catchup":
                from .catchup import CatchupScreen
                self.session.open(CatchupScreen, item)
            elif choice[1] == "download":
                core.add_download(self.session, item)
            elif choice[1] == "forget":
                core.resume.clear(item)
                self._after_details()
            else:
                self.sort_menu()
        self.session.openWithCallback(
            done, ChoiceBox, title=T(
                item.get(
                    "name", u"")), list=choices)

    def sort_menu(self):
        modes = core.SORT_MODES[:4] if self.kind == LIVE else core.SORT_MODES
        choices = [(T((u"\u2713 " if key == self.sort_mode else u"   ") +
                    core.sort_label(key)), key) for key, _label in modes]

        def done(choice):
            if choice:
                self.sort_mode = choice[1]
                # remembered for next time
                core.save_sort(self.kind, self.sort_mode)
                self._refresh_items()
                self._schedule_panel()
        self.session.openWithCallback(
            done, ChoiceBox, title=T(
                _("Sort by")), list=choices)

    def _epg_changed(self):
        """The guide arrived (or changed): redraw channels and panel."""
        if self.alive and self.kind == LIVE and self.items_view:
            self._refresh_items(keep_index=True)
            self._schedule_panel()

    def _tick_epg(self):
        """Every minute update the rows near the cursor (bars and programme on air)."""
        if not self.alive or self.kind != LIVE or not self.items_view:
            return
        center = self["items"].getSelectedIndex()
        for index in range(max(0, center - 15),
                           min(len(self.items_view), center + 16)):
            self["items"].update_entry(
                index, self._entry(
                    self.items_view[index]))

    def _epg_shift(self, step):
        """7 = one hour back, 8 = automatic, 9 = one hour forward (live channels only)."""
        if self.kind != LIVE:
            return
        hours = core.set_epg_offset(
            0 if step == 0 else core.epg_offset_hours() + step)
        self._refresh_items(keep_index=True)
        self["count"].setText(
            T(_("EPG time: automatic") if hours == 0 else _("EPG time: %+d h") % hours))
        self._schedule_panel()

    def _error(self, err):
        if not self.alive:
            return
        self["items"].set_entries(
            [self["items"].entry(None, _("Error: %s") % err, color=C_DIM)])
        self["count"].setText("")

    # ------------------------------------------------------------------
    # Right panel (delayed, so nothing is downloaded on every key press)
    # ------------------------------------------------------------------
    def _schedule_panel(self):
        self.panel_timer.stop()
        item = self["items"].current()
        if not item:
            self._clear_panel()
            return
        self["p_title"].setText(T(item.get("name", "")))
        self.panel_timer.start(450, True)

    def _clear_panel(self):
        for w in ("p_title", "p_meta", "p_extra", "p_plot"):
            self[w].setText("")
        self["progress"].hide()
        self.poster.clear()

    def _fill_panel(self):
        item = self["items"].current()
        if not item:
            return
        key = self._key(item)
        self["progress"].hide()
        self["p_extra"].setText("")
        if item.get("resume_entry"):
            return self._show_resume(item)
        if item["kind"] == SEP:
            self._clear_panel()
            self["p_title"].setText(T(item["name"]))
            self["p_plot"].setText(T(_("Provider header")))
            return
        if item["kind"] == LIVE:
            self.poster.load(item.get("icon"))
            self["p_title"].setText(T(item.get("name", "")))
            self["p_meta"].setText("")
            self["progress"].hide()
            cur, nxt = core.epg().now_next(item.get("epg_id"))
            if cur or nxt:                       # full guide: immediate answer
                return self._show_epg(key, [e for e in (cur, nxt) if e])
            self["p_plot"].setText(T(_("Loading the guide...")))
            run_async(
                core.client().short_epg, (item["id"], 3), callback=lambda epg: self._show_epg(
                    key, epg), errback=lambda e: self._show_epg(
                    key, []))
            return
        if key in self.info_cache:
            return self._show_info(key, self.info_cache[key])
        # With TMDB on, wait directly for its poster (the server cover comes inside the data
        # when TMDB has none): half the requests and no "in between" image.
        if core.tmdb().enabled:
            self.poster.clear()
        else:
            self.poster.load(item.get("icon"))
        self["p_meta"].setText(T(self._right(item)))
        self["p_plot"].setText(T(_("Looking up the details...")))
        run_async(
            _panel_info, (item,), callback=lambda info: self._got_info(
                key, info), errback=lambda e: self._got_info(
                key, merge_info(
                    {}, {}, item.get("name"))))

    def _show_resume(self, item):
        """Continue watching: everything is in the saved copy, no requests to the server."""
        self.poster.load(item.get("icon") or item.get("image"))
        self["p_title"].setText(T(item.get("name", u"")))
        pos = core.resume.get(item)
        pct = core.resume.percent(item)
        meta = _("Stopped at %d min") % (pos // 60) + \
            ((u"  (%d%%)" % pct) if pct else u"")
        self["p_meta"].setText(T(meta))
        self["progress"].setValue(pct or 0)
        self["progress"].show()
        plot = item.get("plot") or u""
        self["p_extra"].setText(T(item.get("subtitle") or u""))
        self["p_plot"].setText(
            T(plot[:240] + u"\n" + _("OK: continue   MENU: remove from the list")))

    def _is_current(self, key):
        item = self["items"].current()
        return self.alive and item and self._key(item) == key

    def _got_info(self, key, info):
        if not self.alive:
            return
        self.info_cache[key] = info
        if info.get("rating"):
            # the TMDB rating shows in the list too
            self._update_row(key)
        if self._is_current(key):
            self._show_info(key, info)

    def _show_info(self, key, info):
        self["p_title"].setText(T(info["title"]))
        # gold line: year / certification / runtime / rating(votes) -- genres
        # go in the extra lines
        self["p_meta"].setText(T(meta_line(info, genres=False)))
        self["p_extra"].setText(
            T(detail_lines(info, self["items"].current() or {})))
        plot = info["overview"] or _("Plot not available.")
        tag = info.get("tagline")
        if tag and tag.lower() != (info.get("title") or u"").lower():
            plot = u"\u201c%s\u201d\n%s" % (tag, plot)
        self["p_plot"].setText(
            T(plot[:260] + (u"\u2026" if len(plot) > 260 else u"")))
        self.poster.load(info["poster"])

    def _show_epg(self, key, epg):
        if not self._is_current(key):
            return
        now = int(time.time())
        cur = [e for e in epg if e["start"] <= now < e["stop"]]
        nxt = [e for e in epg if e["start"] >= now]
        item = self.current_item()
        hint = (
            u"\n" +
            _("Catchup: %d days of archive (MENU)") %
            item.get(
                "archive_days",
                0)) if item and item.get("archive") else u""
        if not cur and not nxt:
            self["p_plot"].setText(T(_("No guide for this channel.") + hint))
            return
        lines = []
        if cur:
            e = cur[0]
            self["p_meta"].setText(T(u"%s - %s   %s" %
                                     (_hm(e["start"]), _hm(e["stop"]), e["title"])))
            total = max(1, e["stop"] - e["start"])
            self["progress"].setValue(int(100 * (now - e["start"]) / total))
            self["progress"].show()
            if e["desc"]:
                self["p_extra"].setText(
                    T(e["desc"][:160] + (u"\u2026" if len(e["desc"]) > 160 else u"")))
        if nxt:
            lines.append(_("Next:") + u"  %s  %s" %
                         (_hm(nxt[0]["start"]), nxt[0]["title"]))
        if hint:
            lines.append(hint)
        self["p_plot"].setText(T(u"\n".join(lines)))


def _short(text, limit=44):
    text = u" ".join((text or u"").split())
    return text if len(
        text) <= limit else text[:limit - 1].rstrip(u" ,") + u"\u2026"


def detail_lines(info, item):
    """Up to four short lines under the poster. Priority: genres/country, series run,
    original title, director/creator, cast, file format."""
    kind = item.get("kind")
    is_series = kind in (SERIES, GROUP)
    lines = []

    # genres and country of origin
    gc = [p for p in (info.get("genres"), info.get("countries")) if p]
    if gc:
        lines.append(_short(u"  •  ".join(gc)))

    # series: how many seasons/episodes and whether it is still running
    if is_series:
        run = []
        ns = info.get("seasons_count") or 0
        ne = info.get("episodes_count") or 0
        if ns:
            run.append(ngettext("%d season", "%d seasons", ns) % ns)
        if ne:
            run.append(ngettext("%d episode", "%d episodes", ne) % ne)
        line = u"  •  ".join(run)
        if info.get("status"):
            line = (
                line +
                u"  •  " +
                info["status"]) if line else info["status"]
        if line:
            lines.append(_short(line))

    original = info.get("original_title")
    if original and original.lower() != (info.get("title") or u"").lower():
        lines.append(_short(_("Original title:") + u" " + original))
    if info.get("director"):
        label = _("Created by:") if is_series else _("Director:")
        lines.append(_short(label + u" " + info["director"]))
    if info.get("cast"):
        cast = u", ".join([c.strip()
                          for c in info["cast"].split(",") if c.strip()][:3])
        lines.append(_short(_("Cast:") + u" " + cast))
    fmt = (info.get("ext") or item.get("ext") or u"").upper()
    if fmt and kind == VOD:
        lines.append(_("Format:") + u" " + fmt)
    return u"\n".join(lines[:4])


def _sort_name(item):
    """Name for alphabetical order without provider prefixes ("IT - ", "|IT|", "[HD]"...)."""
    name = item.get("name") or u""
    return (clean_title(name)[0] or name).lower()


def _hm(ts):
    return time.strftime("%H:%M", time.localtime(ts))


def _panel_info(item):
    """Runs in the background: IPTV server data + TMDB, merged."""
    tm = core.tmdb()
    if item["kind"] == VOD:
        xt = {}
        try:
            xt = core.client().vod_info(item["id"])
        except Exception:
            pass
        xt.setdefault("icon", item.get("icon"))
        tm_info = {}
        if tm.enabled:
            try:
                tm_info = tm.lookup("movie", xt.get("name") or item["name"], xt.get(
                    "year") or item.get("year"), xt.get("tmdb") or item.get("tmdb"))
            except Exception:
                tm_info = {}
        info = merge_info(xt, tm_info, item["name"])
        info["ext"] = xt.get("ext", "")
        return info
    # series (real ones or grouped from VOD)
    xt = {
        "name": item["name"],
        "plot": item.get("plot"),
        "genre": item.get("genre"),
        "rating": item.get("rating"),
        "year": item.get("year"),
        "icon": item.get("icon")}
    tm_info = {}
    if tm.enabled:
        try:
            tm_info = tm.lookup(
                "tv",
                item["name"],
                item.get("year"),
                item.get("tmdb"))
        except Exception:
            tm_info = {}
    return merge_info(xt, tm_info, item["name"])
