# -*- coding: utf-8 -*-
"""XC Diamond - Xtream Codes client with TMDB details for Enigma2.
No lists included: server, username and password are entered by the user."""

from Plugins.Plugin import PluginDescriptor

from . import _, core


def _open_home(session):
    from .home import HomeScreen
    session.open(HomeScreen)


def main(session, **kwargs):
    try:
        from .fonts import ensure_fonts
        ensure_fonts()                       # fallback font for Arabic etc. (once)
    except Exception as e:
        print("[XCDiamond] font: %s" % e)
    # License: on with license_box.SERVER_URL (or DEMO = True to look at the
    # screen)
    try:
        from . import license_box
        if license_box.enabled():
            license_box.request_license(
                session, on_success=lambda: _open_home(session))
            return
    except Exception as e:
        print("[XCDiamond] license: %s" % e)
    _open_home(session)


def sessionstart(reason, session=None, **kwargs):
    """At Enigma2 start: timer for the automatic bouquet update and the daily version check."""
    if reason == 0:
        try:
            from .fonts import ensure_fonts
            ensure_fonts()                   # register the fallback font at boot too
        except Exception as e:
            print("[XCDiamond] font: %s" % e)
        try:
            core.start_auto_bouquet()
        except Exception as e:
            print("[XCDiamond] bouquet timer start: %s" % e)
        try:
            core.start_download_scheduler()
        except Exception as e:
            print("[XCDiamond] download timer start: %s" % e)
        try:
            from .about import start_auto_check
            start_auto_check(session)
        except Exception as e:
            print("[XCDiamond] update check: %s" % e)
        try:
            from . import webif
            webif.start()                    # web interface to manage accounts (port 8765)
        except Exception as e:
            print("[XCDiamond] webif: %s" % e)


def menu(menuid, **kwargs):
    if menuid == "mainmenu":
        return [(core.PLUGIN_NAME, main, "xcdiamond", 45)]
    return []


def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name=core.PLUGIN_NAME,
            description=_("Xtream IPTV with TMDB details"),
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="plugin.png",
            fnc=main),
        PluginDescriptor(
            name=core.PLUGIN_NAME,
            description=_("Xtream IPTV with TMDB details"),
            where=PluginDescriptor.WHERE_EXTENSIONSMENU,
            fnc=main),
        PluginDescriptor(
            name=core.PLUGIN_NAME,
            where=PluginDescriptor.WHERE_MENU,
            fnc=menu),
        PluginDescriptor(
            where=PluginDescriptor.WHERE_SESSIONSTART,
            fnc=sessionstart),
    ]
