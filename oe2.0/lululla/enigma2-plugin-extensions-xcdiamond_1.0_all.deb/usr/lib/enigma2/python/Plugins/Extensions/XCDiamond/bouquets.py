# -*- coding: utf-8 -*-
"""Export channels (and movies) to Enigma2 bouquets, plus the EPGImporter files.

Created structure:
  /etc/enigma2/bouquets.tv                      + one line "FROM BOUQUET userbouquet.xcdiamond.tv"
  /etc/enigma2/userbouquet.xcdiamond.tv          main bouquet "XC Diamond"
  /etc/enigma2/subbouquet.xcdiamond_<n>.tv       one sub-bouquet for each chosen category
  /etc/epgimport/xcdiamond.sources.xml           EPG source = the server xmltv.php
  /etc/epgimport/xcdiamond.channels.xml          channel EPG id -> service reference

Every channel gets a unique reference (SID/TSID/ONID) derived from its server id:
EPGImporter uses it to attach the guide to the right channel.
Written from scratch; no Enigma2 dependency except the final list reload."""

import hashlib
import os
import re
import time

from . import _

try:
    from xml.sax.saxutils import escape
except ImportError:      # pragma: no cover
    def escape(text):
        return text.replace(
            "&",
            "&amp;").replace(
            "<",
            "&lt;").replace(
            ">",
            "&gt;")

ENIGMA_DIR = "/etc/enigma2"
EPGIMPORT_DIR = "/etc/epgimport"
# Per-account tag: "xcd_<account slug>", so every server gets its own bouquet and EPG files
# instead of overwriting a single shared one. LEGACY is the old single-account prefix, which
# export() cleans up once (its files start with "xcdiamond", never with
# "xcd_").
BASE = "xcd"
LEGACY = "xcdiamond"
# Different ONID for channels and movies: tells our services apart from
# satellite ones and from each other
ONIDS = {"live": 0x5844, "vod": 0x5845}        # "XD", "XE"
# EPGImporter tries every reference with a fake recording: a reference without an address
# (like a missing satellite channel) is silently dropped and the guide is not loaded.
EPG_DUMMY_URL = "http%3a//example.m3u8"


def _u(text):
    if text is None:
        return u""
    if not isinstance(text, type(u"")):
        return text.decode("utf-8", "ignore")
    return text


def _utf8(text):
    """Text to write to a file (utf-8 on both Python 2 and 3)."""
    text = _u(text)
    return text.encode("utf-8") if not isinstance(text, str) else text


def service_ids(kind, stream_id):
    """Unique (SID, TSID, ONID, NS) for a server item.
    A channel always has the same reference (in Favorites too), so the guide works everywhere."""
    try:
        n = int(stream_id)
    except (TypeError, ValueError):
        n = abs(hash(stream_id)) & 0x7FFFFFFF
    sid = (n & 0xFFFF) or 1
    tsid = ((n >> 16) & 0xFFFF) + 1
    return sid, tsid, ONIDS.get(kind, ONIDS["live"]), 0


def service_line(player, kind, stream_id, url, name):
    """#SERVICE ... with the address inside (the ':' of the url must be written %3a)."""
    sid, tsid, onid, ns = service_ids(kind, stream_id)
    return u"#SERVICE %s:0:1:%X:%X:%X:%X:0:0:0:%s:%s" % (player, sid, tsid, onid, ns, _u(
        url).replace(u":", u"%3a"), _u(name).replace(u":", u" "))


def epg_ref(kind, stream_id):
    """Reference for EPGImporter: same SID/TSID/ONID as the bouquet + a placeholder address
    (needed to pass the EPGImporter check; the guide is matched by SID/TSID/ONID)."""
    sid, tsid, onid, ns = service_ids(kind, stream_id)
    return u"1:0:1:%X:%X:%X:%X:0:0:0:%s" % (sid, tsid, onid, ns, EPG_DUMMY_URL)


def safe_name(text):
    text = re.sub(r"[^a-z0-9]+", "_", _u(text).lower())
    return text.strip("_")[:40] or "list"


class Exporter(object):
    """Create, update and remove the XC Diamond bouquets."""

    def __init__(
            self,
            client,
            player="4097",
            live_ext="ts",
            position="top",
            enigma_dir=None,
            epg_dir=None,
            account=None):
        self.client = client
        self.player = player
        self.live_ext = live_ext
        self.position = position if position in (
            "top", "bottom", "keep") else "top"
        self.enigma_dir = enigma_dir or ENIGMA_DIR
        self.epg_dir = epg_dir or EPGIMPORT_DIR

        # Account identity: shown as the bouquet name, and used (unique per server+user) for
        # the file names. account overrides it (e.g. the "HOME"/"BACKUP" name); otherwise the
        # username is used, as it is short and recognisable.
        self.account = (
            account or getattr(
                client,
                "username",
                "") or "").strip()
        self.label = self.account or _("XC Diamond")
        key = (
            u"%s|%s" %
            (getattr(
                client,
                "server",
                ""),
                self.account)).encode("utf-8")
        suffix = hashlib.md5(key).hexdigest()[:4]
        self.slug = "%s_%s" % (safe_name(self.account)[:20] or "acct", suffix)
        self.tag = "%s_%s" % (BASE, self.slug)              # e.g. xcd_kul_a1b2
        self.main = "userbouquet.%s.tv" % self.tag

    def path(self, name):
        return os.path.join(self.enigma_dir, name)

    # ------------------------------------------------------------------
    def export(self, selection, favorites=None, epgimport=True, progress=None):
        """selection: {"live": [categories], "vod": [categories]} (dicts with id and name).
        favorites: items for the "Favorites" sub-bouquet.
        Runs in a thread. Returns a summary."""
        self._remove_legacy()
        self.remove(reload_lists=False, keep_main_line=True)
        subs, channels, epg_map = [], 0, []
        jobs = [("live", c) for c in selection.get("live", [])] + \
            [("vod", c) for c in selection.get("vod", [])]
        if favorites:
            jobs.insert(
                0, ("fav", {"id": "favorites", "name": u"\u2665 " + _("Favorites")}))
        for number, (kind, cat) in enumerate(jobs):
            if progress:
                progress(number, len(jobs), cat.get("name"))
            if kind == "fav":
                items = favorites
            else:
                try:
                    items = self.client.items(kind, cat.get("id"))
                except Exception as e:
                    print("[XCDiamond] bouquet %s: %s" % (cat.get("name"), e))
                    continue
            lines = []
            for it in items:
                item_kind = it.get("kind")
                if item_kind not in ("live", "vod"):
                    continue                       # series and headers do not go into bouquets
                ext = self.live_ext if item_kind == "live" else (
                    it.get("ext") or "mp4")
                url = self.client.stream_url(dict(it, ext=ext), self.live_ext)
                ns_kind = item_kind                 # Favorites use the same reference as the channel
                lines.append(
                    service_line(
                        self.player,
                        ns_kind,
                        it["id"],
                        url,
                        it.get("name")))
                lines.append(u"#DESCRIPTION %s" % _u(it.get("name")))
                if item_kind == "live" and it.get("epg_id"):
                    epg_map.append((it["epg_id"], epg_ref(ns_kind, it["id"])))
                channels += 1
            if not lines:
                continue
            sub = "subbouquet.%s_%02d_%s.tv" % (
                self.tag, number, safe_name(cat.get("name")))
            self._write(sub, [u"#NAME %s" % _u(cat.get("name"))] + lines)
            subs.append(sub)
        self._write(self.main, [u"#NAME %s" %
                                _u(self.label)] +
                    [u'#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' %
                     sub for sub in subs])
        self._add_to_bouquets_tv()
        if epgimport:
            self._write_epgimport(epg_map)
        self.reload()
        return {
            "bouquets": len(subs),
            "channels": channels,
            "epg": len(epg_map),
            "time": int(
                time.time())}

    # ------------------------------------------------------------------
    def _write(self, name, lines):
        tmp = self.path(name) + ".tmp"
        with open(tmp, "w") as f:
            for line in lines:
                f.write(_utf8(line) + "\n")
        os.rename(tmp, self.path(name))

    def _add_to_bouquets_tv(self):
        """Put the XC Diamond bouquet in the TV list: at the top, at the bottom, or leave it where it is
        (with "leave where it is" it goes to the top the first time, then a manual move is respected)."""
        tv = self.path("bouquets.tv")
        line = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % self.main
        try:
            with open(tv) as f:
                rows = f.read().splitlines()
        except (IOError, OSError):
            rows = ["#NAME User - bouquets (TV)"]
        present = any(self.main in r for r in rows)
        if present and self.position == "keep":
            return False
        if not os.path.exists(tv + ".xcdiamond.bak") and os.path.exists(tv):
            with open(tv + ".xcdiamond.bak", "w") as f:        # safety copy, once
                f.write("\n".join(rows) + "\n")
        head = [r for r in rows if r.startswith("#NAME")][:1] or [
            "#NAME User - bouquets (TV)"]
        others = [r for r in rows if not r.startswith(
            "#NAME") and self.main not in r]
        while others and not others[-1].strip():
            others.pop()
        if self.position == "bottom":
            new = head + others + [line]
        else:
            new = head + [line] + others
        if new == rows:
            return False
        rows = new
        with open(tv + ".tmp", "w") as f:
            f.write("\n".join(rows) + "\n")
        os.rename(tv + ".tmp", tv)
        return True

    def move(self, position):
        """Move the existing bouquet now (True when something changed)."""
        self.position = position
        if not os.path.exists(self.path(self.main)):
            return False
        changed = self._add_to_bouquets_tv()
        if changed:
            self.reload()
        return changed

    def _write_epgimport(self, epg_map):
        if not os.path.isdir(self.epg_dir):
            try:
                os.makedirs(self.epg_dir)
            except OSError:
                return
        url = "%s/xmltv.php?username=%s&password=%s" % (
            self.client.server, self.client.username, self.client.password)
        channels_file = os.path.join(
            self.epg_dir,
            "%s.channels.xml" %
            self.tag)
        rows = [u'<?xml version="1.0" encoding="utf-8"?>', u"<channels>"]
        seen = set()
        for epg_id, ref in epg_map:
            key = (epg_id, ref)
            if key in seen:
                continue
            seen.add(key)
            rows.append(
                u'  <channel id="%s">%s</channel><!-- %s -->' %
                (escape(
                    _u(epg_id)), ref, escape(
                    _u(epg_id))))
        rows.append(u"</channels>")
        with open(channels_file, "w") as f:
            f.write(_utf8(u"\n".join(rows)) + "\n")
        sources = [u'<?xml version="1.0" encoding="utf-8"?>', u"<sources>",
                   u'  <sourcecat sourcecatname="XC Diamond">',
                   u'    <source type="gen_xmltv" nocheck="1" channels="%s">' % channels_file,
                   u"      <description>XC Diamond - %s</description>" % escape(_u(self.client.server.split("://")[-1])),
                   u"      <url><![CDATA[%s]]></url>" % _u(url),
                   u"    </source>", u"  </sourcecat>", u"</sources>"]
        with open(os.path.join(self.epg_dir, "%s.sources.xml" % self.tag), "w") as f:
            f.write(_utf8(u"\n".join(sources)) + "\n")

    # ------------------------------------------------------------------
    def _remove_legacy(self):
        """Remove bouquets/EPG left by the old single-account builds (prefix 'xcdiamond').
        New files use the 'xcd_' prefix, so this never touches a real per-account bouquet."""
        try:
            for name in os.listdir(self.enigma_dir):
                if name.startswith(
                        "userbouquet.%s." %
                        LEGACY) or name.startswith(
                        "subbouquet.%s_" %
                        LEGACY):
                    try:
                        os.remove(self.path(name))
                    except OSError:
                        pass
        except OSError:
            pass
        tv = self.path("bouquets.tv")
        try:
            with open(tv) as f:
                rows = f.read().splitlines()
            kept = [r for r in rows if ("userbouquet.%s.tv" % LEGACY) not in r]
            if len(kept) != len(rows):
                with open(tv + ".tmp", "w") as f:
                    f.write("\n".join(kept) + "\n")
                os.rename(tv + ".tmp", tv)
        except (IOError, OSError):
            pass
        for name in ("%s.sources.xml" % LEGACY, "%s.channels.xml" % LEGACY):
            p = os.path.join(self.epg_dir, name)
            if os.path.exists(p):
                try:
                    os.remove(p)
                except OSError:
                    pass

    def remove(self, reload_lists=True, keep_main_line=False):
        """Remove this account's XC Diamond bouquets and EPG files; everything else stays untouched."""
        removed = 0
        for name in os.listdir(self.enigma_dir):
            if name.startswith(
                    "subbouquet.%s_" %
                    self.tag) or (
                    name == self.main and not keep_main_line):
                os.remove(self.path(name))
                removed += 1
        if not keep_main_line:
            tv = self.path("bouquets.tv")
            try:
                with open(tv) as f:
                    rows = f.read().splitlines()
                rows = [r for r in rows if self.main not in r]
                with open(tv + ".tmp", "w") as f:
                    f.write("\n".join(rows) + "\n")
                os.rename(tv + ".tmp", tv)
            except (IOError, OSError):
                pass
            for name in (
                "%s.sources.xml" %
                self.tag,
                "%s.channels.xml" %
                    self.tag):
                p = os.path.join(self.epg_dir, name)
                if os.path.exists(p):
                    os.remove(p)
        if reload_lists:
            self.reload()
        return removed

    @staticmethod
    def reload():
        """Make Enigma2 reload the bouquets (does nothing on a PC)."""
        try:
            from enigma import eDVBDB
            db = eDVBDB.getInstance()
            db.reloadServicelist()
            db.reloadBouquets()
        except Exception:
            pass

    def installed(self):
        return os.path.exists(self.path(self.main))
