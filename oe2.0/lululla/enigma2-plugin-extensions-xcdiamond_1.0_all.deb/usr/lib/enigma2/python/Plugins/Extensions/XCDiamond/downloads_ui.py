# -*- coding: utf-8 -*-
"""Downloads screen: the list of movies and episodes put aside with MENU > Add to downloads.
The user decides for each one: download now, at a chosen time, stop, or remove."""

import os
import time

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Components.ActionMap import ActionMap
from Components.Label import Label

from .help import open_help
from . import _, core
from .downloads import (
    state_text,
    progress_text,
    free_bytes,
    QUEUED,
    SCHEDULED,
    RUNNING,
    PAUSED,
    DONE,
    ERROR)
from .ui import (
    T,
    XCDList,
    scale_skin,
    footer,
    clock,
    new_timer,
    BG,
    PANEL,
    TEXT,
    DIM,
    ACCENT,
    SEL,
    GOLD,
    C_DIM,
    C_GOLD,
    C_ACCENT)

C_RED = 0xff6060
C_GREEN = 0x7ddf7d


def _when(ts):
    lt, today = time.localtime(ts), time.localtime()
    if lt[:3] == today[:3]:
        return _("today %s") % time.strftime("%H:%M", lt)
    if time.localtime(ts - 86400)[:3] == today[:3]:
        return _("tomorrow %s") % time.strftime("%H:%M", lt)
    return time.strftime("%d/%m %H:%M", lt)


def status_line(it):
    state = it["state"]
    if state == SCHEDULED:
        if it["start_at"] > time.time():
            text = _("Starts %s") % _when(it["start_at"])
        elif core.downloads().running():
            text = _("Waiting for the current download")
        else:
            text = _("Waiting: the only connection of the account is in use (TV)")
        return text, C_GOLD
    if state == RUNNING:
        return state_text(state) + u"  " + progress_text(it), C_ACCENT
    if state == PAUSED:
        return state_text(state) + u"  " + progress_text(it), C_DIM
    if state == DONE:
        return state_text(state) + u"  " + progress_text(it), C_GREEN
    if state == ERROR:
        return state_text(state) + u": " + it.get("error", u""), C_RED
    return state_text(state), C_DIM


def _start_choices():
    """Now, tonight-style fixed times and 'in N hours'."""
    now = time.localtime()
    out = [(_("Now (after the current one)"), 0)]
    for hour in (1, 3, 5):
        ts = time.mktime((now.tm_year, now.tm_mon, now.tm_mday +
                         (1 if now.tm_hour >= hour else 0), hour, 0, 0, 0, 0, -1))
        out.append((_("At %s") % _when(ts), int(ts)))
    for hours in (1, 2, 4, 8):
        out.append((_("In %d hours") % hours, int(time.time() + hours * 3600)))
    return out


class DownloadsScreen(Screen):
    skin = scale_skin("""
    <screen name="XCDDownloads" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="%(bg)s">
        <widget name="header" position="60,30" size="1000,60" font="Regular;44" foregroundColor="%(text)s" backgroundColor="%(bg)s" transparent="1" />
        <widget name="count" position="760,42" size="880,40" font="Regular;28" halign="right" noWrap="1" foregroundColor="%(dim)s" backgroundColor="%(bg)s" transparent="1" />
        %(clock)s
        <eLabel position="60,110" size="1800,2" backgroundColor="%(panel)s" />
        <widget name="list" position="60,130" size="1800,756" itemHeight="84" backgroundColor="%(bg)s" backgroundColorSelected="%(sel)s" scrollbarMode="showOnDemand" transparent="1" />
        <widget name="empty" position="160,330" size="1600,300" font="Regular;32" halign="center" valign="center" foregroundColor="%(dim)s" backgroundColor="%(bg)s" transparent="1" />
        <eLabel position="60,900" size="1800,80" backgroundColor="%(panel)s" zPosition="-1" />
        <widget name="info" position="90,910" size="1740,60" font="Regular;26" valign="center" foregroundColor="%(text)s" backgroundColor="%(panel)s" transparent="1" />
        %(footer)s
    </screen>""" % dict(bg=BG, panel=PANEL, text=TEXT, dim=DIM, accent=ACCENT, sel=SEL, gold=GOLD,
                        clock=clock(), footer=footer()))

    def __init__(self, session):
        Screen.__init__(self, session)
        core.load_keymap()
        self.alive = True
        self.dm = core.downloads()
        self["header"] = Label(T(_("Downloads")))
        self["count"] = Label("")
        self["list"] = XCDList(font_size=30, item_height=84)
        self["empty"] = Label("")
        self["info"] = Label("")
        self["key_red"] = Label(T(_("Back")))
        self["key_green"] = Label(T(_("Download")))
        self["key_yellow"] = Label(T(_("Schedule")))
        self["key_blue"] = Label(T(_("Remove")))
        self["actions"] = ActionMap(["OkCancelActions",
                                     "ColorActions",
                                     "DirectionActions",
                                     "XCDActions"],
                                    {"ok": self.ok,
                                     "cancel": self.close,
                                     "red": self.close,
                                     "green": self.start_now,
                                     "yellow": self.schedule,
                                     "blue": self.remove,
                                     "menu": self.menu,
                                     "help": lambda: open_help(self.session,
                                                               "downloads"),
                                     "up": lambda: self._move("up"),
                                     "down": lambda: self._move("down"),
                                     "pageUp": lambda: self._move("pageUp"),
                                     "pageDown": lambda: self._move("pageDown"),
                                     "left": lambda: self._move("pageUp"),
                                     "right": lambda: self._move("pageDown"),
                                     },
                                    -1)
        self.refresh_timer = new_timer(self._tick)
        self.onLayoutFinish.append(self._start)
        self.onClose.append(self._closed)

    def _closed(self):
        self.alive = False
        self.refresh_timer.stop()

    def _start(self):
        self._redraw()
        self.refresh_timer.start(1000, False)

    # ------------------------------------------------------------------
    def _entry(self, it):
        text, color = status_line(it)
        percent = 100 * \
            it["done"] // it["size"] if it["size"] and it["state"] in (RUNNING, PAUSED) else None
        return self["list"].entry_two(
            it["uid"], it["title"], text, percent, sub_color=color)

    def _redraw(self, keep=True):
        index = self["list"].getSelectedIndex() if keep else 0
        items = self.dm.items
        self["list"].set_entries(
            [self._entry(it) for it in items], min(index, max(0, len(items) - 1)))
        self["empty"].setText(
            T(_("No downloads.\n\nIn a movie or series page press MENU\nand choose “Add to downloads”.")) if not items else u"")
        self._update_header()
        self._update_info()

    def _update_header(self):
        items = self.dm.items
        folder = core.download_folder()
        room = free_bytes(folder)
        free = (u"   •   " + _("%d GB free") %
                (room // (1024 ** 3))) if room >= 0 else u""
        self["count"].setText(T(_("%d in the list") % len(items) + free))

    def _tick(self):
        """Every second: redraw only the rows that change (the running one and the waiting ones)."""
        if not self.alive:
            return
        if len(self.dm.items) != len(self["list"].list):
            return self._redraw()
        for i, it in enumerate(self.dm.items):
            if it["state"] in (
                    RUNNING, SCHEDULED) or getattr(
                    self, "_last_state", {}).get(
                    it["uid"]) != it["state"]:
                self["list"].update_entry(i, self._entry(it))
        self._last_state = dict((it["uid"], it["state"])
                                for it in self.dm.items)
        self._update_info()

    def _move(self, direction):
        self["list"].move(direction)
        self._update_info()

    def current(self):
        uid = self["list"].current()
        return self.dm.find(uid) if uid else None

    def _update_info(self):
        it = self.current()
        if not it:
            self["info"].setText(T(_("Folder: %s") % core.download_folder()))
            return
        path = self.dm.path(it)
        self["info"].setText(
            T(path if it["state"] == DONE else _("Saving to: %s") % path))
        running = it["state"] == RUNNING
        self["key_green"].setText(T(_("Stop") if running else (
            _("Play") if it["state"] == DONE else _("Download"))))

    # ------------------------------------------------------------------
    def ok(self):
        self.start_now()

    def start_now(self):
        it = self.current()
        if not it:
            return
        if it["state"] == RUNNING:
            self.dm.pause(it["uid"])
        elif it["state"] == DONE:
            return self._play(it)
        else:
            self.dm.queue(it["uid"])
        self._redraw()

    def schedule(self):
        it = self.current()
        if not it or it["state"] in (RUNNING, DONE):
            return
        choices = [(T(label), ts) for label, ts in _start_choices()]

        def done(choice):
            if not choice or not self.alive:
                return
            if choice[1]:
                self.dm.schedule(it["uid"], choice[1])
            else:
                self.dm.queue(it["uid"])
            self._redraw()
        self.session.openWithCallback(
            done,
            ChoiceBox,
            title=T(
                _("When to download") +
                u":  " +
                it["title"]),
            list=choices)

    def remove(self):
        it = self.current()
        if not it:
            return
        choices = [(T(_("Remove from the list")), False)]
        if os.path.exists(
                self.dm.path(it)) or os.path.exists(
                self.dm.path(it) + ".part"):
            choices.append(
                (T(_("Remove from the list and delete the file")), True))

        def done(choice):
            if choice and self.alive:
                self.dm.remove(it["uid"], delete_file=choice[1])
                self._redraw()
        self.session.openWithCallback(
            done, ChoiceBox, title=T(
                it["title"]), list=choices)

    def menu(self):
        choices = [(T(_("Download all now (one after the other)")), "all"),
                   (T(_("Stop all")), "stop"),
                   (T(_("Remove completed from the list")), "clear"),
                   (T(_("Download folder") + u":  " + core.download_folder()), "folder")]

        def done(choice):
            if not choice or not self.alive:
                return
            if choice[1] == "all":
                for it in self.dm.items:
                    if it["state"] in (QUEUED, PAUSED, ERROR):
                        self.dm.queue(it["uid"])
            elif choice[1] == "stop":
                for it in list(self.dm.items):
                    self.dm.pause(it["uid"])
            elif choice[1] == "clear":
                self.dm.clear_done()
            else:
                return self.choose_folder()
            self._redraw()
        self.session.openWithCallback(
            done, ChoiceBox, title=T(
                _("Downloads")), list=choices)

    def choose_folder(self):
        candidates = []
        for base in (
            "/media/hdd",
            "/media/usb",
            "/media/usb1",
            "/media/mmc",
            "/media/net",
                "/media/nas"):
            if os.path.isdir(base):
                candidates.append(os.path.join(base, "movie"))
                candidates.append(base)
        if not candidates:
            candidates = ["/tmp"]
        choices = [(T(c), c) for c in candidates]

        def done(choice):
            if choice and self.alive:
                core.cfg.download_dir.value = choice[1]
                core.cfg.download_dir.save()
                core.save_configfile()
                if self.dm.running():
                    self.session.open(
                        MessageBox,
                        T(
                            _("The download in progress keeps its folder; the next ones use the new one.")),
                        MessageBox.TYPE_INFO,
                        timeout=4)
                self._redraw()
        self.session.openWithCallback(
            done, ChoiceBox, title=T(
                _("Download folder")), list=choices)

    def _play(self, it):
        from .player import XCDPlayer
        self.session.open(XCDPlayer,
                          [{"kind": "download",
                            "id": it["uid"],
                              "name": it["title"],
                              "direct_url": self.dm.path(it)}],
                          0)
