# -*- coding: utf-8 -*-
"""Parental control: categories protected by a PIN.

- Adult categories are recognised by name (XXX, Adulti, 18+, Porn...).
- Others are protected by hand from the list (MENU key on the categories).
- Once the PIN is entered they stay unlocked until the plugin is closed.
No Enigma2 dependency: it can be tested on a PC."""

import json
import os
import re

from . import _

_ADULT = re.compile(
    r"(\bxxx\b|\badult[ie]?\b|\badults?\b|\bfor adults\b|18\s*\+|\+\s*18|\bvm\s*18\b|\bporn\w*|\berotic\w*|\bhot\b|\bsexy\b|\bred light\b)",
    re.I)
WEAK_PINS = ("0000", "1111", "1234", "4321", "9999", "1212")


def is_adult(name):
    return bool(_ADULT.search(name or ""))


def pin_problem(pin):
    """Error message when the PIN is not acceptable, otherwise ''."""
    pin = (pin or "").strip()
    if not (len(pin) == 4 and pin.isdigit()):
        return _("The PIN must have 4 digits.")
    if pin in WEAK_PINS or len(set(pin)) == 1:
        return _("PIN too easy (0000, 1234...): choose another one.")
    return u""


class Protection(object):
    """Categories protected or released by hand, per server. File: protected.json"""

    def __init__(self, path):
        self.path = path
        try:
            with open(path) as f:
                self.data = json.load(f)
        except (IOError, OSError, ValueError):
            self.data = {}
        self.unlocked = False          # PIN entered in this session

    @staticmethod
    def key(kind, cat_id):
        return "%s:%s" % (kind, cat_id)

    def _bucket(self, server):
        return self.data.setdefault(server, {"manual": [], "free": []})

    def is_protected(self, server, kind, cat):
        """cat: dict with the category id and name."""
        b = self.data.get(server) or {}
        k = self.key(kind, cat.get("id"))
        if k in (b.get("manual") or []):
            return True
        if k in (b.get("free") or []):
            return False
        return is_adult(cat.get("name"))

    def set_protected(self, server, kind, cat, protected):
        b = self._bucket(server)
        k = self.key(kind, cat.get("id"))
        for lst in (b["manual"], b["free"]):
            if k in lst:
                lst.remove(k)
        if protected and not is_adult(cat.get("name")):
            b["manual"].append(k)
        elif not protected and is_adult(cat.get("name")):
            # recognised automatically, but the user wants it free
            b["free"].append(k)
        try:
            tmp = self.path + ".tmp"
            with open(tmp, "w") as f:
                json.dump(self.data, f)
            os.rename(tmp, self.path)
        except (IOError, OSError):
            pass

    def protected_ids(self, server, kind, categories):
        return set(c.get("id")
                   for c in categories if self.is_protected(server, kind, c))
