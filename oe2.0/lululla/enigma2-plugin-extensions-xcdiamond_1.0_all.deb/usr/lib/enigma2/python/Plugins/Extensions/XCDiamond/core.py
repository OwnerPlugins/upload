# -*- coding: utf-8 -*-
"""Settings, shared objects (Xtream client, TMDB), favorites, resume points and background jobs."""

import json
import os
import time

from Components.config import (
    config,
    ConfigSubsection,
    ConfigText,
    ConfigPassword,
    ConfigSelection,
    ConfigYesNo,
    ConfigClock)

from . import _
from . import __version__ as _VERSION
from . import PLUGIN_NAME as _PLUGIN_NAME
from .api import XtreamClient
from .tmdb import TMDB

# version and name come from __init__.py (single source, same workflow as
# the other repos)
VERSION = _VERSION
PLUGIN_NAME = _PLUGIN_NAME

config.plugins.XCDiamond = ConfigSubsection()
cfg = config.plugins.XCDiamond
cfg.server = ConfigText(default="http://", fixed_size=False)
cfg.username = ConfigText(default="", fixed_size=False)
cfg.password = ConfigPassword(default="", fixed_size=False)
# Built-in TMDB key: the default value of the setting. The user can replace it with their own key
# (or empty the setting and use /etc/enigma2/xc/tmdb.txt); an empty setting falls back to it as well.
TMDB_KEY_FALLBACK = "3c3efcf47c3577558812bb9d64019d65"
cfg.tmdb_key = ConfigText(default=TMDB_KEY_FALLBACK, fixed_size=False)
cfg.tmdb_lang = ConfigSelection(default="it-IT", choices=[
    ("it-IT", "Italiano"), ("en-US", "English"), ("de-DE", "Deutsch"),
    ("fr-FR", "Français"), ("es-ES", "Español")])
cfg.live_format = ConfigSelection(
    default="ts", choices=[
        ("ts", "MPEG-TS (.ts)"), ("m3u8", "HLS (.m3u8)")])
cfg.player = ConfigSelection(
    default="4097",
    choices=[
        ("4097",
         "GStreamer (4097)"),
        ("5001",
         "GstPlayer (5001)"),
        ("5002",
         "ExtEplayer3 (5002)")])
cfg.autonext = ConfigYesNo(default=True)
cfg.resume = ConfigYesNo(default=True)
cfg.epg_offset = ConfigSelection(
    default="0", choices=[
        ("0", _("Automatic"))] + [
            ("%+d" %
             h, (_("%+d hour") if abs(h) == 1 else _("%+d hours")) %
             h) for h in range(
                -12, 13) if h])
SORT_MODES = [
    ("server",
     _("Default (server)")),
    ("az",
     u"A \u2192 Z"),
    ("za",
     u"Z \u2192 A"),
    ("new",
     _("Recently added")),
    ("year",
     _("Year (newest)")),
    ("rating",
     _("TMDB rating"))]
cfg.sort_live = ConfigSelection(default="server", choices=SORT_MODES[:4])
cfg.sort_vod = ConfigSelection(default="server", choices=SORT_MODES)
cfg.sort_series = ConfigSelection(default="server", choices=SORT_MODES)
# chosen live category ids, comma separated
cfg.bq_live = ConfigText(default="", fixed_size=False)
cfg.bq_vod = ConfigText(default="", fixed_size=False)
cfg.bq_fav = ConfigYesNo(default=True)
cfg.bq_top = ConfigSelection(
    default="bottom",
    choices=[
        ("top",
         _("At the top")),
        ("bottom",
         _("At the bottom")),
        ("keep",
         _("Leave where it is"))])
cfg.bq_epg = ConfigYesNo(default=True)
cfg.update_check = ConfigYesNo(default=True)
# folder of playlist.txt (and XC xclink.txt)
cfg.playlist_dir = ConfigText(default="/etc/enigma2/xc", fixed_size=False)
# empty = /media/hdd/movie (or the first disk found)
cfg.download_dir = ConfigText(default="", fixed_size=False)
cfg.bq_auto = ConfigSelection(
    default="off",
    choices=[
        ("off",
         _("Off")),
        ("time",
         _("Every day at a fixed time")),
        ("interval",
         _("Every few hours"))])
# 05:00 (seconds since midnight)
cfg.bq_time = ConfigClock(default=5 * 3600)
cfg.bq_interval = ConfigSelection(
    default="12", choices=[
        (h, _("Every %s hours") %
         h) for h in (
            "3", "6", "12", "24", "48")])
# summary of the last export (json)
cfg.bq_last = ConfigText(default="", fixed_size=False)
cfg.parental = ConfigYesNo(default=False)
cfg.parental_pin = ConfigPassword(default="", fixed_size=False)
cfg.server_check = ConfigSelection(
    default="24",
    choices=[
        ("1",
         _("Every hour")),
        ("6",
         _("Every 6 hours")),
        ("24",
         _("Once a day")),
        ("0",
         _("Manually only (YELLOW)"))])

# Text files on the receiver (easier to edit over FTP than with the remote)
# data files live next to the playlist, like XC
DATA_DIR = "/etc/enigma2/xc"
SERVER_DIR_DEFAULT = "/etc/enigma2/xc"        # same folder as the old XC
# servers added from the plugin are written here
SERVER_FILE_NAME = "playlist.txt"
TMDB_FILE = DATA_DIR + "/tmdb.txt"
FAV_FILE = DATA_DIR + "/favorites.json"
RESUME_FILE = DATA_DIR + "/resume.json"

SERVER_FILE_EXAMPLE = """# One server per line. Lines starting with # are comments.
# Accepted formats:
#   http://server.com:8080/get.php?username=USER&password=PASSWORD&type=m3u_plus
#   http://server.com:8080 USER PASSWORD
# You can give it a name before a vertical bar:
#   Home | http://server.com:8080 USER PASSWORD
"""


_client = None
_tmdb = None


def server_dir():
    return (cfg.playlist_dir.value or SERVER_DIR_DEFAULT).rstrip(
        "/") or SERVER_DIR_DEFAULT


def server_file():
    """playlist.txt in the chosen folder: servers added from the plugin go here."""
    return os.path.join(server_dir(), SERVER_FILE_NAME)


def server_files():
    """playlist.txt first, then every other .txt of the folder (e.g. xclink.txt of XC)."""
    folder = server_dir()
    try:
        others = sorted(n for n in os.listdir(folder) if n.lower().endswith(
            ".txt") and n not in (SERVER_FILE_NAME, os.path.basename(TMDB_FILE)))
    except OSError:
        others = []
    return [server_file()] + [os.path.join(folder, n) for n in others]


def _ensure_data_dir():
    try:
        for folder in (DATA_DIR, server_dir()):
            if not os.path.isdir(folder):
                os.makedirs(folder)
        if not os.path.exists(server_file()):
            with open(server_file(), "w") as f:
                f.write(SERVER_FILE_EXAMPLE)
    except (IOError, OSError):
        pass


def parse_server_line(line):
    """Return {name, server, username, password} or None."""
    try:
        from urllib.parse import urlparse, parse_qs
    except ImportError:
        from urlparse import urlparse, parse_qs
    line = line.strip()
    if not line or line.startswith("#"):
        return None
    name = ""
    if "|" in line:
        name, line = [x.strip() for x in line.split("|", 1)]
    parts = line.split()
    if len(parts) >= 3:                       # http://server:port user password
        server, user, pwd = parts[0], parts[1], parts[2]
    else:                                     # get.php / player_api.php link
        u = urlparse(parts[0] if "://" in parts[0] else "http://" + parts[0])
        q = parse_qs(u.query)
        user = (q.get("username") or [""])[0]
        pwd = (q.get("password") or [""])[0]
        server = "%s://%s" % (u.scheme, u.netloc)
    if not user:
        return None
    return {"name": name or server.split(
        "://")[-1], "server": server, "username": user, "password": pwd}


def read_servers():
    """Servers from the .txt files of the playlist folder (no duplicates).
    Each server remembers its file and line, so it can be renamed, edited or removed."""
    _ensure_data_dir()
    out, seen = [], set()
    for path in server_files():
        try:
            with open(path, "rb") as f:
                lines = f.read().decode("utf-8", "replace").lstrip(u"\ufeff").splitlines()
        except (IOError, OSError):
            continue
        for number, line in enumerate(lines):
            srv = parse_server_line(line)
            if not srv:
                continue
            key = (srv["server"].lower(), srv["username"], srv["password"])
            if key in seen:
                continue
            seen.add(key)
            srv["file"], srv["line"], srv["raw"] = path, number, line.strip()
            out.append(srv)
    return out


def server_line(name, server, username, password):
    server = server.strip().rstrip("/")
    if "://" not in server:
        server = "http://" + server
    line = u"%s %s %s" % (server, username.strip(), password.strip())
    return (
        u"%s | %s" %
        (name.strip().replace(
            "|",
            "/"),
            line)) if name.strip() else line


def _rewrite_line(srv, new_line):
    """Replace (or delete, when new_line is None) the line of a server in its file."""
    with open(srv["file"], "rb") as f:
        text = f.read().decode("utf-8", "replace").lstrip(u"\ufeff")
    lines = text.splitlines()
    index = srv["line"]
    if not (0 <= index < len(lines)) or lines[index].strip() != srv["raw"]:
        index = next((i for i, l in enumerate(lines) if l.strip()
                     == srv["raw"]), -1)   # file changed meanwhile
        if index < 0:
            raise IOError(
                _("The server is no longer in the file %s") %
                srv["file"])
    if new_line is None:
        del lines[index]
    else:
        lines[index] = new_line
    tmp = srv["file"] + ".tmp"
    with open(tmp, "wb") as f:
        f.write((u"\n".join(lines) + u"\n").encode("utf-8"))
    os.rename(tmp, srv["file"])


def add_server(name, server, username, password):
    _ensure_data_dir()
    path = server_file()
    with open(path, "rb") as f:
        text = f.read().decode("utf-8", "replace")
    if text and not text.endswith("\n"):
        text += u"\n"
    text += server_line(name, server, username, password) + u"\n"
    with open(path + ".tmp", "wb") as f:
        f.write(text.encode("utf-8"))
    os.rename(path + ".tmp", path)


def xc_link(server, username, password):
    """Line in the old XC format (xclink.txt): XC reads only get.php links, without a name."""
    server = server.strip().rstrip("/")
    if "://" not in server:
        server = "http://" + server
    return u"%s/get.php?username=%s&password=%s&type=m3u_plus" % (
        server, username.strip(), password.strip())


def _is_own_file(srv):
    return os.path.basename(srv["file"]) == SERVER_FILE_NAME


def edit_server(srv, name, server, username, password):
    if _is_own_file(srv):
        _rewrite_line(srv, server_line(name, server, username, password))
    else:                                   # keep the XC file readable by XC
        _rewrite_line(srv, xc_link(server, username, password))
        if name.strip():
            add_server(name, server, username, password)


def rename_server(srv, name):
    """In playlist.txt the name is written on the line; a server of another file (XC) gets a
    named copy in playlist.txt, which comes first in the list, and its file is left as it is."""
    if _is_own_file(srv):
        edit_server(srv, name, srv["server"], srv["username"], srv["password"])
    else:
        add_server(name, srv["server"], srv["username"], srv["password"])


def remove_server(srv):
    _rewrite_line(srv, None)


def apply_server(srv):
    cfg.server.value = srv["server"]
    cfg.username.value = srv["username"]
    cfg.password.value = srv["password"]
    for c in (cfg.server, cfg.username, cfg.password):
        c.save()
    save_configfile()
    reset()


def file_tmdb_key():
    try:
        with open(TMDB_FILE) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#"):
                    return line
    except (IOError, OSError):
        pass
    return ""


def tmdb_key_source():
    """"settings", "file" or "builtin": which key is in use (shown in the Home account panel)."""
    own = cfg.tmdb_key.value.strip()
    if own and own != TMDB_KEY_FALLBACK:
        return "settings"
    return "file" if file_tmdb_key() else "builtin"


def tmdb_key():
    """Key from the settings; if empty, from /etc/enigma2/xc/tmdb.txt; if empty too, the built-in key."""
    own = cfg.tmdb_key.value.strip()
    if own and own != TMDB_KEY_FALLBACK:
        return own
    return file_tmdb_key() or TMDB_KEY_FALLBACK


def autoconfigure():
    """First start: with empty settings, use the first server of the file."""
    if not configured():
        servers = read_servers()
        if servers:
            apply_server(servers[0])


def sort_config(kind):
    """Sort setting for Live, Movies (vod) or Series."""
    return {
        "live": cfg.sort_live,
        "vod": cfg.sort_vod}.get(
        kind,
        cfg.sort_series)


def sort_label(mode):
    label = dict(SORT_MODES).get(mode, mode)
    if not isinstance(
            label,
            type(u"")):       # Python 2: utf-8 text -> unicode
        label = label.decode("utf-8")
    return label


def save_sort(kind, mode):
    c = sort_config(kind)
    c.value = mode
    c.save()
    save_configfile()


def configured():
    return len(cfg.server.value.strip()) > len(
        "http://") and bool(cfg.username.value.strip())


def client():
    global _client
    if _client is None:
        _client = XtreamClient(
            cfg.server.value,
            cfg.username.value,
            cfg.password.value)
        _client.epg_shift = epg_offset_hours() * 3600
    return _client


def epg_offset_hours():
    try:
        return int(cfg.epg_offset.value)
    except ValueError:
        return 0


def set_epg_offset(hours):
    """Keys 7/8/9: change the EPG time correction and save it."""
    hours = max(-12, min(12, hours))
    cfg.epg_offset.value = "0" if hours == 0 else "%+d" % hours
    cfg.epg_offset.save()
    save_configfile()
    if _client is not None:
        _client.epg_shift = hours * 3600
    return hours


def tmdb():
    global _tmdb
    if _tmdb is None:
        try:
            from enigma import getDesktop
            from .tmdb import set_resolution
            set_resolution(getDesktop(0).size().width())
        except Exception:
            pass
        _tmdb = TMDB(tmdb_key(), cfg.tmdb_lang.value)
    return _tmdb


def reset():
    """Call after changing the settings."""
    global _client, _tmdb, _epg
    _client = None
    _tmdb = None
    _epg = None
    search_lists.clear()


# ------------------------------------------------------------------
# Search everywhere
# ------------------------------------------------------------------
from .search import Lists as _Lists, History as _History, search as _search   # noqa: E402

search_lists = _Lists()
_history = None


def history():
    global _history
    if _history is None:
        _ensure_data_dir()
        _history = _History(os.path.join(DATA_DIR, "searches.json"))
    return _history


# ------------------------------------------------------------------
# Parental control
# ------------------------------------------------------------------
_protection = None


def protection():
    global _protection
    if _protection is None:
        from .parental import Protection
        _ensure_data_dir()
        _protection = Protection(os.path.join(DATA_DIR, "protected.json"))
    return _protection


def parental_active():
    from .parental import pin_problem
    return bool(cfg.parental.value) and not pin_problem(cfg.parental_pin.value)


def locked():
    """True when categories are protected and the PIN has not been entered yet."""
    return parental_active() and not protection().unlocked


def server_key():
    return u"%s|%s" % (cfg.server.value.rstrip("/"), cfg.username.value)


def is_protected(kind, cat):
    return parental_active() and protection().is_protected(server_key(), kind, cat)


def filter_locked(kind, items):
    """Hide the content of protected categories until the PIN is entered (runs in a thread)."""
    if not locked() or kind not in ("live", "vod", "series"):
        return items
    try:
        cats = client().categories(kind)
    except Exception:
        return items
    ids = protection().protected_ids(server_key(), kind, cats)
    return [i for i in items if i.get("cat") not in ids] if ids else items


def ask_pin(session, callback, title=None):
    """Ask for the PIN when needed; callback(True) when it is fine to go on."""
    if not locked():
        return callback(True)
    from Screens.InputBox import InputBox
    from Screens.MessageBox import MessageBox
    from Components.Input import Input

    def done(text):
        if text is None:
            return callback(False)
        if text.strip() == cfg.parental_pin.value.strip():
            protection().unlocked = True          # unlocked until the plugin is closed
            return callback(True)
        session.open(
            MessageBox,
            _("Wrong PIN."),
            MessageBox.TYPE_ERROR,
            timeout=3)
        callback(False)
    session.openWithCallback(
        done,
        InputBox,
        title=title or _("Enter the parental PIN"),
        windowTitle=_("Parental control"),
        text="",
        maxSize=False,
        type=Input.PIN,
        useableChars="1234567890")


# ------------------------------------------------------------------
# Bouquet
# ------------------------------------------------------------------
def active_account_name():
    """Custom name of the active account (e.g. 'HOME'/'BACKUP'), or '' to fall back to the
    username. Used to name that account's bouquet, so several servers do not collide."""
    try:
        for srv in read_servers():
            if srv["username"] == cfg.username.value and srv["password"] == cfg.password.value:
                return srv["name"] if "|" in (srv.get("raw") or "") else ""
    except Exception:
        pass
    return ""


def exporter():
    from .bouquets import Exporter
    return Exporter(
        client(),
        player=cfg.player.value,
        live_ext=cfg.live_format.value,
        position=cfg.bq_top.value,
        account=active_account_name() or None)


def bouquet_selection_ids():
    return dict((kind, set(x for x in getattr(cfg, "bq_" +
                                              kind).value.split(",") if x)) for kind in ("live", "vod"))


def save_bouquet_selection(ids):
    for kind in ("live", "vod"):
        c = getattr(cfg, "bq_" + kind)
        c.value = ",".join(sorted(ids.get(kind, ())))
        c.save()
    save_configfile()


def save_configfile():
    try:
        from Components.config import configfile
        configfile.save()
    except Exception:
        pass


def run_bouquet_export(progress=None):
    """Runs in a thread: fetch the chosen categories and write the bouquets. Returns the summary."""
    import json as _json
    ids = bouquet_selection_ids()
    c = client()
    selection = {}
    for kind in ("live", "vod"):
        if ids[kind]:
            selection[kind] = [cat for cat in c.categories(
                kind) if cat["id"] in ids[kind]]
    favs = (favorites.items("live") + [i for i in favorites.items(
        "vod") if i.get("kind") == "vod"]) if cfg.bq_fav.value else []
    result = exporter().export(
        selection,
        favorites=favs,
        epgimport=cfg.bq_epg.value,
        progress=progress)
    cfg.bq_last.value = _json.dumps(result)
    cfg.bq_last.save()
    save_configfile()
    return result


def last_bouquet_export():
    import json as _json
    try:
        return _json.loads(cfg.bq_last.value) if cfg.bq_last.value else {}
    except ValueError:
        return {}


_auto = {"timer": None, "started": 0, "running": False, "failed_at": 0}


def next_bouquet_run():
    """Epoch of the next automatic export (None when switched off)."""
    from .scheduler import next_run
    clock = cfg.bq_time.value
    return next_run(
        cfg.bq_auto.value, (clock[0], clock[1]), int(
            cfg.bq_interval.value), int(
            last_bouquet_export().get(
                "time", 0)), started=_auto["started"])


def start_auto_bouquet():
    """At Enigma2 start: check every minute whether the automatic export is due.
    The first check waits two minutes, so the network is up after a reboot."""
    import time as _time
    if _auto["timer"] is not None:
        return
    from .ui import new_timer
    _auto["started"] = int(_time.time())
    _auto["timer"] = new_timer(_auto_check)
    _auto["timer"].start(120000, True)


def _auto_check():
    from .scheduler import is_due
    _auto["timer"].start(60000, True)
    if _auto["running"] or cfg.bq_auto.value == "off" or not configured():
        return
    ids = bouquet_selection_ids()
    if not (ids["live"] or ids["vod"] or cfg.bq_fav.value):
        return
    if not is_due(next_bouquet_run(), failed_at=_auto["failed_at"]):
        return
    from .net import run_async
    _auto["running"] = True
    print("[XCDiamond] automatic bouquet export")
    run_async(run_bouquet_export, callback=_auto_done, errback=_auto_failed)


def _auto_done(result):
    _auto["running"] = False
    _auto["failed_at"] = 0
    print("[XCDiamond] bouquets updated: %s" % result)


def _auto_failed(err):
    import time as _time
    _auto["running"] = False
    _auto["failed_at"] = int(_time.time())     # next try in 30 minutes
    print("[XCDiamond] automatic bouquets: error %s" % err)


# ------------------------------------------------------------------
# Download panel
# ------------------------------------------------------------------
_downloads = None


def download_folder():
    from .downloads import default_folder
    return cfg.download_dir.value.strip() or default_folder()


def downloads():
    global _downloads
    if _downloads is None:
        from .downloads import DownloadManager
        _ensure_data_dir()
        _downloads = DownloadManager(
            os.path.join(
                DATA_DIR,
                "downloads.json"),
            download_folder,
            _connection_free)
    return _downloads


def add_download(session, item, quiet=False):
    """Put a movie or episode in the download panel (the user decides there when to download it)."""
    from Screens.MessageBox import MessageBox
    url = client().stream_url(item)
    if item.get("kind") == "episode" or "season" in item:
        series = item.get("series_name") or u""
        title = u"%s S%02dE%02d" % (series, item.get(
            "season", 0), item.get("episode", 0))
        if item.get("title"):
            title += u" - " + item["title"]
        entry, added = downloads().add(
            url, title.strip(), item.get("ext") or "mp4", subfolder=series)
    else:
        from .tmdb import clean_title
        name = item.get("name") or u"video"
        title, year = clean_title(name)
        title = (
            u"%s (%s)" %
            (title, year) if year else title) if title else name
        entry, added = downloads().add(url, title, item.get("ext") or "mp4")
    if not quiet:
        text = _("Added to the downloads:\n%s\n\nOpen Home > Downloads to choose when.") if added else \
            _("Already in the downloads:\n%s")
        session.open(
            MessageBox,
            text %
            entry["title"],
            MessageBox.TYPE_INFO,
            timeout=4)
    return added


def _watching_this_server():
    """True when the receiver is playing a stream of the current server (plugin player or bouquet)."""
    try:
        import NavigationInstance
        ref = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
        text = ref.toString() if ref else ""
    except Exception:
        return False
    host = client().server.split("://")[-1].split("/")[0].lower()
    return bool(host) and host in text.replace("%3a", ":").lower()


def _connection_free():
    """A download may start unless the account has a single connection already used by the TV."""
    if not configured():
        return True
    max_cons = getattr(client(), "max_connections", 0)
    return max_cons > 1 or not _watching_this_server()


# ------------------------------------------------------------------
# Does the server in use have catchup? (Home shows the Catchup entry only then)
# ------------------------------------------------------------------
CATCHUP_FILE = os.path.join(DATA_DIR, "catchup.json")
CATCHUP_MAX_AGE = 24 * 3600


def has_catchup():
    """True / False when known for the server in use (checked in the last 24 hours), None = not known."""
    entry = _load(CATCHUP_FILE, {}).get(server_key())
    if not entry or time.time() - entry.get("t", 0) > CATCHUP_MAX_AGE:
        return None
    return bool(entry.get("has"))


def remember_catchup(has):
    data = _load(CATCHUP_FILE, {})
    data[server_key()] = {"has": bool(has), "t": int(time.time())}
    _save(CATCHUP_FILE, data)


def check_catchup():
    """Runs in a thread: one look at the live list (cached by the client, shared with search)."""
    from .api import LIVE
    has = any(ch.get("archive") for ch in client().items(LIVE))
    remember_catchup(has)
    return has


def pause_download_for_playback():
    """Pause the running download when the account allows a single connection. Returns its id or None."""
    if _downloads is None:
        return None
    running = _downloads.running()
    if not running:
        return None
    max_cons = getattr(client(), "max_connections", 0) if configured() else 0
    if max_cons > 1:
        return None
    _downloads.pause(running["uid"])
    print(
        "[XCDiamond] download paused while watching (max connections %s)" %
        (max_cons or "?"))
    return running["uid"]


def resume_download(uid):
    if _downloads is not None and _downloads.find(uid):
        _downloads.queue(uid)


_dl_timer = {"timer": None}


def start_download_scheduler():
    """At Enigma2 start: every minute start the downloads that are due."""
    if _dl_timer["timer"] is not None:
        return
    from .ui import new_timer

    def tick():
        _dl_timer["timer"].start(60000, True)
        try:
            if any(it["state"] == "scheduled" for it in downloads().items):
                downloads().tick()
        except Exception as e:
            print("[XCDiamond] downloads: %s" % e)
    _dl_timer["timer"] = new_timer(tick)
    _dl_timer["timer"].start(90000, True)


def search_all(query):
    """Runs in a thread. {"live": [...], "vod": [...], "series": [...]} sorted by relevance."""
    from .vodseries import organize, SEP
    c = client()
    out = {}
    for kind in ("live", "vod", "series"):
        try:
            items = search_lists.get(
                c, kind, organize if kind == "vod" else None)
        except Exception as e:
            print("[XCDiamond] search %s: %s" % (kind, e))
            items = []
        out[kind] = filter_locked(
            kind, [
                i for i in _search(
                    items, query) if i.get("kind") != SEP])
    return out


def open_search(session, text=None):
    """Keyboard (prefilled with the last search), then the results screen."""
    from Screens.VirtualKeyBoard import VirtualKeyBoard

    def go(query):
        query = (query or "").strip()
        if not query:
            return
        if not isinstance(query, type(u"")):
            query = query.decode("utf-8", "ignore")
        history().add(query)
        from .browser import BrowserScreen
        session.open(BrowserScreen, "live", search=query)
    if text is not None:
        return go(text)
    last = history().items[0] if history().items else u""
    session.openWithCallback(go,
                             VirtualKeyBoard,
                             title=_("Search channels, movies and series"),
                             text=last.encode("utf-8") if not isinstance(last,
                                                                         str) else last)


# ------------------------------------------------------------------
# Full EPG guide (one per server, downloaded in the background once a day)
# ------------------------------------------------------------------
EPG_MAX_AGE = 24 * 3600
_epg = None
_epg_waiting = []


def epg():
    global _epg
    if _epg is None:
        from .epg import EpgStore
        _epg = EpgStore(client())
    return _epg


def ensure_epg(callback=None, force=False):
    """Prepare the guide without blocking the GUI: first the saved one, then (if old) a new one.
    callback() is called every time the guide changes."""
    from .net import run_async
    store = epg()
    if callback and callback not in _epg_waiting:
        _epg_waiting.append(callback)
    if store.state == "loading":
        return
    if store.state == "ready" and store.fresh(EPG_MAX_AGE) and not force:
        _notify()
        return

    def downloaded(result):
        if store is not _epg:
            return
        store.set(*result)
        _notify()

    def failed(err):
        if store is not _epg:
            return
        if store.guide:
            store.state = "ready"          # keep the old one
        else:
            store.state, store.message = "error", u"%s" % err
        _notify()

    def start_download():
        store.state = "loading"
        _notify()
        run_async(store.download, callback=downloaded, errback=failed)

    def file_loaded(result):
        if store is not _epg:
            return
        built, guide = result
        if guide:
            store.set(built, guide)
            _notify()
        if force or not store.fresh(EPG_MAX_AGE):
            start_download()

    if not store.guide:
        store.state = "loading"
        run_async(
            store.load_file,
            callback=file_loaded,
            errback=lambda e: start_download())
    else:
        start_download()


def stop_epg_updates(callback):
    if callback in _epg_waiting:
        _epg_waiting.remove(callback)


def _notify():
    for cb in list(_epg_waiting):
        try:
            cb()
        except Exception as e:
            print("[XCDiamond] epg callback: %s" % e)


# ------------------------------------------------------------------
# Small JSON files (favorites, resume positions)
# ------------------------------------------------------------------
def _load(path, default):
    try:
        with open(path) as f:
            return json.load(f)
    except (IOError, OSError, ValueError):
        return default


def _save(path, data):
    try:
        tmp = path + ".tmp"
        with open(tmp, "w") as f:
            json.dump(data, f)
        os.rename(tmp, path)
    except (IOError, OSError):
        pass


class Favorites(object):
    KEYS = (
        "kind",
        "id",
        "name",
        "icon",
        "ext",
        "tmdb",
        "year",
        "rating",
        "episodes")

    def __init__(self):
        self.data = _load(FAV_FILE, {})

    def _key(self, item):
        return "%s:%s" % (item.get("kind"), item.get("id"))

    def contains(self, item):
        return self._key(item) in self.data.get(item.get("kind"), {})

    def toggle(self, item):
        bucket = self.data.setdefault(item.get("kind"), {})
        key = self._key(item)
        if key in bucket:
            del bucket[key]
            added = False
        else:
            bucket[key] = dict((k, item[k]) for k in self.KEYS if k in item)
            added = True
        _save(FAV_FILE, self.data)
        return added

    def items(self, kind):
        found = list(self.data.get(kind, {}).values())
        if kind == "vod":                          # Movies include the series grouped from VOD
            found += list(self.data.get("vodgroup", {}).values())
        return sorted(found, key=lambda i: (i.get("name") or "").lower())


favorites = Favorites()


class Resume(object):
    """Where playback stopped in movies, episodes, catchup programmes and downloaded files.

    Each point belongs to a server (the same id on another server is another title) and keeps
    a small copy of the item, so "Continue watching" can show and play it again.
    Catchup points expire with the server archive. File: /etc/enigma2/xc/resume.json"""

    MAX_ITEMS = 300
    ITEM_KEYS = (
        "kind",
        "id",
        "ext",
        "name",
        "icon",
        "image",
        "year",
        "tmdb",
        "season",
        "episode",
        "subtitle",
        "plot",
        "series_name",
        "direct_url",
        "expires")
    KINDS = ("vod", "series", "catchup", "download")

    def __init__(self):
        data = _load(RESUME_FILE, {})
        self.data = dict((k, v)
                         for k, v in data.items() if isinstance(v, dict))

    @staticmethod
    def key(item):
        owner = "local" if item.get("kind") == "download" else server_key()
        return u"%s|%s:%s" % (owner, item.get("kind"), item.get("id"))

    def supported(self, item):
        return item.get("kind") in self.KINDS

    def _entry(self, item):
        entry = self.data.get(self.key(item))
        if entry and entry.get("expires") and entry["expires"] < time.time():
            return None
        return entry

    def get(self, item):
        entry = self._entry(item)
        return int(entry["pos"]) if entry else 0

    def percent(self, item):
        entry = self._entry(item)
        if not entry or not entry.get("len"):
            return None
        return max(1, min(99, int(100 * entry["pos"] / entry["len"])))

    def set(self, item, seconds, length):
        if not self.supported(item):
            return
        key = self.key(item)
        if seconds < 60 or (length and seconds > length - 120):
            # just started or finished: no resume
            self.data.pop(key, None)
        else:
            snapshot = dict(
                (k, item[k]) for k in self.ITEM_KEYS if item.get(k) not in (
                    None, ""))
            self.data[key] = {
                "pos": int(seconds), "len": int(
                    length or 0), "t": int(
                    time.time()), "expires": int(
                    item.get("expires") or 0), "item": snapshot}
        self._trim()
        _save(RESUME_FILE, self.data)

    def clear(self, item):
        if self.data.pop(self.key(item), None) is not None:
            _save(RESUME_FILE, self.data)

    def _trim(self):
        now = time.time()
        for k in [k for k, v in self.data.items() if v.get("expires")
                  and v["expires"] < now]:
            del self.data[k]
        if len(
                self.data) > self.MAX_ITEMS:   # keep the file small: forget the oldest ones
            for k in sorted(self.data, key=lambda k: self.data[k].get("t", 0))[
                    :len(self.data) - self.MAX_ITEMS]:
                del self.data[k]

    def recent(self, kinds=None, limit=40):
        """'Continue watching': items of the current server (and downloaded files), newest first.
        kinds: "vod" = movies, "episode" = series episodes, "catchup", "download"; None = all."""
        own, now, out = server_key() + u"|", time.time(), []
        for key, entry in sorted(
                self.data.items(), key=lambda kv: -kv[1].get("t", 0)):
            if not (key.startswith(own) or key.startswith(u"local|")):
                continue
            if entry.get("expires") and entry["expires"] < now:
                continue
            item = dict(entry.get("item") or {})
            group = "episode" if "season" in item else item.get("kind")
            if kinds and group not in kinds:
                continue
            item["resume_entry"] = True
            out.append(item)
            if len(out) >= limit:
                break
        return out


resume = Resume()


# ------------------------------------------------------------------
# Plugin keymap (CH+/CH-, INFO, TEXT, MENU, digits)
# ------------------------------------------------------------------
_keymap_state = None   # None = not tried yet, True/False = result


def load_keymap():
    """Load keymap.xml once. Returns True when the plugin keys are active."""
    global _keymap_state
    if _keymap_state is None:
        try:
            import keymapparser
            keymapparser.readKeymap(
                os.path.join(
                    os.path.dirname(
                        os.path.abspath(__file__)),
                    "keymap.xml"))
            _keymap_state = True
        except Exception as e:
            print("[XCDiamond] keymap: %s" % e)
            _keymap_state = False
    return _keymap_state
