# -*- coding: utf-8 -*-
"""Info screen: version, author, changes, credits and update from the GitHub repository."""

import os
import time

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.ScrollLabel import ScrollLabel
from Components.Pixmap import Pixmap

from . import _, core, updater
from .net import run_async
from .ui import (
    T,
    ImageLoader,
    scale_skin,
    footer,
    clock,
    new_timer,
    PLUGIN_DIR,
    BG,
    PANEL,
    TEXT,
    DIM,
    ACCENT,
    SEL,
    GOLD)

AUTHOR = u"Lululla (belfagor2005)"


def N_(text):
    """Marks a string for translation without translating it now (it is translated when shown)."""
    return text


# Changes of the last versions (newest first). tools/make_release.py copies the
# first entry into version.json.
CHANGES = [
    ("1.0", [N_("Live channels, movies and series from Xtream servers, with TMDB details"),
             N_("Full EPG guide in the lists and in the player"),
             N_("Series hidden inside movie lists are grouped by season"),
             N_("Search everywhere, favorites, resume, parental control with PIN"),
             N_("Bouquet export with EPGImporter guide and scheduled update"),
             N_("Server list with background checks; updates from GitHub")]),
]


class AboutScreen(Screen):
    skin = scale_skin("""
    <screen name="XCDAbout" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="%(bg)s">
        <widget name="logo" position="80,40" size="370,222" alphatest="blend" zPosition="2" />
        <widget name="title" position="490,80" size="940,70" font="Regular;56" noWrap="1" foregroundColor="%(accent)s" backgroundColor="%(bg)s" transparent="1" />
        <widget name="subtitle" position="490,160" size="940,90" font="Regular;30" foregroundColor="%(dim)s" backgroundColor="%(bg)s" transparent="1" />
        <eLabel position="1472,92" size="166,166" backgroundColor="#00ffffff" />
        <widget name="qr_paypal" position="1480,100" size="150,150" alphatest="blend" zPosition="2" />
        <widget name="lbl_paypal" position="1472,250" size="166,30" font="Regular;24" halign="center" foregroundColor="%(text)s" backgroundColor="%(bg)s" transparent="1" />
        <eLabel position="1692,92" size="166,166" backgroundColor="#00ffffff" />
        <widget name="qr_kofi" position="1700,100" size="150,150" alphatest="blend" zPosition="2" />
        <widget name="lbl_kofi" position="1692,250" size="166,30" font="Regular;24" halign="center" foregroundColor="%(text)s" backgroundColor="%(bg)s" transparent="1" />
        %(clock)s
        <eLabel position="60,288" size="1800,2" backgroundColor="%(panel)s" />
        <widget name="changes" position="80,300" size="1000,660" font="Regular;28" foregroundColor="%(text)s" backgroundColor="%(bg)s" transparent="1" />
        <eLabel position="1120,300" size="740,660" backgroundColor="%(panel)s" zPosition="-1" />
        <eLabel position="1120,300" size="6,660" backgroundColor="%(accent)s" />
        <widget name="upd_title" position="1160,320" size="680,50" font="Regular;36" foregroundColor="%(text)s" backgroundColor="%(panel)s" transparent="1" />
        <widget name="upd" position="1160,385" size="680,330" font="Regular;28" foregroundColor="%(text)s" backgroundColor="%(panel)s" transparent="1" />
        <eLabel position="1160,725" size="660,2" backgroundColor="%(sel)s" />
        <widget name="credits" position="1160,740" size="680,210" font="Regular;24" foregroundColor="%(dim)s" backgroundColor="%(panel)s" transparent="1" />
        %(footer)s
    </screen>""" % dict(bg=BG, panel=PANEL, text=TEXT, dim=DIM, accent=ACCENT, sel=SEL, gold=GOLD,
                        clock=clock(y=28), footer=footer()))

    def __init__(self, session, info=None):
        Screen.__init__(self, session)
        core.load_keymap()
        self.alive = True
        self.busy = False
        self.info = info if info is not None else updater.last_check()
        self.step = u""
        self["logo"] = Pixmap()
        self.logo = ImageLoader(self, "logo", transparent=True)
        self["title"] = Label(T(u"%s  %s" % (core.PLUGIN_NAME, core.VERSION)))
        self["subtitle"] = Label(
            T(_("by %s") % AUTHOR + u"\n" + updater.REPO_URL.replace("https://", "")))
        self["changes"] = ScrollLabel(T(self._changes_text()))
        self["upd_title"] = Label(T(_("Updates")))
        self["qr_paypal"] = Pixmap()
        self["qr_kofi"] = Pixmap()
        self["lbl_paypal"] = Label("PayPal")
        self["lbl_kofi"] = Label("Ko-fi")
        self.qr = [
            ImageLoader(
                self, "qr_paypal"), ImageLoader(
                self, "qr_kofi")]
        self["upd"] = Label("")
        self["credits"] = Label(T(
            _("Movie and series details: TMDB (themoviedb.org).\n"
              "This product uses the TMDB API but is not\nendorsed or certified by TMDB.\n"
              "No lists included: servers and accounts\nare entered by the user.")))
        self["key_red"] = Label(T(_("Back")))
        self["key_green"] = Label(T(_("Check")))
        self["key_yellow"] = Label("")
        self["key_blue"] = Label("")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions", "XCDActions"], {
            "ok": self.close, "cancel": self.close, "red": self.close,
            "green": self.check, "yellow": self.install,
            "up": self["changes"].pageUp, "down": self["changes"].pageDown,
            "pageUp": self["changes"].pageUp, "pageDown": self["changes"].pageDown,
        }, -1)
        self.step_timer = new_timer(self._show_step)
        self.qr_timer = new_timer(self._load_qr)
        self.onLayoutFinish.append(self._start)
        self.onClose.append(self._closed)

    def _closed(self):
        self.alive = False
        self.step_timer.stop()
        self.qr_timer.stop()

    def _start(self):
        self.logo.load(os.path.join(PLUGIN_DIR, "icons", "logo.png"))
        # one image at a time: the decoder is busy with the logo
        self.qr_timer.start(400, True)
        fresh = self.info and time.time() - self.info.get("checked", 0) < 3600
        if fresh:
            self._show_info()
        else:
            self.check()

    def _load_qr(self):
        if self.alive:
            self.qr[0].load(os.path.join(PLUGIN_DIR, "icons", "qr_paypal.png"))
            self.qr[1].load(os.path.join(PLUGIN_DIR, "icons", "qr_kofi.png"))

    # ------------------------------------------------------------------
    @staticmethod
    def _changes_text():
        rows = [_("What's new")]
        for version, items in CHANGES:
            rows.append(u"")
            rows.append(_("Version %s") % version)
            rows += [u"  \u2022  %s" % _(it) for it in items]
        return u"\n".join(rows)

    def _set_yellow(self, text):
        self["key_yellow"].setText(T(text))

    def _show_info(self):
        info = self.info
        if not info:
            self["upd"].setText(T(_("No check done yet.\nGREEN: check now.")))
            return self._set_yellow(u"")
        when = time.strftime(
            "%d/%m %H:%M",
            time.localtime(
                info.get(
                    "checked",
                    0)))
        if updater.is_newer(info.get("version"), core.VERSION):
            rows = [_("New version: %s") %
                    info["version"] + (u"  (%s)" %
                                       info["date"] if info.get("date") else u""), _("Installed: %s") %
                    core.VERSION, u""]
            rows += [u"•  %s" % c for c in info.get("changes", [])[:6]]
            rows += [u"", _("YELLOW: install")]
            self._set_yellow(_("Install %s") % info["version"])
        else:
            rows = [
                _("You have the latest version (%s).") %
                core.VERSION,
                u"",
                _("Checked on %s.") %
                when]
            self._set_yellow(u"")
        self["upd"].setText(T(u"\n".join(rows)))

    def check(self):
        if self.busy:
            return
        self.busy = True
        self["upd"].setText(T(_("Checking GitHub...")))
        run_async(updater.check, (core.VERSION,),
                  callback=self._checked, errback=self._check_failed)

    def _checked(self, info):
        self.busy = False
        if not self.alive:
            return
        self.info = info
        self._show_info()

    def _check_failed(self, err):
        self.busy = False
        if self.alive:
            if "404" in u"%s" % err:
                return self["upd"].setText(
                    T(_("No version published on GitHub yet.\n\nYou have %s.") % core.VERSION))
            self["upd"].setText(
                T(_("Check failed:\n%s\n\nTry again later (GREEN).") % err))

    # ------------------------------------------------------------------
    def install(self):
        info = self.info
        if self.busy or not info or not updater.is_newer(
                info.get("version"), core.VERSION):
            return
        self.session.openWithCallback(
            self._confirmed, MessageBox, T(
                _("Install XC Diamond %s?\nThe GUI restarts at the end.") %
                info["version"]), MessageBox.TYPE_YESNO)

    def _confirmed(self, yes):
        if not yes or not self.alive:
            return
        self.busy = True
        self.step = _("Preparing the update...")
        self._show_step()
        self.step_timer.start(300, False)
        run_async(updater.install, (self.info, self._progress),
                  callback=self._installed, errback=self._install_failed)

    def _progress(self, text):
        """Called from the thread: the timer shows it on screen."""
        self.step = text

    def _show_step(self):
        if self.alive:
            self["upd"].setText(T(self.step))

    def _installed(self, version):
        self.busy = False
        self.step_timer.stop()
        if not self.alive:
            return
        self["upd"].setText(T(_("Version %s installed.") % version))
        self.session.openWithCallback(
            self._restart, MessageBox, T(
                _("XC Diamond %s installed.\nRestart the GUI now?") %
                version), MessageBox.TYPE_YESNO)

    def _restart(self, yes):
        if yes:
            from Screens.Standby import TryQuitMainloop
            self.session.open(TryQuitMainloop, 3)

    def _install_failed(self, err):
        self.busy = False
        self.step_timer.stop()
        if self.alive:
            self["upd"].setText(
                T(_("Update failed:\n%s\n\nThe installed plugin was not touched.") % err))


# ----------------------------------------------------------------------
# Silent check when the box starts (once a day)
# ----------------------------------------------------------------------
_auto = {"timer": None, "session": None, "notified": None}
DAY_MS = 24 * 3600 * 1000


def start_auto_check(session):
    if not core.cfg.update_check.value:
        return
    _auto["session"] = session
    if _auto["timer"] is None:
        _auto["timer"] = new_timer(_auto_check)
    # after start, when the network is ready
    _auto["timer"].start(90 * 1000, True)


def _auto_check():
    _auto["timer"].start(DAY_MS, True)
    if core.cfg.update_check.value:
        run_async(updater.check, (core.VERSION,),
                  callback=_auto_result, errback=lambda e: None)


def _auto_result(info):
    if not info or not info.get(
            "newer") or _auto["notified"] == info["version"]:
        return
    _auto["notified"] = info["version"]
    try:
        from Tools import Notifications
        Notifications.AddPopup(
            T(
                _(u"XC Diamond %s is available.\nOpen XC Diamond \u2192 Info to install it.") %
                info["version"]),
            MessageBox.TYPE_INFO,
            15,
            "XCDiamondUpdate")
    except Exception as e:
        print("[XCDiamond] update notice: %s" % e)
