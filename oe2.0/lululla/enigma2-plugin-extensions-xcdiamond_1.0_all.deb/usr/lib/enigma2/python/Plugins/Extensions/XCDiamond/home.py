# -*- coding: utf-8 -*-
"""Home screen and settings."""

import os

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Screens.ChoiceBox import ChoiceBox
from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from Components.config import getConfigListEntry, ConfigText, ConfigPassword
from Components.Label import Label
from Components.Pixmap import Pixmap

from .help import open_help
from . import _, core
from .api import state_label, LIVE, VOD, SERIES, AuthError
from .net import run_async
from .ui import (
    T,
    XCDList,
    ImageLoader,
    icon,
    scale_skin,
    footer,
    clock,
    PLUGIN_DIR,
    BG,
    PANEL,
    TEXT,
    DIM,
    ACCENT,
    SEL,
    GOLD)

MENU = [   # (key, label, icon in icons/menu_*.png); labels are translated when shown
    (LIVE, "Live channels", "live"),
    (VOD, "Movies", "movies"),
    (SERIES, "TV series", "series"),
    ("catchup", "Catchup", "catchup"),
    ("search", "Search", "search"),
    ("fav", "Favorites", "favorites"),
    ("bouquets", "Bouquets", "bouquet"),
    ("downloads", "Downloads", "download"),
    ("servers", "Servers", "server"),
    ("settings", "Settings", "settings"),
    ("help", "Help", "help"),
    ("about", "Info", "info"),
]
# extraction markers for the .pot (the list above holds the source strings)
_MENU_STRINGS = (
    _("Live channels"),
    _("Movies"),
    _("TV series"),
    _("Catchup"),
    _("Search"),
    _("Favorites"),
    _("Bouquets"),
    _("Downloads"),
    _("Servers"),
    _("Settings"),
    _("Help"),
    _("Info"))


class HomeScreen(Screen):
    skin = scale_skin("""
    <screen name="XCDHome" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="%(bg)s">
        <widget name="logo" position="110,40" size="370,222" alphatest="blend" zPosition="2" />
        <widget name="tagline" position="500,190" size="440,80" font="Regular;26" foregroundColor="%(dim)s" backgroundColor="%(bg)s" transparent="1" />
        %(clock)s
        <widget name="menu" position="120,280" size="700,660" itemHeight="55" backgroundColor="%(bg)s" backgroundColorSelected="%(sel)s" scrollbarMode="showNever" transparent="1" />
        <eLabel position="960,150" size="900,810" backgroundColor="%(panel)s" zPosition="-1" />
        <eLabel position="960,150" size="6,810" backgroundColor="%(accent)s" />
        <widget name="acc_title" position="1000,170" size="820,50" font="Regular;36" foregroundColor="%(text)s" backgroundColor="%(panel)s" transparent="1" />
        <widget name="acc_keys" position="1000,235" size="230,340" font="Regular;28" foregroundColor="%(dim)s" backgroundColor="%(panel)s" transparent="1" />
        <widget name="acc_vals" position="1240,235" size="590,340" font="Regular;28" foregroundColor="%(text)s" backgroundColor="%(panel)s" transparent="1" />
        <eLabel position="1000,592" size="820,2" backgroundColor="%(sel)s" />
        <widget name="coffee" position="1000,610" size="820,44" font="Regular;30" halign="center" foregroundColor="%(gold)s" backgroundColor="%(panel)s" transparent="1" />
        <eLabel position="1102,662" size="246,246" backgroundColor="#00ffffff" />
        <widget name="qr_paypal" position="1110,670" size="230,230" alphatest="blend" zPosition="2" />
        <widget name="lbl_paypal" position="1110,912" size="230,36" font="Regular;26" halign="center" foregroundColor="%(text)s" backgroundColor="%(panel)s" transparent="1" />
        <eLabel position="1472,662" size="246,246" backgroundColor="#00ffffff" />
        <widget name="qr_kofi" position="1480,670" size="230,230" alphatest="blend" zPosition="2" />
        <widget name="lbl_kofi" position="1480,912" size="230,36" font="Regular;26" halign="center" foregroundColor="%(text)s" backgroundColor="%(panel)s" transparent="1" />
        %(footer)s
    </screen>""" % dict(bg=BG, panel=PANEL, text=TEXT, dim=DIM, accent=ACCENT, sel=SEL, gold=GOLD,
                        clock=clock(), footer=footer()))

    def __init__(self, session):
        Screen.__init__(self, session)
        core.load_keymap()
        self.alive = True
        self["logo"] = Pixmap()
        self.logo = ImageLoader(self, "logo", transparent=True)
        self["tagline"] = Label(
            T(_(u"Live  \u2022  Movies  \u2022  TV series\nTMDB details  \u2022  v%s") % core.VERSION))
        self["menu"] = XCDList(font_size=31, item_height=55)
        self["acc_title"] = Label(T(_("Account")))
        self["acc_keys"] = Label("")
        self["acc_vals"] = Label("")
        self["coffee"] = Label(
            T(u"\u2615  " + _("Do you like XC Diamond? Buy me a coffee")))
        self["qr_paypal"] = Pixmap()
        self["qr_kofi"] = Pixmap()
        self["lbl_paypal"] = Label("PayPal")
        self["lbl_kofi"] = Label("Ko-fi")
        self.qr = [
            ImageLoader(
                self, "qr_paypal"), ImageLoader(
                self, "qr_kofi")]
        self["key_red"] = Label(T(_("Exit")))
        self["key_green"] = Label(T(_("Open")))
        self["key_yellow"] = Label(T(_("Refresh")))
        self["key_blue"] = Label(T(_("Settings")))
        self["actions"] = ActionMap(["OkCancelActions",
                                     "ColorActions",
                                     "DirectionActions",
                                     "XCDActions"],
                                    {"ok": self.open_selected,
                                     "green": self.open_selected,
                                     "cancel": self.close,
                                     "red": self.close,
                                     "yellow": self.refresh,
                                     "blue": self.open_settings,
                                     "menu": self.open_settings,
                                     "help": lambda: open_help(self.session,
                                                               "home"),
                                     "up": lambda: self["menu"].move("up"),
                                     "down": lambda: self["menu"].move("down"),
                                     },
                                    -1)
        self.onLayoutFinish.append(self._build)
        self.onClose.append(self._closed)

    def _closed(self):
        self.alive = False
        core.stop_epg_updates(self._epg_changed)
        # protected categories lock again when the plugin closes
        core.protection().unlocked = False

    def _set_info(self, rows):
        """rows: [(label, value)] in two aligned columns."""
        self["acc_keys"].setText(T(u"\n".join(r[0] for r in rows)))
        self["acc_vals"].setText(T(u"\n".join(r[1] for r in rows)))

    def _message(self, text):
        self["acc_keys"].setText("")
        self["acc_vals"].setText(T(text))

    def _build(self):
        self.logo.load(os.path.join(PLUGIN_DIR, "icons", "logo.png"))
        self.qr[0].load(os.path.join(PLUGIN_DIR, "icons", "qr_paypal.png"))
        self.qr[1].load(os.path.join(PLUGIN_DIR, "icons", "qr_kofi.png"))
        core.autoconfigure()
        self._fill_menu()
        if not core.configured():
            self._message(
                _("No server configured.\n\nChoose Servers in the menu,\nor write it in the file\n%s") %
                core.server_file())
        else:
            self.refresh(force_epg=False)

    def _fill_menu(self):
        """The Catchup entry appears only when the server in use has channels with archive."""
        current = self["menu"].current() if self["menu"].list else None
        show_catchup = core.configured() and core.has_catchup() is True
        entries = [
            self["menu"].entry(
                key,
                self._menu_label(
                    key,
                    _(label)),
                icon=icon(
                    "menu_" +
                    ico,
                    48)) for key,
            label,
            ico in MENU if key != "catchup" or show_catchup]
        keys = [e[0] for e in entries]
        self["menu"].set_entries(
            entries, keys.index(current) if current in keys else 0)

    def _catchup_checked(self, has):
        if self.alive:
            self._fill_menu()

    @staticmethod
    def _menu_label(key, label):
        if key == "about":
            from . import updater
            info = updater.last_check()
            if info and updater.is_newer(info.get("version"), core.VERSION):
                return u"%s   \u2022  " % label + _("new %s") % info["version"]
        return label

    def refresh(self, force_epg=True):
        if not core.configured():
            return
        core.client().clear_cache()
        core.ensure_epg(self._epg_changed, force=force_epg)
        self._message(_("Connecting..."))
        run_async(
            core.client().account,
            callback=self._account_ok,
            errback=self._account_err)

    def _epg_changed(self):
        if self.alive and getattr(self, "last_account", None):
            self._account_ok(self.last_account)

    def _account_ok(self, acc):
        if not self.alive:
            return
        self.last_account = acc
        status = (state_label(acc["state"]) if acc.get("state") not in (
            None, "unknown") else acc["status"]) + ((u"  (%s)" % _("trial")) if acc["trial"] else u"")
        if acc["status"].lower() == "active":
            status = u"\u25cf  " + status
        tz = acc.get("timezone") or u"\u2014"
        if acc.get("server_time"):
            tz += u"   \u2022   " + \
                _("server time %s") % acc["server_time"][11:16]
        rows = [
            (_("Status"), status),
            (_("Expires"), acc["expires"]),
            (_("Connections"), acc["connections"]),
            (_("Server"), core.client().server.split("://")[-1]),
            (_("Time zone"), tz),
            (_("EPG guide"), core.epg().status_text()),
            (u"TMDB", (_("active") + u" (%s)" % {"settings": _("your key"), "file": u"tmdb.txt",
                                                 "builtin": _("built-in key")}[core.tmdb_key_source()])
             if core.tmdb().enabled else _("key not set")),
        ]
        if acc.get("message"):
            rows.append((_("Message"), acc["message"][:60]))
        self._set_info(rows)
        if core.has_catchup() is None and not getattr(self, "catchup_checking", False):
            # once per opening; the answer is kept for 24 hours
            self.catchup_checking = True
            run_async(
                core.check_catchup,
                callback=self._catchup_checked,
                errback=lambda e: None)

    def _account_err(self, err):
        if not self.alive:
            return
        prefix = _("Access denied") if isinstance(
            err, AuthError) else _("Server unreachable")
        self._message(
            _("%s\n\n%s\n\nChoose another server from the Servers menu.") %
            (prefix, err))

    def open_selected(self):
        key = self["menu"].current()
        if key == "settings":
            return self.open_settings()
        if key == "downloads":
            from .downloads_ui import DownloadsScreen
            return self.session.open(DownloadsScreen)
        if key == "help":
            return open_help(self.session, "start")
        if key == "about":
            from .about import AboutScreen
            return self.session.openWithCallback(
                lambda *a: self.alive and self._build(), AboutScreen)
        if key == "search":
            return self.open_search()
        if key == "bouquets":
            from .bouquet_ui import BouquetScreen
            return self.session.open(BouquetScreen)
        if key == "servers":
            from .servers import ServerScreen
            return self.session.openWithCallback(
                lambda changed=False: changed and self._build(), ServerScreen)
        if not core.configured():
            self.session.open(MessageBox,
                              T(_("Configure the server first (BLUE key).")),
                              MessageBox.TYPE_INFO,
                              timeout=5)
            return
        if key == "catchup":
            from .catchup import CatchupChannelsScreen
            return self.session.open(CatchupChannelsScreen)
        from .browser import BrowserScreen
        if key == "fav":
            self.session.open(BrowserScreen, VOD, favorites_only=True)
        else:
            self.session.open(BrowserScreen, key)

    def open_search(self):
        """New search or one of the last 10."""
        if not core.configured():
            return
        recent = core.history().items
        if not recent:
            return core.open_search(self.session)
        choices = [(T(u"+  " + _("New search...")), None)] + \
            [(T(u"\u00bb  " + q), q) for q in recent]

        def done(choice):
            if choice:
                core.open_search(self.session, choice[1])
        self.session.openWithCallback(done, ChoiceBox, title=T(
            _("Search channels, movies and series")), list=choices)

    def open_settings(self):
        # with parental control on, the settings ask for the PIN (so it cannot
        # be switched off secretly)
        core.ask_pin(
            self.session,
            lambda ok: ok and self.alive and self.session.openWithCallback(
                lambda changed=False: changed and self._build(),
                SettingsScreen),
            title=_("PIN for the settings"))


class SettingsScreen(ConfigListScreen, Screen):
    skin = scale_skin("""
    <screen name="XCDSettings" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="%(bg)s">
        <widget name="title" position="120,70" size="1200,80" font="Regular;56" foregroundColor="%(accent)s" backgroundColor="%(bg)s" transparent="1" />
        %(clock)s
        <widget name="config" position="120,190" size="1680,640" itemHeight="64" font="Regular;32" foregroundColor="%(text)s" backgroundColor="%(bg)s" backgroundColorSelected="%(sel)s" scrollbarMode="showOnDemand" transparent="1" />
        <eLabel position="120,846" size="1680,2" backgroundColor="%(panel)s" />
        <widget name="help" position="120,860" size="1680,110" font="Regular;26" foregroundColor="%(dim)s" backgroundColor="%(bg)s" transparent="1" />
        %(footer)s
    </screen>""" % dict(bg=BG, panel=PANEL, text=TEXT, dim=DIM, accent=ACCENT, sel=SEL, gold=GOLD,
                        clock=clock(), footer=footer()))

    @staticmethod
    def help_texts():
        return {
            "server": _("Server address, e.g. http://myserver.com:8080  (for testing: http://PC-IP:8080)"),
            "sort": _("Order the lists open with. It can also be changed from the list with the MENU key (and is remembered)."),
            "playlist": _("Folder with playlist.txt (servers added from the plugin) and the other .txt lists, e.g. xclink.txt of XC. OK: choose the folder."),
            "download": _("Where the download panel saves movies and episodes. Empty = /media/hdd/movie. OK: choose the folder."),
            "upd": _("Once a day it checks GitHub (OwnerPlugins/XCDiamond) for a new version. Install it from Home > Info."),
            "bq": _("The categories for the bouquets are chosen in Home > Bouquets. The automatic update works while the receiver is on."),
            "parental": _("Adult categories lock by themselves; others are protected from the list with MENU. The PIN is asked once per session."),
            "epg": _("Automatic is right almost always. If programmes are a few hours ahead or behind, correct it here (or with 7/8/9 in the channel list)."),
            "tmdb": _("The key built into XC Diamond is already set. You can replace it with your own free key from themoviedb.org, or empty it and write yours in /etc/enigma2/xc/tmdb.txt"),
        }

    def __init__(self, session):
        Screen.__init__(self, session)
        self.entries = self._entries()
        try:
            ConfigListScreen.__init__(
                self,
                self.entries,
                session=session,
                on_change=self._changed)
        except TypeError:                          # older images without on_change
            ConfigListScreen.__init__(self, self.entries, session=session)
        self["title"] = Label(T(_("Settings")))
        self["help"] = Label("")
        self["key_red"] = Label(T(_("Cancel")))
        self["key_green"] = Label(T(_("Save")))
        self["key_yellow"] = Label(T(_("Test connection")))
        self["key_blue"] = Label(T(_("Server from file")))
        self["setup_actions"] = ActionMap(["SetupActions", "ColorActions"], {
            "cancel": self.cancel, "red": self.cancel,
            "green": self.save, "save": self.save,
            "yellow": self.test, "blue": self.pick_server, "ok": self.keyboard,
        }, -2)
        self["config"].onSelectionChanged.append(self._help)
        self.onLayoutFinish.append(self._help)

    def _entries(self):
        c = core.cfg
        entries = [
            getConfigListEntry(T(_("Server")), c.server, "server"),
            getConfigListEntry(T(_("Username")), c.username, ""),
            getConfigListEntry(T(_("Password")), c.password, ""),
            getConfigListEntry(T(_("TMDB key")), c.tmdb_key, "tmdb"),
            getConfigListEntry(T(_("TMDB details language")), c.tmdb_lang, ""),
            getConfigListEntry(T(_("Live channel format")), c.live_format, ""),
            getConfigListEntry(T(_("Video player")), c.player, ""),
            getConfigListEntry(T(_("Play next episode automatically")), c.autonext, ""),
            getConfigListEntry(T(_("Offer to resume movies and episodes")), c.resume, ""),
            getConfigListEntry(T(_("Live channel order")), c.sort_live, "sort"),
            getConfigListEntry(T(_("Movie order")), c.sort_vod, "sort"),
            getConfigListEntry(T(_("Series order")), c.sort_series, "sort"),
            getConfigListEntry(T(_("EPG time correction")), c.epg_offset, "epg"),
            getConfigListEntry(T(_("Playlist folder (playlist.txt)")), c.playlist_dir, "playlist"),
            getConfigListEntry(T(_("Automatic server check")), c.server_check, ""),
            getConfigListEntry(T(_("Bouquet: position in the TV list")), c.bq_top, "bq"),
            getConfigListEntry(T(_("Bouquet: add Favorites")), c.bq_fav, "bq"),
            getConfigListEntry(T(_("Bouquet: create the EPGImporter guide")), c.bq_epg, "bq"),
            getConfigListEntry(T(_("Bouquet: automatic update")), c.bq_auto, "bq"),
        ]
        if c.bq_auto.value == "time":
            entries.append(getConfigListEntry(
                T(_("Bouquet: update time")), c.bq_time, "bq"))
        elif c.bq_auto.value == "interval":
            entries.append(getConfigListEntry(
                T(_("Bouquet: update every")), c.bq_interval, "bq"))
        entries += [
            getConfigListEntry(T(_("Download folder")), c.download_dir, "download"),
            getConfigListEntry(T(_("Tell me about new versions")), c.update_check, "upd"),
            getConfigListEntry(T(_("Parental control")), c.parental, "parental"),
            getConfigListEntry(T(_("Parental PIN (4 digits)")), c.parental_pin, "parental"),
        ]
        return entries

    def _choose_download_folder(self):
        def done(path):
            if path:
                core.cfg.download_dir.value = path.rstrip("/") or "/"
                self["config"].setList(self.entries)
        try:
            from Screens.LocationBox import LocationBox
            self.session.openWithCallback(
                done,
                LocationBox,
                text=T(
                    _("Download folder")),
                currDir=core.download_folder() +
                "/",
                minFree=None)
        except Exception as e:
            print("[XCDiamond] folder browser: %s" % e)

    def _changed(self):
        """Show or hide the time/interval rows when the update mode changes."""
        cur = self["config"].getCurrent()
        if cur and cur[1] is core.cfg.bq_auto:
            self.entries = self._entries()
            self["config"].setList(self.entries)

    def _help(self):
        cur = self["config"].getCurrent()
        key = cur[2] if cur and len(cur) > 2 else ""
        text = self.help_texts().get(key) or _(
            "OK: keyboard for text fields.  Left/Right: change value.  BLUE: choose a server from %s") % core.server_file()
        self["help"].setText(T(text))

    def keyboard(self):
        cur = self["config"].getCurrent()
        if cur and cur[1] is core.cfg.playlist_dir:
            from .servers import choose_playlist_folder
            return choose_playlist_folder(
                self.session,
                lambda: self["config"].setList(
                    self.entries))
        if cur and cur[1] is core.cfg.download_dir:
            return self._choose_download_folder()
        if not cur or not isinstance(cur[1], (ConfigText, ConfigPassword)):
            return
        item = cur[1]

        def done(text):
            if text is not None:
                item.setValue(text.strip())
                self["config"].invalidateCurrent()
        self.session.openWithCallback(
            done, VirtualKeyBoard, title=cur[0], text=item.value)

    def pick_server(self):
        from .servers import ServerScreen

        def done(changed=False):
            if changed:
                self["config"].setList(self.entries)   # redraw the new values
                self.test()
        self.session.openWithCallback(done, ServerScreen)

    def _apply(self):
        moved = core.cfg.bq_top.isChanged()
        for item in self._items():
            item.save()
        core.cfg.save()
        core.save_configfile()
        core.reset()
        if moved:                                   # the new position applies now, without exporting again
            try:
                core.exporter().move(core.cfg.bq_top.value)
            except Exception as e:
                print("[XCDiamond] bouquet position: %s" % e)

    def save(self):
        from .parental import pin_problem
        if core.cfg.parental.value:
            problem = pin_problem(core.cfg.parental_pin.value)
            if problem:
                self.session.open(
                    MessageBox, T(problem), MessageBox.TYPE_ERROR)
                return
        self._apply()
        self.close(True)

    def test(self):
        self._apply()
        self["help"].setText(T(_("Testing the connection...")))

        def ok(acc):
            self["help"].setText(T(_("Connected: account %s, expires %s, connections %s")
                                   % (acc["status"], acc["expires"], acc["connections"])))

        def err(e):
            self["help"].setText(T(_("Connection failed: %s") % e))
        run_async(core.client().account, callback=ok, errback=err)

    def _items(self):
        """Every setting of the screen, also the rows hidden right now (time/interval)."""
        items = [entry[1] for entry in self.entries]
        for extra in (core.cfg.bq_time, core.cfg.bq_interval):
            if extra not in items:
                items.append(extra)
        return items

    def cancel(self):
        for item in self._items():
            item.cancel()
        self.close(False)
