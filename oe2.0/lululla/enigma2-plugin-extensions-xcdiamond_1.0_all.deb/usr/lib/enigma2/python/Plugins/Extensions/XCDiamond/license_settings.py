# -*- coding: utf-8 -*-
"""License settings of XC Diamond: the only file to edit for the license.
Updates of license_box.py do not touch these values."""

# /exec address of license_server.gs (Google Apps Script)
SERVER_URL = "https://script.google.com/macros/s/AKfycbzCKv_nRQvmmbjeGqr_a-YADI1fbslN4T89TQ4SQH0ekek84AGjJTRWx8TfGmXDCeHI/exec"
# True = screen with made-up data, OK enters (no server)
DEMO = False
# shown to users who are waiting or blocked
CONTACT = "www.linuxsat-support.com"
