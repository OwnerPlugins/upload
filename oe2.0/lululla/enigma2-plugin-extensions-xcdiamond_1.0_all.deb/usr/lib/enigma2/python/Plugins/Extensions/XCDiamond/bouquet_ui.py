# -*- coding: utf-8 -*-
"""Bouquet screen: tick the categories, GREEN writes the bouquets (with the EPGImporter guide)."""

import time

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label

from .help import open_help
from . import _, core
from .net import run_async
from .ui import (
    T,
    XCDList,
    icon,
    scale_skin,
    footer,
    clock,
    new_timer,
    BG,
    PANEL,
    TEXT,
    DIM,
    ACCENT,
    SEL,
    GOLD,
    C_DIM,
    C_GOLD,
    C_TEXT)


def sections():
    return [("live", _("LIVE CHANNELS")), ("vod", _("MOVIES"))]


def auto_text():
    """'every day at 05:00', 'every 12 hours' or 'off'."""
    c = core.cfg
    if c.bq_auto.value == "time":
        return _("every day at %s") % (u"%02d:%02d" % tuple(c.bq_time.value))
    if c.bq_auto.value == "interval":
        return _("every %s hours") % c.bq_interval.value
    return _("off")


def _day_times(current):
    """Choices every 30 minutes, plus the current time if it is not on the half hour."""
    times = [u"%02d:%02d" % (h, m) for h in range(24) for m in (0, 30)]
    mine = u"%02d:%02d" % tuple(current)
    if mine not in times:
        times.append(mine)
        times.sort()
    return times


class BouquetScreen(Screen):
    skin = scale_skin("""
    <screen name="XCDBouquet" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="%(bg)s">
        <widget name="header" position="60,30" size="1000,60" font="Regular;44" foregroundColor="%(text)s" backgroundColor="%(bg)s" transparent="1" />
        <widget name="count" position="760,42" size="880,40" font="Regular;28" halign="right" noWrap="1" foregroundColor="%(dim)s" backgroundColor="%(bg)s" transparent="1" />
        %(clock)s
        <eLabel position="60,110" size="1800,2" backgroundColor="%(panel)s" />
        <widget name="list" position="60,130" size="1100,840" itemHeight="60" backgroundColor="%(bg)s" backgroundColorSelected="%(sel)s" scrollbarMode="showOnDemand" transparent="1" />
        <eLabel position="1190,130" size="670,840" backgroundColor="%(panel)s" zPosition="-1" />
        <widget name="info" position="1220,150" size="610,800" font="Regular;26" foregroundColor="%(text)s" backgroundColor="%(panel)s" transparent="1" />
        %(footer)s
    </screen>""" % dict(bg=BG, panel=PANEL, text=TEXT, dim=DIM, accent=ACCENT, sel=SEL, gold=GOLD,
                        clock=clock(), footer=footer()))

    def __init__(self, session):
        Screen.__init__(self, session)
        core.load_keymap()
        self.alive = True
        self.cats = {"live": [], "vod": []}
        self.selected = core.bouquet_selection_ids()
        self.busy = False
        self.progress_text = u""
        self["header"] = Label(T(_("Bouquets")))
        self["count"] = Label("")
        self["list"] = XCDList(font_size=30, item_height=60)
        self["info"] = Label("")
        self["key_red"] = Label(T(_("Back")))
        self["key_green"] = Label(T(_("Create bouquets")))
        self["key_yellow"] = Label(T(_("All / none")))
        self["key_blue"] = Label(T(_("Remove bouquets")))
        self["actions"] = ActionMap(["OkCancelActions",
                                     "ColorActions",
                                     "DirectionActions",
                                     "XCDActions"],
                                    {"ok": self.toggle,
                                     "cancel": self.close,
                                     "red": self.close,
                                     "green": self.create,
                                     "yellow": self.toggle_section,
                                     "blue": self.remove,
                                     "menu": self.options_menu,
                                     "help": lambda: open_help(self.session,
                                                               "bouquets"),
                                     "up": lambda: self["list"].move("up"),
                                     "down": lambda: self["list"].move("down"),
                                     "pageUp": lambda: self["list"].move("pageUp"),
                                     "pageDown": lambda: self["list"].move("pageDown"),
                                     "left": lambda: self["list"].move("pageUp"),
                                     "right": lambda: self["list"].move("pageDown"),
                                     },
                                    -1)
        self.progress_timer = new_timer(self._show_progress)
        self.onLayoutFinish.append(self._start)
        self.onClose.append(self._closed)

    def _closed(self):
        self.alive = False
        self.progress_timer.stop()

    # ------------------------------------------------------------------
    def _start(self):
        self["list"].set_entries([self["list"].entry(
            None, _("Loading categories..."), color=C_DIM)])
        self._update_info()
        run_async(self._load, callback=self._loaded, errback=self._error)

    @staticmethod
    def _load():
        c = core.client()
        return {"live": c.categories("live"), "vod": c.categories("vod")}

    def _loaded(self, cats):
        if not self.alive:
            return
        self.cats = cats
        # categories that no longer exist on the server are forgotten
        for kind in ("live", "vod"):
            ids = set(c["id"] for c in cats[kind])
            self.selected[kind] = set(
                x for x in self.selected[kind] if x in ids)
        self._redraw()

    def _error(self, err):
        if self.alive:
            self["list"].set_entries(
                [self["list"].entry(None, _("Error: %s") % err, color=C_DIM)])

    def _redraw(self, keep_index=True):
        lst = self["list"]
        index = lst.getSelectedIndex() if keep_index and lst.list else 1
        entries = []
        for kind, title in sections():
            n = len(self.selected[kind])
            entries.append(lst.entry({"section": kind}, u"\u2014  %s  \u2014" % title, _(
                "%d chosen") % n if n else u"", C_GOLD, color=C_DIM))
            for cat in self.cats.get(kind, []):
                on = cat["id"] in self.selected[kind]
                lock = core.is_protected(kind, cat)
                entries.append(
                    lst.entry(
                        {
                            "kind": kind,
                            "cat": cat},
                        (u"\u2713   " if on else u"      ") +
                        cat["name"],
                        color=C_TEXT if on else C_DIM,
                        icon=icon(
                            "lock",
                            32) if lock else None,
                        icon_size=32))
        lst.set_entries(entries, index)
        total = sum(len(v) for v in self.selected.values())
        self["count"].setText(T(_("%d categories chosen") % total))

    def _update_info(self):
        c = core.cfg
        last = core.last_bouquet_export()
        lines = []
        if last:
            lines += [
                _("Last bouquet created:"),
                u"%s" %
                time.strftime(
                    "%d/%m/%Y %H:%M",
                    time.localtime(
                        last.get(
                            "time",
                            0))),
                _("%d lists, %d items, %d channels with guide") %
                (last.get(
                    "bouquets",
                    0),
                    last.get(
                        "channels",
                        0),
                 last.get(
                    "epg",
                    0)),
                u""]
        else:
            lines += [_("No bouquet created."), u""]
        yes, no = _("yes"), _("no")
        lines += [
            _("OK: choose the categories"),
            _("GREEN: create/update the XC Diamond bouquet"),
            _("(one sub-bouquet for each category)"),
            u"",
            _("Position in the list: %s") %
            c.bq_top.getText(),
            _("Favorites in the bouquet: %s") %
            (yes if c.bq_fav.value else no),
            _("Guide for EPGImporter: %s") %
            (yes if c.bq_epg.value else no),
            _("Automatic update: %s") %
            auto_text()]
        nxt = core.next_bouquet_run()
        if nxt:
            lines.append(_("Next update: %s") % time.strftime(
                "%d/%m %H:%M", time.localtime(max(nxt, time.time()))))
        lines.append(_("MENU: position and automatic update"))
        if c.bq_epg.value:
            lines += [u"",
                      _("Guide: in EPGImporter enable the source"),
                      _(u"\u201cXC Diamond\u201d and start the import.")]
        self["info"].setText(T(u"\n".join(lines)))

    # ------------------------------------------------------------------
    def toggle(self):
        row = self["list"].current()
        if not row or self.busy:
            return
        if "section" in row:
            return self.toggle_section()
        kind, cat = row["kind"], row["cat"]

        def flip(ok=True):
            if not ok or not self.alive:
                return
            ids = self.selected[kind]
            if cat["id"] in ids:
                ids.discard(cat["id"])
            else:
                ids.add(cat["id"])
            core.save_bouquet_selection(self.selected)
            self._redraw()
        if cat["id"] not in self.selected[kind] and core.is_protected(
                kind, cat):
            # protected category: the PIN is needed to add it
            return core.ask_pin(self.session, flip)
        flip()

    def toggle_section(self):
        """YELLOW: select (or clear) all categories of the current section."""
        row = self["list"].current()
        if not row or self.busy:
            return
        kind = row.get("section") or row.get("kind")
        cats = [
            c for c in self.cats.get(
                kind,
                []) if not core.is_protected(
                kind,
                c)]
        ids = self.selected[kind]
        if all(c["id"] in ids for c in cats):
            ids.clear()
        else:
            # protected ones are added one by one with the PIN
            ids.update(c["id"] for c in cats)
        core.save_bouquet_selection(self.selected)
        self._redraw()

    def create(self):
        if self.busy:
            return
        if not (self.selected["live"]
                or self.selected["vod"] or core.cfg.bq_fav.value):
            return self.session.open(MessageBox,
                                     T(_("Choose at least one category (OK).")),
                                     MessageBox.TYPE_INFO,
                                     timeout=4)
        self.busy = True
        self.progress_text = _("Preparing the bouquets...")
        self._show_progress()
        self.progress_timer.start(300, False)
        run_async(core.run_bouquet_export, (self._progress,),
                  callback=self._done, errback=self._failed)

    def _progress(self, number, total, name):
        """Called from the thread: the text is stored, the timer shows it (the GUI is touched only from its thread)."""
        self.progress_text = _("Creating the bouquets: %d of %d") % (
            number + 1, total) + u"  \u2014  %s" % name

    def _show_progress(self):
        if self.alive:
            self["count"].setText(T(self.progress_text))

    def _done(self, result):
        self.busy = False
        self.progress_timer.stop()
        if not self.alive:
            return
        self._redraw()
        self._update_info()
        msg = _("XC Diamond bouquet created: %d lists, %d items.") % (
            result["bouquets"], result["channels"])
        if core.cfg.bq_epg.value and result.get("epg"):
            msg += u"\n\n" + \
                _(u"Guide: %d channels linked.\nIn EPGImporter enable the source \u201cXC Diamond\u201d.") % result["epg"]
        self.session.open(MessageBox, T(msg), MessageBox.TYPE_INFO, timeout=8)

    def _failed(self, err):
        self.busy = False
        self.progress_timer.stop()
        if self.alive:
            self["count"].setText("")
            self.session.open(
                MessageBox, T(
                    _("Error while creating: %s") %
                    err), MessageBox.TYPE_ERROR)

    def options_menu(self):
        """MENU: bouquet position and automatic update, all with the remote."""
        if self.busy:
            return
        from Screens.ChoiceBox import ChoiceBox
        choices = [(T(_("Position in the TV list") + u":  " + core.cfg.bq_top.getText()),
                    "position"), (T(_("Automatic update") + u":  " + auto_text()), "auto")]

        def done(choice):
            if choice and self.alive:
                (self.position_menu if choice[1] ==
                 "position" else self.auto_menu)()
        self.session.openWithCallback(
            done, ChoiceBox, title=T(
                _("Bouquet options")), list=choices)

    def auto_menu(self):
        from Screens.ChoiceBox import ChoiceBox
        c = core.cfg
        choices = [(T(_("Off")), ("off", None))]
        choices += [(T(_("Every day at %s") % hhmm), ("time", hhmm))
                    for hhmm in _day_times(c.bq_time.value)]
        choices += [(T(_("Every %s hours") % h), ("interval", h))
                    for h in ("3", "6", "12", "24", "48")]
        current = {"off": 0}.get(c.bq_auto.value)
        if current is None:
            wanted = (
                "time",
                u"%02d:%02d" %
                tuple(
                    c.bq_time.value)) if c.bq_auto.value == "time" else (
                "interval",
                c.bq_interval.value)
            current = next(
                (i for i, ch in enumerate(choices) if ch[1] == wanted), 0)
        self.session.openWithCallback(self._auto_chosen, ChoiceBox, title=T(
            _("Automatic update of the bouquets")), list=choices, selection=current)

    def _auto_chosen(self, choice):
        if not choice or not self.alive:
            return
        c = core.cfg
        mode, value = choice[1]
        c.bq_auto.value = mode
        if mode == "time":
            hour, minute = value.split(":")
            c.bq_time.value = [int(hour), int(minute)]
        elif mode == "interval":
            c.bq_interval.value = value
        for item in (c.bq_auto, c.bq_time, c.bq_interval):
            item.save()
        core.save_configfile()
        self._update_info()

    def position_menu(self):
        """Where to put the XC Diamond bouquet in the TV bouquet list."""
        from Screens.ChoiceBox import ChoiceBox
        c = core.cfg.bq_top
        choices = [(T(_("At the top of the list")),
                    "top"),
                   (T(_("At the bottom of the list")),
                    "bottom"),
                   (T(_("Leave where it is (if you move it by hand)")),
                    "keep")]
        sel = [
            v for _label,
            v in choices].index(
            c.value) if c.value in (
            "top",
            "bottom",
            "keep") else 0
        self.session.openWithCallback(self._position_chosen, ChoiceBox, title=T(
            _("Position of the XC Diamond bouquet")), list=choices, selection=sel)

    def _position_chosen(self, choice):
        if not choice or not self.alive:
            return
        c = core.cfg.bq_top
        c.value = choice[1]
        c.save()
        core.save_configfile()
        moved = False
        try:
            moved = core.exporter().move(choice[1])
        except Exception as e:
            print("[XCDiamond] bouquet position: %s" % e)
        self._update_info()
        if moved:
            self.session.open(
                MessageBox, T(
                    _("Bouquet moved: %s.") %
                    c.getText().lower()), MessageBox.TYPE_INFO, timeout=3)

    def remove(self):
        if self.busy:
            return

        def answer(yes):
            if not yes or not self.alive:
                return
            n = core.exporter().remove()
            core.cfg.bq_last.value = ""
            core.cfg.bq_last.save()
            self._update_info()
            self.session.open(
                MessageBox, T(
                    _("XC Diamond bouquets removed (%d files). The other bouquets were not touched.") %
                    n), MessageBox.TYPE_INFO, timeout=5)
        self.session.openWithCallback(
            answer,
            MessageBox,
            T(
                _("Remove all XC Diamond bouquets and the EPGImporter guide?")),
            MessageBox.TYPE_YESNO,
            default=False)
