# -*- coding: utf-8 -*-
"""Tiny self-contained QR Code generator (byte mode) -> PNG. No external dependencies.

Written from scratch to put the web-interface address on screen as a QR the phone camera can
read. Supports versions 1..10 at error-correction level M, which is far more than the short
"http://ip:8765/?t=token" URL needs. Validated against a reference encoder.
"""

import struct
import zlib

# (total_codewords, data_codewords) per block, for each version at level M
_EC_M = {
    1: [(26, 16)],
    2: [(44, 28)],
    3: [(70, 44)],
    4: [(50, 32), (50, 32)],
    5: [(67, 43), (67, 43)],
    6: [(43, 27), (43, 27), (43, 27), (43, 27)],
    7: [(49, 31), (49, 31), (49, 31), (49, 31)],
    8: [(60, 38), (60, 38), (61, 39), (61, 39)],
    9: [(58, 36), (58, 36), (58, 36), (59, 37), (59, 37)],
    10: [(69, 43), (69, 43), (69, 43), (69, 43), (70, 44)],
}

# alignment-pattern centre coordinates per version (version 1 has none)
_ALIGN = {
    1: [], 2: [
        6, 18], 3: [
            6, 22], 4: [
                6, 26], 5: [
                    6, 30], 6: [
                        6, 34], 7: [
                            6, 22, 38], 8: [
                                6, 24, 42], 9: [
                                    6, 26, 46], 10: [
                                        6, 28, 50], }


# ------------------------------------------------------------------ GF(256)

_EXP = [0] * 512
_LOG = [0] * 256
_x = 1
for _i in range(255):
    _EXP[_i] = _x
    _LOG[_x] = _i
    _x <<= 1
    if _x & 0x100:
        _x ^= 0x11D
for _i in range(255, 512):
    _EXP[_i] = _EXP[_i - 255]


def _gf_mul(a, b):
    if a == 0 or b == 0:
        return 0
    return _EXP[_LOG[a] + _LOG[b]]


def _rs_generator(n):
    g = [1]
    for i in range(n):
        g2 = [0] * (len(g) + 1)
        for j in range(len(g)):
            g2[j] ^= _gf_mul(g[j], 1)
            g2[j + 1] ^= _gf_mul(g[j], _EXP[i])
        g = g2
    return g


def _rs_encode(data, n):
    gen = _rs_generator(n)
    res = list(data) + [0] * n
    for i in range(len(data)):
        coef = res[i]
        if coef != 0:
            for j in range(len(gen)):
                res[i + j] ^= _gf_mul(gen[j], coef)
    return res[len(data):]


# ------------------------------------------------------------------ bit stream

def _count_bits(version):
    return 8 if version <= 9 else 16


def _fit_version(n_bytes):
    for v in range(1, 11):
        data_cw = sum(d for (_t, d) in _EC_M[v])
        need = 4 + _count_bits(v) + 8 * n_bytes
        if need <= data_cw * 8:
            return v
    raise ValueError("data too long for QR versions 1..10")


def _encode_data(text, version):
    data = bytearray(text.encode("utf-8"))
    bits = []

    def put(value, length):
        for i in range(length - 1, -1, -1):
            bits.append((value >> i) & 1)

    put(0b0100, 4)                        # byte mode
    put(len(data), _count_bits(version))
    for b in data:
        put(b, 8)

    data_cw = sum(d for (_t, d) in _EC_M[version])
    cap = data_cw * 8
    put(0, min(4, cap - len(bits)))       # terminator
    while len(bits) % 8:
        bits.append(0)
    codewords = bytearray(int("".join(str(b) for b in bits[i:i + 8]), 2)
                          for i in range(0, len(bits), 8))
    pad = [0xEC, 0x11]
    i = 0
    while len(codewords) < data_cw:
        codewords.append(pad[i % 2])
        i += 1
    return codewords


def _interleave(codewords, version):
    blocks = _EC_M[version]
    data_blocks, ec_blocks = [], []
    pos = 0
    for (total, dcount) in blocks:
        chunk = codewords[pos:pos + dcount]
        pos += dcount
        data_blocks.append(list(chunk))
        ec_blocks.append(_rs_encode(chunk, total - dcount))

    result = []
    maxd = max(len(b) for b in data_blocks)
    for i in range(maxd):
        for b in data_blocks:
            if i < len(b):
                result.append(b[i])
    maxe = max(len(b) for b in ec_blocks)
    for i in range(maxe):
        for b in ec_blocks:
            if i < len(b):
                result.append(b[i])
    return result


# ------------------------------------------------------------------ matrix

def _size(version):
    return version * 4 + 17


def _new_matrix(version):
    n = _size(version)
    return [[None] * n for _ in range(n)], [[False] * n for _ in range(n)]


def _place_finder(m, fn, r, c):
    for dr in range(-1, 8):
        for dc in range(-1, 8):
            rr, cc = r + dr, c + dc
            if 0 <= rr < len(m) and 0 <= cc < len(m):
                inside = (0 <= dr <= 6 and 0 <= dc <= 6)
                val = 0
                if inside:
                    if dr in (0, 6) or dc in (0, 6):
                        val = 1
                    elif 2 <= dr <= 4 and 2 <= dc <= 4:
                        val = 1
                m[rr][cc] = val
                fn[rr][cc] = True


def _place_alignment(m, fn, version):
    centres = _ALIGN[version]
    for r in centres:
        for c in centres:
            if fn[r][c]:              # overlaps a finder
                continue
            for dr in range(-2, 3):
                for dc in range(-2, 3):
                    val = 1 if (
                        abs(dr) == 2 or abs(dc) == 2 or (
                            dr == 0 and dc == 0)) else 0
                    m[r + dr][c + dc] = val
                    fn[r + dr][c + dc] = True


def _place_timing(m, fn):
    n = len(m)
    for i in range(8, n - 8):
        v = 1 if i % 2 == 0 else 0
        if not fn[6][i]:
            m[6][i] = v
            fn[6][i] = True
        if not fn[i][6]:
            m[i][6] = v
            fn[i][6] = True


def _reserve_format(m, fn, version):
    n = len(m)
    for i in range(9):
        if not fn[8][i]:
            fn[8][i] = True
        if not fn[i][8]:
            fn[i][8] = True
    for i in range(8):
        fn[8][n - 1 - i] = True
        fn[n - 1 - i][8] = True
    m[n - 8][8] = 1                      # dark module
    fn[n - 8][8] = True
    if version >= 7:
        for i in range(6):
            for j in range(3):
                fn[n - 11 + j][i] = True
                fn[i][n - 11 + j] = True


def _place_data(m, fn, bits):
    n = len(m)
    idx = 0
    col = n - 1
    upward = True
    while col > 0:
        if col == 6:
            col -= 1
        rows = range(n - 1, -1, -1) if upward else range(n)
        for row in rows:
            for c in (col, col - 1):
                if not fn[row][c]:
                    bit = bits[idx] if idx < len(bits) else 0
                    m[row][c] = bit
                    idx += 1
        upward = not upward
        col -= 2


def _mask(r, c, k):
    if k == 0:
        return (r + c) % 2 == 0
    if k == 1:
        return r % 2 == 0
    if k == 2:
        return c % 3 == 0
    if k == 3:
        return (r + c) % 3 == 0
    if k == 4:
        return (r // 2 + c // 3) % 2 == 0
    if k == 5:
        return (r * c) % 2 + (r * c) % 3 == 0
    if k == 6:
        return ((r * c) % 2 + (r * c) % 3) % 2 == 0
    return ((r + c) % 2 + (r * c) % 3) % 2 == 0


def _apply_mask(m, fn, k):
    out = [row[:] for row in m]
    for r in range(len(m)):
        for c in range(len(m)):
            if not fn[r][c] and _mask(r, c, k):
                out[r][c] ^= 1
    return out


_FORMAT_GEN = 0x537
_FORMAT_MASK = 0x5412


def _bch_format(data15):
    d = data15 << 10
    for i in range(14, 9, -1):
        if (d >> i) & 1:
            d ^= _FORMAT_GEN << (i - 10)
    return (data15 << 10) | (d & 0x3FF)


def _place_format(m, version, k):
    n = len(m)
    bits = (_bch_format((0 << 3) | k)) ^ _FORMAT_MASK   # EC level M = 0b00
    arr = [(bits >> i) & 1 for i in range(
        14, -1, -1)]   # arr[0] is MSB (bit14)
    # standard placement
    coords1 = [(8, 0), (8, 1), (8, 2), (8, 3), (8, 4), (8, 5), (8, 7), (8, 8),
               (7, 8), (5, 8), (4, 8), (3, 8), (2, 8), (1, 8), (0, 8)]
    for i, (r, c) in enumerate(coords1):
        m[r][c] = arr[i]
    coords2 = [(n -
                1, 8), (n -
                        2, 8), (n -
                                3, 8), (n -
                                        4, 8), (n -
                                                5, 8), (n -
                                                        6, 8), (n -
                                                                7, 8), (8, n -
                                                                        8), (8, n -
                                                                             7), (8, n -
                                                                                  6), (8, n -
                                                                                       5), (8, n -
                                                                                            4), (8, n -
                                                                                                 3), (8, n -
                                                                                                      2), (8, n -
                                                                                                           1)]
    for i, (r, c) in enumerate(coords2):
        m[r][c] = arr[i]


_VERSION_GEN = 0x1F25


def _bch_version(v):
    d = v << 12
    for i in range(17, 11, -1):
        if (d >> i) & 1:
            d ^= _VERSION_GEN << (i - 12)
    return (v << 12) | (d & 0xFFF)


def _place_version(m, version):
    if version < 7:
        return
    n = len(m)
    bits = _bch_version(version)
    for i in range(18):
        b = (bits >> i) & 1
        r, c = i // 3, i % 3
        m[n - 11 + c][r] = b
        m[r][n - 11 + c] = b


def _penalty(m):
    n = len(m)
    score = 0
    for line in (m, [[m[r][c] for r in range(n)] for c in range(n)]):
        for row in line:
            run = 1
            for i in range(1, n):
                if row[i] == row[i - 1]:
                    run += 1
                else:
                    if run >= 5:
                        score += 3 + (run - 5)
                    run = 1
            if run >= 5:
                score += 3 + (run - 5)
    for r in range(n - 1):
        for c in range(n - 1):
            if m[r][c] == m[r][c + 1] == m[r + 1][c] == m[r + 1][c + 1]:
                score += 3
    dark = sum(sum(row) for row in m)
    ratio = dark * 100 // (n * n)
    score += 10 * (abs(ratio - 50) // 5)
    return score


def matrix(text, version=None):
    """Return the QR module matrix (list of rows of 0/1) for text."""
    if version is None:
        version = _fit_version(len(text.encode("utf-8")))
    codewords = _encode_data(text, version)
    bits_cw = _interleave(codewords, version)
    data_bits = []
    for cw in bits_cw:
        for i in range(7, -1, -1):
            data_bits.append((cw >> i) & 1)

    base_m, fn = _new_matrix(version)
    n = _size(version)
    _place_finder(base_m, fn, 0, 0)
    _place_finder(base_m, fn, 0, n - 7)
    _place_finder(base_m, fn, n - 7, 0)
    _place_alignment(base_m, fn, version)
    _place_timing(base_m, fn)
    _reserve_format(base_m, fn, version)
    _place_data(base_m, fn, data_bits)

    best, best_score = None, None
    for k in range(8):
        cand = _apply_mask(base_m, fn, k)
        _place_format(cand, version, k)
        _place_version(cand, version)
        s = _penalty(cand)
        if best_score is None or s < best_score:
            best, best_score = cand, s
    return best


# ------------------------------------------------------------------ PNG

def _png(
    matrix_rows, scale=8, border=4, dark=(
        0, 0, 0), light=(
            255, 255, 255)):
    n = len(matrix_rows)
    size = (n + 2 * border) * scale
    row_bytes = size * 3

    def px(on):
        return bytes(dark if on else light)

    raw = bytearray()
    for y in range(size):
        raw.append(0)                      # filter type 0
        my = y // scale - border
        for x in range(size):
            mx = x // scale - border
            on = (0 <= my < n and 0 <= mx < n and matrix_rows[my][mx] == 1)
            raw += px(on)

    def chunk(tag, data):
        c = struct.pack(">I", len(data)) + tag + data
        return c + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

    sig = b"\x89PNG\r\n\x1a\n"
    ihdr = struct.pack(">IIBBBBB", size, size, 8, 2, 0, 0, 0)
    idat = zlib.compress(bytes(raw), 9)
    return sig + chunk(b"IHDR", ihdr) + chunk(b"IDAT",
                                              idat) + chunk(b"IEND", b"")


def save_png(text, path, scale=8, border=4):
    data = _png(matrix(text), scale=scale, border=border)
    with open(path, "wb") as f:
        f.write(data)
    return path
