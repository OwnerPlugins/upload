# -*- coding: utf-8 -*-
"""TMDB (The Movie Database) client with a disk cache.

Accepts both the v3 "API Key" (32 characters) and the v4 "Read Access Token"
(long string starting with eyJ...). Both are free at
https://www.themoviedb.org/settings/api
"""

import hashlib
import json
import os
import re
import time

from .net import get_json, urlencode, ensure_dir, CACHE_DIR

API = "https://api.themoviedb.org/3"
IMG = "https://image.tmdb.org/t/p/"
CACHE_TTL = 7 * 86400

# Tags that providers add to titles and that confuse the search
_JUNK = [
    # "IT - ", "|IT| ", "[ITA]: "
    r"^\s*[\|\[\(]?\s*[A-Z]{2,3}\s*[\|\]\)]?\s*[-:|]\s*",
    r"\b(4K|UHD|FHD|HD|SD|HEVC|H\.?265|x265|x264|1080p|720p|2160p|HDR|DV|3D)\b",
    r"\b(MULTI|MULTISUB|SUB\s*ITA|SUB|ITA|ENG|DUAL|AUDIO)\b",
    r"\[[^\]]*\]",
    r"\bS\d{1,2}\s*E\d{1,3}\b.*$",
]


def clean_title(name):
    """'IT - Sintel [HD] (2010)' -> ('Sintel', '2010')"""
    text = name or ""
    year = ""
    m = re.search(r"\((\d{4})\)|\b((?:19|20)\d{2})\s*$", text)
    if m:
        year = m.group(1) or m.group(2)
        text = text[:m.start()] + text[m.end():]
    for pattern in _JUNK:
        text = re.sub(pattern, " ", text, flags=re.I)
    text = re.sub(r"[\._]+", " ", text)
    text = re.sub(r"\s*[-|:]+\s*$", "", text)
    text = re.sub(r"\s{2,}", " ", text).strip(" -|:")
    if not text and year:      # movies titled with a year, e.g. "2012"
        text, year = year, ""
    return text, year


# Image sizes for the box resolution (core.py calls set_resolution at start)
SIZES = {
    "poster": "w342",
    "backdrop": "w1280",
    "logo": "w500",
    "still": "w300"}


def set_resolution(width):
    if width <= 1280:     # HD: lighter images, faster to load
        SIZES.update(poster="w185", backdrop="w780", logo="w300", still="w185")
    elif width >= 2560:   # WQHD/UHD
        SIZES.update(
            poster="w500",
            backdrop="w1280",
            logo="w500",
            still="w500")
    else:
        SIZES.update(
            poster="w342",
            backdrop="w1280",
            logo="w500",
            still="w300")


def image(path, size="poster"):
    return (IMG + SIZES.get(size, size) + path) if path else ""


CERT_COUNTRIES = ("IT", "US", "GB")


def _certification(entries, key):
    """Age rating: Italy first, then USA, then United Kingdom."""
    by_country = {}
    for entry in entries or []:
        country = entry.get("iso_3166_1")
        if key == "release_dates":
            for rd in entry.get("release_dates") or []:
                if rd.get("certification"):
                    by_country.setdefault(country, rd["certification"])
        elif entry.get("rating"):
            by_country.setdefault(country, entry["rating"])
    for country in CERT_COUNTRIES:
        if by_country.get(country):
            return by_country[country].strip()
    return ""


def _logo(images, language):
    """Title logo (transparent PNG): user language, then English, then no language."""
    logos = [l for l in (images or {}).get("logos") or [] if (
        l.get("file_path") or "").lower().endswith(".png")]
    lang = (language or "it")[:2]
    for wanted in (lang, "en", None):
        for logo in logos:
            if logo.get("iso_639_1") == wanted:
                return image(logo["file_path"], "logo")
    return ""


def _trailer(videos, language):
    """YouTube key of the trailer: official in the user language, then English, then any."""
    results = [v for v in (videos or {}).get("results") or [] if v.get(
        "site") == "YouTube" and v.get("key")]
    lang = (language or "it")[:2]

    def score(v):
        return ((v.get("type") == "Trailer") *
                4 +
                (v.get("iso_639_1") == lang) *
                2 +
                (v.get("official") is True) +
                (v.get("type") == "Teaser") *
                0.5)
    results.sort(key=score, reverse=True)
    return results[0]["key"] if results and results[0].get(
        "type") in ("Trailer", "Teaser") else ""


def _names(items, limit, key="name"):
    return ", ".join(i.get(key, "")
                     for i in (items or [])[:limit] if i.get(key))


def _is_latin(text):
    """False when the name uses letters of other alphabets (Korean, Chinese, Cyrillic...)."""
    return all(ord(c) < 0x250 or not c.isalpha() for c in text or u"")


class TMDB(object):
    def __init__(self, key, language="it-IT", timeout=15):
        self.key = (key or "").strip()
        self.language = language or "it-IT"
        self.timeout = timeout
        self.cache_dir = ensure_dir(os.path.join(CACHE_DIR, "tmdb"))

    @property
    def enabled(self):
        return len(self.key) >= 20

    # ---------------------------------------------------------------
    def _get(self, path, **params):
        if not self.enabled:
            return None
        params.setdefault("language", self.language)
        headers = None
        if self.key.startswith("eyJ"):          # token v4
            headers = {"Authorization": "Bearer " + self.key}
            query = urlencode(params)
        else:                                    # v3 key
            query = urlencode(dict(params, api_key=self.key))
        cache_key = hashlib.md5(
            ("%s?%s" %
             (path, urlencode(
                 sorted(
                     params.items())))).encode("utf-8")).hexdigest()
        cache_file = os.path.join(self.cache_dir, cache_key + ".json")
        try:
            if time.time() - os.path.getmtime(cache_file) < CACHE_TTL:
                with open(cache_file) as f:
                    return json.load(f)
        except (OSError, IOError, ValueError):
            pass
        data = get_json("%s%s?%s" % (API, path, query), self.timeout, headers)
        try:
            with open(cache_file, "w") as f:
                json.dump(data, f)
        except (OSError, IOError):
            pass
        return data

    # ---------------------------------------------------------------
    def latin_name(self, person):
        """Name in Latin letters: when TMDB gives it in another alphabet (e.g. 나홍진),
        look for the Latin spelling among the other names of the person (e.g. Na Hong-jin)."""
        name = person.get("name") or u""
        if _is_latin(name) or not person.get("id"):
            return name
        try:
            data = self._get(
                "/person/%s" %
                person["id"],
                language="en-US") or {}
        except Exception:
            return name
        for alt in [data.get("name") or u""] + \
                list(data.get("also_known_as") or []):
            if alt and _is_latin(alt):
                return alt
        return name

    def _people(self, people, limit):
        return u", ".join(self.latin_name(p)
                          for p in (people or [])[:limit] if p.get("name"))

    # ---------------------------------------------------------------
    def find_id(self, kind, name, year="", tmdb_id=""):
        """kind: 'movie' or 'tv'. Returns the TMDB id or ''."""
        tmdb_id = (tmdb_id or "").strip()
        if tmdb_id.isdigit() and tmdb_id != "0":
            return tmdb_id
        if tmdb_id.lower().startswith("tt"):       # the server gave an IMDb code
            data = self._get(
                "/find/%s" %
                tmdb_id,
                external_source="imdb_id") or {}
            found = data.get("movie_results" if kind ==
                             "movie" else "tv_results") or []
            if found:
                return str(found[0].get("id", ""))
        title, found_year = clean_title(name)
        year = year or found_year
        if not title:
            return ""
        year_param = "year" if kind == "movie" else "first_air_date_year"
        attempts = [{year_param: year}] if year else []
        attempts.append({})
        for extra in attempts:
            data = self._get(
                "/search/%s" %
                kind,
                query=title,
                include_adult="false",
                **extra) or {}
            results = data.get("results") or []
            if results:
                best = self._best(results, title, kind)
                return str(best.get("id", ""))
        return ""

    @staticmethod
    def _best(results, title, kind):
        key = "title" if kind == "movie" else "name"
        okey = "original_title" if kind == "movie" else "original_name"
        low = title.lower()
        for r in results[:5]:
            if low in (
                (r.get(key) or "").lower(),
                    (r.get(okey) or "").lower()):
                return r
        return results[0]

    # ---------------------------------------------------------------
    def movie(self, movie_id):
        lang = self.language[:2]
        d = self._get(
            "/movie/%s" %
            movie_id,
            append_to_response="credits,release_dates,images,videos",
            include_image_language="%s,en,null" %
            lang,
            include_video_language="%s,en" %
            lang) or {}
        if not d.get("id"):
            return {}
        overview = d.get("overview") or ""
        if not overview and not self.language.startswith("en"):
            overview = (self._get("/movie/%s" %
                                  movie_id, language="en-US") or {}).get("overview", "")
        crew = (d.get("credits") or {}).get("crew") or []
        cast = (d.get("credits") or {}).get("cast") or []
        return {
            "tmdb": str(d["id"]),
            "title": d.get("title") or "",
            "original_title": d.get("original_title") or "",
            "tagline": d.get("tagline") or "",
            "year": (d.get("release_date") or "")[:4],
            "runtime": ("%d min" % d["runtime"]) if d.get("runtime") else "",
            "genres": _names(d.get("genres"), 4),
            "countries": _names(d.get("production_countries"), 3),
            "rating": ("%.1f" % d["vote_average"]) if d.get("vote_average") else "",
            "votes": d.get("vote_count") or 0,
            "overview": overview,
            "director": self._people([c for c in crew if c.get("job") == "Director"], 3)[:80],
            "cast": self._people(cast, 8),
            "poster": image(d.get("poster_path"), "poster"),
            "backdrop": image(d.get("backdrop_path"), "backdrop"),
            "certification": _certification((d.get("release_dates") or {}).get("results"), "release_dates"),
            "logo": _logo(d.get("images"), self.language),
            "trailer": _trailer(d.get("videos"), self.language),
        }

    def tv(self, tv_id):
        lang = self.language[:2]
        d = self._get(
            "/tv/%s" %
            tv_id,
            append_to_response="credits,content_ratings,images,videos",
            include_image_language="%s,en,null" %
            lang,
            include_video_language="%s,en" %
            lang) or {}
        if not d.get("id"):
            return {}
        overview = d.get("overview") or ""
        if not overview and not self.language.startswith("en"):
            overview = (self._get("/tv/%s" %
                                  tv_id, language="en-US") or {}).get("overview", "")
        runtime = d.get("episode_run_time") or []
        return {
            "tmdb": str(
                d["id"]),
            "title": d.get("name") or "",
            "original_title": d.get("original_name") or "",
            "tagline": d.get("tagline") or "",
            "year": (
                d.get("first_air_date") or "")[
                :4],
            "runtime": (
                "%d min" %
                    runtime[0]) if runtime else "",
            "genres": _names(
                d.get("genres"),
                4),
            "countries": ", ".join(
                d.get("origin_country") or []),
            "rating": (
                "%.1f" %
                d["vote_average"]) if d.get("vote_average") else "",
            "votes": d.get("vote_count") or 0,
            "overview": overview,
            "director": self._people(
                d.get("created_by"),
                3),
            "cast": self._people(
                (d.get("credits") or {}).get("cast"),
                8),
            "poster": image(
                d.get("poster_path"),
                "poster"),
            "backdrop": image(
                d.get("backdrop_path"),
                "backdrop"),
            "certification": _certification(
                (d.get("content_ratings") or {}).get("results"),
                "content_ratings"),
            "logo": _logo(
                d.get("images"),
                self.language),
            "trailer": _trailer(
                d.get("videos"),
                self.language),
            "seasons_count": d.get("number_of_seasons") or 0,
            "episodes_count": d.get("number_of_episodes") or 0,
            "status": d.get("status") or "",
        }

    def season(self, tv_id, season_number):
        """{episode_number: {title, overview, still, air_date, rating}, "poster": season poster}"""
        d = self._get("/tv/%s/season/%s" % (tv_id, season_number)) or {}
        out = {"poster": image(d.get("poster_path"), "poster")}
        for e in d.get("episodes") or []:
            out[e.get("episode_number")] = {
                "title": e.get("name") or "",
                "overview": e.get("overview") or "",
                "still": image(e.get("still_path"), "still"),
                "air_date": e.get("air_date") or "",
                "rating": ("%.1f" % e["vote_average"]) if e.get("vote_average") else "",
            }
        return out

    # ---------------------------------------------------------------
    def lookup(self, kind, name, year="", tmdb_id=""):
        """Search + details in one go. kind: 'movie' or 'tv'."""
        found = self.find_id(kind, name, year, tmdb_id)
        if not found:
            return {}
        return self.movie(found) if kind == "movie" else self.tv(found)
