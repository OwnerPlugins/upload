# -*- coding: utf-8 -*-
"""Arabic shaping + simple bidi for Enigma2.

Enigma2 draws glyphs left-to-right with no OpenType shaping and no bidi, so logical
Arabic comes out disconnected and in the wrong order (or as empty boxes when the font
has only the base block). This module turns logical Arabic into the connected
presentation forms (U+FB50..U+FEFF) and reorders right-to-left, so a plain renderer
shows it correctly -- provided a font with the Arabic presentation forms is present
(see fonts.py / Noto Naskh Arabic).

Self-contained and dependency-free on purpose: the forms table is generated from the
Unicode data, not copied from any library or plugin. Latin text is returned untouched,
at near-zero cost, because shape() returns immediately when no Arabic is present.
"""

import sys

PY3 = sys.version_info[0] >= 3
try:
    _unichr = unichr  # noqa: F821  (Python 2)
except NameError:
    _unichr = chr

N = None

# base codepoint -> (isolated, final, initial, medial); None where a form
# does not exist
FORMS = {
    0x0621: (
        0xFE80, N, N, N), 0x0622: (
            0xFE81, 0xFE82, N, N), 0x0623: (
                0xFE83, 0xFE84, N, N), 0x0624: (
                    0xFE85, 0xFE86, N, N), 0x0625: (
                        0xFE87, 0xFE88, N, N), 0x0626: (
                            0xFE89, 0xFE8A, 0xFE8B, 0xFE8C), 0x0627: (
                                0xFE8D, 0xFE8E, N, N), 0x0628: (
                                    0xFE8F, 0xFE90, 0xFE91, 0xFE92), 0x0629: (
                                        0xFE93, 0xFE94, N, N), 0x062A: (
                                            0xFE95, 0xFE96, 0xFE97, 0xFE98), 0x062B: (
                                                0xFE99, 0xFE9A, 0xFE9B, 0xFE9C), 0x062C: (
                                                    0xFE9D, 0xFE9E, 0xFE9F, 0xFEA0), 0x062D: (
                                                        0xFEA1, 0xFEA2, 0xFEA3, 0xFEA4), 0x062E: (
                                                            0xFEA5, 0xFEA6, 0xFEA7, 0xFEA8), 0x062F: (
                                                                0xFEA9, 0xFEAA, N, N), 0x0630: (
                                                                    0xFEAB, 0xFEAC, N, N), 0x0631: (
                                                                        0xFEAD, 0xFEAE, N, N), 0x0632: (
                                                                            0xFEAF, 0xFEB0, N, N), 0x0633: (
                                                                                0xFEB1, 0xFEB2, 0xFEB3, 0xFEB4), 0x0634: (
                                                                                    0xFEB5, 0xFEB6, 0xFEB7, 0xFEB8), 0x0635: (
                                                                                        0xFEB9, 0xFEBA, 0xFEBB, 0xFEBC), 0x0636: (
                                                                                            0xFEBD, 0xFEBE, 0xFEBF, 0xFEC0), 0x0637: (
                                                                                                0xFEC1, 0xFEC2, 0xFEC3, 0xFEC4), 0x0638: (
                                                                                                    0xFEC5, 0xFEC6, 0xFEC7, 0xFEC8), 0x0639: (
                                                                                                        0xFEC9, 0xFECA, 0xFECB, 0xFECC), 0x063A: (
                                                                                                            0xFECD, 0xFECE, 0xFECF, 0xFED0), 0x0641: (
                                                                                                                0xFED1, 0xFED2, 0xFED3, 0xFED4), 0x0642: (
                                                                                                                    0xFED5, 0xFED6, 0xFED7, 0xFED8), 0x0643: (
                                                                                                                        0xFED9, 0xFEDA, 0xFEDB, 0xFEDC), 0x0644: (
                                                                                                                            0xFEDD, 0xFEDE, 0xFEDF, 0xFEE0), 0x0645: (
                                                                                                                                0xFEE1, 0xFEE2, 0xFEE3, 0xFEE4), 0x0646: (
                                                                                                                                    0xFEE5, 0xFEE6, 0xFEE7, 0xFEE8), 0x0647: (
                                                                                                                                        0xFEE9, 0xFEEA, 0xFEEB, 0xFEEC), 0x0648: (
                                                                                                                                            0xFEED, 0xFEEE, N, N), 0x0649: (
                                                                                                                                                0xFEEF, 0xFEF0, 0xFBE8, 0xFBE9), 0x064A: (
                                                                                                                                                    0xFEF1, 0xFEF2, 0xFEF3, 0xFEF4), 0x0671: (
                                                                                                                                                        0xFB50, 0xFB51, N, N), 0x0677: (
                                                                                                                                                            0xFBDD, N, N, N), 0x0679: (
                                                                                                                                                                0xFB66, 0xFB67, 0xFB68, 0xFB69), 0x067A: (
                                                                                                                                                                    0xFB5E, 0xFB5F, 0xFB60, 0xFB61), 0x067B: (
                                                                                                                                                                        0xFB52, 0xFB53, 0xFB54, 0xFB55), 0x067E: (
                                                                                                                                                                            0xFB56, 0xFB57, 0xFB58, 0xFB59), 0x067F: (
                                                                                                                                                                                0xFB62, 0xFB63, 0xFB64, 0xFB65), 0x0680: (
                                                                                                                                                                                    0xFB5A, 0xFB5B, 0xFB5C, 0xFB5D), 0x0683: (
                                                                                                                                                                                        0xFB76, 0xFB77, 0xFB78, 0xFB79), 0x0684: (
                                                                                                                                                                                            0xFB72, 0xFB73, 0xFB74, 0xFB75), 0x0686: (
                                                                                                                                                                                                0xFB7A, 0xFB7B, 0xFB7C, 0xFB7D), 0x0687: (
                                                                                                                                                                                                    0xFB7E, 0xFB7F, 0xFB80, 0xFB81), 0x0688: (
                                                                                                                                                                                                        0xFB88, 0xFB89, N, N), 0x068C: (
                                                                                                                                                                                                            0xFB84, 0xFB85, N, N), 0x068D: (
                                                                                                                                                                                                                0xFB82, 0xFB83, N, N), 0x068E: (
                                                                                                                                                                                                                    0xFB86, 0xFB87, N, N), 0x0691: (
                                                                                                                                                                                                                        0xFB8C, 0xFB8D, N, N), 0x0698: (
                                                                                                                                                                                                                            0xFB8A, 0xFB8B, N, N), 0x06A4: (
                                                                                                                                                                                                                                0xFB6A, 0xFB6B, 0xFB6C, 0xFB6D), 0x06A6: (
                                                                                                                                                                                                                                    0xFB6E, 0xFB6F, 0xFB70, 0xFB71), 0x06A9: (
                                                                                                                                                                                                                                        0xFB8E, 0xFB8F, 0xFB90, 0xFB91), 0x06AD: (
                                                                                                                                                                                                                                            0xFBD3, 0xFBD4, 0xFBD5, 0xFBD6), 0x06AF: (
                                                                                                                                                                                                                                                0xFB92, 0xFB93, 0xFB94, 0xFB95), 0x06B1: (
                                                                                                                                                                                                                                                    0xFB9A, 0xFB9B, 0xFB9C, 0xFB9D), 0x06B3: (
                                                                                                                                                                                                                                                        0xFB96, 0xFB97, 0xFB98, 0xFB99), 0x06BA: (
                                                                                                                                                                                                                                                            0xFB9E, 0xFB9F, N, N), 0x06BB: (
                                                                                                                                                                                                                                                                0xFBA0, 0xFBA1, 0xFBA2, 0xFBA3), 0x06BE: (
                                                                                                                                                                                                                                                                    0xFBAA, 0xFBAB, 0xFBAC, 0xFBAD), 0x06C0: (
                                                                                                                                                                                                                                                                        0xFBA4, 0xFBA5, N, N), 0x06C1: (
                                                                                                                                                                                                                                                                            0xFBA6, 0xFBA7, 0xFBA8, 0xFBA9), 0x06C5: (
                                                                                                                                                                                                                                                                                0xFBE0, 0xFBE1, N, N), 0x06C6: (
                                                                                                                                                                                                                                                                                    0xFBD9, 0xFBDA, N, N), 0x06C7: (
                                                                                                                                                                                                                                                                                        0xFBD7, 0xFBD8, N, N), 0x06C8: (
                                                                                                                                                                                                                                                                                            0xFBDB, 0xFBDC, N, N), 0x06C9: (
                                                                                                                                                                                                                                                                                                0xFBE2, 0xFBE3, N, N), 0x06CB: (
                                                                                                                                                                                                                                                                                                    0xFBDE, 0xFBDF, N, N), 0x06CC: (
                                                                                                                                                                                                                                                                                                        0xFBFC, 0xFBFD, 0xFBFE, 0xFBFF), 0x06D0: (
                                                                                                                                                                                                                                                                                                            0xFBE4, 0xFBE5, 0xFBE6, 0xFBE7), 0x06D2: (
                                                                                                                                                                                                                                                                                                                0xFBAE, 0xFBAF, N, N), 0x06D3: (
                                                                                                                                                                                                                                                                                                                    0xFBB0, 0xFBB1, N, N)}

# alef base after a lam -> (isolated ligature, final ligature)
LAMALEF = {
    0x0622: (
        0xFEF5, 0xFEF6), 0x0623: (
            0xFEF7, 0xFEF8), 0x0625: (
                0xFEF9, 0xFEFA), 0x0627: (
                    0xFEFB, 0xFEFC)}

LAM = 0x0644

# A letter joins to the previous one if it has a final/medial form; it joins to the
# next one if it has an initial/medial form. Derived from the forms table
# above.
_JOIN_PREV = {}
_JOIN_NEXT = {}
for _cp, _f in FORMS.items():
    _JOIN_PREV[_cp] = _f[1] is not None or _f[3] is not None
    _JOIN_NEXT[_cp] = _f[2] is not None or _f[3] is not None


def _is_transparent(cp):
    """Combining marks (harakat, tashkil) do not break the join and keep their place."""
    return (
        0x0610 <= cp <= 0x061A or
        0x064B <= cp <= 0x065F or
        cp == 0x0670 or
        0x06D6 <= cp <= 0x06DC or
        0x06DF <= cp <= 0x06E4 or
        0x06E7 <= cp <= 0x06E8 or
        0x06EA <= cp <= 0x06ED
    )


def _is_arabic(cp):
    return (
        0x0600 <= cp <= 0x06FF or
        0x0750 <= cp <= 0x077F or
        0x08A0 <= cp <= 0x08FF or
        0xFB50 <= cp <= 0xFDFF or
        0xFE70 <= cp <= 0xFEFF
    )


def has_arabic(text):
    for ch in text:
        if _is_arabic(ord(ch)):
            return True
    return False


def _reshape(text):
    chars = list(text)
    cps = [ord(c) for c in chars]
    n = len(chars)
    out = []
    i = 0
    while i < n:
        cp = cps[i]

        if cp not in FORMS:
            out.append(chars[i])
            i += 1
            continue

        # previous visible (non-transparent) codepoint
        p = i - 1
        while p >= 0 and _is_transparent(cps[p]):
            p -= 1
        prev_cp = cps[p] if p >= 0 else None

        # next visible (non-transparent) codepoint
        q = i + 1
        while q < n and _is_transparent(cps[q]):
            q += 1
        next_cp = cps[q] if q < n else None

        joins_prev = (
            prev_cp in FORMS and _JOIN_NEXT.get(prev_cp, False)
            and _JOIN_PREV.get(cp, False)
        )

        # lam + alef ligature
        if cp == LAM and next_cp in LAMALEF:
            iso, fin = LAMALEF[next_cp]
            out.append(_unichr(fin if joins_prev else iso))
            # skip the alef (and any transparent marks already appended? keep
            # marks)
            i = q + 1
            continue

        joins_next = (
            next_cp in FORMS and _JOIN_PREV.get(next_cp, False)
            and _JOIN_NEXT.get(cp, False)
        )

        iso, fin, ini, med = FORMS[cp]
        if joins_prev and joins_next:
            form = med or ini or fin or iso
        elif joins_next:
            form = ini or iso
        elif joins_prev:
            form = fin or iso
        else:
            form = iso
        out.append(_unichr(form if form else cp))
        i += 1

    return u"".join(out)


def _is_ltr(ch):
    cp = ord(ch)
    if cp >= 0x0590:            # anything from Hebrew/Arabic upward: treat as RTL/neutral
        return False
    # ASCII letters, digits and the punctuation that belongs to a latin/number
    # run
    return ch.isalnum() or ch in u" .,:;/\\-_@&'\"()[]{}+%#!?=*"


def _bidi(text):
    """Base direction RTL: reverse everything, then restore the order inside latin runs."""
    rev = text[::-1]
    out = []
    i = 0
    n = len(rev)
    while i < n:
        if _is_ltr(rev[i]):
            j = i
            while j < n and _is_ltr(rev[j]):
                j += 1
            out.append(rev[i:j][::-1])
            i = j
        else:
            out.append(rev[i])
            i += 1
    return u"".join(out)


def shape(text):
    """Return text ready to draw. Non-Arabic text is returned unchanged."""
    if not text:
        return text
    if not isinstance(text, type(u"")):
        try:
            text = text.decode("utf-8")
        except Exception:
            return text
    if not has_arabic(text):
        return text
    return _bidi(_reshape(text))


if __name__ == "__main__":
    samples = [u"سلام", u"العربية",
               u"HADEED حديد 2014", u"English Movies"]
    for s in samples:
        r = shape(s)
        print(repr(s), "->", repr(r), "len", len(r))
