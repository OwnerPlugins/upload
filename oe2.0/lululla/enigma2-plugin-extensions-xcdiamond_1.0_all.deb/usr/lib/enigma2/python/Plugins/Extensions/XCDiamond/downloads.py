# -*- coding: utf-8 -*-
"""Download panel (like XC): movies and episodes are added to a list, the user decides
when to download them: now, at a chosen time, or never.

- One download at a time, in a background thread: it goes on when the plugin is closed.
- Files are written as name.ext.part and renamed at the end; a stopped or broken download
  restarts where it stopped (HTTP Range) when the server allows it.
- The list is saved in /etc/enigma2/xc/downloads.json and survives reboots.
No Enigma2 dependency except the timer started by start_scheduler(): it can be tested on a PC."""

import json
import os
import re
import threading
import time

from . import _
from .net import open_stream

CHUNK = 256 * 1024
SAVE_EVERY = 10            # seconds between saves of the list while downloading

QUEUED, SCHEDULED, RUNNING, PAUSED, DONE, ERROR = "queued", "scheduled", "running", "paused", "done", "error"


def state_text(state):
    return {
        QUEUED: _("In the list"),
        SCHEDULED: _("Scheduled"),
        RUNNING: _("Downloading"),
        PAUSED: _("Stopped"),
        DONE: _("Completed"),
        ERROR: _("Error")}.get(
        state,
        state)


def safe_name(text):
    """File name without characters that FAT/NTFS disks or Enigma2 do not like."""
    text = re.sub(r'[\\/:*?"<>|\x00-\x1f]+', " ", text or u"").strip(" .")
    return re.sub(r"\s+", " ", text)[:120] or u"video"


def default_folder():
    for folder in (
        "/media/hdd/movie",
        "/media/usb/movie",
        "/media/hdd",
            "/media/usb"):
        if os.path.isdir(folder):
            return folder
    return "/media/hdd/movie"


def free_bytes(folder):
    try:
        st = os.statvfs(folder)
        return st.f_bavail * st.f_frsize
    except (OSError, AttributeError):
        return -1


class DownloadManager(object):
    def __init__(
            self,
            list_file,
            folder_getter=default_folder,
            can_start=None):
        self.list_file = list_file
        self.folder_getter = folder_getter
        # callable: False = wait (e.g. the only connection is in use)
        self.can_start = can_start
        self.lock = threading.RLock()
        self.items = self._load()
        self.worker = None
        self.stop_flag = False
        for it in self.items:                       # a download cut by a reboot can be resumed
            if it["state"] == RUNNING:
                it["state"] = PAUSED

    # ---------- list ----------
    def _load(self):
        try:
            with open(self.list_file) as f:
                data = json.load(f)
            return data if isinstance(data, list) else []
        except (IOError, OSError, ValueError):
            return []

    def save(self):
        with self.lock:
            try:
                folder = os.path.dirname(self.list_file)
                if folder and not os.path.isdir(folder):
                    os.makedirs(folder)
                with open(self.list_file + ".tmp", "w") as f:
                    json.dump(self.items, f)
                os.rename(self.list_file + ".tmp", self.list_file)
            except (IOError, OSError) as e:
                print("[XCDiamond] downloads: cannot save the list: %s" % e)

    def find(self, uid):
        for it in self.items:
            if it["uid"] == uid:
                return it
        return None

    def add(self, url, title, ext="mp4", subfolder=u""):
        """Add a movie or episode. Returns (entry, added): added False when it was already there."""
        uid = url.split("?")[0]
        with self.lock:
            old = self.find(uid)
            if old:
                return old, False
            name = safe_name(title)
            entry = {"uid": uid,
                     "url": url,
                     "title": title,
                     "file": name + "." + (ext or "mp4"),
                     "subfolder": safe_name(subfolder) if subfolder else u"",
                     "state": QUEUED,
                     "start_at": 0,
                     "size": 0,
                     "done": 0,
                     "error": u"",
                     "added": int(time.time())}
            self.items.append(entry)
        self.save()
        return entry, True

    def remove(self, uid, delete_file=False):
        with self.lock:
            it = self.find(uid)
            if not it:
                return
            if it["state"] == RUNNING:
                self.stop()
            path = self.path(it)
            for p in ((path + ".part",) + ((path,) if delete_file else ())):
                if os.path.exists(p):
                    try:
                        os.remove(p)
                    except OSError:
                        pass
            self.items.remove(it)
        self.save()

    def clear_done(self):
        with self.lock:
            self.items = [it for it in self.items if it["state"] != DONE]
        self.save()

    def path(self, it):
        folder = self.folder_getter()
        if it.get("subfolder"):
            folder = os.path.join(folder, it["subfolder"])
        return os.path.join(folder, it["file"])

    def schedule(self, uid, start_at):
        with self.lock:
            it = self.find(uid)
            if it and it["state"] != RUNNING:
                it["state"], it["start_at"], it["error"] = SCHEDULED, int(
                    start_at), u""
        self.save()

    def queue(self, uid):
        """Start as soon as possible (after the one running now)."""
        with self.lock:
            it = self.find(uid)
            if it and it["state"] not in (RUNNING, DONE):
                it["state"], it["start_at"], it["error"] = SCHEDULED, 0, u""
        self.save()
        self.tick()

    def pause(self, uid):
        with self.lock:
            it = self.find(uid)
            if not it:
                return
            if it["state"] == RUNNING:
                self.stop()
            elif it["state"] == SCHEDULED:
                it["state"] = PAUSED if it["done"] else QUEUED
        self.save()

    def running(self):
        for it in self.items:
            if it["state"] == RUNNING:
                return it
        return None

    # ---------- worker ----------
    def tick(self, now=None):
        """Called every minute (and after changes): starts the next due download."""
        now = now or time.time()
        with self.lock:
            if self.worker is not None and self.worker.is_alive():
                return None
            due = [it for it in self.items if it["state"]
                   == SCHEDULED and it["start_at"] <= now]
            if not due:
                return None
            if self.can_start is not None and not self.can_start():
                return None                          # stays scheduled: tried again at the next tick
            nxt = sorted(due, key=lambda it: (it["start_at"], it["added"]))[0]
            nxt["state"], nxt["error"] = RUNNING, u""
            self.stop_flag = False
            self.worker = threading.Thread(target=self._run, args=(nxt,))
            self.worker.daemon = True
            self.worker.start()
            return nxt

    def stop(self):
        self.stop_flag = True

    def _run(self, it):
        try:
            self._download(it)
        except Exception as e:
            with self.lock:
                it["state"], it["error"] = ERROR, (u"%s" % e)[:120]
            print("[XCDiamond] download failed %s: %s" % (it["title"], e))
        self.save()
        with self.lock:
            self.worker = None
        self.tick()                                  # the next one in the list, if due

    def _download(self, it):
        path = self.path(it)
        folder = os.path.dirname(path)
        if not os.path.isdir(folder):
            os.makedirs(folder)
        part = path + ".part"
        have = os.path.getsize(part) if os.path.exists(part) else 0
        headers = {"Range": "bytes=%d-" % have} if have else None
        resp = open_stream(it["url"], timeout=30, headers=headers)
        try:
            code = getattr(resp, "status", None) or resp.getcode()
            length = int(resp.headers.get("Content-Length") or 0)
            if have and code != 206:                 # the server ignores Range: start again
                have = 0
            total = have + length if length else 0
            room = free_bytes(folder)
            if length and room >= 0 and room < length + 50 * 1024 * 1024:
                raise IOError(_("not enough free space (%d MB free)") %
                              (room // (1024 * 1024)))
            with self.lock:
                it["size"], it["done"] = total, have
            last_save = time.time()
            with open(part, "ab" if have else "wb") as f:
                while True:
                    if self.stop_flag:
                        with self.lock:
                            it["state"] = PAUSED
                        return
                    data = resp.read(CHUNK)
                    if not data:
                        break
                    f.write(data)
                    with self.lock:
                        it["done"] += len(data)
                    if time.time() - last_save > SAVE_EVERY:
                        self.save()
                        last_save = time.time()
        finally:
            resp.close()
        if total and it["done"] < total:
            raise IOError(
                _("download interrupted at %d%%") %
                (100 * it["done"] // total))
        os.rename(part, path)
        with self.lock:
            it["state"], it["size"] = DONE, it["done"]
        print("[XCDiamond] download completed: %s" % path)


def progress_text(it):
    mb = 1024 * 1024
    if it["size"]:
        return u"%d%%  (%d / %d MB)" % (100 * \
                        it["done"] // it["size"], it["done"] // mb, it["size"] // mb)
    if it["done"]:
        return u"%d MB" % (it["done"] // mb)
    return u""
