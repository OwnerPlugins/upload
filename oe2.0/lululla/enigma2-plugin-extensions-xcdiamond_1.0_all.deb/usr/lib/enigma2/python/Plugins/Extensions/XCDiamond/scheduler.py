# -*- coding: utf-8 -*-
"""When the automatic bouquet export runs.

Two modes, like XC: every day at a fixed time, or every N hours.
- A run missed while the receiver was off is done at the next start (catch-up).
- After a failed run the next try is 30 minutes later, not every minute.
No Enigma2 dependency: it can be tested on a PC."""

import time

DAY = 24 * 3600
RETRY_SECS = 30 * 60


def _today_at(hour, minute, now):
    lt = time.localtime(now)
    return int(
        time.mktime(
            (lt.tm_year, lt.tm_mon, lt.tm_mday, hour, minute, 0, 0, 0, -1)))


def _add_days(ts, days, hour, minute):
    """Same clock time a number of days later (correct across daylight saving changes)."""
    lt = time.localtime(ts)
    return int(
        time.mktime(
            (lt.tm_year, lt.tm_mon, lt.tm_mday + days, hour, minute, 0, 0, 0, -1)))


def next_run(mode, clock, interval_hours, last_run, now=None, started=None):
    """Epoch of the next automatic export, or None when it is off.

    mode: "off" | "time" | "interval";  clock: (hour, minute);  interval_hours: int
    last_run: epoch of the last export (0 = never);  started: when the receiver started.
    A value in the past means "due now"."""
    now = now or time.time()
    if mode == "time":
        hour, minute = clock
        candidate = _today_at(hour, minute, now)
        if last_run >= candidate or (not last_run and candidate <= now):
            # done today (or never run yet): tomorrow
            candidate = _add_days(candidate, 1, hour, minute)
        elif last_run and candidate - DAY > last_run and now < candidate:
            # yesterday's run was missed: catch up
            candidate = _add_days(candidate, -1, hour, minute)
        return candidate
    if mode == "interval":
        base = last_run or started or now
        return int(base + max(1, int(interval_hours)) * 3600)
    return None


def is_due(next_time, now=None, failed_at=0):
    now = now or time.time()
    if next_time is None or now < next_time:
        return False
    return not failed_at or now - failed_at >= RETRY_SECS
