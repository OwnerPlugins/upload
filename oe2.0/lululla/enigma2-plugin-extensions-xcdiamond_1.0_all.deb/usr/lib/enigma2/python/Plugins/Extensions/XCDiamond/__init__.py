# -*- coding: utf-8 -*-
"""XC Diamond: plugin metadata and gettext setup.

The single source of the version is __version__ here: core.py, the Info screen, the updater
and tools/make_release.py all read it from this file (same workflow as the other repos).

Source strings are English. Translations live in locale/<lang>/LC_MESSAGES/XCDiamond.mo
(template: locale/XCDiamond.pot). Strings not found in the plugin domain fall back to the
Enigma2 domain, so common words ("Yes", "No", "Cancel") use the image translation.
"""

import gettext
import os

__author__ = "Lululla"
__email__ = "ekekaz@gmail.com"
__copyright__ = "Copyright (c) 2026 Lululla"
__license__ = "GPL-v2"
__version__ = "1.0"

PLUGIN_NAME = "XC Diamond"
PLUGIN_DOMAIN = "XCDiamond"
LOCALE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "locale")


def locale_init():
    gettext.bindtextdomain(PLUGIN_DOMAIN, LOCALE_DIR)


def _(text):
    if not text:
        return text
    translated = gettext.dgettext(PLUGIN_DOMAIN, text)
    if translated == text:
        translated = gettext.gettext(text)
    return translated


def ngettext(singular, plural, n):
    translated = gettext.dngettext(PLUGIN_DOMAIN, singular, plural, n)
    if translated in (singular, plural):
        translated = gettext.ngettext(singular, plural, n)
    return translated


locale_init()
try:
    from Components.Language import language
    language.addCallback(locale_init)
except Exception:          # outside Enigma2 (tests)
    pass
