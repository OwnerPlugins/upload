# -*- coding: utf-8 -*-
"""Player: live (zapping with CH+/CH-), movies and episodes (resume, skips, next episode)."""

import time

from enigma import eServiceReference, iPlayableService
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.InfoBarGenerics import InfoBarSeek, InfoBarAudioSelection, InfoBarSubtitleSupport
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.ProgressBar import ProgressBar
from Components.ServiceEventTracker import ServiceEventTracker, InfoBarBase

from . import _, core
from .api import LIVE
from .net import run_async
from .epg import progress
from .ui import T, ImageLoader, meta_line, scale_skin, new_timer, veil_path, PANEL, TEXT, DIM, GOLD, ACCENT

INFO_WIDGETS = (
    "info_bg",
    "info_backdrop",
    "info_veil",
    "info_poster",
    "info_title",
    "info_meta",
    "info_text")


def _hm(ts):
    return time.strftime("%H:%M", time.localtime(ts))


def _fmt(secs):
    secs = max(0, int(secs))
    h, m, s = secs // 3600, (secs % 3600) // 60, secs % 60
    return ("%d:%02d:%02d" % (h, m, s)) if h else ("%d:%02d" % (m, s))


class XCDPlayer(
        Screen,
        InfoBarBase,
        InfoBarSeek,
        InfoBarAudioSelection,
        InfoBarSubtitleSupport):
    skin = scale_skin("""
    <screen name="XCDPlayer" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#ff000000">
        <widget name="info_bg" position="60,80" size="1800,750" backgroundColor="%(panel)s" zPosition="-3" />
        <widget name="info_backdrop" position="60,80" size="1800,750" zPosition="-2" />
        <widget name="info_veil" pixmap="%(veil)s" position="60,80" size="1800,750" alphatest="blend" zPosition="-1" />
        <widget name="info_poster" position="100,120" size="300,450" alphatest="blend" zPosition="2" />
        <widget name="info_title" position="440,110" size="1380,60" font="Regular;44" foregroundColor="%(text)s" backgroundColor="%(panel)s" transparent="1" />
        <widget name="info_meta" position="440,175" size="1380,40" font="Regular;28" foregroundColor="%(gold)s" backgroundColor="%(panel)s" transparent="1" />
        <widget name="info_text" position="440,235" size="1380,570" font="Regular;28" foregroundColor="%(text)s" backgroundColor="%(panel)s" transparent="1" />
        <eLabel position="0,860" size="1920,220" backgroundColor="%(panel)s" zPosition="-1" />
        <eLabel position="0,860" size="1920,4" backgroundColor="%(accent)s" />
        <widget name="thumb" position="60,878" size="170,184" alphatest="blend" zPosition="2" />
        <widget name="title" position="260,880" size="1300,56" font="Regular;40" foregroundColor="%(text)s" backgroundColor="%(panel)s" transparent="1" />
        <widget name="subtitle" position="260,938" size="1300,40" font="Regular;28" foregroundColor="%(gold)s" backgroundColor="%(panel)s" transparent="1" />
        <widget name="progress" position="260,990" size="1300,10" foregroundColor="%(accent)s" backgroundColor="#00303a4a" />
        <widget name="line3" position="260,1014" size="1600,40" font="Regular;24" foregroundColor="%(dim)s" backgroundColor="%(panel)s" transparent="1" />
        <widget name="time" position="1580,975" size="280,40" font="Regular;28" halign="right" foregroundColor="%(dim)s" backgroundColor="%(panel)s" transparent="1" />
        <widget source="global.CurrentTime" render="Label" position="1660,880" size="200,56" font="Regular;40" halign="right" foregroundColor="%(text)s" backgroundColor="%(panel)s" transparent="1">
            <convert type="ClockToText">Format:%%H:%%M</convert>
        </widget>
    </screen>""" % dict(panel=PANEL, accent=ACCENT, text=TEXT, gold=GOLD, dim=DIM, veil=veil_path("veil_info")))

    def __init__(self, session, playlist, index=0, on_close_index=None):
        Screen.__init__(self, session)
        # timers and bar state BEFORE InfoBarSeek: its __init__ already calls
        # lockShow/unlockShow
        self._show_locks = 0
        self.shown_bar = True
        self.hide_timer = new_timer(self.hide_bar)
        InfoBarBase.__init__(self, steal_current_service=True)
        InfoBarSeek.__init__(self, actionmap="InfobarSeekActions")
        InfoBarAudioSelection.__init__(self)
        InfoBarSubtitleSupport.__init__(self)
        keymap_ok = core.load_keymap()

        self.alive = True
        self.playlist = playlist
        self.index = index
        self.on_close_index = on_close_index
        try:
            self.prev_service = session.nav.getCurrentlyPlayingServiceOrGroup()
        except AttributeError:
            self.prev_service = session.nav.getCurrentlyPlayingServiceReference()

        self["title"] = Label("")
        self["subtitle"] = Label("")
        self["time"] = Label("")
        self["line3"] = Label("")
        self["progress"] = ProgressBar()
        self["thumb"] = Pixmap()
        self["info_bg"] = Label("")
        self["info_poster"] = Pixmap()
        self["info_backdrop"] = Pixmap()
        self["info_veil"] = Pixmap()
        self["info_title"] = Label("")
        self["info_meta"] = Label("")
        self["info_text"] = Label("")
        self.thumb = ImageLoader(self, "thumb", fallback="poster")
        self.info_poster = ImageLoader(self, "info_poster", fallback="poster")
        self.info_backdrop = ImageLoader(self, "info_backdrop")
        self.info_open = False
        self.epg_now = self.epg_next = None

        self["actions"] = ActionMap(["XCDPlayerActions", "OkCancelActions"], {
            "ok": self.toggle_bar,
            "help": self.open_help,
            # EXIT/STOP from the plugin keymap (not "cancel" too: it would fire
            # twice)
            "leave": self.leave,
            "info": self.toggle_info,
            "nextChannel": lambda: self.step(1),
            "prevChannel": lambda: self.step(-1),
            "back1": lambda: self.skip(-60), "fwd1": lambda: self.skip(60),
            "back5": lambda: self.skip(-300), "fwd5": lambda: self.skip(300),
            "back10": lambda: self.skip(-600), "fwd10": lambda: self.skip(600),
        }, -2)
        if not keymap_ok:   # without the plugin keymap EXIT must still work
            self["exit_fallback"] = ActionMap(
                ["OkCancelActions"], {
                    "cancel": self.leave}, -2)

        self._events = ServiceEventTracker(screen=self, eventmap={
            iPlayableService.evEOF: self._on_eof,
            iPlayableService.evStart: self._on_start,
        })
        self.tick_timer = new_timer(self._tick)
        self.seek_timer = new_timer(self._do_resume_seek)
        self.retry_timer = new_timer(self._reconnect)
        # times of the last automatic reconnections (live)
        self.retries = []
        self.paused_download = None        # download paused to free the connection
        self._resume_to = 0
        # Careful: onLayoutFinish takes screen methods only. OpenATV runs everything that is not
        # a method (lambdas too) with exec() -> "exec() arg 1 must be a
        # string".
        self.onLayoutFinish.append(self._layout_done)
        self.onFirstExecBegin.append(self.start)
        self.onClose.append(self._closed)

    # ------------------------------------------------------------------
    @property
    def item(self):
        return self.playlist[self.index]

    def _free_connection(self):
        """A download running on an account with a single connection would make the server cut
        one of the two streams (and repeated double connections can get the account blocked):
        pause it while watching, restart it when the player closes."""
        it = self.item
        if self.paused_download is None and it.get(
                "kind") not in ("trailer", "download"):
            self.paused_download = core.pause_download_for_playback()
            if self.paused_download:
                self.session.open(
                    MessageBox, T(
                        _(
                            "The download in progress is paused: your account allows only one "
                            "connection. It restarts when you close the player.")), MessageBox.TYPE_INFO, timeout=5)

    def start(self):
        self._free_connection()
        it = self.item
        saved = core.resume.get(it) if (
            core.cfg.resume.value and core.resume.supported(it)) else 0
        if saved:
            def answer(yes):
                self._resume_to = saved if yes else 0
                self.play()
            self.session.openWithCallback(
                answer, MessageBox, T(
                    _("Resume from %s?") %
                    _fmt(saved)), MessageBox.TYPE_YESNO, timeout=10, default=True)
        else:
            self._resume_to = 0
            self.play()

    def play(self):
        it = self.item
        url = it.get("direct_url") or core.client().stream_url(
            it, core.cfg.live_format.value)   # trailer: direct link
        ref = eServiceReference(int(core.cfg.player.value), 0, url)
        ref.setName(T(it.get("name", "")))
        self.session.nav.playService(ref)
        self["title"].setText(T(it.get("name", "")))
        self["progress"].setValue(0)
        self.epg_now = self.epg_next = None
        if it.get("kind") == LIVE:
            self.thumb.load(it.get("icon"))
            self["subtitle"].setText("")
            self["line3"].setText(
                T(_(u"INFO: guide   CH+/CH- or \u25b2\u25bc: channel   EXIT: exit")))
            self._load_epg(it)
        else:
            info = it.get("info") or {}
            self.thumb.load(it.get("image") or info.get(
                "poster") or it.get("poster") or it.get("icon"))
            self["subtitle"].setText(
                T(it.get("subtitle", "") or meta_line(info)))
            self["line3"].setText(
                T(_(u"INFO: details   1/3: \u00b11 min   4/6: \u00b15 min   7/9: \u00b110 min   EXIT: exit")))
        if self.info_open:
            self._fill_info()
        self.show_bar()
        self.tick_timer.start(1000, False)

    def _load_epg(self, it):
        """Programme on air and next: from the full guide when present, otherwise asked to the server."""
        cur, nxt = core.epg().now_next(it.get("epg_id"))
        if cur or nxt:
            return self._set_epg(cur, nxt)
        index = self.index

        def done(epg):
            if not self.alive or index != self.index or not epg:
                return
            now = int(time.time())
            current = [e for e in epg if e["start"] <= now < e["stop"]]
            following = [e for e in epg if e["start"] >= now]
            self._set_epg(
                current[0] if current else None,
                following[0] if following else None)
        run_async(
            core.client().short_epg,
            (it["id"],
             3),
            callback=done,
            errback=lambda e: None)

    def _set_epg(self, cur, nxt):
        self.epg_now, self.epg_next = cur, nxt
        if cur:
            self["subtitle"].setText(
                T(u"%s - %s   %s" % (_hm(cur["start"]), _hm(cur["stop"]), cur["title"])))
        if nxt:
            self["line3"].setText(T(_("Next") +
                                    u"  %s   %s" %
                                    (_hm(nxt["start"]), nxt["title"])))
        self._tick()
        if self.info_open:
            self._fill_info()

    # ------------------------------------------------------------------
    def _service_seek(self):
        service = self.session.nav.getCurrentService()
        return service and service.seek()

    def _position(self):
        seek = self._service_seek()
        if not seek:
            return 0, 0
        pos = seek.getPlayPosition()
        length = seek.getLength()
        p = pos[1] / 90000 if pos and not pos[0] else 0
        ln = length[1] / 90000 if length and not length[0] else 0
        return p, ln

    def _tick(self):
        if self.item.get("kind") == LIVE:
            cur = self.epg_now
            if cur and time.time(
            ) >= cur["stop"] and self.epg_next:   # programme over: move to the next
                return self._load_epg(self.item)
            if cur:
                self["progress"].setValue(progress(cur))
                left = int(max(0, cur["stop"] - time.time()) // 60)
                self["time"].setText(T(_("%d min left") % left))
            else:
                self["time"].setText("")
            return
        p, ln = self._position()
        self["progress"].setValue(int(100 * p / ln) if ln else 0)
        self["time"].setText(("%s / %s" %
                              (_fmt(p), _fmt(ln))) if ln else _fmt(p))

    def skip(self, secs):
        seek = self._service_seek()
        if seek and seek.isCurrentlySeekable():
            seek.seekRelative(1 if secs > 0 else -1, abs(secs) * 90000)
            self.show_bar()

    def _on_start(self):
        if self._resume_to:
            self.seek_timer.start(1500, True)

    def _do_resume_seek(self):
        seek = self._service_seek()
        if seek and seek.isCurrentlySeekable():
            seek.seekTo(self._resume_to * 90000)
        self._resume_to = 0

    def _save_position(self):
        if not core.resume.supported(self.item) or not core.cfg.resume.value:
            return
        p, ln = self._position()
        core.resume.set(self.item, p, ln)

    # ------------------------------------------------------------------
    def step(self, delta):
        """Live: change channel. Episodes: go to the previous/next one."""
        if len(self.playlist) < 2:
            return
        self._save_position()
        self.index = (self.index + delta) % len(self.playlist)
        self._resume_to = 0
        self.play()

    def _on_eof(self):
        if self.item.get("kind") == LIVE:
            # live streams sometimes drop (server or network): reconnect by
            # itself, but not in a loop
            now = time.time()
            self.retries = [t for t in self.retries if now - t < 120]
            if len(self.retries) < 5:
                self.retries.append(now)
                self["line3"].setText(T(_("Signal lost: reconnecting...")))
                self.show_bar()
                self.retry_timer.start(2000, True)
            else:
                self["line3"].setText(
                    T(_("The channel keeps stopping: try another channel or the m3u8 format in Settings.")))
            return
        core.resume.clear(self.item)
        if core.cfg.autonext.value and self.index + 1 < len(self.playlist):
            self.index += 1
            self.start()
        else:
            self._set_info_visible(False)
            self.leave(save=False)

    # ------------------------------------------------------------------
    def show_bar(self):
        self.show()
        self.shown_bar = True
        if not self._show_locks:
            self.hide_timer.start(5000, True)

    # Requests from InfoBarSeek (pause/fast forward keep the bar visible)
    def lockShow(self):
        self._show_locks += 1
        self.hide_timer.stop()
        self.show()
        self.shown_bar = True

    def unlockShow(self):
        self._show_locks = max(0, self._show_locks - 1)
        if not self._show_locks and self.shown_bar:
            self.hide_timer.start(5000, True)

    def doShow(self):
        self.show_bar()

    def doTimerHide(self):
        self.hide_bar()

    def hide_bar(self):
        if self.info_open:
            return
        self.hide()
        self.shown_bar = False

    def toggle_bar(self):
        if self.shown_bar:
            self.hide_bar()
        else:
            self.show_bar()

    def _layout_done(self):
        self._set_info_visible(False)

    # ------------------------------------------------------------------
    # INFO panel
    # ------------------------------------------------------------------
    def _set_info_visible(self, visible):
        self.info_open = visible
        for name in INFO_WIDGETS:
            if visible:
                self[name].show()
            else:
                self[name].hide()
        if not visible:
            self.info_poster.clear()
            self.info_backdrop.clear()

    def toggle_info(self):
        if self.info_open:
            self._set_info_visible(False)
            self.show_bar()
            return
        self._set_info_visible(True)
        self._fill_info()
        self.show()
        self.shown_bar = True
        self.hide_timer.stop()             # stays open until closed

    def _fill_info(self):
        it = self.item
        backdrop = u""
        if it.get("kind") == LIVE:
            title, poster = it.get("name", ""), it.get("icon")
            cur, nxt = self.epg_now, self.epg_next
            meta, lines = u"", []
            if cur:
                meta = u"%s - %s   \u2022   " % (_hm(cur["start"]), _hm(cur["stop"])) + \
                    _("%d min left") % (max(0, cur["stop"] - time.time()) // 60)
                lines += [_("On air:") + u"  " + cur["title"],
                          cur.get("desc") or u""]
            if nxt:
                lines += [u"", _("Next") + u"  %s:  %s" %
                          (_hm(nxt["start"]), nxt["title"]), nxt.get("desc") or u""]
            text = u"\n".join(line for line in lines if line is not None) or _(
                "No guide for this channel.")
        else:
            info = it.get("info") or {}
            title = info.get("title") or it.get("name", "")
            poster = info.get("poster") or it.get(
                "poster") or it.get("image") or it.get("icon")
            backdrop = info.get("backdrop") or u""
            meta = it.get("subtitle", "") if not info else meta_line(info)
            if it.get("subtitle") and info:
                meta = it["subtitle"]
            lines = []
            if info.get("director"):
                label = _("Created by:") if "season" in it else _(
                    "Director:")    # series have creators
                lines.append(label + u"  " + info["director"])
            if info.get("cast"):
                lines.append(_("Cast:") + u"  " + info["cast"])
            if lines:
                lines.append(u"")
            plot = it.get("plot") or info.get(
                "overview") or _("Plot not available.")
            lines.append(plot[:900])
            text = u"\n".join(lines)
        self["info_title"].setText(T(title))
        self["info_meta"].setText(T(meta))
        self["info_text"].setText(T(text))
        self.info_poster.load(poster)
        # TMDB backdrop behind the panel (not for live channels)
        self.info_backdrop.load(backdrop)

    def leave(self, save=True):
        if self.info_open:                 # EXIT closes the INFO panel first
            self._set_info_visible(False)
            self.show_bar()
            return
        if save:
            self._save_position()
        self.close()

    def open_help(self):
        from .help import open_help
        open_help(self.session, "player")

    def _reconnect(self):
        if self.alive and self.item.get("kind") == LIVE:
            print(
                "[XCDiamond] live stream stopped: reconnecting %s" %
                self.item.get("name"))
            self.session.nav.stopService()
            self.play()

    def _closed(self):
        self.alive = False
        for t in (
                self.hide_timer,
                self.tick_timer,
                self.seek_timer,
                self.retry_timer):
            t.stop()
        if self.paused_download:
            core.resume_download(self.paused_download)
        self.session.nav.stopService()
        if self.prev_service:
            self.session.nav.playService(self.prev_service)
        if self.on_close_index:
            self.on_close_index(self.index)
