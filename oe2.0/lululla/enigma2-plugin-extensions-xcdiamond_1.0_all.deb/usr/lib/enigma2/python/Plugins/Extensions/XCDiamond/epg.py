# -*- coding: utf-8 -*-
"""Full guide (xmltv.php) downloaded in the background once a day.

- Parsed straight from the network in chunks (iterparse): no huge file in /tmp,
  constant memory even with guides of hundreds of MB.
- Only the next 24 hours are kept, with shortened descriptions, in one json per server.
- Screens ask now_next(channel_id): immediate answer from memory.
No Enigma2 dependency except the data path: it can be tested on a PC."""

import calendar
import hashlib
import json
import os
import re
import time

try:
    from xml.etree.cElementTree import iterparse
except ImportError:
    from xml.etree.ElementTree import iterparse

from . import _
from .net import open_stream, ensure_dir, CACHE_DIR, urlencode

KEEP_SECS = 24 * 3600
# keep the last hours too: needed when the time is corrected with 7/8/9
PAST_SECS = 4 * 3600
DESC_MAX = 300
_TZ = re.compile(r"^(\d{14})\s*([+-]\d{4})?")


def epg_dir():
    """Receiver disk when present (survives reboots), otherwise /tmp."""
    for base in ("/media/hdd", "/media/usb", "/media/mmc"):
        if os.path.isdir(base) and os.access(base, os.W_OK):
            return ensure_dir(os.path.join(base, "xcdiamond", "epg"))
    return ensure_dir(os.path.join(CACHE_DIR, "epg"))


def parse_xmltv_time(text, server_delta=0):
    """'20261127140500 +0100' -> epoch. Without a zone: server wall-clock time."""
    m = _TZ.match((text or "").strip())
    if not m:
        return 0
    try:
        st = time.strptime(m.group(1), "%Y%m%d%H%M%S")
    except ValueError:
        return 0
    tz = m.group(2)
    if tz:
        sign = -1 if tz[0] == "-" else 1
        offset = sign * (int(tz[1:3]) * 3600 + int(tz[3:5]) * 60)
        return int(calendar.timegm(st) - offset)
    return int(time.mktime(st) - server_delta)


def parse_stream(stream, now=None, server_delta=0):
    """Read an xmltv from a file or the network. Returns {channel: [[start, stop, title, desc], ...]}."""
    now = now or time.time()
    limit = now + KEEP_SECS
    guide = {}
    for _event, elem in iterparse(stream):
        tag = elem.tag
        if tag == "programme":
            channel = (elem.get("channel") or "").strip().lower()
            start = parse_xmltv_time(elem.get("start"), server_delta)
            stop = parse_xmltv_time(elem.get("stop"), server_delta)
            if channel and start and stop > now - \
                    PAST_SECS and start < limit and stop > start:
                title = (elem.findtext("title") or "").strip()
                desc = (elem.findtext("desc") or "").strip()[:DESC_MAX]
                guide.setdefault(channel, []).append(
                    [start, stop, title, desc])
            elem.clear()
        elif tag == "channel":
            elem.clear()
    for events in guide.values():
        events.sort(key=lambda e: e[0])
    return guide


class EpgStore(object):
    """Guide of one server: in memory for the screens, on disk between restarts."""

    def __init__(self, client):
        self.client = client
        key = u"%s|%s" % (client.server, client.username)
        self.path = os.path.join(epg_dir(), hashlib.md5(
            key.encode("utf-8")).hexdigest() + ".json")
        self.guide = {}
        self.built = 0           # when it was downloaded
        self.state = "none"      # none | loading | ready | missing | error
        self.message = u""

    # --------------------------------------------------------------- (thread)
    def load_file(self):
        """Read the saved json. Returns (built, guide) or (0, {})."""
        try:
            with open(self.path) as f:
                data = json.load(f)
            return int(data.get("built", 0)), data.get("guide") or {}
        except (IOError, OSError, ValueError):
            return 0, {}

    def download(self):
        """Download and parse the server xmltv.php. Returns (built, guide)."""
        if self.client.server_delta is None:
            try:
                self.client.account()
            except Exception:
                pass
        url = "%s/xmltv.php?%s" % (self.client.server,
                                   urlencode({"username": self.client.username,
                                              "password": self.client.password}))
        stream = open_stream(url, timeout=60)
        try:
            guide = parse_stream(
                stream, server_delta=self.client.server_delta or 0)
        finally:
            stream.close()
        built = int(time.time())
        if guide:
            tmp = self.path + ".tmp"
            with open(tmp, "w") as f:
                json.dump({"built": built, "guide": guide}, f)
            os.rename(tmp, self.path)
        return built, guide

    # --------------------------------------------------------------- (GUI)
    def set(self, built, guide):
        self.built, self.guide = built, guide or {}
        self.state = "ready" if self.guide else "missing"

    def fresh(self, max_age):
        return self.built and time.time() - self.built < max_age

    def now_next(self, channel_id, now=None):
        """(programme on air, next one) for a channel; each programme is a dict or None.
        The manual time correction (EPG setting) is applied here."""
        events = self.guide.get((channel_id or "").strip().lower())
        if not events:
            return None, None
        shift = getattr(self.client, "epg_shift", 0)
        now = (now or time.time()) - shift
        current = following = None
        for start, stop, title, desc in events:
            if start <= now < stop:
                current = _event(start, stop, title, desc, shift)
            elif start >= now:
                following = _event(start, stop, title, desc, shift)
                break
        return current, following

    def status_text(self):
        if self.state == "loading":
            return _("downloading...")
        if self.state == "ready":
            return _("%d channels, downloaded %s") % (len(self.guide),
                                                      time.strftime("%d/%m %H:%M", time.localtime(self.built)))
        if self.state == "missing":
            return _("the server has no full guide (using the per-channel one)")
        if self.state == "error":
            return _("error: %s") % self.message
        return _("not downloaded yet")


def _event(start, stop, title, desc, shift=0):
    return {
        "start": start +
        shift,
        "stop": stop +
        shift,
        "title": title,
        "desc": desc}


def progress(event, now=None):
    """Elapsed percentage of the programme (0-100)."""
    if not event:
        return 0
    now = now or time.time()
    total = max(1, event["stop"] - event["start"])
    return max(0, min(100, int(100 * (now - event["start"]) / total)))
