# -*- coding: utf-8 -*-
"""Xtream Codes client (player_api.php, JSON).
Returns normalized dictionaries, so the screens never deal with the quirks of the
various panels (missing fields, lists instead of dictionaries, base64...)."""

import base64
import re
import threading
import time

from . import _
from .net import get_json, urlencode

# ---------------------------------------------------------------
# Gentle with the servers: panels ban accounts that make too many requests.
# - one request at a time per server, with a short pause between two requests;
# - when the server answers "too many requests" (429, 509, ...) nothing is asked
#   for a while (cooldown), instead of insisting;
# - answers are cached (lists 5-10 min, details longer).
# ---------------------------------------------------------------
MIN_GAP = 0.35            # seconds between two requests to the same server
COOLDOWN = 120            # seconds of silence after a "too many requests" answer
LIMIT_CODES = (429, 509, 503, 458)
_hosts = {}
_hosts_lock = threading.Lock()


def _host_state(server):
    host = server.split("://")[-1].split("/")[0].lower()
    with _hosts_lock:
        if host not in _hosts:
            _hosts[host] = {
                "lock": threading.Lock(),
                "last": 0.0,
                "cooldown": 0.0}
        return _hosts[host]


def cooldown_left(server):
    """Seconds the server still has to rest (0 = it can be asked)."""
    return max(0, int(_host_state(server)["cooldown"] - time.time()))


def _http_code(error):
    return getattr(error, "code", None)


LIVE, VOD, SERIES = "live", "vod", "series"


class XtreamError(Exception):
    pass


class AuthError(XtreamError):
    """Login refused. state: "auth" (wrong user/password) or banned/disabled/expired when the panel says so."""

    def __init__(self, message, state="auth"):
        XtreamError.__init__(self, message)
        self.state = state


class LimitError(XtreamError):
    """The server answered "too many requests": it is resting (see cooldown_left)."""
    pass


def state_label(state):
    return {
        "active": _("Active"),
        "banned": _("Banned"),
        "disabled": _("Disabled"),
        "expired": _("Expired"),
        "auth": _("Wrong credentials"),
        "unknown": _("Unknown")}.get(
        state,
        state)


def account_state(user, server):
    """active | banned | disabled | expired | unknown, from the panel user_info."""
    status = _s(user.get("status")).lower()
    if status in ("banned", "ban"):
        return "banned"
    if status in ("disabled", "inactive"):
        return "disabled"
    exp = _s(user.get("exp_date"))
    if status == "expired" or (
            exp.isdigit() and int(exp) and int(exp) < time.time()):
        return "expired"
    if status == "active":
        return "active"
    return "unknown"


def _s(value, default=""):
    """Clean string from any JSON value."""
    if value is None:
        return default
    if isinstance(value, (list, tuple)):
        value = value[0] if value else default
    try:
        text = u"%s" % value
    except Exception:
        return default
    return text.strip()


def _b64(text):
    if not text:
        return ""
    try:
        return base64.b64decode(text).decode("utf-8", "replace").strip()
    except Exception:
        return _s(text)


def _year(*values):
    for v in values:
        m = re.search(r"(18|19|20)\d{2}", _s(v))
        if m:
            return m.group(0)
    return ""


def _flag(value):
    """Panels send 1, "1", true, "true" or 1.0 for yes."""
    return _s(value).lower() in ("1", "true", "yes", "1.0")


def _int(value, default=0):
    try:
        return int(float(_s(value) or default))
    except ValueError:
        return default


def _rating(value):
    try:
        r = float(_s(value).replace(",", "."))
        return ("%.1f" % r) if r > 0 else ""
    except ValueError:
        return ""


def _wall_to_epoch(text, delta):
    """'2026-11-27 14:05:00' (server wall-clock time) -> real epoch, or 0."""
    if not text:
        return 0
    try:
        local = time.mktime(time.strptime(text[:19], "%Y-%m-%d %H:%M:%S"))
    except (ValueError, OverflowError):
        return 0
    return int(local - delta)


def _clock_delta(time_now):
    """Difference (in quarter hours) between the server clock and the receiver clock: 0 in the same time zone."""
    server = _wall_to_epoch(time_now, 0)
    if not server:
        return 0
    return int(round((server - time.time()) / 900.0)) * 900


def normalize_server(url):
    url = _s(url)
    if not url:
        return ""
    if not re.match(r"^https?://", url, re.I):
        url = "http://" + url
    url = re.sub(
        r"/(player_api|get|enigma2|panel_api|xmltv)\.php.*$",
        "",
        url,
        flags=re.I)
    return url.rstrip("/")


class XtreamClient(object):
    def __init__(self, server, username, password, timeout=20):
        self.server = normalize_server(server)
        self.username = _s(username)
        self.password = _s(password)
        self.timeout = timeout
        self._cache = {}
        # seconds between the server wall clock and the receiver clock
        self.server_delta = None
        # manual correction in seconds (EPG time setting)
        self.epg_shift = 0
        self.max_connections = 0   # from the last account() answer (0 = unknown)
        self.active_connections = 0

    # ---------------------------------------------------------------
    def _call(self, action=None, cache_secs=0, **params):
        if not self.server:
            raise XtreamError(_("Server not configured"))
        query = {"username": self.username, "password": self.password}
        if action:
            query["action"] = action
        for k, v in params.items():
            if v not in (None, ""):
                query[k] = v
        url = "%s/player_api.php?%s" % (self.server, urlencode(query))
        if cache_secs:
            hit = self._cache.get(url)
            if hit and time.time() - hit[0] < cache_secs:
                return hit[1]
        host = _host_state(self.server)
        if host["cooldown"] > time.time():
            raise LimitError(
                _("The server asked to slow down: try again in %d seconds.") %
                cooldown_left(
                    self.server))
        with host["lock"]:                              # one request at a time per server
            wait = host["last"] + MIN_GAP - time.time()
            if wait > 0:
                time.sleep(wait)
            try:
                data = get_json(url, self.timeout)
            except ValueError:
                raise XtreamError(_("Invalid reply from the server"))
            except Exception as e:
                if _http_code(e) in LIMIT_CODES:
                    host["cooldown"] = time.time() + COOLDOWN
                    print(
                        "[XCDiamond] %s: too many requests (%s), pausing %d s" %
                        (self.server, _http_code(e), COOLDOWN))
                    raise LimitError(
                        _("The server asked to slow down: try again in %d seconds.") %
                        COOLDOWN)
                raise XtreamError(_("Server unreachable: %s") % e)
            finally:
                host["last"] = time.time()
        if isinstance(data, dict) and isinstance(data.get("user_info"), dict) \
                and _s(data["user_info"].get("auth")) == "0":
            state = account_state(data["user_info"], {})
            if state in ("banned", "disabled", "expired"):
                raise AuthError(state_label(state), state)
            raise AuthError(_("Wrong username or password"))
        if cache_secs:
            self._cache[url] = (time.time(), data)
        return data

    def clear_cache(self):
        self._cache = {}

    # ---------------------------------------------------------------
    def account(self, cache_secs=0):
        data = self._call(cache_secs=cache_secs)
        if not isinstance(data, dict) or "user_info" not in data:
            raise XtreamError(_("This does not look like an Xtream server"))
        u = data.get("user_info") or {}
        s = data.get("server_info") or {}
        self.server_delta = _clock_delta(_s(s.get("time_now")))
        exp = _s(u.get("exp_date"))
        try:
            exp_text = time.strftime(
                "%d/%m/%Y",
                time.localtime(
                    int(exp))) if exp and exp != "null" else _("Unlimited")
        except ValueError:
            exp_text = exp
        self.max_connections = _int(u.get("max_connections"), 0)
        self.active_connections = _int(u.get("active_cons"), 0)
        return {
            "state": account_state(u, data.get("server_info") or {}),
            "status": _s(u.get("status"), "?"),
            "expires": exp_text,
            "connections": "%s / %s" % (_s(u.get("active_cons"), "0"), _s(u.get("max_connections"), "?")),
            "message": _s(u.get("message")),
            "trial": _s(u.get("is_trial")) == "1",
            "timezone": _s(s.get("timezone")),
            "server_time": _s(s.get("time_now")),
            "formats": u.get("allowed_output_formats") or [],
        }

    # ---------------------------------------------------------------
    def categories(self, kind):
        action = {LIVE: "get_live_categories", VOD: "get_vod_categories",
                  SERIES: "get_series_categories"}[kind]
        data = self._call(action, cache_secs=600) or []
        out = []
        for c in data if isinstance(data, list) else []:
            out.append({"id": _s(c.get("category_id")),
                       "name": _s(c.get("category_name"), "?")})
        return out

    def items(self, kind, category_id=None):
        action = {
            LIVE: "get_live_streams",
            VOD: "get_vod_streams",
            SERIES: "get_series"}[kind]
        data = self._call(
            action,
            cache_secs=300,
            category_id=category_id) or []
        if not isinstance(data, list):
            return []
        out = []
        for it in data:
            if kind == SERIES:
                out.append({
                    "kind": SERIES, "id": _s(it.get("series_id")), "name": _s(it.get("name"), "?"),
                    "icon": _s(it.get("cover")), "rating": _rating(it.get("rating")),
                    "year": _year(it.get("releaseDate"), it.get("release_date"), it.get("name")),
                    "tmdb": _s(it.get("tmdb") or it.get("tmdb_id")), "plot": _s(it.get("plot")),
                    "genre": _s(it.get("genre")), "added": _s(it.get("last_modified")),
                    "cat": _s(it.get("category_id")),
                })
            else:
                out.append(
                    {
                        "kind": kind, "id": _s(
                            it.get("stream_id")), "name": _s(
                            it.get("name"), "?"), "icon": _s(
                            it.get("stream_icon")), "rating": _rating(
                            it.get("rating")), "year": _year(
                            it.get("year"), it.get("name")) if kind == VOD else "", "ext": _s(
                                it.get("container_extension"), "mp4"), "tmdb": _s(
                                    it.get("tmdb") or it.get("tmdb_id")), "epg_id": _s(
                                        it.get("epg_channel_id")), "added": _s(
                                            it.get("added")), "archive": _flag(
                                                it.get("tv_archive")), "archive_days": _int(
                                                    it.get("tv_archive_duration")) if _flag(
                                                        it.get("tv_archive")) else 0, "cat": _s(
                                                            it.get("category_id")), })
        return out

    # ---------------------------------------------------------------
    def short_epg(self, stream_id, limit=4):
        if self.server_delta is None:          # the server time is needed to correct the times
            try:
                self.account()
            except Exception:
                self.server_delta = 0
        data = self._call(
            "get_short_epg",
            cache_secs=120,
            stream_id=stream_id,
            limit=limit) or {}
        out = []
        for e in data.get("epg_listings") or [] if isinstance(
                data, dict) else []:
            start, stop = self._epg_times(e)
            out.append({"title": _b64(e.get("title")), "desc": _b64(
                e.get("description")), "start": start, "stop": stop})
        return out

    def _epg_times(self, e):
        """Real times (epoch) of a programme.

        Many panels compute start_timestamp by treating local time as UTC, so the programme
        is shifted by 1-2 hours. The "start"/"end" strings are the server wall-clock time,
        in the same zone as time_now: removing the difference between the server clock
        and the receiver clock gives the right time."""
        start = _wall_to_epoch(_s(e.get("start")), self.server_delta or 0)
        stop = _wall_to_epoch(
            _s(e.get("end") or e.get("stop")), self.server_delta or 0)
        if not start or not stop:
            try:
                start = int(_s(e.get("start_timestamp"), "0"))
                stop = int(_s(e.get("stop_timestamp"), "0"))
            except ValueError:
                start = stop = 0
        if start and stop:
            start += self.epg_shift
            stop += self.epg_shift
        return start, stop

    def catchup_table(self, stream_id):
        """Programmes of a channel for catchup: the past days kept by the server plus what follows.
        Each one: title, desc, start, stop (real epoch, with the EPG correction), wall_start
        (server clock "YYYY-MM-DD HH:MM:SS", needed for the timeshift address), archived."""
        if self.server_delta is None:
            try:
                self.account()
            except Exception:
                self.server_delta = 0
        data = self._call(
            "get_simple_data_table",
            cache_secs=300,
            stream_id=stream_id) or {}
        out = []
        for e in data.get("epg_listings") or [] if isinstance(
                data, dict) else []:
            start, stop = self._epg_times(e)
            if not start or stop <= start:
                continue
            wall = _s(e.get("start"))[:19]
            if not wall:              # only timestamps: rebuild the server clock time
                wall = time.strftime(
                    "%Y-%m-%d %H:%M:%S", time.localtime(start - self.epg_shift + (self.server_delta or 0)))
            out.append({"title": _b64(e.get("title")),
                        "desc": _b64(e.get("description")),
                        "start": start,
                        "stop": stop,
                        "wall_start": wall,
                        "archived": _flag(e.get("has_archive"))})
        out.sort(key=lambda p: p["start"])
        return out

    def catchup_url(self, stream_id, programme, ext="ts"):
        """Timeshift address of a past programme: /timeshift/user/pass/minutes/YYYY-MM-DD:HH-MM/id.ts"""
        minutes = max(
            1, int(
                (programme["stop"] - programme["start"] + 59) // 60))
        wall = programme["wall_start"]
        start = "%s:%s" % (wall[:10], wall[11:16].replace(
            ":", "-"))       # 2026-11-27:14-05
        return "%s/timeshift/%s/%s/%d/%s/%s.%s" % (
            self.server, self.username, self.password, minutes, start, stream_id, ext)

    def vod_info(self, vod_id):
        data = self._call("get_vod_info", cache_secs=3600, vod_id=vod_id) or {}
        info = data.get("info") if isinstance(data, dict) else None
        info = info if isinstance(info, dict) else {}
        movie = data.get("movie_data") if isinstance(data, dict) else None
        movie = movie if isinstance(movie, dict) else {}
        backdrop = info.get("backdrop_path") or []
        return {
            "tmdb": _s(info.get("tmdb_id") or info.get("tmdb")),
            "name": _s(info.get("name") or movie.get("name")),
            "o_name": _s(info.get("o_name")),
            "plot": _s(info.get("plot") or info.get("description")),
            "cast": _s(info.get("cast") or info.get("actors")),
            "director": _s(info.get("director")),
            "genre": _s(info.get("genre")),
            "year": _year(info.get("releasedate"), info.get("release_date"), info.get("year")),
            "duration": _s(info.get("duration")),
            "rating": _rating(info.get("rating")),
            "poster": _s(info.get("movie_image") or info.get("cover_big")),
            "backdrop": _s(backdrop[0] if isinstance(backdrop, list) and backdrop else backdrop),
            "trailer": _s(info.get("youtube_trailer")),
            "ext": _s(movie.get("container_extension"), "mp4"),
        }

    def series_info(self, series_id):
        data = self._call(
            "get_series_info",
            cache_secs=1800,
            series_id=series_id) or {}
        if not isinstance(data, dict):
            data = {}
        info = data.get("info") if isinstance(data.get("info"), dict) else {}
        raw_eps = data.get("episodes") or {}
        # some panels send a list of lists instead of a dictionary
        if isinstance(raw_eps, list):
            raw_eps = dict((str(i + 1), v) for i, v in enumerate(raw_eps))
        seasons = {}
        for key, eps in raw_eps.items():
            for ep in eps or []:
                epi = ep.get("info") if isinstance(
                    ep.get("info"), dict) else {}
                try:
                    snum = int(_s(ep.get("season"), key) or key)
                except ValueError:
                    snum = 0
                try:
                    enum = int(_s(ep.get("episode_num"), "0") or 0)
                except ValueError:
                    enum = 0
                seasons.setdefault(
                    snum, []).append(
                    {
                        "kind": SERIES, "id": _s(
                            ep.get("id")), "season": snum, "episode": enum, "name": _s(
                            ep.get("title"), _("Episode %d") %
                            enum), "ext": _s(
                            ep.get("container_extension"), "mp4"), "plot": _s(
                            epi.get("plot")), "duration": _s(
                                epi.get("duration")), "image": _s(
                                    epi.get("movie_image")), "rating": _rating(
                                        epi.get("rating")), })
        for eps in seasons.values():
            eps.sort(key=lambda e: e["episode"])
        backdrop = info.get("backdrop_path") or []
        return {
            "tmdb": _s(info.get("tmdb") or info.get("tmdb_id")),
            "name": _s(info.get("name")), "plot": _s(info.get("plot")),
            "cast": _s(info.get("cast")), "director": _s(info.get("director")),
            "genre": _s(info.get("genre")), "rating": _rating(info.get("rating")),
            "year": _year(info.get("releaseDate"), info.get("release_date")),
            "poster": _s(info.get("cover")),
            "backdrop": _s(backdrop[0] if isinstance(backdrop, list) and backdrop else backdrop),
            "seasons": seasons,  # {number: [episodes]}
        }

    # ---------------------------------------------------------------
    def stream_url(self, item, live_ext="ts"):
        kind = item.get("kind")
        if kind == LIVE:
            path, ext = "live", live_ext
        elif kind == VOD:
            path, ext = "movie", item.get("ext") or "mp4"
        else:
            path, ext = "series", item.get("ext") or "mp4"
        return "%s/%s/%s/%s/%s.%s" % (self.server,
                                      path,
                                      self.username,
                                      self.password,
                                      item["id"],
                                      ext)
