# -*- coding: utf-8 -*-
"""YouTube trailers: the TMDB YouTube key becomes a playable video through the yt-dlp command.

Same method as the WorldCam/TVGarden YouTube helper (by Lululla):
- yt-dlp is run as a command (-g prints the direct address), never imported: importing the
  module inside Enigma2 is slow and can hang the GUI thread pool;
- progressive MP4 first (formats 18, 22), then any HTTP MP4, then the best one;
- first try with the android_vr client (no JavaScript runtime needed), then yt-dlp defaults;
- node/bun/quickjs used when installed; long timeouts because receivers are slow.
yt-dlp is not shipped with the plugin:  opkg update && opkg install python3-yt-dlp
"""

import os
import subprocess
import sys

VERSION_TIMEOUT = 60
RESOLVE_TIMEOUT = 150
FORMAT_CHAIN = "18/22/best[ext=mp4][protocol^=http]/best"
CLIENT_ATTEMPTS = (
    ["--extractor-args", "youtube:player_client=android_vr"], [])
JS_RUNTIMES = (("node", "node"), ("bun", "bun"), ("quickjs", "qjs"))

_cmd = {"ytdlp": None, "js": None}


def _which(name):
    for folder in (os.environ.get("PATH")
                   or "/usr/bin:/bin:/usr/local/bin").split(os.pathsep):
        path = os.path.join(folder, name)
        if os.path.isfile(path) and os.access(path, os.X_OK):
            return path
    return None


def _run(cmd, timeout):
    """(returncode, stdout, stderr) as text; timeout on Python 3 only."""
    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE)
    try:
        if sys.version_info[0] >= 3:
            out, err = proc.communicate(timeout=timeout)
        else:
            out, err = proc.communicate()
    except Exception:
        proc.kill()
        proc.communicate()
        raise
    return proc.returncode, out.decode(
        "utf-8", "ignore"), err.decode("utf-8", "ignore")


def _js_args():
    if _cmd["js"] is None:
        _cmd["js"] = []
        for runtime, binary in JS_RUNTIMES:
            path = _which(binary)
            if path:
                _cmd["js"] = ["--js-runtimes", "%s:%s" % (runtime, path)]
                break
    return _cmd["js"]


def find_ytdlp():
    """Command list that runs yt-dlp, or None. The working one is remembered."""
    if _cmd["ytdlp"]:
        return _cmd["ytdlp"]
    candidates = []
    found = _which("yt-dlp")
    if found:
        candidates.append([found])
    for path in ("/usr/bin/yt-dlp", "/usr/local/bin/yt-dlp"):
        if os.path.exists(path) and [path] not in candidates:
            candidates.append([path])
    for python in ("/usr/bin/python3", "/usr/bin/python", sys.executable):
        # inside Enigma2 sys.executable can be the enigma2 binary: only real
        # python interpreters
        if python and os.path.exists(python) and os.path.basename(python).startswith(
                "python") and [python, "-m", "yt_dlp"] not in candidates:
            candidates.append([python, "-m", "yt_dlp"])
    for cmd in candidates:
        try:
            code, out, _err = _run(cmd + ["--version"], VERSION_TIMEOUT)
            if code == 0:
                print(
                    "[XCDiamond] yt-dlp: %s (%s)" %
                    (" ".join(cmd), out.strip()))
                _cmd["ytdlp"] = cmd
                return cmd
        except Exception as e:
            print("[XCDiamond] yt-dlp candidate %s: %s" % (" ".join(cmd), e))
    return None


def available():
    """Quick check without starting yt-dlp (for the GUI)."""
    if _cmd["ytdlp"] or _which("yt-dlp") or os.path.exists("/usr/bin/yt-dlp"):
        return True
    try:
        from importlib.util import find_spec
        return find_spec("yt_dlp") is not None
    except Exception:
        try:
            import imp
            imp.find_module("yt_dlp")
            return True
        except Exception:
            return False


def _short_error(stderr):
    lines = [line.strip()
             for line in (stderr or "").splitlines() if line.strip()]
    errors = [line for line in lines if line.startswith("ERROR")]
    text = (errors or lines or ["unknown error"])[-1]
    return text.replace("ERROR: ", "")[:160]


def resolve(key):
    """Runs in a thread. YouTube key (or URL) -> (direct_url, error)."""
    url = key if key.startswith(
        ("http://", "https://")) else "https://www.youtube.com/watch?v=%s" % key
    ytdlp = find_ytdlp()
    if not ytdlp:
        return "", "yt-dlp is not installed"
    base = ytdlp + ["-g",
                    "--no-playlist",
                    "--playlist-items",
                    "1",
                    "--no-warnings",
                    "--socket-timeout",
                    "20",
                    "-f",
                    FORMAT_CHAIN] + _js_args()
    error = ""
    for extra in CLIENT_ATTEMPTS:
        try:
            code, out, err = _run(base + list(extra) + [url], RESOLVE_TIMEOUT)
        except Exception as e:
            error = "yt-dlp timeout" if "imeout" in type(
                e).__name__ else str(e)
            print("[XCDiamond] trailer: %s" % error)
            if error == "yt-dlp timeout":
                break
            continue
        for line in out.splitlines():
            line = line.strip()
            if line.startswith(("http://", "https://")):
                return line, ""
        error = _short_error(err)
        print("[XCDiamond] trailer failed (%s): %s" % (code, error))
    return "", error
