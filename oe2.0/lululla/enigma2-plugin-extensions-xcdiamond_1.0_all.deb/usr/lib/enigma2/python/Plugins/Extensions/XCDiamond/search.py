# -*- coding: utf-8 -*-
"""Search the whole server: channels, movies (with the series inside VOD) and series.

- Ignores case, accents and provider prefixes ("IT - ", "[HD]"...).
- Titles starting with the searched word come first, then those containing it.
- Full lists are downloaded once and kept in memory for 30 minutes.
No Enigma2 dependency: it can be tested on a PC."""

import json
import os
import re
import time
import unicodedata

from .tmdb import clean_title

LIST_TTL = 30 * 60
MAX_RESULTS = 300          # per section: more is useless and slows the list down
HISTORY_MAX = 10


def normalize(text):
    """'IT - Città [HD]' -> 'citta'"""
    if not text:
        return u""
    if not isinstance(text, type(u"")):
        text = text.decode("utf-8", "ignore")
    text = clean_title(text)[0] or text
    text = unicodedata.normalize("NFKD", text)
    text = u"".join(c for c in text if not unicodedata.combining(c))
    text = re.sub(u"[^\\w]+", u" ", text.lower(), flags=re.UNICODE)
    return text.strip()


def score(item_norm, query_norm, words):
    """0 = not found; higher = more relevant."""
    if not item_norm:
        return 0
    if item_norm == query_norm:
        return 100
    if item_norm.startswith(query_norm):
        return 80
    if (u" " + query_norm) in (u" " + item_norm):  # starts a word of the title
        return 60
    if query_norm in item_norm:
        return 40
    if words and all(
            w in item_norm for w in words):      # all words, in any order
        return 20
    return 0


def search(items, query):
    """Items sorted by relevance (ties in alphabetical order)."""
    q = normalize(query)
    if not q:
        return []
    words = q.split()
    found = []
    for item in items:
        norm = item.get("_norm")
        if norm is None:
            norm = item["_norm"] = normalize(item.get("name"))
        s = score(norm, q, words)
        if s:
            found.append((-s, norm, item))
    found.sort(key=lambda x: (x[0], x[1]))
    return [f[2] for f in found[:MAX_RESULTS]]


class History(object):
    """Last searches, saved to a file."""

    def __init__(self, path):
        self.path = path
        try:
            with open(path) as f:
                self.items = [x for x in json.load(f) if x][:HISTORY_MAX]
        except (IOError, OSError, ValueError):
            self.items = []

    def add(self, query):
        query = (query or u"").strip()
        if not query:
            return
        self.items = [query] + \
            [x for x in self.items if x.lower() != query.lower()]
        self.items = self.items[:HISTORY_MAX]
        try:
            tmp = self.path + ".tmp"
            with open(tmp, "w") as f:
                json.dump(self.items, f)
            os.rename(tmp, self.path)
        except (IOError, OSError):
            pass


class Lists(object):
    """Full server lists for the search (downloaded once, valid for 30 minutes)."""

    def __init__(self):
        self.data = {}        # {kind: (time, items)}

    def get(self, client, kind, organize=None):
        hit = self.data.get(kind)
        if hit and time.time() - hit[0] < LIST_TTL:
            return hit[1]
        items = client.items(kind, None)
        if organize:
            items = organize(items)
        self.data[kind] = (time.time(), items)
        return items

    def clear(self):
        self.data = {}
