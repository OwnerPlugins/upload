# -*- coding: utf-8 -*-
"""Shared GUI parts: colours, FHD -> HD skin scaling, lists,
images (posters/backdrops) and small Python 2/3 compatibility helpers."""

import os
import re
import sys

from enigma import (eListboxPythonMultiContent, ePicLoad, eTimer, getDesktop,
                    gFont, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_VALIGN_CENTER)
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
try:
    from Components.MultiContent import MultiContentEntryPixmapAlphaBlend as PixEntry
except ImportError:
    from Components.MultiContent import MultiContentEntryPixmapAlphaTest as PixEntry
try:
    from Components.MultiContent import MultiContentEntryProgress
except ImportError:
    MultiContentEntryProgress = None
try:
    from Tools.LoadPixmap import LoadPixmap
except ImportError:
    LoadPixmap = None

from . import _
from .net import download, run_async

PY3 = sys.version_info[0] >= 3
PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))

try:
    # Arabic shaping + bidi, applied to every string on its way to a widget
    # (see T()).
    from .arabic_text import shape as _shape
except Exception:
    def _shape(text):
        return text

# ------------------------------------------------------------------
# Palette (Enigma2 format: #AARRGGBB, AA=00 opaque, AA=ff transparent)
# ------------------------------------------------------------------
BG = "#000b0f17"
PANEL = "#00141b26"
PANEL2 = "#001c2533"
ACCENT = "#008fd3ff"      # diamond blue
TEXT = "#00e6edf3"
DIM = "#008b949e"
GOLD = "#00f2cc60"
SEL = "#00233046"

C_TEXT = 0xe6edf3
C_DIM = 0x8b949e
C_GOLD = 0xf2cc60
C_ACCENT = 0x8fd3ff
C_WHITE = 0xffffff


def T(text):
    """Text ready for widgets: utf-8 str on Python 2, str on Python 3.

    Arabic is shaped and reordered here, so every screen gets it for free (this is the
    single point all displayed text passes through). Latin text is returned unchanged.
    """
    if text is None:
        return ""
    if PY3:
        s = text if isinstance(text, str) else str(text)
        return _shape(s)
    if isinstance(text, unicode):  # noqa: F821  (Python 2 only)
        return _shape(text).encode("utf-8")
    try:
        return _shape(text.decode("utf-8")).encode("utf-8")
    except Exception:
        return str(text)


def new_timer(callback):
    t = eTimer()
    try:
        t.callback.append(callback)
    except AttributeError:
        t._conn = t.timeout.connect(callback)
    return t


# ------------------------------------------------------------------
# Skin: everything is written for 1920x1080 and scaled here for HD (1280x720) and WQHD boxes
# ------------------------------------------------------------------
def _desktop_width():
    try:
        return getDesktop(0).size().width()
    except Exception:
        return 1920


FACTOR = _desktop_width() / 1920.0


def sc(value):
    return int(round(value * FACTOR))


def veil_path(kind="veil"):
    """Dark veil PNG for the right resolution (HD, FHD or WQHD).
    kind: "veil" = full screen (detail pages), "veil_info" = player INFO panel."""
    width = _desktop_width()
    name = "hd" if width <= 1280 else ("wqhd" if width >= 2560 else "fhd")
    return os.path.join(PLUGIN_DIR, "icons", "%s_%s.png" % (kind, name))


def scale_skin(xml):
    if abs(FACTOR - 1.0) < 0.01:
        return xml

    def pair(m):
        a, b = m.group(2), m.group(3)
        def conv(v): return v if not v.lstrip("-").isdigit() else str(sc(int(v)))  # noqa: E731
        return '%s="%s,%s"' % (m.group(1), conv(a), conv(b))

    xml = re.sub(r'\b(position|size)="([^",]+),([^"]+)"', pair, xml)
    xml = re.sub(r'font="([^";]+);(\d+)"', lambda m: 'font="%s;%d"' %
                 (m.group(1), sc(int(m.group(2)))), xml)
    xml = re.sub(r'\b(itemHeight|scrollbarWidth|borderWidth)="(\d+)"',
                 lambda m: '%s="%d"' % (m.group(1), max(1, sc(int(m.group(2))))), xml)
    return re.sub(r"<widget\b[^>]*itemHeight=[^>]*>", _whole_rows, xml)


def _whole_rows(m):
    """List height = whole rows after scaling (otherwise the last row is cut in half)."""
    tag = m.group(0)
    ih = re.search(r'itemHeight="(\d+)"', tag)
    size = re.search(r'size="(\d+),(\d+)"', tag)
    if not (ih and size):
        return tag
    item = int(ih.group(1))
    rows = max(1, int(round(int(size.group(2)) / float(item))))
    return tag.replace(
        size.group(0), 'size="%s,%d"' %
        (size.group(1), rows * item))


_icons = {}


def icon(name, size=None):
    """PNG from icons/ loaded once (None when missing).
    size: side in FHD pixels; the file of the right size is picked (lists do not scale images)."""
    if size:
        real = sc(size)
        name = "%s_%d" % (name, min((32, 48, 64), key=lambda s: abs(s - real)))
    if name not in _icons:
        path = os.path.join(PLUGIN_DIR, "icons", name + ".png")
        _icons[name] = LoadPixmap(path) if (
            LoadPixmap and os.path.exists(path)) else None
    return _icons[name]


def footer(y=990, labels=("key_red", "key_green", "key_yellow", "key_blue")):
    """Coloured key bar at the bottom of the screen."""
    colors = ["#00e0443e", "#003fb950", "#00e3b341", "#003b82f6"]
    out = []
    x = 60
    for name, color in zip(labels, colors):
        out.append(
            '<eLabel position="%d,%d" size="8,40" backgroundColor="%s" />' %
            (x, y, color))
        out.append(
            '<widget name="%s" position="%d,%d" size="400,40" font="Regular;28" '
            'foregroundColor="%s" backgroundColor="%s" transparent="1" valign="center" />' %
            (name, x + 20, y, TEXT, BG))
        x += 450
    return "\n".join(out)


def clock(x=1660, y=36):
    return (
        '<widget source="global.CurrentTime" render="Label" position="%d,%d" size="200,50" '
        'font="Regular;36" halign="right" foregroundColor="%s" backgroundColor="%s" transparent="1">'
        '<convert type="ClockToText">Format:%%H:%%M</convert></widget>' %
        (x, y, TEXT, BG))


# ------------------------------------------------------------------
# Two-column list (text on the left, detail on the right)
# ------------------------------------------------------------------
class XCDList(MenuList):
    def __init__(self, font_size=30, item_height=60):
        MenuList.__init__(self, [], False, eListboxPythonMultiContent)
        self.item_height = sc(item_height)
        self.l.setFont(0, gFont("Regular", sc(font_size)))
        self.l.setFont(1, gFont("Regular", sc(font_size - 6)))
        self.l.setItemHeight(self.item_height)
        self.width = sc(600)

    def _width(self):
        # the real width is known only after the skin has been applied
        try:
            w = self.instance.size().width()
            if w > 0:
                self.width = w
        except Exception:
            pass
        return self.width

    def entry(
            self,
            payload,
            text,
            right="",
            right_color=C_DIM,
            color=C_TEXT,
            icon=None,
            right_w=170,
            icon_size=48):
        h = self.item_height
        self._width()
        right_w = sc(right_w) if right else 0
        pad = sc(18)
        row = [payload]
        # PNG icon on the left (e.g. Home menu)
        if icon is not None:
            # same size as the file picked by icon(..., icon_size)
            isz = sc(icon_size)
            row.append(
                PixEntry(
                    pos=(
                        pad,
                        (h - isz) // 2),
                    size=(
                        isz,
                        isz),
                    png=icon))
            pad += isz + sc(22)
        row.append(
            MultiContentEntryText(
                pos=(
                    pad,
                    0),
                size=(
                    self.width -
                    right_w -
                    pad -
                    sc(18),
                    h),
                font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                text=T(text),
                color=color,
                color_sel=C_WHITE))
        pad = sc(18)
        if right:
            row.append(
                MultiContentEntryText(
                    pos=(
                        self.width - right_w - pad,
                        0),
                    size=(
                        right_w,
                        h),
                    font=1,
                    flags=RT_HALIGN_RIGHT | RT_VALIGN_CENTER,
                    text=T(right),
                    color=right_color,
                    color_sel=right_color))
        return row

    def set_item_height(self, height):
        self.item_height = sc(height)
        self.l.setItemHeight(self.item_height)

    def entry_two(
            self,
            payload,
            text,
            sub=u"",
            percent=None,
            sub_color=C_GOLD):
        """Two-level row: name on top, detail (e.g. programme on air) and bar below."""
        h = self.item_height
        self._width()
        pad = sc(18)
        bar_w = sc(150) if percent is not None else 0
        top = int(h * 0.52)
        row = [
            payload,
            MultiContentEntryText(
                pos=(
                    pad,
                    sc(4)),
                size=(
                    self.width - pad * 2,
                    top - sc(4)),
                font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                text=T(text),
                color=C_TEXT,
                color_sel=C_WHITE)]
        if sub:
            row.append(
                MultiContentEntryText(
                    pos=(
                        pad,
                        top),
                    size=(
                        self.width - pad * 3 - bar_w,
                        h - top - sc(6)),
                    font=1,
                    flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                    text=T(sub),
                    color=sub_color,
                    color_sel=sub_color))
        if percent is not None:
            x, y, bh = self.width - pad - bar_w, top + \
                (h - top - sc(8)) // 2, sc(8)
            row.append(
                MultiContentEntryText(
                    pos=(
                        x,
                        y),
                    size=(
                        bar_w,
                        bh),
                    font=1,
                    text="",
                    backcolor=0x303a4a,
                    backcolor_sel=0x46546a))
            if MultiContentEntryProgress is not None and percent > 0:
                row.append(
                    MultiContentEntryProgress(
                        pos=(
                            x,
                            y),
                        size=(
                            bar_w,
                            bh),
                        percent=percent,
                        borderWidth=0,
                        foreColor=C_ACCENT,
                        foreColorSelected=C_ACCENT))
        return row

    def update_entry(self, index, entry):
        """Redraw one row instead of the whole list."""
        if not (0 <= index < len(self.list)):
            return
        self.list[index] = entry
        try:
            self.l.invalidateEntry(index)
        except Exception:
            current = self.getSelectedIndex()
            self.setList(self.list)
            self.moveToIndex(current)

    def set_entries(self, entries, index=0):
        self.setList(entries)
        if entries:
            self.moveToIndex(min(index, len(entries) - 1))

    def current(self):
        cur = self.getCurrent()
        return cur[0] if cur else None

    def move(self, direction):
        inst = self.instance
        if inst is None:
            return
        inst.moveSelection({"up": inst.moveUp,
                            "down": inst.moveDown,
                            "pageUp": inst.pageUp,
                            "pageDown": inst.pageDown}[direction])

    def focus(self, active):
        try:
            self.selectionEnabled(1 if active else 0)
        except Exception:
            pass


# ------------------------------------------------------------------
# Images: download in the background and show in a Pixmap widget
# ------------------------------------------------------------------
class ImageLoader(object):
    """Show an image (URL or file) in a Pixmap.

    The box decoder handles one image at a time: when another one arrives while it is
    busy, startDecode refuses it. So there is a one-slot queue: the last requested
    image starts as soon as the decoder is free, and older requests are dropped."""

    def __init__(
            self,
            screen,
            widget,
            fallback=None,
            transparent=False,
            on_show=None):
        """fallback: "poster" or "image" = XC Diamond placeholder when the real image is missing.
        transparent: for PNGs with transparency (logos). on_show: called when the image is on screen."""
        self.screen = screen
        self.widget = widget
        self.bg = "#FF000000" if transparent else "#00000000"
        self.on_show = on_show
        self.fallback = os.path.join(
            PLUGIN_DIR, "icons", "fallback_%s.png" %
            fallback) if fallback else None
        self.token = 0
        self.busy = False
        self.decoding = None       # token of the image being decoded
        self.queued = None         # (path, token) waiting for the decoder
        # when the decoder does not answer, nothing hangs
        self.watchdog = new_timer(self._stuck)
        self._new_decoder()

    def _new_decoder(self):
        self.picload = ePicLoad()
        try:
            self._conn = self.picload.PictureData.connect(self._decoded)
        except AttributeError:
            self.picload.PictureData.get().append(self._decoded)

    def _alive(self):
        return getattr(self.screen, "alive", True)

    def clear(self):
        self.token += 1
        self.url = None
        self.queued = None
        try:
            self.screen[self.widget].hide()
        except Exception:
            pass

    def load(self, url):
        if url and url == getattr(
                self, "url", None) and self.screen[self.widget].visible:
            return                                   # already shown
        self.url = url
        self.token += 1
        token = self.token
        if not url:
            if self.fallback:
                self._show(self.fallback, token)
            else:
                self.clear()
            return
        if url.startswith("/"):
            self._show(url, token)
            return
        run_async(
            download, (url,), callback=lambda path: self._show(
                path, token, url), errback=lambda e: log(
                "image not downloaded %s: %s" %
                (url, e)))

    def _show(self, path, token, url=""):
        if token != self.token or not self._alive():
            return
        if not path or not os.path.exists(path):
            log("image not available: %s" % (url or path))
            if self.fallback and path != self.fallback:
                # always something in its place
                return self._show(self.fallback, token)
            self.clear()
            return
        if self.busy:
            # starts as soon as the decoder is free
            self.queued = (path, token)
            return
        self._start(path, token)

    def _start(self, path, token):
        try:
            size = self.screen[self.widget].instance.size()
            self.picload.setPara(
                (size.width(), size.height(), 1, 1, False, 1, self.bg))
            self.busy = True
            self.decoding = token
            self.watchdog.start(4000, True)
            if self.picload.startDecode(path):          # not 0 = refused
                self.busy = False
                self.watchdog.stop()
                log("decode refused: %s" % path)
                self.clear()
        except Exception as e:
            self.busy = False
            log("image error %s: %s" % (path, e))
            self.clear()

    def _stuck(self):
        """The decoder did not answer within 4 seconds: move on to the next image."""
        log("decoder not answering (%s): moving on" % self.widget)
        self.busy = False
        self._new_decoder()                # the old one is stuck: use a new one
        self._next()

    def _next(self):
        if self.queued and self._alive():
            path, token = self.queued
            self.queued = None
            if token == self.token:
                self._start(path, token)

    def _decoded(self, info=None):
        self.watchdog.stop()
        self.busy = False
        if not self._alive():
            return
        if self.decoding == self.token:
            ptr = self.picload.getData()
            if ptr is not None:
                self.screen[self.widget].instance.setPixmap(ptr)
                self.screen[self.widget].show()
                if self.on_show:
                    self.on_show()
            else:
                log("empty decode (%s)" % self.widget)
        self._next()


def log(text):
    print("[XCDiamond] %s" % text)


def merge_info(xtream, tm, fallback_name=""):
    """Merge the IPTV server data with TMDB data (TMDB wins)."""
    xtream = xtream or {}
    tm = tm or {}

    def pick(*vals):
        for v in vals:
            if v:
                return v
        return ""
    return {
        "title": pick(tm.get("title"), xtream.get("name"), fallback_name),
        "original_title": tm.get("original_title", ""),
        "tagline": tm.get("tagline", ""),
        "year": pick(tm.get("year"), xtream.get("year")),
        "runtime": pick(tm.get("runtime"), _minutes(xtream.get("duration"))),
        "genres": pick(tm.get("genres"), xtream.get("genre")),
        # TMDB only (server ratings are unreliable)
        "rating": tm.get("rating", ""),
        "votes": tm.get("votes", 0),
        "director": pick(tm.get("director"), xtream.get("director")),
        "cast": pick(tm.get("cast"), xtream.get("cast")),
        "countries": tm.get("countries", ""),
        "overview": pick(tm.get("overview"), xtream.get("plot")),
        "poster": pick(tm.get("poster"), xtream.get("poster"), xtream.get("icon")),
        "backdrop": pick(tm.get("backdrop"), xtream.get("backdrop")),
        "tmdb": tm.get("tmdb", ""),
        "certification": tm.get("certification", ""),
        "logo": tm.get("logo", ""),
        "trailer": pick(tm.get("trailer"), xtream.get("trailer")),
        "source": "TMDB" if tm else _("IPTV server"),
        "seasons_count": tm.get("seasons_count", 0),
        "episodes_count": tm.get("episodes_count", 0),
        "status": tm.get("status", ""),
    }


def _minutes(text):
    """'01:47:30' or '107' -> '107 min' (server durations come in many formats)."""
    text = (text or u"").strip()
    parts = text.split(":")
    try:
        if len(parts) == 3:
            mins = int(parts[0]) * 60 + int(parts[1])
        elif len(parts) == 2:
            mins = int(parts[0])
        else:
            mins = int(float(text))
    except ValueError:
        return text
    return (u"%d min" % mins) if mins > 0 else u""


def _votes(n):
    """Compact vote count: 1234 -> '1.2k', 23000 -> '23k'."""
    try:
        n = int(n)
    except (TypeError, ValueError):
        return ""
    if n < 1000:
        return str(n)
    if n < 10000:
        return (u"%.1fk" % (n / 1000.0)).replace(u".0k", u"k")
    return u"%dk" % (n // 1000)


def meta_line(info, max_genres=0, genres=True):
    parts = []
    if info.get("year"):
        parts.append(info["year"])
    if info.get("certification"):
        parts.append(info["certification"])
    if info.get("runtime"):
        parts.append(info["runtime"])
    if info.get("rating"):
        rating = u"\u2605 %s" % info["rating"]
        vc = _votes(info.get("votes"))
        if vc:
            rating += u" (%s)" % vc
        parts.append(rating)
    if genres and info.get("genres"):
        g = info["genres"]
        if max_genres:
            g = u", ".join(g.split(", ")[:max_genres])
        parts.append(g)
    return u"   \u2022   ".join(parts)
