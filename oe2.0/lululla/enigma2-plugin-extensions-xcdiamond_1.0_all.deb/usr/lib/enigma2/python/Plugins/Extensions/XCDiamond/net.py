# -*- coding: utf-8 -*-
"""Network: HTTP requests, JSON, image downloads, background execution.
No Enigma2 dependency except twisted (present on every image)."""

import hashlib
import json
import os
import ssl
import sys

PY3 = sys.version_info[0] >= 3

if PY3:
    from urllib.request import Request, urlopen
    from urllib.parse import urlencode as _urlencode, quote
else:  # Python 2
    from urllib2 import Request, urlopen
    from urllib import urlencode as _urlencode, quote


def urlencode(params):
    """Like urllib.urlencode, but does not break on accented letters with Python 2."""
    items = params.items() if isinstance(params, dict) else params
    if not PY3:
        items = [(k.encode("utf-8") if isinstance(k, unicode) else k,  # noqa: F821
                  v.encode("utf-8") if isinstance(v, unicode) else v)  # noqa: F821
                 for k, v in items]
    return _urlencode(list(items))


USER_AGENT = "Mozilla/5.0 (Linux; Enigma2) XCDiamond/1.0"
CACHE_DIR = "/tmp/xcdiamond"

__all__ = [
    "http_get",
    "get_json",
    "open_stream",
    "download",
    "run_async",
    "urlencode",
    "quote",
    "CACHE_DIR"]


def _ssl_context():
    # Many receivers have old CA certificates: without this HTTPS fails.
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        return ctx
    except Exception:
        return None


_CTX = _ssl_context()


def http_get(url, timeout=15, headers=None):
    """GET and return the response bytes. Raises on error."""
    h = {"User-Agent": USER_AGENT, "Accept": "*/*"}
    if headers:
        h.update(headers)
    req = Request(url, headers=h)
    if _CTX is not None and url.startswith("https"):
        try:
            resp = urlopen(req, timeout=timeout, context=_CTX)
        except TypeError:
            resp = urlopen(req, timeout=timeout)
    else:
        resp = urlopen(req, timeout=timeout)
    try:
        return resp.read()
    finally:
        resp.close()


def open_stream(url, timeout=60, headers=None):
    """Open an HTTP response to read in chunks (EPG guide, downloads). headers: e.g. Range."""
    h = {"User-Agent": USER_AGENT, "Accept": "*/*"}
    if headers:
        h.update(headers)
    req = Request(url, headers=h)
    if _CTX is not None and url.startswith("https"):
        try:
            return urlopen(req, timeout=timeout, context=_CTX)
        except TypeError:
            pass
    return urlopen(req, timeout=timeout)


def get_json(url, timeout=15, headers=None):
    data = http_get(url, timeout, headers)
    if not data:
        return None
    if PY3 or isinstance(data, bytes):
        data = data.decode("utf-8", "replace")
    return json.loads(data)


def ensure_dir(path):
    if not os.path.isdir(path):
        try:
            os.makedirs(path)
        except OSError:
            pass
    return path


def cached_image_path(url):
    if not url:
        return ""
    name = hashlib.md5(url.encode("utf-8")).hexdigest()
    ext = ".png" if url.lower().split("?")[0].endswith(".png") else ".jpg"
    return os.path.join(ensure_dir(os.path.join(CACHE_DIR, "img")), name + ext)


def image_kind(data):
    """Format from the first bytes; None when the box decoder cannot read it (WebP, HTML...)."""
    head = data[:12]
    if head[:3] == b"\xff\xd8\xff":
        return "jpg"
    if head[:8] == b"\x89PNG\r\n\x1a\n":
        return "png"
    if head[:6] in (b"GIF87a", b"GIF89a"):
        return "gif"
    return None


def download(url, timeout=15):
    """Download an image into the cache and return the local path ('' on failure
    or when the box cannot show that format)."""
    if not url:
        return ""
    path = cached_image_path(url)
    if os.path.exists(path) and os.path.getsize(path) > 0:
        return path
    try:
        data = http_get(url, timeout)
        if not data or len(data) < 100:
            return ""
        if image_kind(
                data) is None:          # WebP, error pages...: the decoder would hang
            print("[XCDiamond] unsupported image format: %s" % url)
            return ""
        tmp = path + ".part"
        with open(tmp, "wb") as f:
            f.write(data)
        os.rename(tmp, path)
        return path
    except Exception:
        return ""


def run_async(func, args=(), callback=None, errback=None):
    """Run func(*args) in a thread; callback/errback run in the GUI thread.
    Outside Enigma2 (tests) everything runs immediately."""
    try:
        from twisted.internet import threads
        d = threads.deferToThread(func, *args)
        if callback:
            d.addCallback(callback)
        d.addErrback(lambda f: errback(f.value) if errback else None)
        return d
    except ImportError:
        try:
            result = func(*args)
        except Exception as e:
            if errback:
                errback(e)
            return None
        if callback:
            callback(result)
        return None
