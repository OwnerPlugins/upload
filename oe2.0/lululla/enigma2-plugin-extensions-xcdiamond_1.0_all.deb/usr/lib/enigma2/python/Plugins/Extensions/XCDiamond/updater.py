# -*- coding: utf-8 -*-
"""XC Diamond updates from the GitHub repository OwnerPlugins/XCDiamond.

The repository holds a version.json file (made by tools/make_release.py):
    {"version": "2.2", "date": "2026-12-01",
     "file": "https://github.com/OwnerPlugins/XCDiamond/releases/download/v2.2/XCDiamond-2.2.tar.gz",
     "sha256": "...", "size": 123456,
     "changes": ["change 1", "change 2"]}

The package is a .tar.gz holding only usr/lib/enigma2/python/Plugins/Extensions/XCDiamond/...
Before installing, size, sha256 and the location of every file are checked.
When the box license is enabled in the plugin, updates install only on an authorized box.
"""

import hashlib
import json
import os
import tarfile
import time

from . import _
from .net import http_get

REPO = "OwnerPlugins/XCDiamond"
BRANCH = "main"
VERSION_URL = "https://raw.githubusercontent.com/%s/%s/version.json" % (
    REPO, BRANCH)
REPO_URL = "https://github.com/%s" % REPO
PREFIX = "usr/lib/enigma2/python/Plugins/Extensions/XCDiamond/"
TMP_FILE = "/tmp/xcdiamond_update.tar.gz"
# last check (redone after a reboot)
STATE_FILE = "/tmp/xcdiamond/update.json"
MAX_SIZE = 20 * 1024 * 1024


class UpdateError(Exception):
    pass


def version_tuple(v):
    out = []
    for part in str(v or "0").strip().lstrip("vV").split("."):
        digits = "".join(ch for ch in part if ch.isdigit())
        out.append(int(digits) if digits else 0)
    while len(out) < 3:
        out.append(0)
    return tuple(out)


def is_newer(remote, local):
    return version_tuple(remote) > version_tuple(local)


def check(local_version):
    """Read version.json from GitHub (in a thread). Returns the dictionary with "newer" True/False."""
    raw = http_get(VERSION_URL + "?t=%d" % int(time.time() // 600), timeout=15)
    if not raw:
        raise UpdateError(_("empty reply from GitHub"))
    try:
        info = json.loads(
            raw.decode(
                "utf-8",
                "replace") if isinstance(
                raw,
                bytes) else raw)
    except ValueError:
        raise UpdateError(_("invalid version.json"))
    if not isinstance(info, dict) or not info.get("version"):
        raise UpdateError(_("version.json without a version"))
    changes = info.get("changes") or []
    if not isinstance(changes, list):
        changes = [u"%s" % changes]
    result = {
        "version": u"%s" % info["version"],
        "date": u"%s" % (info.get("date") or u""),
        "file": u"%s" % (info.get("file") or u""),
        "sha256": u"%s" % (info.get("sha256") or u"").lower(),
        "size": int(info.get("size") or 0),
        "changes": [u"%s" % c for c in changes][:30],
        "checked": int(time.time()),
    }
    result["newer"] = is_newer(result["version"], local_version)
    _save_state(result)
    return result


def last_check():
    try:
        with open(STATE_FILE) as f:
            return json.load(f)
    except (IOError, OSError, ValueError):
        return None


def _save_state(info):
    try:
        folder = os.path.dirname(STATE_FILE)
        if not os.path.isdir(folder):
            os.makedirs(folder)
        with open(STATE_FILE, "w") as f:
            json.dump(info, f)
    except (IOError, OSError):
        pass


def license_ok():
    """True when the license is disabled in the plugin, or when the box is active on the server."""
    try:
        from . import license_box
    except Exception:
        return True
    if license_box.DEMO or not license_box.SERVER_URL.startswith("https://"):
        return True
    box_id = license_box.read_box_id()
    result = license_box.license_status(box_id) if box_id else None
    return bool(result and result.get("result") ==
                "ok" and result.get("state") == "active")


def _check_members(tar):
    for m in tar.getmembers():
        name = m.name.lstrip("./")
        if not name or name in (
            "usr",
            "usr/lib",
            "usr/lib/enigma2",
            "usr/lib/enigma2/python",
            "usr/lib/enigma2/python/Plugins",
            "usr/lib/enigma2/python/Plugins/Extensions",
                PREFIX.rstrip("/")):
            continue
        if not name.startswith(PREFIX) or ".." in name.split(
                "/") or m.issym() or m.islnk() or m.isdev():
            raise UpdateError(
                _("the package contains a misplaced file: %s") % name[:80])


def install(info, progress=None, root="/"):
    """Download, check and install (in a thread). Raises UpdateError when something is wrong."""
    url = info.get("file") or u""
    if not url.startswith(u"https://"):
        raise UpdateError(_("invalid package address"))
    if not license_ok():
        raise UpdateError(_("updates are reserved for authorized boxes"))
    if progress:
        progress(_("Downloading version %s...") % info.get("version"))
    data = http_get(url, timeout=60)
    if not data:
        raise UpdateError(_("empty download"))
    if len(data) > MAX_SIZE or (
        info.get("size") and len(data) != int(
            info["size"])):
        raise UpdateError(_("unexpected package size"))
    digest = hashlib.sha256(data).hexdigest()
    if not info.get("sha256") or digest != info["sha256"]:
        raise UpdateError(
            _("sha256 check failed: damaged or different package"))
    with open(TMP_FILE, "wb") as f:
        f.write(data)
    if progress:
        progress(_("Installing..."))
    try:
        with tarfile.open(TMP_FILE, "r:gz") as tar:
            _check_members(tar)
            members = [m for m in tar.getmembers() if m.isfile() or m.isdir()]
            for m in members:
                m.mode = (m.mode | 0o644) & 0o755
                m.uid = m.gid = 0
            try:
                tar.extractall(
                    root,
                    members=members,
                    filter="fully_trusted")   # already checked above
            except TypeError:                                                     # older Python
                tar.extractall(root, members=members)
    except tarfile.TarError as e:
        raise UpdateError(_("unreadable package: %s") % e)
    finally:
        try:
            os.remove(TMP_FILE)
        except OSError:
            pass
    _clean_pyc(os.path.join(root, PREFIX))
    return info.get("version")


def _clean_pyc(folder):
    """Remove old .pyc files: Python recompiles the new files at restart."""
    for base, dirs, files in os.walk(folder):
        for name in files:
            if name.endswith((".pyc", ".pyo")):
                try:
                    os.remove(os.path.join(base, name))
                except OSError:
                    pass
