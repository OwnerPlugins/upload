# -*- coding: utf-8 -*-
"""Tidy up the VOD lists of providers that also put series in them.

- Fake rows like "==NEW IN CINEMAS==" -> headers (kind "sep"), not playable.
- Episodes written in many ways -> grouped into one entry per series (kind "vodgroup"):
    "Breaking Bad S01E02", "Lost 2x05", "Mare Fuori 6 ep1",
    "Gomorra Stagione 3 Episodio 4", "Doc ep 7" (season 1), "Dark Season 2 Episode 3"
Provider titles may be Italian or English, so both keyword sets are matched.
No Enigma2 dependency: it can be tested on a PC."""

import re

from . import _
from .tmdb import clean_title

SEP = "sep"
GROUP = "vodgroup"

_SEPARATOR = re.compile(
    r"^\s*([=\-#*_~═─]{2,}|[\[\(\|]{1,2}\s*[=\-#*]+).*?([=\-#*_~═─]{2,}|[=\-#*]+\s*[\]\)\|]{1,2})\s*$")

_D = r"[\s._\-–|:]"          # separators between name and numbering
_SEASON = r"(?:stagione|season)"
_EPISODE = r"(?:episodio|episode|ep\.?|puntata)"
_PATTERNS = [
    # Breaking Bad S01E02 / S1 E2 / s01.e02
    re.compile(
        r"^(?P<n>.*?)%s*\bS(?P<s>\d{1,2})%s*E(?P<e>\d{1,3})\b" %
        (_D, _D), re.I),
    # Lost 2x05
    re.compile(r"^(?P<n>.*?)%s+(?P<s>\d{1,2})x(?P<e>\d{1,3})\b" % _D, re.I),
    # Gomorra Stagione 3 Episodio 4 / Stagione 3 - Ep. 4 / Season 3 Episode 4
    re.compile(r"^(?P<n>.*?)%s*\b%s%s*(?P<s>\d{1,2})[\s._\-–|:,]*%s%s*(?P<e>\d{1,3})\b"
               % (_D, _SEASON, _D, _EPISODE, _D), re.I),
    # Mare Fuori 6 ep1 / Mare Fuori 6 ep. 1 / Mare Fuori 6 episodio 1
    re.compile(
        r"^(?P<n>.*?)\s+(?P<s>\d{1,2})\s*%s\s*(?P<e>\d{1,3})\b" %
        _EPISODE, re.I),
    # Doc ep 7 / Doc - Episode 7  (season 1)
    re.compile(
        r"^(?P<n>.*?)%s+%s%s*(?P<e>\d{1,3})\b" %
        (_D, _EPISODE, _D), re.I),
]


def is_separator(name):
    return bool(_SEPARATOR.match(name or ""))


def separator_text(name):
    text = re.sub(r"[=\-#*_~\[\]\(\)\|═─]+", " ", name or "")
    return re.sub(r"\s{2,}", " ", text).strip()


def parse_episode(name):
    """Return (series_name, season, episode) or None when it is not an episode."""
    for pattern in _PATTERNS:
        m = pattern.match(name or "")
        if not m:
            continue
        series = clean_title(m.group("n"))[0]
        series = series.strip(" -|:–")
        if len(series) < 2:
            continue
        season = int(m.groupdict().get("s") or 1)
        return series, season, int(m.group("e"))
    return None


def organize(items):
    """Server VOD list -> list with headers and grouped series.
    The provider order is kept: a series appears where its first episode was."""
    out = []
    groups = {}
    for index, item in enumerate(items):
        name = item.get("name") or ""
        if is_separator(name):
            out.append({"kind": SEP, "id": "sep%d" %
                       index, "name": separator_text(name)})
            continue
        found = parse_episode(name)
        if not found:
            out.append(item)
            continue
        series, season, episode = found
        key = series.lower()
        group = groups.get(key)
        if group is None:
            group = {
                "kind": GROUP,
                "id": "g:" + key,
                "name": series,
                "icon": item.get(
                    "icon",
                    ""),
                "cat": item.get(
                    "cat",
                    ""),
                "year": "",
                "rating": "",
                "tmdb": "",
                "added": item.get(
                    "added",
                    ""),
                "episodes": []}
            groups[key] = group
            out.append(group)
        group["episodes"].append({
            "kind": item.get("kind"), "id": item["id"], "ext": item.get("ext", "mp4"),
            "season": season, "episode": episode, "name": name, "plot": "",
            "duration": "", "image": item.get("icon", ""), "rating": "",
        })
        if (item.get("added") or "") > (group["added"] or ""):
            group["added"] = item["added"]
    for group in groups.values():
        group["episodes"].sort(key=lambda e: (e["season"], e["episode"]))
    return out


def seasons_of(group):
    """{season: [episodes]} for the series screen."""
    seasons = {}
    for ep in group.get("episodes", []):
        seasons.setdefault(ep["season"], []).append(ep)
    return seasons


def summary(group):
    """'11 ep.' or '2 seas. • 20 ep.'"""
    eps = group.get("episodes", [])
    n_seasons = len(set(e["season"] for e in eps))
    if n_seasons > 1:
        return _(u"%d seas. \u2022 %d ep.") % (n_seasons, len(eps))
    return _("%d ep.") % len(eps)
