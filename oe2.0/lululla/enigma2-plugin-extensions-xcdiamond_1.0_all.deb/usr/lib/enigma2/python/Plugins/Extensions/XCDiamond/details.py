# -*- coding: utf-8 -*-
"""Detail pages: movies (backdrop, poster, TMDB data) and series (seasons, episodes with stills)."""

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.ScrollLabel import ScrollLabel

from .help import open_help
from . import _, ngettext, core
from .net import run_async
from .vodseries import GROUP, seasons_of, parse_episode
from .ui import (
    T,
    XCDList,
    ImageLoader,
    scale_skin,
    footer,
    clock,
    merge_info,
    meta_line,
    BG,
    PANEL,
    TEXT,
    DIM,
    ACCENT,
    SEL,
    GOLD,
    C_DIM,
    C_GOLD,
    veil_path)


def _backdrop_skin():
    # A semi-transparent eLabel does NOT blend on the receiver: it replaces the pixels and "punches"
    # through to the TV video. A PNG with alphatest="blend" really blends with
    # the background.
    return (
        '<widget name="backdrop" position="0,0" size="1920,1080" zPosition="-2" />'
        '<ePixmap pixmap="%s" position="0,0" size="1920,1080" alphatest="blend" zPosition="-1" />' %
        veil_path())


class _InfoScreen(Screen):
    """Shared parts: backdrop, poster, favorites, safe closing."""

    def _common_init(self, item):
        core.load_keymap()
        self.alive = True
        self.item = item
        self["backdrop"] = Pixmap()
        self["poster"] = Pixmap()
        self["logo"] = Pixmap()
        self["bar_blue"] = Label("")
        self["key_blue"] = Label("")
        self.trailer_key = ""
        self.logo = ImageLoader(
            self,
            "logo",
            transparent=True,
            on_show=self._logo_shown)
        self.backdrop = ImageLoader(self, "backdrop")
        self.poster = ImageLoader(self, "poster", fallback="poster")
        self.onClose.append(self._closed)

    def _closed(self):
        self.alive = False

    # ---------- title logo and trailer (shared by movies and series) --------
    def _logo_shown(self):
        # the official logo is there: the written title is not needed
        self["title"].hide()

    def _set_extras(self, info):
        if info.get("logo"):
            self.logo.load(info["logo"])
        else:
            self.logo.clear()
            self["title"].show()
        self.trailer_key = info.get("trailer") or ""
        if self.trailer_key:
            self["bar_blue"].show()
            self["key_blue"].setText(T(_("Trailer")))
        else:
            self["bar_blue"].hide()
            self["key_blue"].setText("")

    def play_trailer(self):
        if getattr(self, "trailer_busy", False):
            return
        if not self.trailer_key:
            self.session.open(MessageBox,
                              T(_("TMDB has no trailer for this title.")),
                              MessageBox.TYPE_INFO,
                              timeout=4)
            return
        from . import trailer
        if not trailer.available():
            self.session.open(
                MessageBox,
                T(
                    _("Trailers need yt-dlp.\n\nFrom Telnet:\nopkg update && opkg install python3-yt-dlp")),
                MessageBox.TYPE_INFO)
            return
        self.trailer_busy = True
        self["key_blue"].setText(T(_("Trailer: please wait...")))
        title = self["title"].getText()
        key = self.trailer_key

        def ready(result):
            self.trailer_busy = False
            if not self.alive:
                return
            url, error = result if isinstance(
                result, tuple) else (
                u"", u"%s" %
                result)
            self["key_blue"].setText(T(_("Trailer")))
            if not url:
                self.session.open(MessageBox, T( _("Trailer not available.") + (
                    u"\n\n" + error if error else u"")), MessageBox.TYPE_INFO, timeout=8)
                return
            from .player import XCDPlayer
            self.session.open(XCDPlayer,
                              [{"kind": "trailer",
                                "id": key,
                                "name": _("Trailer") + u"  \u2014  " + title,
                                  "direct_url": url,
                                  "info": getattr(self,
                                                  "info",
                                                  None)}],
                              0)
        run_async(trailer.resolve, (key,), callback=ready,
                  errback=lambda e: ready((u"", u"%s" % e)))

    def toggle_fav(self):
        added = core.favorites.toggle(self.item)
        self["key_yellow"].setText(T(_fav_text(added)))

    def _fav_label(self):
        return T(_fav_text(core.favorites.contains(self.item)))


# ======================================================================
# Movies
# ======================================================================
class MovieScreen(_InfoScreen):
    skin = scale_skin(
        """
    <screen name="XCDMovie" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="%(bg)s">
        %(backdrop)s
        <widget name="poster" position="80,120" size="460,690" alphatest="blend" zPosition="2" />
        <widget name="title" position="600,110" size="1260,76" font="Regular;56" foregroundColor="%(text)s" backgroundColor="%(bg)s" transparent="1" />
        <widget name="logo" position="600,86" size="900,110" alphatest="blend" zPosition="2" />
        <widget name="bar_blue" position="1410,990" size="8,40" backgroundColor="#003b82f6" />
        <widget name="key_blue" position="1430,990" size="400,40" font="Regular;28" valign="center" foregroundColor="%(text)s" backgroundColor="%(bg)s" transparent="1" />
        <widget name="tagline" position="600,190" size="1260,40" font="Regular;28" foregroundColor="%(dim)s" backgroundColor="%(bg)s" transparent="1" />
        <widget name="meta" position="600,240" size="1260,44" font="Regular;30" foregroundColor="%(gold)s" backgroundColor="%(bg)s" transparent="1" />
        <widget name="lbl_dir" position="600,310" size="170,38" font="Regular;26" foregroundColor="%(dim)s" backgroundColor="%(bg)s" transparent="1" />
        <widget name="director" position="780,310" size="1080,38" font="Regular;26" foregroundColor="%(text)s" backgroundColor="%(bg)s" transparent="1" />
        <widget name="lbl_cast" position="600,354" size="170,38" font="Regular;26" foregroundColor="%(dim)s" backgroundColor="%(bg)s" transparent="1" />
        <widget name="cast" position="780,354" size="1080,76" font="Regular;26" foregroundColor="%(text)s" backgroundColor="%(bg)s" transparent="1" />
        <widget name="lbl_country" position="600,436" size="170,38" font="Regular;26" foregroundColor="%(dim)s" backgroundColor="%(bg)s" transparent="1" />
        <widget name="country" position="780,436" size="1080,38" font="Regular;26" foregroundColor="%(text)s" backgroundColor="%(bg)s" transparent="1" />
        <eLabel position="600,494" size="1260,2" backgroundColor="%(accent)s" />
        <widget name="plot" position="600,515" size="1260,390" font="Regular;30" foregroundColor="%(text)s" backgroundColor="%(bg)s" transparent="1" />
        <widget name="source" position="80,830" size="460,36" font="Regular;22" halign="center" foregroundColor="%(dim)s" backgroundColor="%(bg)s" transparent="1" />
        %(clock)s
        %(footer)s
    </screen>""" %
        dict(
            bg=BG, text=TEXT, dim=DIM, gold=GOLD, accent=ACCENT, backdrop=_backdrop_skin(), clock=clock(), footer=footer(
                labels=(
                    "key_red", "key_green", "key_yellow"))))

    def __init__(self, session, item, info=None):
        Screen.__init__(self, session)
        self._common_init(item)
        # data already found by the list (may be None)
        self.pre_info = info
        self["title"] = Label(T(item.get("name", "")))
        self["tagline"] = Label("")
        self["meta"] = Label("")
        self["lbl_dir"] = Label(T(_("Director")))
        self["director"] = Label("")
        self["lbl_cast"] = Label(T(_("Cast")))
        self["cast"] = Label("")
        self["lbl_country"] = Label(T(_("Country")))
        self["country"] = Label("")
        self["plot"] = ScrollLabel(T(_("Loading details...")))
        self["source"] = Label("")
        self["key_red"] = Label(T(_("Back")))
        self["key_green"] = Label(T(_("Play")))
        self["key_yellow"] = Label(self._fav_label())
        self["actions"] = ActionMap(["OkCancelActions",
                                     "ColorActions",
                                     "DirectionActions",
                                     "XCDActions"],
                                    {"ok": self.play,
                                     "green": self.play,
                                     "cancel": self.close,
                                     "red": self.close,
                                     "yellow": self.toggle_fav,
                                     "blue": self.play_trailer,
                                     "menu": self.download_menu,
                                     "help": lambda: open_help(self.session,
                                                               "details"),
                                     "up": lambda: self["plot"].pageUp(),
                                     "down": lambda: self["plot"].pageDown(),
                                     },
                                    -1)
        self.onLayoutFinish.append(self._load)

    def _load(self):
        # no Trailer key until we know there is one
        self._set_extras({})
        info = self.pre_info
        if info and info.get("ext"):
            # the list already has everything: show it now, no more requests
            self.item["ext"] = info["ext"]
            self._show(info)
            return
        if info:
            self._show(info)                 # meanwhile show what is there
        else:
            if not core.tmdb().enabled:          # with TMDB the poster comes with the data
                self.poster.load(self.item.get("icon"))
        run_async(self._fetch, callback=self._show, errback=self._error)

    def _fetch(self):
        it = self.item
        xt = {}
        try:
            xt = core.client().vod_info(it["id"])
        except Exception:
            pass
        xt.setdefault("icon", it.get("icon"))
        tm = {}
        if core.tmdb().enabled:
            try:
                tm = core.tmdb().lookup(
                    "movie",
                    xt.get("name") or it["name"],
                    xt.get("year") or it.get("year"),
                    xt.get("tmdb") or it.get("tmdb"))
            except Exception:
                tm = {}
        info = merge_info(xt, tm, it["name"])
        if xt.get("ext"):
            it["ext"] = xt["ext"]
        return info

    def _show(self, info):
        if not self.alive:
            return
        self.info = info
        self["title"].setText(T(info["title"]))
        tagline = info["tagline"]
        if info["original_title"] and info["original_title"] != info["title"]:
            tagline = (
                u"%s  \u2014  %s" %
                (info["original_title"],
                 tagline)) if tagline else info["original_title"]
        self["tagline"].setText(T(tagline))
        self["meta"].setText(T(meta_line(info)))
        self["director"].setText(T(info["director"] or u"\u2014"))
        self["cast"].setText(T(info["cast"] or u"\u2014"))
        self["country"].setText(T(info["countries"] or u"\u2014"))
        self["plot"].setText(T(info["overview"] or _("Plot not available.")))
        src = _("Data: %s") % info["source"]
        if info["source"] != "TMDB" and not core.tmdb().enabled:
            src += u" " + _("(set the TMDB key)")
        self["source"].setText(T(src))
        self.poster.load(info["poster"])
        self.backdrop.load(info["backdrop"])
        self._set_extras(info)

    def _error(self, err):
        if self.alive:
            self["plot"].setText(T(_("Cannot load the details: %s") % err))

    def download_menu(self):
        """MENU: put the movie in the download panel."""
        from Screens.ChoiceBox import ChoiceBox

        def done(choice):
            if choice and self.alive:
                core.add_download(self.session, self.item)
        self.session.openWithCallback(done, ChoiceBox, title=T(
            self.item.get("name", u"")), list=[(T(_("Add to downloads")), "download")])

    def play(self):
        from .player import XCDPlayer
        item = dict(self.item)
        # poster, plot and cast in the player too (INFO)
        item["info"] = getattr(self, "info", None)
        self.session.open(XCDPlayer, [item], 0)


# ======================================================================
# TV series
# ======================================================================
class SeriesScreen(_InfoScreen):
    skin = scale_skin(
        """
    <screen name="XCDSeries" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="%(bg)s">
        %(backdrop)s
        <widget name="poster" position="60,50" size="260,390" alphatest="blend" zPosition="2" />
        <widget name="title" position="360,50" size="1300,66" font="Regular;48" foregroundColor="%(text)s" backgroundColor="%(bg)s" transparent="1" />
        <widget name="logo" position="360,34" size="800,86" alphatest="blend" zPosition="2" />
        <widget name="bar_blue" position="1410,990" size="8,40" backgroundColor="#003b82f6" />
        <widget name="key_blue" position="1430,990" size="400,40" font="Regular;28" valign="center" foregroundColor="%(text)s" backgroundColor="%(bg)s" transparent="1" />
        %(clock)s
        <widget name="meta" position="360,120" size="1500,40" font="Regular;28" foregroundColor="%(gold)s" backgroundColor="%(bg)s" transparent="1" />
        <widget name="plot" position="360,170" size="1500,190" font="Regular;26" foregroundColor="%(text)s" backgroundColor="%(bg)s" transparent="1" />
        <widget name="cast" position="360,370" size="1500,70" font="Regular;24" foregroundColor="%(dim)s" backgroundColor="%(bg)s" transparent="1" />
        <eLabel position="60,460" size="1800,2" backgroundColor="%(accent)s" />
        <widget name="seasons" position="60,480" size="360,496" itemHeight="62" backgroundColor="%(panel)s" backgroundColorSelected="%(sel)s" scrollbarMode="showOnDemand" />
        <widget name="episodes" position="440,480" size="840,496" itemHeight="62" backgroundColor="%(panel)s" backgroundColorSelected="%(sel)s" scrollbarMode="showOnDemand" />
        <eLabel position="1300,480" size="560,490" backgroundColor="%(panel)s" zPosition="-1" />
        <widget name="still" position="1300,480" size="560,315" alphatest="blend" zPosition="2" />
        <widget name="ep_title" position="1320,805" size="520,40" font="Regular;26" foregroundColor="%(text)s" backgroundColor="%(panel)s" transparent="1" />
        <widget name="ep_plot" position="1320,848" size="520,118" font="Regular;21" foregroundColor="%(dim)s" backgroundColor="%(panel)s" transparent="1" />
        %(footer)s
    </screen>""" %
        dict(
            bg=BG, panel=PANEL, text=TEXT, dim=DIM, gold=GOLD, accent=ACCENT, sel=SEL, backdrop=_backdrop_skin(), clock=clock(), footer=footer(
                labels=(
                    "key_red", "key_green", "key_yellow"))))

    def __init__(self, session, item, info=None):
        Screen.__init__(self, session)
        self._common_init(item)
        self.pre_info = info
        self.focus = "seasons"
        self.seasons = {}          # {number: [episodes]}
        self.tm_seasons = {}       # TMDB data cache per season
        self.tmdb_id = ""
        self["title"] = Label(T(item.get("name", "")))
        self["meta"] = Label("")
        self["plot"] = Label(T(_("Loading...")))
        self["cast"] = Label("")
        self["seasons"] = XCDList(font_size=30, item_height=62)
        self["episodes"] = XCDList(font_size=28, item_height=62)
        self["still"] = Pixmap()
        self["ep_title"] = Label("")
        self["ep_plot"] = Label("")
        self.still = ImageLoader(self, "still", fallback="image")
        self["key_red"] = Label(T(_("Back")))
        self["key_green"] = Label(T(_("Play")))
        self["key_yellow"] = Label(self._fav_label())
        self["actions"] = ActionMap(["OkCancelActions",
                                     "ColorActions",
                                     "DirectionActions",
                                     "XCDActions"],
                                    {"ok": self.ok,
                                     "green": self.play,
                                     "cancel": self.back,
                                     "red": self.close,
                                     "yellow": self.toggle_fav,
                                     "blue": self.play_trailer,
                                     "menu": self.download_menu,
                                     "help": lambda: open_help(self.session,
                                                               "details"),
                                     "up": lambda: self.move("up"),
                                     "down": lambda: self.move("down"),
                                     "pageUp": lambda: self.move("pageUp"),
                                     "pageDown": lambda: self.move("pageDown"),
                                     "left": lambda: self._set_focus("seasons"),
                                     "right": self._to_episodes,
                                     },
                                    -1)
        self.onLayoutFinish.append(self._load)

    # ------------------------------------------------------------------
    def _load(self):
        info = self.pre_info
        self._set_extras(info or {})
        if info:                             # poster, backdrop and plot at once; episodes come later
            self.series_poster = info["poster"]
            self.poster.load(info["poster"])
            self.backdrop.load(info["backdrop"])
            self.series_backdrop = info["backdrop"]
            self["title"].setText(T(info["title"]))
            self["meta"].setText(T(meta_line(info)))
            self["plot"].setText(T((info["overview"] or u"")[:520]))
        else:
            if not core.tmdb().enabled:          # with TMDB the poster comes with the data
                self.poster.load(self.item.get("icon"))
        self._set_focus("seasons")
        run_async(self._fetch, callback=self._show, errback=self._error)

    def _fetch(self):
        it = self.item
        if it.get(
                "kind") == GROUP:            # series found inside VOD: we already have the episodes
            xt = {
                "name": it["name"],
                "plot": "",
                "tmdb": it.get(
                    "tmdb",
                    ""),
                "year": it.get(
                    "year",
                    ""),
                "poster": "",
                "backdrop": "",
                "seasons": seasons_of(it)}
        else:
            xt = core.client().series_info(it["id"])
        tm = {}
        if core.tmdb().enabled:
            try:
                tm = core.tmdb().lookup("tv", xt.get("name") or it["name"], xt.get(
                    "year") or it.get("year"), xt.get("tmdb") or it.get("tmdb"))
            except Exception:
                tm = {}
        xt.setdefault("icon", it.get("icon"))
        return xt, merge_info(xt, tm, it["name"])

    def _show(self, result):
        if not self.alive:
            return
        xt, info = result
        # for the player: series poster and cast
        self.series_meta = info
        self.seasons = xt["seasons"]
        self.tmdb_id = info["tmdb"]
        self["title"].setText(T(info["title"]))
        meta = meta_line(info)
        n = info.get("seasons_count") or len(self.seasons)
        if n:
            meta += u"   \u2022   " + \
                ngettext("%d season", "%d seasons", n) % n
        self["meta"].setText(T(meta))
        plot = info["overview"] or _("Plot not available.")
        self["plot"].setText(
            T(plot[:520] + (u"\u2026" if len(plot) > 520 else u"")))
        self["cast"].setText(
            T((_("Cast:") + u"  " + info["cast"]) if info["cast"] else u""))
        self.poster.load(info["poster"])
        self.backdrop.load(info["backdrop"])
        self.series_backdrop = info["backdrop"]
        self.series_poster = info["poster"]
        self._set_extras(info)
        sl = self["seasons"]
        nums = sorted(self.seasons)
        if not nums:
            sl.set_entries([sl.entry(None, _("No episodes"), color=C_DIM)])
            return
        sl.set_entries([sl.entry(n, _("Season %d") %
                                 n if n else _("Specials"), _("%d ep.") %
                                 len(self.seasons[n]), right_w=100) for n in nums])
        self._fill_episodes()

    def _error(self, err):
        if self.alive:
            self["plot"].setText(T(_("Cannot load the series: %s") % err))

    # ------------------------------------------------------------------
    def _season_poster(self, season):
        """Poster of the selected season (when TMDB has one), otherwise the series poster."""
        poster = self.tm_seasons.get(
            season, {}).get("poster") or getattr(
            self, "series_poster", u"")
        if poster:
            self.poster.load(poster)

    def _fill_episodes(self):
        season = self["seasons"].current()
        self._season_poster(season)
        eps = self.seasons.get(season, [])
        el = self["episodes"]
        tm = self.tm_seasons.get(season, {})
        entries = []
        for ep in eps:
            t = tm.get(ep["episode"], {})
            name = t.get("title") or _episode_title(
                ep, self.item.get("name", ""))
            res = core.resume.get(ep) if core.cfg.resume.value else 0
            right = (
                u"\u25b6 %d min" %
                (res //
                 60)) if res else _duration(
                ep.get("duration"))
            entries.append(
                el.entry(
                    ep, u"%02d   %s" %
                    (ep["episode"], name), right, C_GOLD if res else C_DIM))
        el.set_entries(
            entries or [
                el.entry(
                    None,
                    _("No episodes"),
                    color=C_DIM)])
        self._show_episode()
        if season is not None and season not in self.tm_seasons and self.tmdb_id and core.tmdb().enabled:
            self.tm_seasons[season] = {}
            run_async(
                core.tmdb().season,
                (self.tmdb_id,
                 season),
                callback=lambda data: self._tm_season_ok(
                    season,
                    data),
                errback=lambda e: None)

    def _tm_season_ok(self, season, data):
        if not self.alive:
            return
        self.tm_seasons[season] = data or {}
        if self["seasons"].current() == season:
            index = self["episodes"].getSelectedIndex()
            self._fill_episodes()
            self["episodes"].moveToIndex(index)
            self._show_episode()

    def _show_episode(self):
        ep = self["episodes"].current()
        if not ep:
            self["ep_title"].setText("")
            self["ep_plot"].setText("")
            self.still.clear()
            return
        t = self.tm_seasons.get(ep["season"], {}).get(ep["episode"], {})
        title = u"S%02dE%02d  %s" % (ep["season"], ep["episode"], t.get(
            "title") or _episode_title(ep, self.item.get("name", "")))
        self["ep_title"].setText(T(title))
        plot = t.get("overview") or ep.get("plot") or u""
        extra = u"  \u2022  ".join(
            x for x in (
                t.get("air_date"),
                (u"\u2605 " + t["rating"]) if t.get("rating") else u"") if x)
        self["ep_plot"].setText(
            T((extra + u"\n" if extra else u"") + plot[:260]))
        # episode still: TMDB, then server, then series backdrop, then
        # placeholder
        self.still.load(
            t.get("still") or ep.get("image") or getattr(
                self, "series_backdrop", u""))

    # ------------------------------------------------------------------
    def _set_focus(self, which):
        self.focus = which
        self["seasons"].focus(which == "seasons")
        self["episodes"].focus(which == "episodes")

    def move(self, direction):
        self[self.focus].move(direction)
        if self.focus == "seasons":
            self._fill_episodes()
        else:
            self._show_episode()

    def _to_episodes(self):
        if self["episodes"].current():
            self._set_focus("episodes")
            self._show_episode()

    def ok(self):
        if self.focus == "seasons":
            self._to_episodes()
        else:
            self.play()

    def back(self):
        if self.focus == "episodes":
            self._set_focus("seasons")
        else:
            self.close()

    def _download_item(self, ep):
        tm = self.tm_seasons.get(ep["season"], {}).get(ep["episode"], {})
        return dict(
            ep, series_name=_short_episode_name(
                self.item.get(
                    "name", ""), ""), title=tm.get("title") or _episode_title(
                ep, self.item.get(
                    "name", "")))

    def download_menu(self):
        """MENU: put the episode or the whole season in the download panel."""
        from Screens.ChoiceBox import ChoiceBox
        ep = self["episodes"].current()
        season = ep["season"] if ep else (
            self["seasons"].current() if self.seasons else None)
        if season is None:
            return
        choices = []
        if ep and self.focus == "episodes":
            choices.append((T(_("Add this episode to the downloads")), "one"))
        choices.append(
            (T(_("Add the whole season %d to the downloads") % season), "season"))

        def done(choice):
            if not choice or not self.alive:
                return
            if choice[1] == "one":
                core.add_download(self.session, self._download_item(ep))
            else:
                eps = self.seasons.get(season, [])
                added = sum(
                    1 for e in eps if core.add_download(
                        self.session,
                        self._download_item(e),
                        quiet=True))
                self.session.open(
                    MessageBox, T(
                        _("%d episodes added to the downloads.\nOpen Home > Downloads to choose when.") %
                        added), MessageBox.TYPE_INFO, timeout=4)
        self.session.openWithCallback(
            done, ChoiceBox, title=T(
                self.item.get(
                    "name", u"")), list=choices)

    def play(self):
        ep = self["episodes"].current()
        if not ep:
            if self.focus == "seasons":
                return self._to_episodes()
            return
        season = ep["season"]
        eps = self.seasons.get(season, [])
        tm = self.tm_seasons.get(season, {})
        series_name = self.item.get("name", "")
        short_series = _short_episode_name(series_name, "")
        playlist = []
        for e in eps:
            e = dict(e)
            t = tm.get(e["episode"], {})
            e["subtitle"] = t.get("title") or _episode_title(e, series_name)
            e["name"] = u"%s  \u2014  S%02dE%02d" % (
                short_series, e["season"], e["episode"])
            e["plot"] = t.get("overview") or e.get("plot") or u""
            e["image"] = t.get("still") or e.get("image") or u""
            e["info"] = getattr(self, "series_meta", None)
            e["series_name"] = short_series
            e["icon"] = (e["info"] or {}).get("poster") or self.item.get(
                "icon") or u""   # for "Continue watching"
            playlist.append(e)
        index = eps.index(ep) if ep in eps else 0
        from .player import XCDPlayer
        self.session.openWithCallback(
            lambda *a: self.alive and self._after_play(),
            XCDPlayer,
            playlist,
            index,
            self._remember_index)

    def _remember_index(self, index):
        self._last_index = index

    def _after_play(self):
        index = getattr(
            self,
            "_last_index",
            self["episodes"].getSelectedIndex())
        self._fill_episodes()           # update the "resume" marks
        self["episodes"].moveToIndex(index)
        self._show_episode()


def _fav_text(is_favorite):
    return u"\u2665 " + (_("Remove") if is_favorite else _("Favorite"))


def _duration(text):
    """'00:42:10' -> '42 min'"""
    parts = (text or "").split(":")
    try:
        if len(parts) == 3:
            mins = int(parts[0]) * 60 + int(parts[1])
            return (u"%d min" % mins) if mins else u""
    except ValueError:
        pass
    return u""


def _episode_title(ep, series_name):
    """Readable episode title without TMDB: the server one or 'Episode N'."""
    import re
    if parse_episode(
        ep.get(
            "name",
            "")):        # "Mare Fuori 6 ep1", "S01E02"... carry no title
        return _("Episode %d") % ep.get("episode", 0)
    text = _short_episode_name(ep.get("name", ""), series_name)
    if not text or re.match(r"^(S\d+\s*E\d+|\d+)$", text.strip(), re.I):
        return _("Episode %d") % ep.get("episode", 0)
    return text


def _short_episode_name(name, series_name):
    """Remove the series name and prefixes like 'IT - ' from the episode title."""
    from .tmdb import clean_title
    text = name or u""
    if series_name and text.lower().startswith(series_name.lower()):
        text = text[len(series_name):]
    text = text.strip(u" -|:\u2014")
    cleaned = clean_title(text)[0]
    return cleaned or text or name
