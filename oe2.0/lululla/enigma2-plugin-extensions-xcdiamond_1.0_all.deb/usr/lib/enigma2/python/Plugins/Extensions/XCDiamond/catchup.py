# -*- coding: utf-8 -*-
"""Catchup: past programmes of a channel with archive (tv_archive), played through /timeshift/.

Left: days (today, yesterday, ...). Right: programmes of the day. Bright rows are in the
archive and can be played; dim rows are not (yet) recorded by the server."""

import time

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label

from .help import open_help
from . import _, ngettext, core
from .net import run_async
from .ui import (
    T,
    XCDList,
    scale_skin,
    footer,
    clock,
    BG,
    PANEL,
    TEXT,
    DIM,
    ACCENT,
    SEL,
    GOLD,
    C_TEXT,
    C_DIM,
    C_GOLD)


def N_(text):
    return text


# the receiver usually has no system locale: weekday names go through gettext
WEEKDAYS = (
    N_("Mon"),
    N_("Tue"),
    N_("Wed"),
    N_("Thu"),
    N_("Fri"),
    N_("Sat"),
    N_("Sun"))


def _hm(ts):
    return time.strftime("%H:%M", time.localtime(ts))


def day_label(day_start, today_start):
    diff = int(round((today_start - day_start) / 86400.0))
    if diff == 0:
        return _("Today")
    if diff == 1:
        return _("Yesterday")
    if diff == -1:
        return _("Tomorrow")
    lt = time.localtime(day_start)
    return u"%s %02d/%02d" % (_(WEEKDAYS[lt.tm_wday]), lt.tm_mday, lt.tm_mon)


def _day_start(ts):
    lt = time.localtime(ts)
    return int(
        time.mktime(
            (lt.tm_year, lt.tm_mon, lt.tm_mday, 0, 0, 0, 0, 0, -1)))


def group_by_day(programmes, now=None):
    """[(day_start, [programmes])] newest day first; days after today are left out."""
    now = now or time.time()
    today = _day_start(now)
    days = {}
    for p in programmes:
        d = _day_start(p["start"])
        if d <= today:
            days.setdefault(d, []).append(p)
    return sorted(days.items(), reverse=True)


class CatchupScreen(Screen):
    skin = scale_skin("""
    <screen name="XCDCatchup" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="%(bg)s">
        <widget name="header" position="60,30" size="1300,60" font="Regular;44" noWrap="1" foregroundColor="%(text)s" backgroundColor="%(bg)s" transparent="1" />
        %(clock)s
        <eLabel position="60,110" size="1800,2" backgroundColor="%(panel)s" />
        <widget name="days" position="60,130" size="340,720" itemHeight="60" backgroundColor="%(bg)s" backgroundColorSelected="%(sel)s" scrollbarMode="showOnDemand" transparent="1" />
        <widget name="progs" position="430,130" size="1430,720" itemHeight="60" backgroundColor="%(bg)s" backgroundColorSelected="%(sel)s" scrollbarMode="showOnDemand" transparent="1" />
        <eLabel position="60,870" size="1800,110" backgroundColor="%(panel)s" zPosition="-1" />
        <widget name="desc" position="90,880" size="1740,90" font="Regular;26" foregroundColor="%(text)s" backgroundColor="%(panel)s" transparent="1" />
        %(footer)s
    </screen>""" % dict(bg=BG, panel=PANEL, text=TEXT, dim=DIM, accent=ACCENT, sel=SEL, gold=GOLD,
                        clock=clock(), footer=footer()))

    def __init__(self, session, channel):
        Screen.__init__(self, session)
        core.load_keymap()
        self.alive = True
        self.channel = channel
        self.days = []
        self.focus = "days"
        self["header"] = Label(
            T(_("Catchup") + u"  ›  " + channel.get("name", u"")))
        self["days"] = XCDList(font_size=30, item_height=60)
        self["progs"] = XCDList(font_size=30, item_height=60)
        self["desc"] = Label(T(_("Loading the archive...")))
        self["key_red"] = Label(T(_("Back")))
        self["key_green"] = Label(T(_("Play")))
        self["key_yellow"] = Label("")
        self["key_blue"] = Label("")
        self["actions"] = ActionMap(["OkCancelActions",
                                     "ColorActions",
                                     "DirectionActions",
                                     "XCDActions"],
                                    {"ok": self.ok,
                                     "green": self.play,
                                     "cancel": self.back,
                                     "red": self.close,
                                     "help": lambda: open_help(self.session,
                                                               "catchup"),
                                     "left": lambda: self._set_focus("days"),
                                     "right": lambda: self._set_focus("progs"),
                                     "up": lambda: self._move("up"),
                                     "down": lambda: self._move("down"),
                                     "pageUp": lambda: self._move("pageUp"),
                                     "pageDown": lambda: self._move("pageDown"),
                                     },
                                    -1)
        self.onLayoutFinish.append(self._start)
        self.onClose.append(self._closed)

    def _closed(self):
        self.alive = False

    def _start(self):
        self._set_focus("days")
        run_async(
            core.client().catchup_table,
            (self.channel["id"],
             ),
            callback=self._loaded,
            errback=self._error)

    def _loaded(self, programmes):
        if not self.alive:
            return
        self.days = group_by_day(programmes)
        if not self.days:
            self["days"].set_entries([])
            self["desc"].setText(
                T(_("The server has no archive for this channel.")))
            return
        today = _day_start(time.time())
        self["days"].set_entries([self["days"].entry(d, day_label(d, today), u"%d" % len(
            [p for p in progs if p["archived"]]), C_GOLD, right_w=70) for d, progs in self.days])
        self._fill_programmes()

    def _error(self, err):
        if self.alive:
            self["desc"].setText(T(_("Error: %s") % err))

    def _fill_programmes(self):
        index = self["days"].getSelectedIndex()
        if not (0 <= index < len(self.days)):
            return
        progs = self.days[index][1]
        lst = self["progs"]
        now = time.time()
        entries = []
        for p in progs:
            if p["archived"]:
                color, right = C_TEXT, u"▶"
            elif p["start"] <= now < p["stop"]:
                color, right = C_GOLD, _("on air")
            else:
                color, right = C_DIM, u""
            entries.append(
                lst.entry(
                    p, u"%s - %s   %s" %
                    (_hm(
                        p["start"]), _hm(
                        p["stop"]), p["title"]), right, C_GOLD, color=color, right_w=150))
        # start from the most recent programme in the archive
        last = max([i for i, p in enumerate(progs) if p["archived"]] or [0])
        lst.set_entries(entries, last)
        self._show_desc()

    def _show_desc(self):
        p = self["progs"].current(
        ) if self.focus == "progs" or self.days else None
        if not p:
            return self["desc"].setText(u"")
        text = p["title"] + (u"  —  " + p["desc"] if p.get("desc") else u"")
        if not p["archived"]:
            text = _("Not in the archive.") + u"  " + text
        self["desc"].setText(T(text[:300]))

    def _set_focus(self, which):
        if which == "progs" and not self.days:
            return
        self.focus = which
        self["days"].selectionEnabled(which == "days")
        self["progs"].selectionEnabled(which == "progs")
        self._show_desc()

    def _move(self, direction):
        lst = self[self.focus]
        lst.move(direction)
        if self.focus == "days":
            self._fill_programmes()
        else:
            self._show_desc()

    def ok(self):
        if self.focus == "days":
            self._set_focus("progs")
        else:
            self.play()

    def back(self):
        if self.focus == "progs":
            self._set_focus("days")
        else:
            self.close()

    def play(self):
        p = self["progs"].current() if self.days else None
        if not p:
            return
        if not p["archived"]:
            return self.session.open(
                MessageBox, T(
                    _("This programme is not in the archive.")), MessageBox.TYPE_INFO, timeout=3)
        from .player import XCDPlayer
        ch = self.channel
        days = ch.get("archive_days") or 3
        item = {
            "kind": "catchup",
            "id": "%s:%d" %
            (ch["id"],
             p["start"]),
            "name": u"%s  \u2014  %s" %
            (ch.get(
                "name",
                u""),
                p["title"]),
            "icon": ch.get("icon"),
            "plot": p.get("desc"),
            "direct_url": core.client().catchup_url(
                ch["id"],
                p),
            "expires": p["start"] +
            days *
            86400}  # the server deletes it from the archive then
        self.session.open(XCDPlayer, [item], 0)


def archive_sections(categories, channels):
    """[(category, [channels with archive])] in the server order; categories without archive are left out."""
    by_cat = {}
    for ch in channels:
        if ch.get("archive"):
            by_cat.setdefault(ch.get("cat", ""), []).append(ch)
    out = [(c, by_cat[c["id"]]) for c in categories if c["id"] in by_cat]
    known = set(c["id"] for c in categories)
    orphans = [
        ch for cid,
        chs in by_cat.items() if cid not in known for ch in chs]
    if orphans:
        out.append(({"id": "", "name": _("Other channels")}, orphans))
    return out


def _load_sections():
    """Runs in a thread: live categories + all live channels (one request each, cached by the client)."""
    from .api import LIVE
    client = core.client()
    cats = client.categories(LIVE)
    channels = core.filter_locked(LIVE, client.items(LIVE))
    sections = archive_sections(cats, channels)
    with_archive = sum(len(chs) for _cat, chs in sections)
    core.remember_catchup(with_archive > 0)
    print("[XCDiamond] catchup: %d live channels, %d with archive (%s)" %
          (len(channels), with_archive, client.server))
    return sections, len(channels)


class CatchupChannelsScreen(Screen):
    """Home > Catchup: only categories and channels that the server keeps in the archive."""
    skin = scale_skin("""
    <screen name="XCDCatchupChannels" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="%(bg)s">
        <widget name="header" position="60,30" size="1000,60" font="Regular;44" foregroundColor="%(text)s" backgroundColor="%(bg)s" transparent="1" />
        <widget name="count" position="760,42" size="880,40" font="Regular;28" halign="right" noWrap="1" foregroundColor="%(dim)s" backgroundColor="%(bg)s" transparent="1" />
        %(clock)s
        <eLabel position="60,110" size="1800,2" backgroundColor="%(panel)s" />
        <widget name="cats" position="60,130" size="620,840" itemHeight="60" backgroundColor="%(bg)s" backgroundColorSelected="%(sel)s" scrollbarMode="showOnDemand" transparent="1" />
        <widget name="chans" position="710,130" size="1150,840" itemHeight="60" backgroundColor="%(bg)s" backgroundColorSelected="%(sel)s" scrollbarMode="showOnDemand" transparent="1" />
        <widget name="empty" position="160,400" size="1600,240" font="Regular;32" halign="center" valign="center" foregroundColor="%(dim)s" backgroundColor="%(bg)s" transparent="1" />
        %(footer)s
    </screen>""" % dict(bg=BG, panel=PANEL, text=TEXT, dim=DIM, accent=ACCENT, sel=SEL, gold=GOLD,
                        clock=clock(), footer=footer()))

    def __init__(self, session):
        Screen.__init__(self, session)
        core.load_keymap()
        self.alive = True
        self.sections = []
        self.focus = "cats"
        self["header"] = Label(T(_("Catchup")))
        self["count"] = Label("")
        self["cats"] = XCDList(font_size=30, item_height=60)
        self["chans"] = XCDList(font_size=30, item_height=60)
        self["empty"] = Label(T(_("Loading the channels with archive...")))
        self["key_red"] = Label(T(_("Back")))
        self["key_green"] = Label(T(_("Open")))
        self["key_yellow"] = Label("")
        self["key_blue"] = Label("")
        self["actions"] = ActionMap(["OkCancelActions",
                                     "ColorActions",
                                     "DirectionActions",
                                     "XCDActions"],
                                    {"ok": self.ok,
                                     "green": self.ok,
                                     "cancel": self.back,
                                     "red": self.close,
                                     "help": lambda: open_help(self.session,
                                                               "catchup"),
                                     "left": lambda: self._set_focus("cats"),
                                     "right": lambda: self._set_focus("chans"),
                                     "up": lambda: self._move("up"),
                                     "down": lambda: self._move("down"),
                                     "pageUp": lambda: self._move("pageUp"),
                                     "pageDown": lambda: self._move("pageDown"),
                                     },
                                    -1)
        self.onLayoutFinish.append(self._start)
        self.onClose.append(self._closed)

    def _closed(self):
        self.alive = False

    def _start(self):
        self._set_focus("cats")
        run_async(_load_sections, callback=self._loaded, errback=self._error)

    def _loaded(self, result):
        if not self.alive:
            return
        sections, checked = result
        self.sections = sections
        if not sections:
            self["empty"].setText(T(_("No channel with catchup (archive) on this server.\n\n"
                                      "Checked: %d live channels of %s\n"
                                      "Only the server in use is checked: choose another one in Servers.") %
                                    (checked, core.client().server.split("://")[-1])))
            return
        self["empty"].setText(u"")
        total = sum(len(chs) for _cat, chs in sections)
        self["count"].setText(
            T(ngettext("%d channel with archive", "%d channels with archive", total) % total))
        self["cats"].set_entries([self["cats"].entry(i, cat["name"], u"%d" % len(
            chs), C_GOLD, right_w=90) for i, (cat, chs) in enumerate(sections)])
        self._fill_channels()

    def _error(self, err):
        if self.alive:
            self["empty"].setText(T(_("Error: %s") % err))

    def _fill_channels(self):
        index = self["cats"].getSelectedIndex()
        if not (0 <= index < len(self.sections)):
            return
        lst = self["chans"]
        lst.set_entries(
            [
                lst.entry(
                    ch, ch.get(
                        "name", u""), ngettext(
                        "%d day", "%d days", ch.get(
                            "archive_days", 0)) %
                    ch.get(
                        "archive_days", 0), C_GOLD, right_w=150) for ch in self.sections[index][1]])

    def _set_focus(self, which):
        if which == "chans" and not self.sections:
            return
        self.focus = which
        self["cats"].selectionEnabled(which == "cats")
        self["chans"].selectionEnabled(which == "chans")

    def _move(self, direction):
        self[self.focus].move(direction)
        if self.focus == "cats":
            self._fill_channels()

    def ok(self):
        if self.focus == "cats":
            return self._set_focus("chans")
        ch = self["chans"].current()
        if ch:
            self.session.open(CatchupScreen, ch)

    def back(self):
        if self.focus == "chans":
            self._set_focus("cats")
        else:
            self.close()
