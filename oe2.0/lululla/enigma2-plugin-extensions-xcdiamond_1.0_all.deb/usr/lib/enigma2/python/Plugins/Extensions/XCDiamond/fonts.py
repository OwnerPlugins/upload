# -*- coding: utf-8 -*-
"""Fallback fonts so scripts the box font lacks are not drawn as empty boxes.

Two replacement fonts are registered, in order; Enigma2 uses them only to fill glyphs
missing in the current skin font, so Latin text and the symbols stay as they are:

  1) DejaVu Sans         -> Latin/Cyrillic/Greek gaps and the symbols (star, heart, play).
  2) Noto Naskh Arabic   -> the Arabic PRESENTATION FORMS (U+FB50..U+FEFF) produced by
                            arabic_text.shape(). Without this font the shaped Arabic would
                            still be boxes, because DejaVu has almost no presentation forms.

Drop NotoNaskhArabic-Regular.ttf (OFL, free to redistribute) into this folder. Any of the
candidate names below is accepted, so an Arabic font already on the image can be used too.
"""

import os

from .ui import PLUGIN_DIR

FONT_DIR = os.path.join(PLUGIN_DIR, "fonts")

# (file, registered name) pairs, tried in order. Missing files are skipped.
LATIN_FONT = ("DejaVuSans.ttf", "XCDiamondFallback")
ARABIC_CANDIDATES = (
    "NotoNaskhArabic-Regular.ttf",
    "NotoSansArabic-Regular.ttf",
    "NotoNaskhArabic.ttf",
    "Amiri-Regular.ttf",
    "Traditional_Arabic.ttf",   # classic font, has the presentation forms the shaper needs
    "TraditionalArabic.ttf",
    "arial_arabic.ttf",
)

_done = False


def _add(filename, name):
    path = os.path.join(FONT_DIR, filename)
    if not os.path.exists(path):
        return False
    try:
        from enigma import addFont
        # (file, name, scale=100, is_replacement=1 -> global fallback for missing glyphs)
        addFont(path, name, 100, 1)
        print("[XCDiamond] fallback font registered: %s" % filename)
        return True
    except Exception as e:
        print("[XCDiamond] font %s: %s" % (filename, e))
        return False


def ensure_fonts():
    global _done
    if _done:
        return
    _done = True

    _add(LATIN_FONT[0], LATIN_FONT[1])

    for cand in ARABIC_CANDIDATES:
        if _add(cand, "XCDiamondArabic"):
            break
    else:
        print(
            "[XCDiamond] no Arabic font in %s -> Arabic may still show as boxes "
            "(add NotoNaskhArabic-Regular.ttf)" %
            FONT_DIR)
