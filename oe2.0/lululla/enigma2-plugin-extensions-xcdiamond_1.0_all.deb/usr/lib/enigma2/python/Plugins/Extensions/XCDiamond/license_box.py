# -*- coding: utf-8 -*-
"""Box authorization (MAC based) with the XC Diamond look.

Flow:
  1. The plugin reads the box MAC (eth0, then wlan0..3).
  2. It asks the license server (Google Apps Script, tools/license_server.gs) the state of
     that MAC for this plugin.
  3. unknown  -> registration form -> the server stores the row as "pending"
     pending  -> waiting screen; checks again every 30 seconds. The server can approve by
                 itself after N hours (sheet "settings", auto_approve_hours: 24 = one day, 0 = by hand)
     active   -> the plugin opens
     blocked  -> access denied
  4. The developer can also approve or block by hand in the Google Sheet ("state" column).

Protection: at registration the server gives the box a secret token, saved in
/etc/enigma2/<PLUGIN_ID>.lic; every request sends MAC + token, so copying the MAC of an
approved box is not enough. Valuable content goes in the "content" sheet and is asked
with protected_value("key"): only active boxes with a valid token receive it.

Settings are in license_settings.py (SERVER_URL, DEMO, CONTACT), so updates of this file
never overwrite them. DEMO = True shows the screen with made-up data: OK enters, YELLOW
shows the other states.
"""

import hashlib
import json
import os
import ssl
import time

try:  # Python 3
    from urllib.request import Request, urlopen
except ImportError:  # Python 2
    from urllib2 import Request, urlopen

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap

from . import _
from .ui import (
    T,
    ImageLoader,
    scale_skin,
    footer,
    clock,
    new_timer,
    PLUGIN_DIR,
    BG,
    PANEL,
    TEXT,
    DIM,
    ACCENT,
    SEL,
    GOLD)

# ============================================================
# SETTINGS
# ============================================================
PLUGIN_ID = "XCDiamond"            # goes into the "plugin" column of the sheet
try:                               # SERVER_URL, DEMO and CONTACT live in license_settings.py
    from .license_settings import SERVER_URL, DEMO, CONTACT
except ImportError:
    SERVER_URL, DEMO, CONTACT = "", True, "www.linuxsat-support.com"
CHECK_INTERVAL_MS = 30000          # automatic check while waiting for approval
LOG_FILE = "/tmp/license_box.log"
TOKEN_DIR = "/etc/enigma2"         # survives plugin updates

C_GREEN, C_AMBER, C_RED = "#007ddf7d", "#00e3b341", "#00ff6060"


def enabled():
    return DEMO or SERVER_URL.startswith("https://")


def write_log(msg):
    try:
        with open(LOG_FILE, "a") as f:
            f.write("[%s-license] %s\n" % (PLUGIN_ID, msg))
    except Exception:
        pass


# ============================================================
# MAC address and secret token
# ============================================================
def read_box_id():
    for iface in ["eth0"] + ["wlan%d" % i for i in range(4)]:
        path = "/sys/class/net/%s/address" % iface
        try:
            if os.path.exists(path):
                with open(path) as f:
                    mac = f.read().strip().upper()
                if mac and mac != "00:00:00:00:00:00":
                    return mac
        except Exception as e:
            write_log("error %s: %s" % (iface, e))
    return ""


def _token_path():
    return os.path.join(TOKEN_DIR, "%s.lic" % PLUGIN_ID)


def read_token():
    try:
        with open(_token_path()) as f:
            return f.read().strip()
    except Exception:
        return ""


def save_token(token):
    try:
        with open(_token_path(), "w") as f:
            f.write(token)
        os.chmod(_token_path(), 0o600)
    except Exception as e:
        write_log("save_token error: %s" % e)


def hash_password(password):
    return hashlib.sha256(password.encode("utf-8")).hexdigest()


# ============================================================
# Server calls (run them in a thread: they can take seconds)
# ============================================================
def call_server(data):
    """JSON POST to Apps Script. Returns a dict, or None on network errors."""
    data = dict(data, plugin=PLUGIN_ID, token=read_token())
    try:
        req = Request(SERVER_URL, data=json.dumps(data).encode(
            "utf-8"), headers={"Content-Type": "application/json"})
        ctx = ssl.create_default_context()      # old CA lists on many boxes
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        try:
            resp = urlopen(req, timeout=20, context=ctx)
        except TypeError:
            resp = urlopen(req, timeout=20)
        body = resp.read().decode("utf-8")
        return json.loads(body) if body else None
    except Exception as e:
        write_log("call_server error: %s" % e)
        return None


def license_status(box_id):
    return call_server({"op": "status", "box": box_id})


def protected_value(key, box_id=None):
    """Protected content from the "content" sheet, or None when not authorized."""
    result = call_server(
        {"op": "value", "box": box_id or read_box_id(), "name": key})
    if result and result.get("result") == "ok":
        return result.get("value")
    return None


def send_registration(fields, box_id):
    payload = {"op": "register", "box": box_id}
    for key, value in fields.items():
        if key == "password":
            payload["password_hash"] = hash_password(value)
        else:
            payload[key] = value
    return call_server(payload)


def state_from_reply(result):
    """Server reply -> one of: register, pending, active, blocked, wrong_token, offline, error."""
    if result is None:
        return "offline"
    outcome = result.get("result")
    if outcome == "unknown":
        return "register"
    if outcome == "wrong_token":
        return "wrong_token"
    if outcome == "ok" and result.get("state") in (
            "pending", "active", "blocked"):
        return result["state"]
    return "error"


# ============================================================
# The screen
# ============================================================
FIELDS = [
    # (field, label, required) - the server stores them in the columns with the same name
    ("username", "Username", True),
    ("password", "Password", True),
    ("receiver_model", "Receiver model", False),
    ("email", "Email", False),
]
_FIELD_STRINGS = (
    _("Username"),
    _("Password"),
    _("Receiver model"),
    _("Email"))

DEMO_DATA = {
    "username": u"mario.rossi",
    "password": u"demo1234",
    "receiver_model": u"Vu+ Uno 4K SE",
    "email": u"mario@example.com"}
DEMO_STATES = (
    "register",
    "pending",
    "active",
    "blocked",
    "wrong_token",
    "offline")


class LicenseScreen(Screen):
    skin = scale_skin("""
    <screen name="XCDLicense" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="%(bg)s">
        <widget name="logo" position="80,40" size="370,222" alphatest="blend" zPosition="2" />
        <widget name="title" position="490,80" size="1200,70" font="Regular;54" noWrap="1" foregroundColor="%(accent)s" backgroundColor="%(bg)s" transparent="1" />
        <widget name="subtitle" position="490,160" size="1300,90" font="Regular;30" foregroundColor="%(dim)s" backgroundColor="%(bg)s" transparent="1" />
        %(clock)s
        <eLabel position="60,288" size="1800,2" backgroundColor="%(panel)s" />
        <eLabel position="60,310" size="860,650" backgroundColor="%(panel)s" zPosition="-1" />
        <eLabel position="60,310" size="6,650" backgroundColor="%(accent)s" />
        <widget name="state" position="100,330" size="800,56" font="Regular;40" noWrap="1" foregroundColor="%(gold)s" backgroundColor="%(panel)s" transparent="1" />
        <widget name="keys" position="100,410" size="350,520" font="Regular;30" foregroundColor="%(dim)s" backgroundColor="%(panel)s" transparent="1" />
        <widget name="values" position="460,410" size="440,520" font="Regular;30" foregroundColor="%(text)s" backgroundColor="%(panel)s" transparent="1" />
        <widget name="message" position="980,320" size="640,560" font="Regular;30" foregroundColor="%(text)s" backgroundColor="%(bg)s" transparent="1" />
        <widget name="support" position="980,890" size="640,70" font="Regular;28" foregroundColor="%(gold)s" backgroundColor="%(bg)s" transparent="1" />
        <eLabel position="1662,366" size="180,180" backgroundColor="#00ffffff" />
        <widget name="qr_paypal" position="1670,374" size="164,164" alphatest="blend" zPosition="2" />
        <widget name="lbl_paypal" position="1636,550" size="224,30" font="Regular;24" halign="center" foregroundColor="%(text)s" backgroundColor="%(bg)s" transparent="1" />
        <eLabel position="1662,612" size="180,180" backgroundColor="#00ffffff" />
        <widget name="qr_kofi" position="1670,620" size="164,164" alphatest="blend" zPosition="2" />
        <widget name="lbl_kofi" position="1636,796" size="224,30" font="Regular;24" halign="center" foregroundColor="%(text)s" backgroundColor="%(bg)s" transparent="1" />
        %(footer)s
    </screen>""" % dict(bg=BG, panel=PANEL, text=TEXT, dim=DIM, accent=ACCENT, sel=SEL, gold=GOLD,
                        clock=clock(), footer=footer()))

    def __init__(
            self,
            session,
            box_id,
            on_success,
            on_cancel=None,
            state="register",
            info=None):
        Screen.__init__(self, session)
        self.box_id = box_id or u"00:00:00:00:00:00"
        self.on_success = on_success
        self.on_cancel = on_cancel
        self.state = state
        self.info = info or {}
        self.form = dict(DEMO_DATA) if DEMO else dict(
            (f[0], u"") for f in FIELDS)
        self.index = 0
        self.alive = True
        self.busy = False
        self["logo"] = Pixmap()
        self.logo = ImageLoader(self, "logo", transparent=True)
        self["title"] = Label(T(_("Box authorization")))
        self["subtitle"] = Label("")
        self["state"] = Label("")
        self["keys"] = Label("")
        self["values"] = Label("")
        self["message"] = Label("")
        self["support"] = Label(
            T(_("Do you like XC Diamond? Buy me a coffee")))
        self["qr_paypal"] = Pixmap()
        self["qr_kofi"] = Pixmap()
        self["lbl_paypal"] = Label("PayPal")
        self["lbl_kofi"] = Label("Ko-fi")
        self.qr = [
            ImageLoader(
                self, "qr_paypal"), ImageLoader(
                self, "qr_kofi")]
        for key in ("key_red", "key_green", "key_yellow", "key_blue"):
            self[key] = Label("")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions"], {
            "ok": self.ok, "cancel": self.cancel, "red": self.cancel,
            "green": self.green, "yellow": self.yellow,
            "up": lambda: self._move(-1), "down": lambda: self._move(1),
        }, -1)
        self.check_timer = new_timer(self.check_now)
        self.qr_timer = new_timer(self._load_qr)
        self.onLayoutFinish.append(self._start)
        self.onClose.append(self._closed)

    def _closed(self):
        self.alive = False
        self.check_timer.stop()
        self.qr_timer.stop()

    def _start(self):
        self.logo.load(os.path.join(PLUGIN_DIR, "icons", "logo.png"))
        # after the logo: the decoder handles one image at a time
        self.qr_timer.start(400, True)
        self._show()

    def _load_qr(self):
        if self.alive:
            self.qr[0].load(os.path.join(PLUGIN_DIR, "icons", "qr_paypal.png"))
            self.qr[1].load(os.path.join(PLUGIN_DIR, "icons", "qr_kofi.png"))

    # ---------- drawing ----------
    def _show(self):
        st = self.state
        sub = u"MAC  %s" % self.box_id
        if DEMO:
            sub += u"   •   " + _("DEMO: made-up data, no server")
        self["subtitle"].setText(T(sub))
        labels = {
            "register": (_("Registration"), GOLD),
            "pending": (u"●  " + _("Waiting for approval"), C_AMBER),
            "active": (u"●  " + _("Authorized"), C_GREEN),
            "blocked": (u"●  " + _("Access denied"), C_RED),
            "wrong_token": (u"●  " + _("Box not recognized"), C_RED),
            "offline": (u"●  " + _("License server unreachable"), C_AMBER),
            "error": (u"●  " + _("Unexpected reply"), C_RED),
        }
        text, color = labels.get(st, labels["error"])
        self["state"].setText(T(text))
        try:
            from enigma import gRGB
            self["state"].instance.setForegroundColor(gRGB(int(color[3:], 16)))
        except Exception:
            pass

        rows = []
        for i, (key, label, required) in enumerate(FIELDS):
            value = self.form.get(key, u"")
            shown = (
                u"•" *
                len(value)) if key == "password" and value else (
                value or _("(empty)"))
            mark = u"▶ " if st == "register" and i == self.index else u"   "
            rows.append(
                (mark + _(label) + (u"" if required else u" *"), shown))
        if st != "register":
            registered = self.info.get("registered") or (
                time.strftime("%d/%m/%Y") if DEMO else u"")
            if registered:
                rows.append((u"   " + _("Registered"), registered))
            # auto_at = self.info.get("auto_at")
            # if st == "pending" and auto_at:
                # rows.append((u"   " + _("Auto activation"), time.strftime("%d/%m %H:%M", time.localtime(auto_at))))
        self["keys"].setText(T(u"\n".join(r[0] for r in rows)))
        self["values"].setText(T(u"\n".join(r[1] for r in rows)))

        messages = {
            "register": _("To use XC Diamond this box must be registered once.\n\n"
                          "Up/Down: choose a field   OK: write it\n"
                          "GREEN: send the registration\n\n"
                          "* = optional. The password is sent encrypted."),
            "pending": _("Registration received.\n\nThe box will be activated by the developer"
                         "%s.\n\nThis screen checks again by itself every 30 seconds; GREEN checks now.\n\n%s"),
            "active": _("This box is authorized.\n\nOK: open XC Diamond"),
            "blocked": _("This box has been blocked.\n\nFor information:\n%s"),
            "wrong_token": _("This MAC is registered, but the key saved on this box is missing or different "
                             "(for example after reinstalling the image).\n\n"
                             "Ask the developer to reset the registration of the MAC:\n%s\n\n%s"),
            "offline": _("The license server cannot be reached.\nCheck the internet connection.\n\nGREEN: try again"),
            "error": _("The license server sent an unexpected reply.\n\nGREEN: try again"),
        }
        msg = messages.get(st, messages["error"])
        if st == "pending":
            msg = msg % (u"", CONTACT)
            # auto = self.info.get("auto_hours")
            # msg = msg % ((_(" or automatically within %d hours") % auto) if auto else u"", CONTACT)
        elif st == "blocked":
            msg = msg % CONTACT
        elif st == "wrong_token":
            msg = msg % (self.box_id, CONTACT)
        if DEMO:
            msg += u"\n\n" + \
                _("DEMO   OK: enter the plugin   YELLOW: next state")
        self["message"].setText(T(msg))

        green = {"register": _("Register"), "pending": _("Check now"), "active": _(
            "Open"), "offline": _("Try again"), "error": _("Try again")}.get(st, u"")
        self["key_red"].setText(T(_("Exit")))
        self["key_green"].setText(T(green))
        self["key_yellow"].setText(T(_("Next state") if DEMO else u""))
        if st == "pending" and not DEMO:
            self.check_timer.start(CHECK_INTERVAL_MS, True)

    # ---------- keys ----------
    def _move(self, step):
        if self.state == "register":
            self.index = (self.index + step) % len(FIELDS)
            self._show()

    def ok(self):
        if DEMO or self.state == "active":
            return self._enter()
        if self.state == "register":
            key, label = FIELDS[self.index][:2]

            def done(answer):
                if answer is not None and self.alive:
                    self.form[key] = answer.strip()
                    self._show()
            self.session.openWithCallback(
                done, VirtualKeyBoard, title=T(
                    _(label)), text=self.form.get(
                    key, u""))

    def green(self):
        if self.state == "register":
            return self.register()
        if self.state == "active":
            return self._enter()
        if self.state in ("pending", "offline", "error"):
            self.check_now()

    def yellow(self):
        if DEMO:
            self.state = DEMO_STATES[(DEMO_STATES.index(self.state) + 1) % len(DEMO_STATES)] \
                if self.state in DEMO_STATES else "register"
            if self.state == "pending":
                self.info = {
                    "auto_hours": 24,
                    "auto_at": time.time() + 24 * 3600}
            self._show()

    def cancel(self):
        if self.on_cancel:
            self.on_cancel()
        self.close()

    def _enter(self):
        on_success = self.on_success
        self.close()
        if on_success:
            on_success()

    # ---------- server ----------
    def register(self):
        for key, label, required in FIELDS:
            if required and not self.form.get(key):
                return self._error(_("Required field: %s") % _(label))
        if len(self.form.get("username", "")) < 3:
            return self._error(_("Username: at least 3 characters"))
        if len(self.form.get("password", "")) < 6:
            return self._error(_("Password: at least 6 characters"))
        if DEMO:
            self.state, self.info = "pending", {
                "auto_hours": 24, "auto_at": time.time() + 24 * 3600}
            return self._show()
        self._ask(
            lambda: send_registration(
                self.form,
                self.box_id),
            self._registered)

    def _registered(self, result):
        if result and result.get("result") == "ok":
            if result.get("token"):
                save_token(result["token"])
            self.state = "pending"
            self.info = result
        else:
            self.state = "offline" if result is None else "error"
            if result and result.get("message"):
                self._error(result["message"])
        self._show()

    def check_now(self):
        if DEMO or self.busy:
            return
        self._ask(lambda: license_status(self.box_id), self._checked)

    def _checked(self, result):
        self.state = state_from_reply(result)
        self.info = result or {}
        if self.state == "active":
            _remember_active()
            return self._enter()
        self._show()

    def _ask(self, func, then):
        from .net import run_async
        self.busy = True
        self["key_green"].setText(T(_("Please wait...")))

        def done(result):
            self.busy = False
            if self.alive:
                then(result)
        run_async(func, callback=done, errback=lambda e: done(None))

    def _error(self, text):
        self.session.open(
            MessageBox,
            T(text),
            MessageBox.TYPE_ERROR,
            timeout=5)


# an authorized box works this long when the server is unreachable
GRACE_SECS = 7 * 86400


def _ok_path():
    return _token_path() + ".ok"


def _remember_active():
    try:
        with open(_ok_path(), "w") as f:
            f.write("%d" % int(time.time()))
    except Exception:
        pass


def _recently_active():
    try:
        with open(_ok_path()) as f:
            return time.time() - int(f.read().strip() or 0) < GRACE_SECS
    except Exception:
        return False


# ============================================================
# Entry point: called by plugin.main()
# ============================================================
def request_license(session, on_success, on_cancel=None):
    box_id = read_box_id()
    if DEMO:
        return session.open(
            LicenseScreen,
            box_id or u"00:1E:A0:12:34:56",
            on_success,
            on_cancel,
            "register")
    if not box_id:
        session.open(MessageBox,
                     T(_("Cannot read the MAC address")),
                     MessageBox.TYPE_ERROR,
                     timeout=8)
        return on_cancel and on_cancel()

    from .net import run_async

    def checked(result):
        state = state_from_reply(result)
        if state == "active":
            _remember_active()
            return on_success()
        if state == "offline" and _recently_active():
            # server down: an authorized box keeps working for a while
            return on_success()
        session.open(
            LicenseScreen,
            box_id,
            on_success,
            on_cancel,
            state,
            result or {})
    run_async(license_status, (box_id,), callback=checked,
              errback=lambda e: checked(None))
