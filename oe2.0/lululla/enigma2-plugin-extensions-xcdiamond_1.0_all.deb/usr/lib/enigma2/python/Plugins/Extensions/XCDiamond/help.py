# -*- coding: utf-8 -*-
"""Help screen: topics on the left, text on the right. Opened from the Home menu and with the
HELP key in every screen (it opens on the topic of that screen)."""

from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.ScrollLabel import ScrollLabel

from . import _, core
from .ui import (
    T,
    XCDList,
    scale_skin,
    footer,
    clock,
    BG,
    PANEL,
    TEXT,
    DIM,
    ACCENT,
    SEL,
    GOLD)


def N_(text):
    return text


# (key, title, text). Texts are translated when shown.
TOPICS = [
    ("start", N_("Getting started"), N_(
        "1. Add your server: Home > Servers > MENU > Add a server, or write it in the file "
        "/etc/enigma2/xc/playlist.txt (one per line).\n\n"
        "Accepted lines:\n"
        "  http://server.com:8080/get.php?username=USER&password=PASS&type=m3u_plus\n"
        "  http://server.com:8080 USER PASS\n"
        "  Name | http://server.com:8080 USER PASS\n\n"
        "The other .txt files of the folder are read too, e.g. xclink.txt of the old XC. "
        "The folder can be changed in Settings.\n\n"
        "2. In Servers choose the server with OK.\n\n"
        "3. Movie and series details come from TMDB: a key is already included. "
        "You can use your own free key in Settings or in /etc/enigma2/xc/tmdb.txt.")),
    ("home", N_("Home"), N_(
        "Up/Down: choose   OK or GREEN: open\n"
        "YELLOW: refresh account and EPG guide\n"
        "BLUE: settings   RED: exit\n\n"
        "On the right: account state, expiry, connections in use, server time and EPG guide.")),
    ("lists", N_("Lists: live, movies, series"), N_(
        "Left: categories. Right: titles. Stopping half a second on a category opens it.\n\n"
        "OK: details (channels: play)   GREEN: play\n"
        "YELLOW: search in this category   TEXT: search everywhere\n"
        "BLUE: add to / remove from favorites\n"
        "MENU: sort the list, protect a category with the PIN, catchup of a channel, "
        "add a movie to the downloads, remove from Continue watching\n"
        "CH+ / CH-: page up / down\n"
        "7 / 8 / 9: EPG time one hour back / automatic / one hour forward (channels)\n\n"
        "♥ Favorites and ▶ Continue watching are at the top of the categories. "
        "▶ 43% on a title means you stopped there.")),
    ("details", N_("Movie and series pages"), N_(
        "GREEN or OK: play   YELLOW: favorite   BLUE: trailer (needs yt-dlp)\n"
        "MENU: add the movie, the episode or the whole season to the downloads\n\n"
        "Series: Left/Right switches between seasons and episodes. "
        "▶ 12 min on an episode = you stopped there.")),
    ("player", N_("Player"), N_(
        "INFO: details panel (channels: guide)   EXIT: close\n"
        "Channels: CH+/CH- or Up/Down change channel. If the stream stops, the player reconnects by itself.\n"
        "Movies and episodes: 1/3 = 1 minute back/forward, 4/6 = 5 minutes, 7/9 = 10 minutes. "
        "When you close, the position is saved: next time you can resume from there.")),
    ("catchup", N_("Catchup"), N_(
        "Home > Catchup shows only the categories and channels the server keeps in the archive "
        "(the number of days is on the right).\n\n"
        "OK on a channel: days and programmes. Bright programmes are in the archive and play with OK; "
        "dim ones are not recorded.\n\n"
        "From the channel list: MENU on a channel with archive.")),
    ("downloads", N_("Downloads"), N_(
        "In a movie or series page press MENU > Add to downloads: the title goes into the panel "
        "(Home > Downloads) and you decide there.\n\n"
        "GREEN: download now / stop / play when completed\n"
        "YELLOW: schedule (at night or in a few hours)\n"
        "BLUE: remove from the list (also the file, if you want)\n"
        "MENU: download all, stop all, clear completed, folder\n\n"
        "One download at a time, also with the plugin closed. A stopped download restarts where it stopped.")),
    ("bouquets", N_("Bouquets and EPG guide"), N_(
        "Home > Bouquets: OK ticks the categories, GREEN creates the bouquet of the active "
        "account (named after it, one sub-bouquet per category) in the TV list. BLUE removes it. "
        "Each account keeps its own bouquet, so several servers do not overwrite each other.\n\n"
        "MENU: position in the TV list (top, bottom, leave where it is) and automatic update "
        "(every day at a time or every few hours).\n\n"
        "Guide: in EPGImporter enable the source “XC Diamond” and start the import.")),
    ("servers", N_("Servers"), N_(
        "All the servers of the playlist folder, checked in the background: "
        "Active, Banned, Disabled, Expired, Wrong credentials, Unreachable.\n\n"
        "OK/GREEN: use this server   YELLOW: check all again   BLUE: reload the files\n"
        "MENU: add, edit, rename, remove a server, playlist folder.\n\n"
        "On the right: address, code and QR to manage the accounts from a phone or computer "
        "(see “Web interface”).\n\n"
        "Lines of xclink.txt (old XC) stay in the XC format, so XC can still read them.")),
    ("webif", N_("Web interface (phone/PC)"), N_(
        "Manage your accounts from a browser on the same network, without the remote.\n\n"
        "Open Home > Servers: the panel on the right shows the address and an 8-character code, "
        "with a QR.\n\n"
        "On the phone: scan the QR with the camera.\n"
        "By hand: in the browser type  IP:8765/?t=CODE  "
        "(for example 192.168.1.50:8765/?t=a1b2c3d4).\n\n"
        "From there you can add, edit, delete and activate accounts. The code is required: without "
        "it nobody on the network can read or change anything, and passwords are never shown.")),
    ("parental", N_("Parental control"), N_(
        "Settings > Parental control and a 4-digit PIN.\n\n"
        "Adult categories are locked by themselves; others with MENU on the category. "
        "The PIN is asked once, until you close the plugin. With parental control on, "
        "the settings ask for the PIN too.")),
    ("connections", N_("Connections and bans"), N_(
        "Servers block accounts that make too many requests or use more connections than allowed.\n\n"
        "XC Diamond asks one thing at a time per server, keeps the answers for a while, and stops "
        "for two minutes when the server says “too many requests”.\n\n"
        "With a one-connection account: watching pauses the running download (it restarts when you "
        "close the player), and scheduled downloads wait while the TV shows a channel of the same server.")),
    ("files", N_("Files"), N_(
        "/etc/enigma2/xc/\n"
        "  playlist.txt  servers (and the other .txt of the folder)\n"
        "  tmdb.txt  your TMDB key (optional)\n"
        "  favorites.json  resume.json  downloads.json\n"
        "  searches.json  protected.json  server_cache.json\n"
        "  webif.token  web interface code\n\n"
        "/etc/epgimport/xcd_*.xml  EPGImporter guide (one per account)\n"
        "/etc/enigma2/userbouquet.xcd_*.tv  bouquets (one per account)\n"
        "/media/hdd/movie  downloads (can be changed)")),
]


class HelpScreen(Screen):
    skin = scale_skin("""
    <screen name="XCDHelp" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="%(bg)s">
        <widget name="header" position="60,30" size="1200,60" font="Regular;44" foregroundColor="%(text)s" backgroundColor="%(bg)s" transparent="1" />
        %(clock)s
        <eLabel position="60,110" size="1800,2" backgroundColor="%(panel)s" />
        <widget name="topics" position="60,130" size="560,840" itemHeight="60" backgroundColor="%(bg)s" backgroundColorSelected="%(sel)s" scrollbarMode="showOnDemand" transparent="1" />
        <eLabel position="650,130" size="1210,840" backgroundColor="%(panel)s" zPosition="-1" />
        <eLabel position="650,130" size="6,840" backgroundColor="%(accent)s" />
        <widget name="title" position="690,150" size="1140,50" font="Regular;36" noWrap="1" foregroundColor="%(gold)s" backgroundColor="%(panel)s" transparent="1" />
        <widget name="text" position="690,215" size="1140,740" font="Regular;28" foregroundColor="%(text)s" backgroundColor="%(panel)s" transparent="1" />
        %(footer)s
    </screen>""" % dict(bg=BG, panel=PANEL, text=TEXT, dim=DIM, accent=ACCENT, sel=SEL, gold=GOLD,
                        clock=clock(), footer=footer()))

    def __init__(self, session, topic="start"):
        Screen.__init__(self, session)
        core.load_keymap()
        self["header"] = Label(
            T(_("Help") + u"  •  " + core.PLUGIN_NAME + u" " + core.VERSION))
        self["topics"] = XCDList(font_size=30, item_height=60)
        self["title"] = Label("")
        self["text"] = ScrollLabel("")
        self["key_red"] = Label(T(_("Back")))
        self["key_green"] = Label("")
        self["key_yellow"] = Label(T(_("Page up")))
        self["key_blue"] = Label(T(_("Page down")))
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions", "XCDActions"], {
            "ok": self.close, "cancel": self.close, "red": self.close,
            "up": lambda: self._move("up"), "down": lambda: self._move("down"),
            "yellow": self["text"].pageUp, "blue": self["text"].pageDown,
            "left": self["text"].pageUp, "right": self["text"].pageDown,
            "pageUp": self["text"].pageUp, "pageDown": self["text"].pageDown,
        }, -1)
        self.start_topic = topic
        self.onLayoutFinish.append(self._start)

    def _start(self):
        keys = [key for key, _title, _text in TOPICS]
        index = keys.index(self.start_topic) if self.start_topic in keys else 0
        self["topics"].set_entries([self["topics"].entry(
            key, _(title)) for key, title, _text in TOPICS], index)
        self._show()

    def _move(self, direction):
        self["topics"].move(direction)
        self._show()

    def _show(self):
        key = self["topics"].current()
        for k, title, text in TOPICS:
            if k == key:
                self["title"].setText(T(_(title)))
                self["text"].setText(T(_(text)))
                break


def open_help(session, topic="start"):
    session.open(HelpScreen, topic)
