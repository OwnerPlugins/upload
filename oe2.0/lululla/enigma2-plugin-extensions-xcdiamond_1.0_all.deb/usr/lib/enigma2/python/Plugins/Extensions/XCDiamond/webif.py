# -*- coding: utf-8 -*-
"""Small web interface to manage the Xtream accounts from a phone or computer.

Runs a tiny HTTP server (Twisted, already present in Enigma2) on port 8765, always on while
the box is up. It reuses core's server CRUD, so there is no duplicated logic. Every API call
needs the token shown on the TV (carried inside the QR as ?t=...), so nobody on the LAN can
read or change the accounts without it. Passwords are never sent to the browser.
"""

import hashlib
import hmac
import json
import os
import socket

from . import core

PORT = 8765
TOKEN_FILE = os.path.join(core.DATA_DIR, "webif.token")

try:
    from twisted.web import server as _tw_server, resource as _tw_resource
    from twisted.internet import reactor
    _HAVE_TWISTED = True
except Exception:
    _HAVE_TWISTED = False

_listener = None
_token = None


# ------------------------------------------------------------------ helpers

def _to_text(value):
    if isinstance(value, bytes):
        return value.decode("utf-8", "replace")
    return value if value is not None else u""


def token():
    """Stable per-box token, kept across restarts so the QR stays valid."""
    global _token
    if _token:
        return _token
    try:
        with open(TOKEN_FILE) as f:
            saved = f.read().strip()
        if saved:
            _token = saved
            return _token
    except (IOError, OSError):
        pass
    _token = hashlib.sha256(os.urandom(16)).hexdigest()[:8]
    try:
        core._ensure_data_dir()
        with open(TOKEN_FILE, "w") as f:
            f.write(_token)
    except (IOError, OSError):
        pass
    return _token


def lan_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
    except Exception:
        ip = "127.0.0.1"
    finally:
        s.close()
    return ip


def info():
    """For the TV panel / QR: address and token."""
    ip = lan_ip()
    return {
        "ip": ip,
        "port": PORT,
        "token": token(),
        "url": "http://%s:%d/?t=%s" % (ip, PORT, token()),
    }


def _sid(srv):
    raw = u"%s|%s|%s" % (srv["server"].rstrip(
        "/").lower(), srv["username"], srv["password"])
    return hashlib.md5(raw.encode("utf-8")).hexdigest()[:12]


def _find(sid):
    for srv in core.read_servers():
        if _sid(srv) == sid:
            return srv
    return None


def _is_active(srv):
    try:
        return (srv["server"].rstrip("/") == core.cfg.server.value.rstrip("/")
                and srv["username"] == core.cfg.username.value)
    except Exception:
        return False


def _server_list():
    out = []
    for srv in core.read_servers():
        out.append({
            "id": _sid(srv),
            "name": srv.get("name") or srv["username"],
            "server": srv["server"],
            "username": srv["username"],
            "has_pw": bool(srv.get("password")),
            "active": _is_active(srv),
        })
    return out


# ------------------------------------------------------------------ API actions

def _api(path, data):
    """Return (dict, http_status). data: parsed JSON body for POST actions."""
    if path == "/api/servers":
        return {"ok": True, "servers": _server_list(
        ), "active_count": len(_server_list())}, 200

    if path == "/api/add":
        name = _to_text(data.get("name")).strip()
        server = _to_text(data.get("server")).strip()
        user = _to_text(data.get("username")).strip()
        pw = _to_text(data.get("password"))
        if not server or not user:
            return {"ok": False, "error": "server and username are required"}, 400
        core.add_server(name, server, user, pw)
        return {"ok": True}, 200

    if path == "/api/edit":
        srv = _find(_to_text(data.get("id")))
        if not srv:
            return {"ok": False, "error": "not found"}, 404
        name = _to_text(data.get("name")).strip()
        server = _to_text(data.get("server")).strip() or srv["server"]
        user = _to_text(data.get("username")).strip() or srv["username"]
        pw = _to_text(data.get("password"))
        if not pw:                       # empty password field -> keep the current one
            pw = srv["password"]
        core.edit_server(srv, name, server, user, pw)
        return {"ok": True}, 200

    if path == "/api/remove":
        srv = _find(_to_text(data.get("id")))
        if not srv:
            return {"ok": False, "error": "not found"}, 404
        core.remove_server(srv)
        return {"ok": True}, 200

    if path == "/api/activate":
        srv = _find(_to_text(data.get("id")))
        if not srv:
            return {"ok": False, "error": "not found"}, 404
        core.apply_server(srv)
        return {"ok": True}, 200

    return {"ok": False, "error": "unknown endpoint"}, 404


# ------------------------------------------------------------------ HTTP resource

if _HAVE_TWISTED:

    class _Root(_tw_resource.Resource):
        isLeaf = True

        def render_GET(self, request):
            return self._dispatch(request)

        def render_POST(self, request):
            return self._dispatch(request)

        def _dispatch(self, request):
            path = _to_text(request.path)
            if path in ("/", "/index.html"):
                request.setHeader(b"Content-Type", b"text/html; charset=utf-8")
                return _PAGE.encode("utf-8")

            # everything under /api needs the token
            if path.startswith("/api/"):
                got = request.args.get(b"t") or request.args.get("t") or [b""]
                got = _to_text(got[0])
                if not hmac.compare_digest(str(got), str(token())):
                    request.setResponseCode(403)
                    request.setHeader(b"Content-Type", b"application/json")
                    return json.dumps(
                        {"ok": False, "error": "bad token"}).encode("utf-8")

                data = {}
                try:
                    body = request.content.read()
                    if body:
                        data = json.loads(_to_text(body))
                except Exception:
                    data = {}

                try:
                    result, status = _api(path, data)
                except Exception as e:
                    result, status = {"ok": False, "error": str(e)}, 500
                request.setResponseCode(status)
                request.setHeader(b"Content-Type", b"application/json")
                return json.dumps(result).encode("utf-8")

            request.setResponseCode(404)
            return b"not found"


def start():
    """Start the web interface (idempotent). Always on while the box runs."""
    global _listener
    if _listener is not None:
        return True
    if not _HAVE_TWISTED:
        print("[XCDiamond] webif: twisted.web not available, web interface disabled")
        return False
    try:
        _listener = reactor.listenTCP(PORT, _tw_server.Site(_Root()))
        i = info()
        print("[XCDiamond] webif on %s" % i["url"])
        return True
    except Exception as e:
        print("[XCDiamond] webif start failed: %s" % e)
        return False


def stop():
    global _listener
    if _listener is not None:
        try:
            _listener.stopListening()
        except Exception:
            pass
        _listener = None


# ------------------------------------------------------------------ the page

_PAGE = u"""<!DOCTYPE html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>XC Diamond - Accounts</title>
<style>
 :root{--bg:#0d0f12;--panel:#171a1f;--line:#262b32;--text:#e9e5dc;--dim:#8b8f98;--gold:#d8a24a;--accent:#4a90d8;--danger:#c0504a;--ok:#4aa06a}
 *{box-sizing:border-box}
 body{margin:0;background:var(--bg);color:var(--text);font:16px/1.4 -apple-system,Segoe UI,Roboto,sans-serif;padding:16px;max-width:680px;margin:0 auto}
 h1{font-size:22px;letter-spacing:.08em;text-transform:uppercase;margin:4px 0 2px}
 .sub{color:var(--dim);font-size:13px;margin-bottom:18px}
 .card{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:14px 16px;margin-bottom:12px}
 .card.active{border-color:var(--gold)}
 .row{display:flex;align-items:center;gap:10px}
 .name{font-weight:600;font-size:17px}
 .tag{font-size:11px;color:var(--gold);border:1px solid var(--gold);border-radius:6px;padding:1px 6px;letter-spacing:.08em}
 .meta{color:var(--dim);font-size:13px;margin-top:4px;word-break:break-all}
 .acts{display:flex;gap:8px;margin-top:12px;flex-wrap:wrap}
 button{font:inherit;border:1px solid var(--line);background:#20242b;color:var(--text);border-radius:8px;padding:8px 14px;cursor:pointer}
 button:active{transform:translateY(1px)}
 .p{background:var(--gold);border-color:var(--gold);color:#000;font-weight:600}
 .d{color:var(--danger);border-color:#3a2a2a}
 .add{width:100%;margin:6px 0 18px;background:#20242b;border-style:dashed}
 dialog{background:var(--panel);color:var(--text);border:1px solid var(--line);border-radius:14px;width:92%;max-width:440px;padding:18px}
 dialog::backdrop{background:rgba(0,0,0,.6)}
 label{display:block;font-size:12px;color:var(--dim);margin:12px 0 4px;letter-spacing:.06em;text-transform:uppercase}
 input{width:100%;background:#0f1216;border:1px solid var(--line);color:var(--text);border-radius:8px;padding:10px;font:inherit}
 .dact{display:flex;gap:8px;justify-content:flex-end;margin-top:18px}
 .err{color:var(--danger);font-size:13px;min-height:18px;margin-top:6px}
 .empty{color:var(--dim);text-align:center;padding:30px}
</style></head>
<body>
 <h1>XC Diamond</h1>
 <div class="sub">Manage your Xtream accounts</div>
 <div id="list"><div class="empty">Loading...</div></div>
 <button class="add" onclick="openForm()">+ Add account</button>

 <dialog id="dlg"><form method="dialog" onsubmit="return false">
  <div id="dtitle" style="font-size:18px;font-weight:600">Account</div>
  <input type="hidden" id="f_id">
  <label>Name (optional)</label><input id="f_name" placeholder="Home, Backup...">
  <label>Server address</label><input id="f_server" placeholder="http://server.com:8080" autocapitalize="off" autocomplete="off">
  <label>Username</label><input id="f_user" autocapitalize="off" autocomplete="off">
  <label>Password</label><input id="f_pw" type="password" placeholder="(unchanged)" autocapitalize="off" autocomplete="off">
  <div class="err" id="err"></div>
  <div class="dact"><button type="button" onclick="dlg.close()">Cancel</button>
   <button type="button" class="p" onclick="save()">Save</button></div>
 </form></dialog>

<script>
var T=new URLSearchParams(location.search).get('t')||'';
var dlg=document.getElementById('dlg');
function api(path,body){return fetch(path+'?t='+encodeURIComponent(T),
  {method:body?'POST':'GET',headers:{'Content-Type':'application/json'},body:body?JSON.stringify(body):undefined})
  .then(function(r){return r.json().then(function(j){return{status:r.status,j:j}})});}
function esc(s){return (s||'').replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
function load(){api('/api/servers').then(function(x){
  if(x.status===403){document.getElementById('list').innerHTML='<div class="empty">Invalid or missing token.<br>Open the link from the QR on your TV.</div>';return;}
  var L=x.j.servers||[],h='';
  if(!L.length)h='<div class="empty">No accounts yet.</div>';
  L.forEach(function(s){
   h+='<div class="card'+(s.active?' active':'')+'">'
    +'<div class="row"><span class="name">'+esc(s.name)+'</span>'+(s.active?'<span class="tag">ACTIVE</span>':'')+'</div>'
    +'<div class="meta">'+esc(s.server)+'  &middot;  '+esc(s.username)+'</div>'
    +'<div class="acts">'
    +(s.active?'':'<button class="p" onclick="act(\\''+s.id+'\\')">Activate</button>')
    +'<button onclick=\\'edit('+JSON.stringify(s).replace(/\\x27/g,"&#39;")+')\\'>Edit</button>'
    +'<button class="d" onclick="del(\\''+s.id+'\\',\\''+esc(s.name)+'\\')">Delete</button>'
    +'</div></div>';
  });
  document.getElementById('list').innerHTML=h;
});}
function openForm(){document.getElementById('dtitle').textContent='Add account';
 ['f_id','f_name','f_server','f_user','f_pw'].forEach(function(i){document.getElementById(i).value=''});
 document.getElementById('err').textContent='';dlg.showModal();document.getElementById('f_pw').placeholder='';}
function edit(s){document.getElementById('dtitle').textContent='Edit account';
 document.getElementById('f_id').value=s.id;document.getElementById('f_name').value=s.name||'';
 document.getElementById('f_server').value=s.server||'';document.getElementById('f_user').value=s.username||'';
 document.getElementById('f_pw').value='';document.getElementById('f_pw').placeholder='(unchanged)';
 document.getElementById('err').textContent='';dlg.showModal();}
function save(){var id=document.getElementById('f_id').value;
 var b={id:id,name:document.getElementById('f_name').value,server:document.getElementById('f_server').value,
  username:document.getElementById('f_user').value,password:document.getElementById('f_pw').value};
 api(id?'/api/edit':'/api/add',b).then(function(x){
  if(x.j.ok){dlg.close();load();}else{document.getElementById('err').textContent=x.j.error||'Error';}});}
function act(id){api('/api/activate',{id:id}).then(load);}
function del(id,name){if(confirm('Delete "'+name+'"?'))api('/api/remove',{id:id}).then(load);}
load();
</script>
</body></html>"""
